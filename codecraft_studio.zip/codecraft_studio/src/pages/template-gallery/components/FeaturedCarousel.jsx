import React, { useState, useEffect } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const FeaturedCarousel = ({ featuredTemplates, onPreview, onUseTemplate }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    if (!isAutoPlaying || featuredTemplates?.length <= 1) return;

    const interval = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % featuredTemplates?.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, featuredTemplates?.length]);

  const goToSlide = (index) => {
    setCurrentSlide(index);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const goToPrevious = () => {
    setCurrentSlide(prev => prev === 0 ? featuredTemplates?.length - 1 : prev - 1);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const goToNext = () => {
    setCurrentSlide(prev => (prev + 1) % featuredTemplates?.length);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  if (!featuredTemplates?.length) return null;

  const currentTemplate = featuredTemplates?.[currentSlide];

  return (
    <div className="relative mb-8 bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl overflow-hidden">
      <div className="relative h-80 md:h-96">
        {/* Background Image */}
        <div className="absolute inset-0">
          <Image
            src={currentTemplate?.heroImage}
            alt={`${currentTemplate?.name} hero image`}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30" />
        </div>

        {/* Content */}
        <div className="relative h-full flex items-center">
          <div className="container mx-auto px-6">
            <div className="max-w-2xl text-white">
              <div className="flex items-center space-x-2 mb-4">
                <span className="inline-flex items-center px-3 py-1 rounded-full bg-accent text-accent-foreground text-sm font-medium">
                  <Icon name="Star" size={14} className="mr-1" />
                  Featured Template
                </span>
                <span className="inline-flex items-center px-3 py-1 rounded-full bg-white/20 text-white text-sm font-medium">
                  {currentTemplate?.category}
                </span>
              </div>

              <h2 className="text-3xl md:text-4xl font-bold mb-4">{currentTemplate?.name}</h2>
              <p className="text-lg text-white/90 mb-6 line-clamp-2">{currentTemplate?.description}</p>

              <div className="flex items-center space-x-4 mb-6 text-sm text-white/80">
                <div className="flex items-center space-x-1">
                  <Icon name="Clock" size={16} />
                  <span>{currentTemplate?.setupTime}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Package" size={16} />
                  <span>{currentTemplate?.components} components</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Download" size={16} />
                  <span>{currentTemplate?.downloads} downloads</span>
                </div>
              </div>

              <div className="flex space-x-4">
                <Button
                  variant="outline"
                  onClick={() => onPreview(currentTemplate)}
                  iconName="Eye"
                  iconPosition="left"
                  iconSize={16}
                  className="bg-white/10 border-white/30 text-white hover:bg-white/20"
                >
                  Preview Template
                </Button>
                <Button
                  variant="default"
                  onClick={() => onUseTemplate(currentTemplate)}
                  iconName="Download"
                  iconPosition="left"
                  iconSize={16}
                  className="bg-accent hover:bg-accent/90"
                >
                  Use This Template
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Arrows */}
        {featuredTemplates?.length > 1 && (
          <>
            <button
              onClick={goToPrevious}
              className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-all duration-200 hover-lift"
            >
              <Icon name="ChevronLeft" size={20} />
            </button>
            <button
              onClick={goToNext}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-all duration-200 hover-lift"
            >
              <Icon name="ChevronRight" size={20} />
            </button>
          </>
        )}

        {/* Slide Indicators */}
        {featuredTemplates?.length > 1 && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
            {featuredTemplates?.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full transition-all duration-200 ${
                  index === currentSlide
                    ? 'bg-white scale-110' :'bg-white/50 hover:bg-white/70'
                }`}
              />
            ))}
          </div>
        )}

        {/* Auto-play Indicator */}
        <div className="absolute top-4 right-4">
          <button
            onClick={() => setIsAutoPlaying(!isAutoPlaying)}
            className="w-8 h-8 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-all duration-200"
            title={isAutoPlaying ? 'Pause slideshow' : 'Resume slideshow'}
          >
            <Icon name={isAutoPlaying ? 'Pause' : 'Play'} size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default FeaturedCarousel;