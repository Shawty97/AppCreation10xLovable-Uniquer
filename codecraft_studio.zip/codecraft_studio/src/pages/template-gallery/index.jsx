import React, { useState, useEffect } from 'react';
import { Search, Star } from 'lucide-react';
import { templateService } from '../../services/templateService';
import TemplateCard from './components/TemplateCard';
import SearchBar from './components/SearchBar';

import FeaturedCarousel from './components/FeaturedCarousel';
import TemplateModal from './components/TemplateModal';
import SortOptions from './components/SortOptions';
import IndustryCollections from './components/IndustryCollections';

export default function TemplateGallery() {
  const [templates, setTemplates] = useState([]);
  const [featuredTemplates, setFeaturedTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedFramework, setSelectedFramework] = useState('all');
  const [sortBy, setSortBy] = useState('rating');
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [categories, setCategories] = useState([]);
  const [frameworks, setFrameworks] = useState([]);

  useEffect(() => {
    loadTemplates();
  }, []);

  useEffect(() => {
    if (searchQuery || selectedCategory !== 'all' || selectedFramework !== 'all') {
      searchTemplates();
    } else {
      loadTemplates();
    }
  }, [searchQuery, selectedCategory, selectedFramework, sortBy]);

  const loadTemplates = async () => {
    setLoading(true);
    setError('');

    try {
      // Load all templates
      const { data: allTemplates, error: allError } = await templateService?.getAll(100);
      
      // Load featured templates
      const { data: featured, error: featuredError } = await templateService?.getFeatured(10);

      if (allError || featuredError) {
        setError('Failed to load templates');
      } else {
        setTemplates(allTemplates || []);
        setFeaturedTemplates(featured || []);
        
        // Extract categories and frameworks
        const categorySet = new Set();
        const frameworkSet = new Set();
        
        allTemplates?.forEach(template => {
          if (template?.category) categorySet?.add(template?.category);
          if (template?.framework) frameworkSet?.add(template?.framework);
        });

        setCategories(['all', ...Array.from(categorySet)]);
        setFrameworks(['all', ...Array.from(frameworkSet)]);
      }
    } catch (err) {
      setError('Failed to load templates');
    } finally {
      setLoading(false);
    }
  };

  const searchTemplates = async () => {
    setLoading(true);
    setError('');

    try {
      const searchFilters = {
        category: selectedCategory === 'all' ? null : selectedCategory,
        framework: selectedFramework === 'all' ? null : selectedFramework
      };

      const { data, error } = await templateService?.search(searchQuery, searchFilters);

      if (error) {
        setError('Failed to search templates');
      } else {
        // Sort results
        const sortedData = sortTemplates(data || [], sortBy);
        setTemplates(sortedData);
      }
    } catch (err) {
      setError('Failed to search templates');
    } finally {
      setLoading(false);
    }
  };

  const sortTemplates = (templatesList, sortType) => {
    return [...templatesList]?.sort((a, b) => {
      switch (sortType) {
        case 'newest':
          return new Date(b.created_at) - new Date(a.created_at);
        case 'rating':
          return (b?.rating || 0) - (a?.rating || 0);
        case 'downloads':
          return (b?.download_count || 0) - (a?.download_count || 0);
        case 'name':
          return a?.name?.localeCompare(b?.name);
        default:
          return (b?.rating || 0) - (a?.rating || 0);
      }
    });
  };

  const handleTemplateSelect = async (template) => {
    setSelectedTemplate(template);
    setIsModalOpen(true);
    
    // Track view/download
    if (template?.id) {
      try {
        await templateService?.incrementDownload(template?.id);
      } catch (err) {
        // Silent fail for analytics
      }
    }
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
  };

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
  };

  const handleFrameworkChange = (framework) => {
    setSelectedFramework(framework);
  };

  const handleSortChange = (sort) => {
    setSortBy(sort);
    if (templates?.length > 0) {
      const sorted = sortTemplates(templates, sort);
      setTemplates(sorted);
    }
  };

  // Transform templates for display
  const displayTemplates = templates?.map(template => ({
    id: template?.id,
    name: template?.name,
    description: template?.description,
    category: template?.category,
    framework: template?.framework,
    rating: template?.rating || 0,
    downloads: template?.download_count || 0,
    creator: template?.user_profiles?.full_name || 'Anonymous',
    creatorAvatar: template?.user_profiles?.avatar_url,
    thumbnail: template?.thumbnail_url || `https://images.unsplash.com/photo-${template?.framework === 'react' ? '1633356122544-f134324a6cee' : '1627398242454-45a1280ece14'}?w=400&h=300&fit=crop`,
    preview_url: template?.preview_url,
    is_premium: template?.is_premium,
    is_featured: template?.is_featured,
    tags: template?.tags || [],
    created_at: template?.created_at,
    updated_at: template?.updated_at
  })) || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Template Gallery</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Jumpstart your next project with our professionally designed templates
          </p>
        </div>

        {/* Featured Templates */}
        {featuredTemplates?.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <Star className="w-5 h-5 text-yellow-500" />
              <h2 className="text-2xl font-semibold text-gray-900">Featured Templates</h2>
            </div>
            <FeaturedCarousel 
              templates={featuredTemplates?.map(template => ({
                id: template?.id,
                name: template?.name,
                description: template?.description,
                framework: template?.framework,
                thumbnail: template?.thumbnail_url || `https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=600&h=400&fit=crop`,
                rating: template?.rating || 0,
                downloads: template?.download_count || 0,
                is_premium: template?.is_premium
              }))}
              onTemplateSelect={handleTemplateSelect}
              onPreview={handleTemplateSelect}
              onUseTemplate={handleTemplateSelect}
            />
          </div>
        )}

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <SearchBar 
                onSearch={handleSearch}
                placeholder="Search templates..."
              />
            </div>
            <div>
              <select
                value={selectedCategory}
                onChange={(e) => handleCategoryChange(e?.target?.value)}
                className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Categories</option>
                {categories?.filter(cat => cat !== 'all')?.map(category => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <select
                value={selectedFramework}
                onChange={(e) => handleFrameworkChange(e?.target?.value)}
                className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Frameworks</option>
                {frameworks?.filter(fw => fw !== 'all')?.map(framework => (
                  <option key={framework} value={framework}>
                    {framework}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Sort Options */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <h3 className="text-lg font-medium text-gray-900">
              {displayTemplates?.length} templates found
            </h3>
            {searchQuery && (
              <span className="text-sm text-gray-500">
                for "{searchQuery}"
              </span>
            )}
          </div>
          <SortOptions 
            value={sortBy}
            onSortChange={handleSortChange}
          />
        </div>

        {/* Error Display */}
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            {error}
            <button 
              onClick={loadTemplates}
              className="ml-2 underline hover:no-underline"
            >
              Try Again
            </button>
          </div>
        )}

        {/* Templates Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6]?.map((i) => (
              <div key={i} className="bg-white rounded-lg border p-6 animate-pulse">
                <div className="aspect-video bg-gray-200 rounded mb-4"></div>
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-3/4"></div>
              </div>
            ))}
          </div>
        ) : displayTemplates?.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg border">
            <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No templates found</h3>
            <p className="text-gray-600 mb-4">Try adjusting your search or filters</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSelectedFramework('all');
              }}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayTemplates?.map((template) => (
              <TemplateCard
                key={template?.id}
                template={template}
                onSelect={() => handleTemplateSelect(template)}
                onPreview={() => handleTemplateSelect(template)}
                onUseTemplate={() => handleTemplateSelect(template)}
              />
            ))}
          </div>
        )}

        {/* Industry Collections */}
        <IndustryCollections 
          collections={[]}
          onCategorySelect={handleCategoryChange}
          onViewCollection={handleCategoryChange}
        />

        {/* Template Detail Modal */}
        <TemplateModal
          template={selectedTemplate}
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onUseTemplate={() => handleTemplateSelect(selectedTemplate)}
        />
      </div>
    </div>
  );
}