import React, { useState } from 'react';
import Button from '../../../components/ui/Button';

const PlatformPreview = ({ platform, projectData, onProjectUpdate }) => {
  const [selectedDevice, setSelectedDevice] = useState('phone');
  const [orientation, setOrientation] = useState('portrait');
  const [previewMode, setPreviewMode] = useState('design');

  const devices = {
    ios: {
      phone: { name: 'iPhone 14 Pro', width: 393, height: 852, scale: 0.4 },
      tablet: { name: 'iPad Pro', width: 1024, height: 1366, scale: 0.3 }
    },
    android: {
      phone: { name: 'Pixel 7', width: 412, height: 915, scale: 0.4 },
      tablet: { name: 'Galaxy Tab S8', width: 1138, height: 712, scale: 0.3 }
    }
  };

  const currentDevice = devices?.[platform]?.[selectedDevice];
  const isLandscape = orientation === 'landscape';
  const displayWidth = isLandscape ? currentDevice?.height : currentDevice?.width;
  const displayHeight = isLandscape ? currentDevice?.width : currentDevice?.height;
  const scaledWidth = displayWidth * currentDevice?.scale;
  const scaledHeight = displayHeight * currentDevice?.scale;

  const mockScreens = [
    { id: 'home', name: 'Home Screen', color: 'bg-blue-500' },
    { id: 'profile', name: 'Profile Screen', color: 'bg-green-500' },
    { id: 'settings', name: 'Settings Screen', color: 'bg-purple-500' },
    { id: 'chat', name: 'Chat Screen', color: 'bg-orange-500' }
  ];

  const [currentScreen, setCurrentScreen] = useState('home');

  const handleScreenChange = (screenId) => {
    setCurrentScreen(screenId);
  };

  const generateCode = () => {
    const codeTemplates = {
      ios: `
// iOS Swift Code
import UIKit
import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack {
                Text("${projectData?.name}")
                    .font(.largeTitle)
                    .padding()
                
                // Native iOS components
                List {
                    NavigationLink("Home", destination: HomeView())
                    NavigationLink("Profile", destination: ProfileView())
                    NavigationLink("Settings", destination: SettingsView())
                }
            }
            .navigationTitle("${projectData?.name}")
        }
    }
}`,
      android: `
// Android Kotlin Code
package com.example.${projectData?.name?.toLowerCase()?.replace(/\s+/g, '')}

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${projectData?.name}") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Welcome to ${projectData?.name}")
            // Native Android components
        }
    }
}`
    };

    return codeTemplates?.[platform] || '';
  };

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Preview Controls</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Device Type */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">Device Type</label>
            <select
              value={selectedDevice}
              onChange={(e) => setSelectedDevice(e?.target?.value)}
              className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="phone">Phone</option>
              <option value="tablet">Tablet</option>
            </select>
          </div>

          {/* Orientation */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">Orientation</label>
            <select
              value={orientation}
              onChange={(e) => setOrientation(e?.target?.value)}
              className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="portrait">Portrait</option>
              <option value="landscape">Landscape</option>
            </select>
          </div>

          {/* Preview Mode */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">Preview Mode</label>
            <select
              value={previewMode}
              onChange={(e) => setPreviewMode(e?.target?.value)}
              className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="design">Design View</option>
              <option value="code">Code View</option>
              <option value="interactive">Interactive</option>
            </select>
          </div>

          {/* Actions */}
          <div className="flex items-end space-x-2">
            <Button variant="outline" size="sm" className="flex-1">
              Export
            </Button>
            <Button variant="primary" size="sm" className="flex-1">
              Test
            </Button>
          </div>
        </div>
      </div>
      {/* Preview Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Device Preview */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                {currentDevice?.name} Preview
              </h3>
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <span>{displayWidth} × {displayHeight}</span>
                <span>•</span>
                <span className="capitalize">{platform}</span>
              </div>
            </div>
            
            <div className="flex justify-center">
              <div className="relative">
                {/* Device Frame */}
                <div 
                  className={`
                    relative bg-gray-900 rounded-3xl p-4 shadow-2xl
                    ${platform === 'ios' ? 'rounded-3xl' : 'rounded-2xl'}
                  `}
                  style={{
                    width: scaledWidth + 32,
                    height: scaledHeight + 32
                  }}
                >
                  {/* Screen */}
                  <div 
                    className="bg-white rounded-2xl overflow-hidden relative"
                    style={{
                      width: scaledWidth,
                      height: scaledHeight
                    }}
                  >
                    {previewMode === 'design' && (
                      <>
                        {/* Status Bar */}
                        <div className={`
                          flex justify-between items-center px-4 py-2 text-xs
                          ${platform === 'ios' ?'bg-white text-black' :'bg-gray-800 text-white'
                          }
                        `}>
                          <span>9:41 AM</span>
                          <div className="flex items-center space-x-1">
                            <div className="w-4 h-2 bg-green-500 rounded-sm"></div>
                            <div className="w-4 h-2 border border-current rounded-sm"></div>
                            <span>100%</span>
                          </div>
                        </div>

                        {/* App Content */}
                        <div className="flex-1 p-4">
                          <div className="text-center mb-4">
                            <h2 className="text-lg font-bold text-gray-900">
                              {projectData?.name}
                            </h2>
                            <p className="text-sm text-gray-600">
                              {projectData?.description}
                            </p>
                          </div>

                          {/* Mock Content based on current screen */}
                          <div className="space-y-3">
                            {currentScreen === 'home' && (
                              <div className="space-y-2">
                                <div className="h-16 bg-blue-100 rounded-lg flex items-center justify-center">
                                  <span className="text-blue-700 font-medium">Welcome Dashboard</span>
                                </div>
                                <div className="grid grid-cols-2 gap-2">
                                  <div className="h-12 bg-green-100 rounded-lg flex items-center justify-center">
                                    <span className="text-green-700 text-sm">Quick Action</span>
                                  </div>
                                  <div className="h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                                    <span className="text-purple-700 text-sm">Analytics</span>
                                  </div>
                                </div>
                              </div>
                            )}

                            {currentScreen === 'profile' && (
                              <div className="space-y-2">
                                <div className="flex items-center space-x-3">
                                  <div className="w-12 h-12 bg-gray-300 rounded-full"></div>
                                  <div>
                                    <div className="h-3 bg-gray-200 rounded w-20 mb-1"></div>
                                    <div className="h-2 bg-gray-100 rounded w-16"></div>
                                  </div>
                                </div>
                                <div className="space-y-1">
                                  <div className="h-8 bg-gray-100 rounded"></div>
                                  <div className="h-8 bg-gray-100 rounded"></div>
                                  <div className="h-8 bg-gray-100 rounded"></div>
                                </div>
                              </div>
                            )}

                            {currentScreen === 'settings' && (
                              <div className="space-y-1">
                                {[...Array(6)]?.map((_, i) => (
                                  <div key={i} className="flex items-center justify-between p-2 border-b border-gray-100">
                                    <div className="h-3 bg-gray-200 rounded w-24"></div>
                                    <div className="w-8 h-4 bg-blue-500 rounded-full"></div>
                                  </div>
                                ))}
                              </div>
                            )}

                            {currentScreen === 'chat' && (
                              <div className="space-y-2">
                                <div className="flex justify-end">
                                  <div className="bg-blue-500 text-white text-xs p-2 rounded-lg max-w-32">
                                    Hello there!
                                  </div>
                                </div>
                                <div className="flex justify-start">
                                  <div className="bg-gray-200 text-gray-800 text-xs p-2 rounded-lg max-w-32">
                                    Hi! How are you?
                                  </div>
                                </div>
                                <div className="flex justify-end">
                                  <div className="bg-blue-500 text-white text-xs p-2 rounded-lg max-w-32">
                                    I'm doing great!
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Navigation Bar */}
                        <div className={`
                          flex justify-around items-center py-2 border-t
                          ${platform === 'ios' ?'bg-white border-gray-200' :'bg-gray-50 border-gray-300'
                          }
                        `}>
                          {mockScreens?.map((screen) => (
                            <button
                              key={screen?.id}
                              onClick={() => handleScreenChange(screen?.id)}
                              className={`
                                flex items-center justify-center w-8 h-8 rounded-full text-xs
                                ${currentScreen === screen?.id 
                                  ? screen?.color + 'text-white' :'bg-gray-200 text-gray-600'
                                }
                              `}
                            >
                              {screen?.name?.[0]}
                            </button>
                          ))}
                        </div>
                      </>
                    )}

                    {previewMode === 'code' && (
                      <div className="p-4 h-full overflow-auto">
                        <pre className="text-xs text-gray-800 whitespace-pre-wrap">
                          {generateCode()}
                        </pre>
                      </div>
                    )}

                    {previewMode === 'interactive' && (
                      <div className="flex items-center justify-center h-full">
                        <div className="text-center p-4">
                          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z" />
                            </svg>
                          </div>
                          <p className="text-sm text-gray-600">
                            Interactive mode requires app build
                          </p>
                          <Button variant="primary" size="sm" className="mt-2">
                            Build App
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Home Indicator (iOS) */}
                  {platform === 'ios' && (
                    <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2">
                      <div className="w-32 h-1 bg-white rounded-full opacity-50"></div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Screen Navigation & Info */}
        <div className="space-y-6">
          {/* Screen Navigator */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Screens</h3>
            
            <div className="space-y-2">
              {mockScreens?.map((screen) => (
                <button
                  key={screen?.id}
                  onClick={() => handleScreenChange(screen?.id)}
                  className={`
                    w-full flex items-center space-x-3 p-3 rounded-lg text-left transition-colors
                    ${currentScreen === screen?.id 
                      ? 'bg-blue-50 border border-blue-200' :'bg-gray-50 hover:bg-gray-100'
                    }
                  `}
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-medium ${screen?.color}`}>
                    {screen?.name?.[0]}
                  </div>
                  <span className="font-medium text-gray-900">{screen?.name}</span>
                </button>
              ))}
            </div>

            <Button variant="outline" className="w-full mt-4">
              Add Screen
            </Button>
          </div>

          {/* Platform Info */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Platform Details</h3>
            
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Platform:</span>
                <span className="font-medium capitalize">{platform}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Device:</span>
                <span className="font-medium">{currentDevice?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Resolution:</span>
                <span className="font-medium">{displayWidth} × {displayHeight}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Orientation:</span>
                <span className="font-medium capitalize">{orientation}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Scale:</span>
                <span className="font-medium">{Math.round(currentDevice?.scale * 100)}%</span>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
            
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Export Design
              </Button>
              
              <Button variant="outline" className="w-full justify-start">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
                Copy Code
              </Button>
              
              <Button variant="outline" className="w-full justify-start">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                </svg>
                Share Preview
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlatformPreview;