import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const BuildConfiguration = ({ selectedProject }) => {
  const [activeTab, setActiveTab] = useState('general');
  const [config, setConfig] = useState({
    buildCommand: 'npm run build',
    publishDirectory: 'dist',
    nodeVersion: '18.x',
    environmentVariables: {
      NODE_ENV: 'production',
      API_URL: 'https://api.example.com'
    },
    presets: {
      caching: true,
      optimization: true,
      minification: true,
      treeshaking: true
    }
  });

  const configTabs = [
    { id: 'general', label: 'General', icon: 'Settings' },
    { id: 'environment', label: 'Environment', icon: 'Key' },
    { id: 'presets', label: 'Presets', icon: 'Package' },
    { id: 'notifications', label: 'Notifications', icon: 'Bell' }
  ];

  const presetTemplates = [
    {
      id: 'react',
      name: 'React Application',
      description: 'Optimized for React.js applications',
      settings: {
        buildCommand: 'npm run build',
        publishDirectory: 'build',
        nodeVersion: '18.x'
      }
    },
    {
      id: 'vue',
      name: 'Vue.js Application', 
      description: 'Configured for Vue.js projects',
      settings: {
        buildCommand: 'npm run build',
        publishDirectory: 'dist',
        nodeVersion: '18.x'
      }
    },
    {
      id: 'nextjs',
      name: 'Next.js Application',
      description: 'Full-stack React framework setup',
      settings: {
        buildCommand: 'npm run build && npm run export',
        publishDirectory: 'out',
        nodeVersion: '18.x'
      }
    },
    {
      id: 'static',
      name: 'Static Site',
      description: 'Simple HTML/CSS/JS websites',
      settings: {
        buildCommand: '',
        publishDirectory: '.',
        nodeVersion: '18.x'
      }
    }
  ];

  const handleConfigChange = (key, value) => {
    setConfig(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handlePresetChange = (key, value) => {
    setConfig(prev => ({
      ...prev,
      presets: {
        ...prev?.presets,
        [key]: value
      }
    }));
  };

  const handleEnvironmentVariableChange = (key, value) => {
    setConfig(prev => ({
      ...prev,
      environmentVariables: {
        ...prev?.environmentVariables,
        [key]: value
      }
    }));
  };

  const addEnvironmentVariable = () => {
    const key = prompt('Environment variable name:');
    const value = prompt('Environment variable value:');
    
    if (key && value) {
      handleEnvironmentVariableChange(key, value);
    }
  };

  const applyPresetTemplate = (template) => {
    setConfig(prev => ({
      ...prev,
      ...template?.settings
    }));
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'general':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Build Command
                </label>
                <Input
                  type="text"
                  value={config?.buildCommand}
                  onChange={(e) => handleConfigChange('buildCommand', e?.target?.value)}
                  placeholder="npm run build"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Command to build your application
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Publish Directory
                </label>
                <Input
                  type="text"
                  value={config?.publishDirectory}
                  onChange={(e) => handleConfigChange('publishDirectory', e?.target?.value)}
                  placeholder="dist"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Directory containing built assets
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Node.js Version
                </label>
                <Select
                  options={[
                    { value: '16.x', label: 'Node.js 16.x' },
                    { value: '18.x', label: 'Node.js 18.x LTS' },
                    { value: '20.x', label: 'Node.js 20.x' },
                    { value: '21.x', label: 'Node.js 21.x (Latest)' }
                  ]}
                  value={config?.nodeVersion}
                  onChange={(value) => handleConfigChange('nodeVersion', value)}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Package Manager
                </label>
                <Select
                  options={[
                    { value: 'npm', label: 'npm' },
                    { value: 'yarn', label: 'Yarn' },
                    { value: 'pnpm', label: 'pnpm' },
                    { value: 'bun', label: 'Bun' }
                  ]}
                  defaultValue="npm"
                />
              </div>
            </div>
            <div>
              <h4 className="font-medium text-foreground mb-3">Build Triggers</h4>
              <div className="space-y-3">
                <Checkbox
                  label="Auto-deploy on push to main branch"
                  defaultChecked={true}
                />
                <Checkbox
                  label="Deploy preview for pull requests"
                  defaultChecked={true}
                />
                <Checkbox
                  label="Enable build skipping with [skip ci]"
                  defaultChecked={false}
                />
              </div>
            </div>
          </div>
        );

      case 'environment':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-foreground">Environment Variables</h4>
              <Button variant="outline" size="sm" onClick={addEnvironmentVariable}>
                <Icon name="Plus" size={14} className="mr-1" />
                Add Variable
              </Button>
            </div>
            <div className="space-y-3">
              {Object.entries(config?.environmentVariables)?.map(([key, value]) => (
                <div key={key} className="flex items-center space-x-3">
                  <div className="flex-1">
                    <Input
                      type="text"
                      value={key}
                      onChange={(e) => {
                        const newVars = { ...config?.environmentVariables };
                        delete newVars?.[key];
                        newVars[e.target.value] = value;
                        setConfig(prev => ({ ...prev, environmentVariables: newVars }));
                      }}
                      placeholder="Variable name"
                    />
                  </div>
                  <div className="flex-1">
                    <Input
                      type="text"
                      value={value}
                      onChange={(e) => handleEnvironmentVariableChange(key, e?.target?.value)}
                      placeholder="Variable value"
                    />
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => {
                      const newVars = { ...config?.environmentVariables };
                      delete newVars?.[key];
                      setConfig(prev => ({ ...prev, environmentVariables: newVars }));
                    }}
                  >
                    <Icon name="Trash2" size={16} className="text-destructive" />
                  </Button>
                </div>
              ))}
            </div>
            <div className="bg-muted/30 border border-border rounded-lg p-4">
              <h5 className="font-medium text-foreground mb-2 flex items-center">
                <Icon name="Info" size={16} className="mr-2 text-info" />
                Environment Variable Tips
              </h5>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Use VITE_ prefix for client-side variables in Vite projects</li>
                <li>• REACT_APP_ prefix for Create React App projects</li>
                <li>• Keep sensitive data like API keys secure</li>
                <li>• Use different values for staging and production</li>
              </ul>
            </div>
          </div>
        );

      case 'presets':
        return (
          <div className="space-y-6">
            <div>
              <h4 className="font-medium text-foreground mb-3">Template Presets</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {presetTemplates?.map((template) => (
                  <div key={template?.id} className="border border-border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h5 className="font-medium text-foreground">{template?.name}</h5>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => applyPresetTemplate(template)}
                      >
                        Apply
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{template?.description}</p>
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>Build: {template?.settings?.buildCommand || 'None'}</div>
                      <div>Publish: {template?.settings?.publishDirectory}</div>
                      <div>Node: {template?.settings?.nodeVersion}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-medium text-foreground mb-3">Build Optimizations</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <Checkbox
                    label="Enable build caching"
                    checked={config?.presets?.caching}
                    onChange={(checked) => handlePresetChange('caching', checked)}
                  />
                  <Checkbox
                    label="Bundle optimization"
                    checked={config?.presets?.optimization}
                    onChange={(checked) => handlePresetChange('optimization', checked)}
                  />
                </div>
                <div className="space-y-3">
                  <Checkbox
                    label="Code minification"
                    checked={config?.presets?.minification}
                    onChange={(checked) => handlePresetChange('minification', checked)}
                  />
                  <Checkbox
                    label="Tree shaking"
                    checked={config?.presets?.treeshaking}
                    onChange={(checked) => handlePresetChange('treeshaking', checked)}
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 'notifications':
        return (
          <div className="space-y-6">
            <div>
              <h4 className="font-medium text-foreground mb-3">Build Notifications</h4>
              <div className="space-y-4">
                <div className="border border-border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <Icon name="Mail" size={20} className="text-primary" />
                      <div>
                        <h5 className="font-medium text-foreground">Email Notifications</h5>
                        <p className="text-sm text-muted-foreground">Receive build status via email</p>
                      </div>
                    </div>
                    <Checkbox defaultChecked={true} />
                  </div>
                  <div className="ml-11">
                    <Input
                      type="email"
                      placeholder="your.email@example.com"
                      defaultValue="john.doe@example.com"
                      className="text-sm"
                    />
                  </div>
                </div>

                <div className="border border-border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <Icon name="MessageSquare" size={20} className="text-success" />
                      <div>
                        <h5 className="font-medium text-foreground">Slack Integration</h5>
                        <p className="text-sm text-muted-foreground">Send updates to Slack channel</p>
                      </div>
                    </div>
                    <Checkbox defaultChecked={false} />
                  </div>
                  <div className="ml-11">
                    <Input
                      type="text"
                      placeholder="#deployments"
                      className="text-sm"
                    />
                  </div>
                </div>

                <div className="border border-border rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Icon name="Webhook" size={20} className="text-warning" />
                      <div>
                        <h5 className="font-medium text-foreground">Webhook</h5>
                        <p className="text-sm text-muted-foreground">Custom webhook endpoint</p>
                      </div>
                    </div>
                    <Checkbox defaultChecked={false} />
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-foreground mb-3">Notification Events</h4>
              <div className="space-y-2">
                <Checkbox label="Build started" defaultChecked={false} />
                <Checkbox label="Build completed successfully" defaultChecked={true} />
                <Checkbox label="Build failed" defaultChecked={true} />
                <Checkbox label="Deployment started" defaultChecked={false} />
                <Checkbox label="Deployment completed" defaultChecked={true} />
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Configuration Header */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Build Configuration</h3>
            <p className="text-sm text-muted-foreground">
              Customize compilation settings and deployment parameters for {selectedProject?.name}
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Icon name="RotateCcw" size={14} className="mr-1" />
              Reset
            </Button>
            <Button variant="default" size="sm">
              <Icon name="Save" size={14} className="mr-1" />
              Save Changes
            </Button>
          </div>
        </div>

        {/* Configuration Tabs */}
        <div className="border-b border-border">
          <nav className="-mb-px flex space-x-8 overflow-x-auto">
            {configTabs?.map((tab) => (
              <button
                key={tab?.id}
                onClick={() => setActiveTab(tab?.id)}
                className={`whitespace-nowrap flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab?.id
                    ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
                }`}
              >
                <Icon name={tab?.icon} size={14} />
                <span>{tab?.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="mt-6">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default BuildConfiguration;