import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const BuildQueue = ({ builds, onCancel, onRetry }) => {
  const getStatusIcon = (status) => {
    switch (status) {
      case 'building':
        return 'Clock';
      case 'queued':
        return 'Timer';
      case 'completed':
        return 'CheckCircle';
      case 'failed':
        return 'XCircle';
      default:
        return 'Circle';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'building':
        return 'text-warning';
      case 'queued':
        return 'text-muted-foreground';
      case 'completed':
        return 'text-success';
      case 'failed':
        return 'text-destructive';
      default:
        return 'text-muted-foreground';
    }
  };

  const formatDuration = (startTime) => {
    if (!startTime) return '0s';
    const duration = (Date.now() - startTime?.getTime()) / 1000;
    const minutes = Math.floor(duration / 60);
    const seconds = Math.floor(duration % 60);
    return minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;
  };

  return (
    <div className="space-y-6">
      {/* Queue Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Active Builds</p>
              <p className="text-xl font-bold text-warning">
                {builds?.filter(b => b?.status === 'building')?.length}
              </p>
            </div>
            <Icon name="Activity" size={20} className="text-warning" />
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">In Queue</p>
              <p className="text-xl font-bold text-primary">
                {builds?.filter(b => b?.status === 'queued')?.length}
              </p>
            </div>
            <Icon name="Clock" size={20} className="text-primary" />
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Runtime</p>
              <p className="text-xl font-bold text-foreground">
                {builds?.reduce((total, build) => {
                  if (build?.startTime) {
                    return total + Math.floor((Date.now() - build?.startTime?.getTime()) / 1000);
                  }
                  return total;
                }, 0)}s
              </p>
            </div>
            <Icon name="Timer" size={20} className="text-foreground" />
          </div>
        </div>
      </div>

      {/* Build Queue List */}
      <div className="bg-card border border-border rounded-lg">
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-foreground">Build Queue</h3>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Icon name="Pause" size={14} className="mr-1" />
                Pause Queue
              </Button>
              <Button variant="outline" size="sm">
                <Icon name="RotateCcw" size={14} className="mr-1" />
                Clear All
              </Button>
            </div>
          </div>
        </div>

        <div className="divide-y divide-border">
          {builds?.map((build, index) => (
            <div key={build?.id} className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 flex-1">
                  {/* Status Indicator */}
                  <div className="flex flex-col items-center">
                    <Icon 
                      name={getStatusIcon(build?.status)} 
                      size={20} 
                      className={`${getStatusColor(build?.status)} ${
                        build?.status === 'building' ? 'animate-spin' : ''
                      }`}
                    />
                    <span className="text-xs text-muted-foreground mt-1">
                      #{index + 1}
                    </span>
                  </div>

                  {/* Project Info */}
                  <div className="flex-1">
                    <h4 className="font-medium text-foreground">{build?.projectName}</h4>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                      <span>Stage: {build?.stage}</span>
                      <span>•</span>
                      <span>ETA: {build?.estimatedTime}</span>
                      {build?.startTime && (
                        <>
                          <span>•</span>
                          <span>Running: {formatDuration(build?.startTime)}</span>
                        </>
                      )}
                    </div>

                    {/* Progress Bar */}
                    {build?.status === 'building' && (
                      <div className="mt-2">
                        <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                          <span>Progress</span>
                          <span>{Math.round(build?.progress)}%</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div 
                            className="bg-warning h-2 rounded-full transition-all duration-500" 
                            style={{ width: `${build?.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center space-x-2">
                    {build?.status === 'building' && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => onCancel?.(build?.id)}
                      >
                        <Icon name="X" size={14} className="mr-1" />
                        Cancel
                      </Button>
                    )}
                    
                    {build?.status === 'queued' && (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => onCancel?.(build?.id)}
                      >
                        <Icon name="Trash2" size={14} className="mr-1" />
                        Remove
                      </Button>
                    )}

                    {build?.status === 'failed' && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => onRetry?.(build?.id)}
                      >
                        <Icon name="RotateCcw" size={14} className="mr-1" />
                        Retry
                      </Button>
                    )}

                    <Button variant="ghost" size="sm">
                      <Icon name="MoreHorizontal" size={14} />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {builds?.length === 0 && (
          <div className="p-12 text-center">
            <Icon name="Clock" size={48} className="text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">No builds in queue</h3>
            <p className="text-muted-foreground">Start a new build to see it appear here</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BuildQueue;