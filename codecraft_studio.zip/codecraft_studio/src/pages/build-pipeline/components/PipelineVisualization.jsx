import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PipelineVisualization = ({ stages }) => {
  const [selectedStage, setSelectedStage] = useState(null);

  const getStageStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-success border-success text-success';
      case 'running':
        return 'bg-warning border-warning text-warning';
      case 'failed':
        return 'bg-destructive border-destructive text-destructive';
      case 'pending':
        return 'bg-muted border-border text-muted-foreground';
      default:
        return 'bg-muted border-border text-muted-foreground';
    }
  };

  const getConnectorColor = (currentStatus, nextStatus) => {
    if (currentStatus === 'completed' && (nextStatus === 'running' || nextStatus === 'completed')) {
      return 'border-success';
    } else if (currentStatus === 'failed') {
      return 'border-destructive';
    }
    return 'border-muted';
  };

  return (
    <div className="space-y-6">
      {/* Pipeline Overview */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Pipeline Workflow</h3>
            <p className="text-sm text-muted-foreground">
              Visual representation of your build and deployment stages
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Icon name="Settings" size={14} className="mr-1" />
              Configure
            </Button>
            <Button variant="outline" size="sm">
              <Icon name="History" size={14} className="mr-1" />
              History
            </Button>
          </div>
        </div>

        {/* Desktop Pipeline View */}
        <div className="hidden lg:block">
          <div className="relative">
            <div className="flex items-center justify-between">
              {stages?.map((stage, index) => (
                <div key={stage?.id} className="flex items-center">
                  {/* Stage Node */}
                  <div 
                    className={`relative cursor-pointer group ${
                      selectedStage?.id === stage?.id ? 'scale-110' : ''
                    } transition-transform duration-200`}
                    onClick={() => setSelectedStage(stage)}
                  >
                    <div className={`w-16 h-16 rounded-full border-2 flex items-center justify-center ${
                      getStageStatusColor(stage?.status)
                    } bg-opacity-10 group-hover:bg-opacity-20 transition-colors duration-200`}>
                      <Icon name={stage?.icon} size={24} />
                      
                      {/* Running Progress Ring */}
                      {stage?.status === 'running' && stage?.progress && (
                        <div className="absolute inset-0">
                          <svg className="w-16 h-16 transform -rotate-90" viewBox="0 0 100 100">
                            <circle
                              cx="50"
                              cy="50"
                              r="45"
                              stroke="currentColor"
                              strokeWidth="2"
                              fill="transparent"
                              strokeDasharray={`${stage?.progress * 2.827} 283`}
                              className="text-warning"
                            />
                          </svg>
                        </div>
                      )}
                    </div>

                    {/* Stage Label */}
                    <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 text-center">
                      <p className="text-xs font-medium text-foreground whitespace-nowrap">{stage?.name}</p>
                      {stage?.duration && (
                        <p className="text-xs text-muted-foreground">{stage?.duration}</p>
                      )}
                    </div>
                  </div>

                  {/* Connector */}
                  {index < stages?.length - 1 && (
                    <div className={`flex-1 h-0.5 mx-4 border-t-2 border-dashed ${
                      getConnectorColor(stage?.status, stages?.[index + 1]?.status)
                    }`}>
                      {/* Animated flow indicator */}
                      {stage?.status === 'completed' && stages?.[index + 1]?.status === 'running' && (
                        <div className="relative">
                          <div className="absolute top-0 left-0 w-2 h-0.5 bg-warning animate-pulse"></div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Mobile Pipeline View */}
        <div className="block lg:hidden">
          <div className="space-y-4">
            {stages?.map((stage, index) => (
              <div key={stage?.id} className="relative">
                <div 
                  className={`flex items-center p-4 border rounded-lg cursor-pointer ${
                    getStageStatusColor(stage?.status)
                  } bg-opacity-5 border-opacity-20 hover:bg-opacity-10 transition-colors duration-200`}
                  onClick={() => setSelectedStage(selectedStage?.id === stage?.id ? null : stage)}
                >
                  <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center mr-4 ${
                    getStageStatusColor(stage?.status)
                  } bg-opacity-10`}>
                    <Icon name={stage?.icon} size={20} />
                  </div>
                  
                  <div className="flex-1">
                    <h4 className="font-medium text-foreground">{stage?.name}</h4>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <span className="capitalize">{stage?.status}</span>
                      {stage?.duration && (
                        <>
                          <span>•</span>
                          <span>{stage?.duration}</span>
                        </>
                      )}
                      {stage?.status === 'running' && stage?.progress && (
                        <>
                          <span>•</span>
                          <span>{Math.round(stage?.progress)}%</span>
                        </>
                      )}
                    </div>
                  </div>

                  <Icon name="ChevronRight" size={16} className="text-muted-foreground" />
                </div>

                {/* Progress bar for running stage */}
                {stage?.status === 'running' && stage?.progress && (
                  <div className="mt-2 ml-16">
                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className="bg-warning h-2 rounded-full transition-all duration-500" 
                        style={{ width: `${stage?.progress}%` }}
                      ></div>
                    </div>
                  </div>
                )}

                {/* Connector line */}
                {index < stages?.length - 1 && (
                  <div className="absolute left-6 top-16 w-0.5 h-4 bg-border"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stage Details Panel */}
      {selectedStage && (
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                getStageStatusColor(selectedStage?.status)
              } bg-opacity-10`}>
                <Icon name={selectedStage?.icon} size={16} />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{selectedStage?.name}</h3>
                <p className="text-sm text-muted-foreground capitalize">{selectedStage?.status}</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setSelectedStage(null)}>
              <Icon name="X" size={16} />
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-foreground mb-3">Stage Information</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Status:</span>
                  <span className="font-medium capitalize">{selectedStage?.status}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Duration:</span>
                  <span className="font-medium">{selectedStage?.duration || 'N/A'}</span>
                </div>
                {selectedStage?.progress && (
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Progress:</span>
                    <span className="font-medium">{Math.round(selectedStage?.progress)}%</span>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Started:</span>
                  <span className="font-medium">2 minutes ago</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-foreground mb-3">Recent Logs</h4>
              <div className="bg-muted/30 rounded border p-3 text-sm">
                <div className="space-y-1 font-mono">
                  <div className="text-success">✓ Dependencies installed successfully</div>
                  <div className="text-info">→ Starting build process...</div>
                  <div className="text-warning">⚠ Large bundle detected, enabling optimization</div>
                  <div className="text-muted-foreground">Building components...</div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 flex items-center justify-end space-x-2">
            <Button variant="outline" size="sm">
              <Icon name="FileText" size={14} className="mr-1" />
              View Full Logs
            </Button>
            <Button variant="outline" size="sm">
              <Icon name="RotateCcw" size={14} className="mr-1" />
              Retry Stage
            </Button>
          </div>
        </div>
      )}

      {/* Pipeline Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Stages</p>
              <p className="text-xl font-bold text-foreground">{stages?.length}</p>
            </div>
            <Icon name="Layers" size={20} className="text-primary" />
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Completed</p>
              <p className="text-xl font-bold text-success">
                {stages?.filter(s => s?.status === 'completed')?.length}
              </p>
            </div>
            <Icon name="CheckCircle" size={20} className="text-success" />
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Failed</p>
              <p className="text-xl font-bold text-destructive">
                {stages?.filter(s => s?.status === 'failed')?.length}
              </p>
            </div>
            <Icon name="XCircle" size={20} className="text-destructive" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PipelineVisualization;