import React, { useEffect } from 'react';

const DatabasePreview = () => {
  React.useEffect(() => {
    // eslint-disable-next-line no-console
    console.warn('Placeholder: DatabasePreview is not implemented yet.');
  }, []);
  return (
    <>
  { /*DatabasePreview */} 
 </>
  );
};

export default DatabasePreview;
