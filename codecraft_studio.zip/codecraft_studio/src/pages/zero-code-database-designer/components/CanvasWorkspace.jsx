import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Table, Link, Plus, Edit3, Move } from 'lucide-react';

const CanvasWorkspace = ({ 
  tables, 
  relationships, 
  selectedTable, 
  onTableSelect, 
  onTableUpdate, 
  canvasState, 
  onCanvasStateChange, 
  isDragMode 
}) => {
  const canvasRef = useRef(null);
  const [isPanning, setIsPanning] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [dragTarget, setDragTarget] = useState(null);
  const [lastPanPoint, setLastPanPoint] = useState({ x: 0, y: 0 });
  const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });

  // Handle canvas panning
  const handleMouseDown = useCallback((e) => {
    if (e?.target === canvasRef?.current) {
      setIsPanning(true);
      setLastPanPoint({ x: e?.clientX, y: e?.clientY });
    }
  }, []);

  const handleMouseMove = useCallback((e) => {
    setLastMousePos({ x: e?.clientX, y: e?.clientY });

    if (isPanning && !isDragMode) {
      const deltaX = e?.clientX - lastPanPoint?.x;
      const deltaY = e?.clientY - lastPanPoint?.y;
      
      onCanvasStateChange({
        ...canvasState,
        panX: canvasState?.panX + deltaX,
        panY: canvasState?.panY + deltaY
      });
      
      setLastPanPoint({ x: e?.clientX, y: e?.clientY });
    }

    if (isDragging && dragTarget && isDragMode) {
      const rect = canvasRef?.current?.getBoundingClientRect();
      if (rect) {
        const newX = (e?.clientX - rect?.left - canvasState?.panX) / canvasState?.zoom;
        const newY = (e?.clientY - rect?.top - canvasState?.panY) / canvasState?.zoom;
        
        onTableUpdate(dragTarget?.id, {
          position_x: Math.max(0, newX - 100), // Account for table width
          position_y: Math.max(0, newY - 50)   // Account for table height
        });
      }
    }
  }, [isPanning, isDragging, dragTarget, isDragMode, lastPanPoint, canvasState, onCanvasStateChange, onTableUpdate]);

  const handleMouseUp = useCallback(() => {
    setIsPanning(false);
    setIsDragging(false);
    setDragTarget(null);
  }, []);

  useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  // Handle table dragging
  const handleTableMouseDown = useCallback((e, table) => {
    e?.stopPropagation();
    
    if (isDragMode) {
      setIsDragging(true);
      setDragTarget(table);
    }
    
    onTableSelect(table);
  }, [isDragMode, onTableSelect]);

  // Handle zoom
  const handleWheel = useCallback((e) => {
    e?.preventDefault();
    
    const delta = e?.deltaY > 0 ? -0.1 : 0.1;
    const newZoom = Math.min(Math.max(canvasState?.zoom + delta, 0.5), 2.0);
    
    onCanvasStateChange({
      ...canvasState,
      zoom: newZoom
    });
  }, [canvasState, onCanvasStateChange]);

  // Calculate relationship lines
  const getRelationshipPath = useCallback((relationship) => {
    const sourceTable = tables?.find(t => t?.id === relationship?.source_table_id);
    const targetTable = tables?.find(t => t?.id === relationship?.target_table_id);
    
    if (!sourceTable || !targetTable) return null;

    const sourceX = sourceTable?.position_x + 150; // Center of table
    const sourceY = sourceTable?.position_y + 60;
    const targetX = targetTable?.position_x + 150;
    const targetY = targetTable?.position_y + 60;

    // Simple curved line between tables
    const midX = (sourceX + targetX) / 2;
    const controlOffset = Math.abs(sourceY - targetY) * 0.3;
    
    return `M ${sourceX} ${sourceY} Q ${midX} ${sourceY + (sourceY < targetY ? controlOffset : -controlOffset)} ${targetX} ${targetY}`;
  }, [tables]);

  const canvasTransform = `translate(${canvasState?.panX}px, ${canvasState?.panY}px) scale(${canvasState?.zoom})`;

  return (
    <div className="relative w-full h-full bg-gray-100 overflow-hidden">
      {/* Canvas controls */}
      <div className="absolute top-4 left-4 z-10 bg-white rounded-lg shadow-md p-2">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onCanvasStateChange({ ...canvasState, zoom: Math.min(canvasState?.zoom + 0.2, 2.0) })}
            className="p-1 hover:bg-gray-100 rounded text-gray-600"
            title="Zoom In"
          >
            <Plus className="w-4 h-4" />
          </button>
          <span className="text-sm text-gray-600 min-w-[3rem] text-center">
            {Math.round(canvasState?.zoom * 100)}%
          </span>
          <button
            onClick={() => onCanvasStateChange({ ...canvasState, zoom: Math.max(canvasState?.zoom - 0.2, 0.5) })}
            className="p-1 hover:bg-gray-100 rounded text-gray-600"
            title="Zoom Out"
          >
            <Plus className="w-4 h-4 rotate-45" />
          </button>
          <div className="w-px h-6 bg-gray-300" />
          <button
            onClick={() => onCanvasStateChange({ zoom: 1, panX: 0, panY: 0 })}
            className="p-1 hover:bg-gray-100 rounded text-gray-600"
            title="Reset View"
          >
            <Move className="w-4 h-4" />
          </button>
        </div>
      </div>
      {/* Canvas */}
      <div
        ref={canvasRef}
        className="w-full h-full cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onWheel={handleWheel}
      >
        <div style={{ transform: canvasTransform, transformOrigin: '0 0' }}>
          {/* Grid pattern */}
          <svg className="absolute inset-0 pointer-events-none" style={{ width: '2000px', height: '2000px' }}>
            <defs>
              <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#e5e7eb" strokeWidth="1"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>

          {/* Relationship lines */}
          <svg className="absolute inset-0 pointer-events-none" style={{ width: '2000px', height: '2000px' }}>
            {relationships?.map((relationship) => {
              const path = getRelationshipPath(relationship);
              if (!path) return null;

              return (
                <g key={relationship?.id}>
                  <path
                    d={path}
                    fill="none"
                    stroke="#6b7280"
                    strokeWidth="2"
                    markerEnd="url(#arrowhead)"
                  />
                  {/* Relationship type indicator */}
                  <circle
                    cx={(tables?.find(t => t?.id === relationship?.source_table_id)?.position_x + 150 + tables?.find(t => t?.id === relationship?.target_table_id)?.position_x + 150) / 2}
                    cy={(tables?.find(t => t?.id === relationship?.source_table_id)?.position_y + 60 + tables?.find(t => t?.id === relationship?.target_table_id)?.position_y + 60) / 2}
                    r="8"
                    fill="white"
                    stroke="#6b7280"
                    strokeWidth="2"
                  />
                  <text
                    x={(tables?.find(t => t?.id === relationship?.source_table_id)?.position_x + 150 + tables?.find(t => t?.id === relationship?.target_table_id)?.position_x + 150) / 2}
                    y={(tables?.find(t => t?.id === relationship?.source_table_id)?.position_y + 60 + tables?.find(t => t?.id === relationship?.target_table_id)?.position_y + 60) / 2 + 4}
                    textAnchor="middle"
                    className="text-xs font-bold fill-gray-600"
                  >
                    {relationship?.relationship_type === 'one_to_many' ? '1:N' : 
                     relationship?.relationship_type === 'many_to_many' ? 'M:N' : '1:1'}
                  </text>
                </g>
              );
            })}
            
            {/* Arrow marker definition */}
            <defs>
              <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#6b7280" />
              </marker>
            </defs>
          </svg>

          {/* Tables */}
          {tables?.map((table) => (
            <div
              key={table?.id}
              className={`absolute bg-white rounded-lg shadow-md border-2 transition-all duration-200 ${
                selectedTable?.id === table?.id 
                  ? 'border-blue-500 shadow-lg' 
                  : 'border-gray-200 hover:border-gray-300'
              } ${isDragMode ? 'cursor-move' : 'cursor-pointer'}`}
              style={{
                left: `${table?.position_x || 0}px`,
                top: `${table?.position_y || 0}px`,
                width: '300px',
                backgroundColor: table?.color || '#ffffff'
              }}
              onMouseDown={(e) => handleTableMouseDown(e, table)}
            >
              {/* Table header */}
              <div className="px-4 py-3 border-b border-gray-200 bg-gray-50 rounded-t-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Table className="w-4 h-4 text-gray-600" />
                    <span className="font-medium text-gray-900">
                      {table?.display_name || table?.name}
                    </span>
                  </div>
                  <div className="flex items-center space-x-1">
                    {isDragMode && (
                      <Move className="w-4 h-4 text-gray-400" />
                    )}
                    <Edit3 className="w-4 h-4 text-gray-400" />
                  </div>
                </div>
                {table?.description && (
                  <p className="text-xs text-gray-500 mt-1">{table?.description}</p>
                )}
              </div>

              {/* Table fields */}
              <div className="divide-y divide-gray-100 max-h-64 overflow-y-auto">
                {table?.table_fields?.length === 0 ? (
                  <div className="px-4 py-8 text-center text-gray-500">
                    <Plus className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm">No fields yet</p>
                    <p className="text-xs text-gray-400">Add fields to this table</p>
                  </div>
                ) : (
                  table?.table_fields?.sort((a, b) => (a?.sort_order || 0) - (b?.sort_order || 0))?.map((field) => (
                    <div key={field?.id} className="px-4 py-2 hover:bg-gray-50">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <div className={`w-2 h-2 rounded-full ${
                            field?.constraints?.includes('primary_key') ? 'bg-yellow-500' :
                            field?.constraints?.includes('foreign_key') ? 'bg-blue-500' :
                            field?.constraints?.includes('unique') ? 'bg-green-500' :
                            'bg-gray-300'
                          }`} />
                          <span className="text-sm font-medium text-gray-900">
                            {field?.display_name || field?.name}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                            {field?.data_type}
                          </span>
                          {!field?.is_nullable && (
                            <span className="text-xs text-red-600">*</span>
                          )}
                        </div>
                      </div>
                      {field?.description && (
                        <p className="text-xs text-gray-500 mt-1 ml-4">{field?.description}</p>
                      )}
                    </div>
                  ))
                )}
              </div>

              {/* Table footer */}
              <div className="px-4 py-2 border-t border-gray-200 bg-gray-50 rounded-b-lg">
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>
                    {table?.table_fields?.length || 0} field{table?.table_fields?.length !== 1 ? 's' : ''}
                  </span>
                  <span className="flex items-center space-x-1">
                    <Link className="w-3 h-3" />
                    <span>
                      {(table?.source_relationships?.length || 0) + (table?.target_relationships?.length || 0)} relation{((table?.source_relationships?.length || 0) + (table?.target_relationships?.length || 0)) !== 1 ? 's' : ''}
                    </span>
                  </span>
                </div>
              </div>
            </div>
          ))}

          {/* Empty state */}
          {tables?.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center max-w-sm">
                <Table className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No tables yet</h3>
                <p className="text-gray-500 mb-4">
                  Start building your database schema by adding your first table
                </p>
                <p className="text-sm text-gray-400">
                  Use the Tables & Fields panel on the right to create tables
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
      {/* Mode indicator */}
      {isDragMode && (
        <div className="absolute bottom-4 left-4 bg-blue-100 border border-blue-200 rounded-lg px-3 py-2">
          <div className="flex items-center space-x-2">
            <Move className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-700">Drag Mode Active</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default CanvasWorkspace;