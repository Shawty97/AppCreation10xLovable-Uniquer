import React, { useState, useEffect } from 'react';
import { Plus, Edit3, Trash2, GripVertical, Key, Link, Hash, FileText } from 'lucide-react';
import databaseDesignerService from '../../../services/databaseDesignerService';

const TablePropertiesPanel = ({ 
  tables, 
  selectedTable, 
  onTableSelect, 
  onCreateTable, 
  onUpdateTable, 
  onDeleteTable 
}) => {
  const [isCreatingTable, setIsCreatingTable] = useState(false);
  const [editingField, setEditingField] = useState(null);
  const [newTableForm, setNewTableForm] = useState({
    name: '',
    display_name: '',
    description: '',
    color: '#3B82F6'
  });
  const [newFieldForm, setNewFieldForm] = useState({
    name: '',
    display_name: '',
    data_type: 'text',
    constraints: [],
    is_nullable: true,
    description: '',
    default_value: '',
    max_length: '',
    precision_scale: ''
  });

  const dataTypes = [
    { value: 'text', label: 'Text', icon: FileText },
    { value: 'number', label: 'Number', icon: Hash },
    { value: 'decimal', label: 'Decimal', icon: Hash },
    { value: 'boolean', label: 'Boolean', icon: '○' },
    { value: 'date', label: 'Date', icon: '📅' },
    { value: 'datetime', label: 'DateTime', icon: '🕒' },
    { value: 'email', label: 'Email', icon: '@' },
    { value: 'url', label: 'URL', icon: '🔗' },
    { value: 'phone', label: 'Phone', icon: '📞' },
    { value: 'image', label: 'Image', icon: '🖼️' },
    { value: 'file', label: 'File', icon: '📁' },
    { value: 'json', label: 'JSON', icon: '{}' },
    { value: 'uuid', label: 'UUID', icon: Key },
    { value: 'textarea', label: 'Long Text', icon: FileText }
  ];

  const constraintOptions = [
    { value: 'required', label: 'Required', icon: '*' },
    { value: 'unique', label: 'Unique', icon: '!' },
    { value: 'indexed', label: 'Indexed', icon: '⚡' },
    { value: 'primary_key', label: 'Primary Key', icon: Key },
    { value: 'foreign_key', label: 'Foreign Key', icon: Link },
    { value: 'auto_increment', label: 'Auto Increment', icon: '+' }
  ];

  const tableColors = [
    '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', 
    '#EC4899', '#06B6D4', '#84CC16', '#F97316', '#6B7280'
  ];

  useEffect(() => {
    if (selectedTable) {
      setIsCreatingTable(false);
      setEditingField(null);
    }
  }, [selectedTable]);

  const handleCreateTable = async (e) => {
    e?.preventDefault();
    if (!newTableForm?.name?.trim()) return;

    try {
      await onCreateTable({
        ...newTableForm,
        position_x: Math.random() * 400 + 100,
        position_y: Math.random() * 300 + 100
      });
      
      setNewTableForm({
        name: '',
        display_name: '',
        description: '',
        color: '#3B82F6'
      });
      setIsCreatingTable(false);
    } catch (error) {
      console.error('Failed to create table:', error);
    }
  };

  const handleAddField = async (e) => {
    e?.preventDefault();
    if (!selectedTable || !newFieldForm?.name?.trim()) return;

    try {
      const result = await databaseDesignerService?.createTableField({
        ...newFieldForm,
        table_id: selectedTable?.id,
        sort_order: (selectedTable?.table_fields?.length || 0) + 1
      });

      if (result?.success) {
        // Update local table data
        const updatedTable = {
          ...selectedTable,
          table_fields: [...(selectedTable?.table_fields || []), result?.data]
        };
        onTableSelect(updatedTable);
        
        // Reset form
        setNewFieldForm({
          name: '',
          display_name: '',
          data_type: 'text',
          constraints: [],
          is_nullable: true,
          description: '',
          default_value: '',
          max_length: '',
          precision_scale: ''
        });
      }
    } catch (error) {
      console.error('Failed to add field:', error);
    }
  };

  const handleUpdateField = async (fieldId, updates) => {
    try {
      const result = await databaseDesignerService?.updateTableField(fieldId, updates);
      if (result?.success) {
        const updatedTable = {
          ...selectedTable,
          table_fields: selectedTable?.table_fields?.map(field => 
            field?.id === fieldId ? { ...field, ...result?.data } : field
          )
        };
        onTableSelect(updatedTable);
        setEditingField(null);
      }
    } catch (error) {
      console.error('Failed to update field:', error);
    }
  };

  const handleDeleteField = async (fieldId) => {
    if (!confirm('Are you sure you want to delete this field?')) return;

    try {
      const result = await databaseDesignerService?.deleteTableField(fieldId);
      if (result?.success) {
        const updatedTable = {
          ...selectedTable,
          table_fields: selectedTable?.table_fields?.filter(field => field?.id !== fieldId)
        };
        onTableSelect(updatedTable);
      }
    } catch (error) {
      console.error('Failed to delete field:', error);
    }
  };

  const handleConstraintChange = (constraint, checked) => {
    const updatedConstraints = checked
      ? [...newFieldForm?.constraints, constraint]
      : newFieldForm?.constraints?.filter(c => c !== constraint);

    setNewFieldForm({
      ...newFieldForm,
      constraints: updatedConstraints,
      is_nullable: updatedConstraints?.includes('required') ? false : newFieldForm?.is_nullable
    });
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-200 bg-white">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-900">Tables & Fields</h3>
          <button
            onClick={() => setIsCreatingTable(true)}
            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
            title="Add Table"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto">
        {/* Create table form */}
        {isCreatingTable && (
          <div className="p-4 bg-blue-50 border-b border-blue-200">
            <form onSubmit={handleCreateTable} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Table Name *
                </label>
                <input
                  type="text"
                  value={newTableForm?.name}
                  onChange={(e) => setNewTableForm({...newTableForm, name: e?.target?.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="e.g., users, products"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Display Name
                </label>
                <input
                  type="text"
                  value={newTableForm?.display_name}
                  onChange={(e) => setNewTableForm({...newTableForm, display_name: e?.target?.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="e.g., Users, Products"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={newTableForm?.description}
                  onChange={(e) => setNewTableForm({...newTableForm, description: e?.target?.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                  rows={2}
                  placeholder="Brief description of this table"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Color
                </label>
                <div className="flex space-x-2">
                  {tableColors?.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setNewTableForm({...newTableForm, color})}
                      className={`w-6 h-6 rounded-full border-2 ${
                        newTableForm?.color === color ? 'border-gray-400' : 'border-gray-200'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsCreatingTable(false)}
                  className="px-3 py-2 text-gray-600 hover:text-gray-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  Create Table
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Tables list */}
        <div className="divide-y divide-gray-200">
          {tables?.map((table) => (
            <div key={table?.id} className="p-4">
              <button
                onClick={() => onTableSelect(table)}
                className={`w-full text-left p-3 rounded-lg border-2 transition-all ${
                  selectedTable?.id === table?.id
                    ? 'border-blue-500 bg-blue-50' :'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }`}
                style={{ borderLeftColor: table?.color }}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {table?.display_name || table?.name}
                    </h4>
                    {table?.description && (
                      <p className="text-sm text-gray-500 mt-1">{table?.description}</p>
                    )}
                    <p className="text-xs text-gray-400 mt-1">
                      {table?.table_fields?.length || 0} fields
                    </p>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Edit3 className="w-4 h-4 text-gray-400" />
                    <button
                      onClick={(e) => {
                        e?.stopPropagation();
                        if (confirm('Are you sure you want to delete this table?')) {
                          onDeleteTable(table?.id);
                        }
                      }}
                      className="p-1 text-red-600 hover:bg-red-50 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </button>
            </div>
          ))}
        </div>

        {/* Selected table fields */}
        {selectedTable && (
          <div className="border-t border-gray-200">
            <div className="px-4 py-3 bg-gray-50">
              <h4 className="font-medium text-gray-900">
                Fields for {selectedTable?.display_name || selectedTable?.name}
              </h4>
            </div>

            {/* Add field form */}
            <div className="p-4 bg-yellow-50 border-b border-yellow-200">
              <form onSubmit={handleAddField} className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <input
                      type="text"
                      value={newFieldForm?.name}
                      onChange={(e) => setNewFieldForm({...newFieldForm, name: e?.target?.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                      placeholder="Field name"
                      required
                    />
                  </div>
                  <div>
                    <select
                      value={newFieldForm?.data_type}
                      onChange={(e) => setNewFieldForm({...newFieldForm, data_type: e?.target?.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                    >
                      {dataTypes?.map((type) => (
                        <option key={type?.value} value={type?.value}>
                          {type?.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <input
                    type="text"
                    value={newFieldForm?.display_name}
                    onChange={(e) => setNewFieldForm({...newFieldForm, display_name: e?.target?.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                    placeholder="Display name (optional)"
                  />
                </div>

                <div>
                  <textarea
                    value={newFieldForm?.description}
                    onChange={(e) => setNewFieldForm({...newFieldForm, description: e?.target?.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm resize-none"
                    rows={2}
                    placeholder="Field description (optional)"
                  />
                </div>

                {/* Constraints */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Constraints
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {constraintOptions?.map((constraint) => (
                      <label key={constraint?.value} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newFieldForm?.constraints?.includes(constraint?.value)}
                          onChange={(e) => handleConstraintChange(constraint?.value, e?.target?.checked)}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-sm text-gray-700">{constraint?.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setNewFieldForm({
                      name: '', display_name: '', data_type: 'text', constraints: [],
                      is_nullable: true, description: '', default_value: '', max_length: '', precision_scale: ''
                    })}
                    className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
                  >
                    Clear
                  </button>
                  <button
                    type="submit"
                    className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
                  >
                    Add Field
                  </button>
                </div>
              </form>
            </div>

            {/* Fields list */}
            <div className="divide-y divide-gray-200">
              {selectedTable?.table_fields?.sort((a, b) => (a?.sort_order || 0) - (b?.sort_order || 0))?.map((field) => (
                <div key={field?.id} className="p-3 hover:bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <GripVertical className="w-4 h-4 text-gray-400" />
                      <div className={`w-3 h-3 rounded-full ${
                        field?.constraints?.includes('primary_key') ? 'bg-yellow-500' :
                        field?.constraints?.includes('foreign_key') ? 'bg-blue-500' :
                        field?.constraints?.includes('unique') ? 'bg-green-500' :
                        'bg-gray-300'
                      }`} />
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-medium text-gray-900">
                            {field?.display_name || field?.name}
                          </span>
                          <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                            {field?.data_type}
                          </span>
                          {!field?.is_nullable && (
                            <span className="text-red-600 text-xs">*</span>
                          )}
                        </div>
                        {field?.description && (
                          <p className="text-sm text-gray-500 mt-1">{field?.description}</p>
                        )}
                        {field?.constraints?.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {field?.constraints?.map((constraint) => (
                              <span key={constraint} className="text-xs bg-blue-100 text-blue-700 px-1 py-0.5 rounded">
                                {constraintOptions?.find(c => c?.value === constraint)?.label}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => setEditingField(field?.id)}
                        className="p-1 text-gray-600 hover:bg-gray-100 rounded"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteField(field?.id)}
                        className="p-1 text-red-600 hover:bg-red-50 rounded"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              {(!selectedTable?.table_fields || selectedTable?.table_fields?.length === 0) && (
                <div className="p-6 text-center text-gray-500">
                  <Plus className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm">No fields yet</p>
                  <p className="text-xs text-gray-400">Add your first field above</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Empty state */}
        {tables?.length === 0 && (
          <div className="p-6 text-center text-gray-500">
            <Plus className="w-12 h-12 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No tables yet</h3>
            <p className="text-sm text-gray-500 mb-4">
              Create your first database table to get started
            </p>
            <button
              onClick={() => setIsCreatingTable(true)}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Table
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default TablePropertiesPanel;