import React, { useEffect } from 'react';

const QueryBuilder = () => {
  React.useEffect(() => {
    // eslint-disable-next-line no-console
    console.warn('Placeholder: QueryBuilder is not implemented yet.');
  }, []);
  return (
    <>
  { /*QueryBuilder */} 
 </>
  );
};

export default QueryBuilder;
