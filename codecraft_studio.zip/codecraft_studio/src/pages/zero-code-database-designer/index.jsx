import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import databaseDesignerService from '../../services/databaseDesignerService';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import SchemaSelector from './components/SchemaSelector';
import CanvasWorkspace from './components/CanvasWorkspace';
import TablePropertiesPanel from './components/TablePropertiesPanel';
import RelationshipPanel from './components/RelationshipPanel';
import QueryBuilder from './components/QueryBuilder';
import SampleDataGenerator from './components/SampleDataGenerator';
import DatabasePreview from './components/DatabasePreview';
import SQLExporter from './components/SQLExporter';
import SmartSuggestions from './components/SmartSuggestions';
import { Database, Table, Zap, Eye, Download, Lightbulb, Plus } from 'lucide-react';

const ZeroCodeDatabaseDesigner = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Core state
  const [schemas, setSchemas] = useState([]);
  const [currentSchema, setCurrentSchema] = useState(null);
  const [tables, setTables] = useState([]);
  const [relationships, setRelationships] = useState([]);
  const [selectedTable, setSelectedTable] = useState(null);
  
  // UI state
  const [activePanel, setActivePanel] = useState('tables'); // tables, relationships, queries, data, preview, sql
  const [canvasState, setCanvasState] = useState({ zoom: 1, panX: 0, panY: 0 });
  const [isDragMode, setIsDragMode] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);

  // Load initial data
  useEffect(() => {
    if (user) {
      loadSchemas();
    }
  }, [user]);

  const loadSchemas = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await databaseDesignerService?.getDatabaseSchemas();
      if (result?.success) {
        setSchemas(result?.data || []);
        if (result?.data?.length > 0 && !currentSchema) {
          setCurrentSchema(result?.data?.[0]);
          loadSchemaData(result?.data?.[0]?.id);
        }
      } else {
        setError(result?.error || 'Failed to load schemas');
      }
    } catch (err) {
      setError('Failed to load schemas');
      console.error('Load schemas error:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadSchemaData = async (schemaId) => {
    try {
      const [tablesResult, relationshipsResult] = await Promise.all([
        databaseDesignerService?.getDatabaseTables(schemaId),
        databaseDesignerService?.getTableRelationships(schemaId)
      ]);

      if (tablesResult?.success) {
        setTables(tablesResult?.data || []);
      }
      
      if (relationshipsResult?.success) {
        setRelationships(relationshipsResult?.data || []);
      }
    } catch (err) {
      setError('Failed to load schema data');
      console.error('Load schema data error:', err);
    }
  };

  const handleSchemaChange = (schema) => {
    setCurrentSchema(schema);
    setSelectedTable(null);
    if (schema) {
      loadSchemaData(schema?.id);
    }
  };

  const handleCreateTable = async (tableData) => {
    try {
      const result = await databaseDesignerService?.createDatabaseTable({
        ...tableData,
        schema_id: currentSchema?.id
      });
      
      if (result?.success) {
        setTables(prev => [...prev, result?.data]);
        setSelectedTable(result?.data);
      } else {
        setError(result?.error || 'Failed to create table');
      }
    } catch (err) {
      setError('Failed to create table');
      console.error('Create table error:', err);
    }
  };

  const handleUpdateTable = async (tableId, updates) => {
    try {
      const result = await databaseDesignerService?.updateDatabaseTable(tableId, updates);
      
      if (result?.success) {
        setTables(prev => prev?.map(table => 
          table?.id === tableId ? { ...table, ...result?.data } : table
        ));
        if (selectedTable?.id === tableId) {
          setSelectedTable({ ...selectedTable, ...result?.data });
        }
      } else {
        setError(result?.error || 'Failed to update table');
      }
    } catch (err) {
      setError('Failed to update table');
      console.error('Update table error:', err);
    }
  };

  const handleDeleteTable = async (tableId) => {
    try {
      const result = await databaseDesignerService?.deleteDatabaseTable(tableId);
      
      if (result?.success) {
        setTables(prev => prev?.filter(table => table?.id !== tableId));
        if (selectedTable?.id === tableId) {
          setSelectedTable(null);
        }
      } else {
        setError(result?.error || 'Failed to delete table');
      }
    } catch (err) {
      setError('Failed to delete table');
      console.error('Delete table error:', err);
    }
  };

  const handleCreateRelationship = async (relationshipData) => {
    try {
      const result = await databaseDesignerService?.createTableRelationship({
        ...relationshipData,
        schema_id: currentSchema?.id
      });
      
      if (result?.success) {
        setRelationships(prev => [...prev, result?.data]);
      } else {
        setError(result?.error || 'Failed to create relationship');
      }
    } catch (err) {
      setError('Failed to create relationship');
      console.error('Create relationship error:', err);
    }
  };

  const handleSaveCanvasState = useCallback(async (newCanvasState) => {
    setCanvasState(newCanvasState);
    
    if (currentSchema) {
      try {
        await databaseDesignerService?.saveCanvasState(currentSchema?.id, newCanvasState);
      } catch (err) {
        console.error('Failed to save canvas state:', err);
      }
    }
  }, [currentSchema]);

  const sidebarItems = [
    { 
      id: 'tables', 
      label: 'Tables & Fields', 
      icon: Table, 
      active: activePanel === 'tables' 
    },
    { 
      id: 'relationships', 
      label: 'Relationships', 
      icon: Database, 
      active: activePanel === 'relationships' 
    },
    { 
      id: 'queries', 
      label: 'Query Builder', 
      icon: Zap, 
      active: activePanel === 'queries' 
    },
    { 
      id: 'data', 
      label: 'Sample Data', 
      icon: Plus, 
      active: activePanel === 'data' 
    },
    { 
      id: 'preview', 
      label: 'Live Preview', 
      icon: Eye, 
      active: activePanel === 'preview' 
    },
    { 
      id: 'sql', 
      label: 'Export SQL', 
      icon: Download, 
      active: activePanel === 'sql' 
    }
  ];

  const renderRightPanel = () => {
    switch (activePanel) {
      case 'tables':
        return (
          <TablePropertiesPanel
            tables={tables}
            selectedTable={selectedTable}
            onTableSelect={setSelectedTable}
            onCreateTable={handleCreateTable}
            onUpdateTable={handleUpdateTable}
            onDeleteTable={handleDeleteTable}
          />
        );
      case 'relationships':
        return (
          <RelationshipPanel
            tables={tables}
            relationships={relationships}
            onCreateRelationship={handleCreateRelationship}
          />
        );
      case 'queries':
        return (
          <QueryBuilder
            schema={currentSchema}
            tables={tables}
            relationships={relationships}
          />
        );
      case 'data':
        return (
          <SampleDataGenerator
            tables={tables}
            selectedTable={selectedTable}
          />
        );
      case 'preview':
        return (
          <DatabasePreview
            schema={currentSchema}
            tables={tables}
            relationships={relationships}
          />
        );
      case 'sql':
        return (
          <SQLExporter
            schema={currentSchema}
            tables={tables}
            relationships={relationships}
          />
        );
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading database designer...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md">
          <Database className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">Authentication Required</h2>
          <p className="text-gray-600 mb-6">Please sign in to use the Zero-Code Database Designer.</p>
          <a 
            href="/authentication-portal" 
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Sign In to Continue
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <div className="flex-1 flex">
        <Sidebar items={sidebarItems} onItemClick={setActivePanel} onToggleCollapse={() => {}} />
        
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* Top toolbar */}
          <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Database className="w-6 h-6 text-blue-600" />
              <h1 className="text-xl font-semibold text-gray-900">Zero-Code Database Designer</h1>
              
              <SchemaSelector
                schemas={schemas}
                currentSchema={currentSchema}
                onSchemaChange={handleSchemaChange}
                onRefresh={loadSchemas}
              />
            </div>
            
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowSuggestions(!showSuggestions)}
                className={`p-2 rounded-lg transition-colors ${
                  showSuggestions 
                    ? 'bg-yellow-100 text-yellow-700' :'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
                title="Smart Suggestions"
              >
                <Lightbulb className="w-5 h-5" />
              </button>
              
              <button
                onClick={() => setIsDragMode(!isDragMode)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isDragMode 
                    ? 'bg-blue-100 text-blue-700' :'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {isDragMode ? 'Exit Drag Mode' : 'Drag Mode'}
              </button>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border-l-4 border-red-400 px-4 py-3 mx-6 mt-4">
              <div className="flex">
                <div className="ml-3">
                  <p className="text-sm text-red-700">{error}</p>
                  <button 
                    onClick={() => setError(null)}
                    className="text-red-600 hover:text-red-800 underline text-xs mt-1"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Main content */}
          <div className="flex-1 flex">
            {/* Canvas workspace */}
            <div className="flex-1 relative">
              <CanvasWorkspace
                tables={tables}
                relationships={relationships}
                selectedTable={selectedTable}
                onTableSelect={setSelectedTable}
                onTableUpdate={handleUpdateTable}
                canvasState={canvasState}
                onCanvasStateChange={handleSaveCanvasState}
                isDragMode={isDragMode}
              />
              
              {showSuggestions && (
                <div className="absolute top-4 right-4 z-20">
                  <SmartSuggestions
                    schema={currentSchema}
                    tables={tables}
                    onSuggestionApply={(suggestion) => {
                      // Handle applying suggestions
                      console.log('Applying suggestion:', suggestion);
                      setShowSuggestions(false);
                    }}
                  />
                </div>
              )}
            </div>

            {/* Right panel */}
            <div className="w-80 bg-white border-l border-gray-200 flex flex-col">
              {renderRightPanel()}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ZeroCodeDatabaseDesigner;