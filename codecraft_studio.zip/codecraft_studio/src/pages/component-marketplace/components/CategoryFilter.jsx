import React from 'react';
import Icon from '../../../components/AppIcon';

const CategoryFilter = ({ categories, selectedCategory, onCategoryChange }) => {
  const getCategoryIcon = (category) => {
    const iconMap = {
      'All': 'Grid3X3',
      'Form Elements': 'FileText',
      'Data Visualization': 'BarChart3',
      'E-commerce': 'ShoppingBag',
      'Integrations': 'Plug',
      'UI Kits': 'Palette',
      'Navigation': 'Menu',
      'Media': 'Image',
      'Analytics': 'TrendingUp'
    };
    return iconMap?.[category] || 'Package';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 shadow-elevation-1">
      <h3 className="font-semibold text-foreground mb-4 flex items-center space-x-2">
        <Icon name="Filter" size={16} />
        <span>Categories</span>
      </h3>
      <div className="space-y-2">
        {categories?.map((category) => (
          <button
            key={category?.name}
            onClick={() => onCategoryChange(category?.name)}
            className={`w-full flex items-center justify-between p-3 rounded-md text-sm font-medium transition-quick hover-lift ${
              selectedCategory === category?.name
                ? 'bg-primary text-primary-foreground shadow-elevation-1'
                : 'text-foreground hover:bg-muted'
            }`}
          >
            <div className="flex items-center space-x-3">
              <Icon name={getCategoryIcon(category?.name)} size={16} />
              <span>{category?.name}</span>
            </div>
            <span className={`text-xs px-2 py-1 rounded-full ${
              selectedCategory === category?.name
                ? 'bg-primary-foreground/20 text-primary-foreground'
                : 'bg-muted text-muted-foreground'
            }`}>
              {category?.count}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default CategoryFilter;