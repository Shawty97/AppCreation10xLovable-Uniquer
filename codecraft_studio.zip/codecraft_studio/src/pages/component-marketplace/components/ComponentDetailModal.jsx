import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const ComponentDetailModal = ({ component, isOpen, onClose, onAddToCart }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedImage, setSelectedImage] = useState(0);

  if (!isOpen || !component) return null;

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'Info' },
    { id: 'demo', label: 'Live Demo', icon: 'Play' },
    { id: 'documentation', label: 'Documentation', icon: 'FileText' },
    { id: 'reviews', label: 'Reviews', icon: 'MessageSquare' }
  ];

  const mockReviews = [
    {
      id: 1,
      user: "Sarah Johnson",
      avatar: "SJ",
      rating: 5,
      date: "2025-09-28",
      comment: "Excellent component! Easy to integrate and works perfectly with our React app. The documentation is clear and comprehensive."
    },
    {
      id: 2,
      user: "Mike Chen",
      avatar: "MC",
      rating: 4,
      date: "2025-09-25",
      comment: "Great functionality and design. Would love to see more customization options in future updates."
    },
    {
      id: 3,
      user: "Emily Rodriguez",
      avatar: "ER",
      rating: 5,
      date: "2025-09-22",
      comment: "This component saved us weeks of development time. Highly recommended for any e-commerce project."
    }
  ];

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Icon
        key={i}
        name="Star"
        size={14}
        color={i < Math.floor(rating) ? '#F59E0B' : '#E5E7EB'}
        className={i < Math.floor(rating) ? 'fill-current' : ''}
      />
    ));
  };

  const formatPrice = (price) => {
    if (price === 0) return 'Free';
    return `$${price}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      {/* Modal */}
      <div className="relative w-full max-w-6xl max-h-[90vh] bg-card border border-border rounded-lg shadow-elevation-3 overflow-hidden animate-scale-in">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center">
              <Icon name="Package" size={24} color="var(--color-muted-foreground)" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">{component?.name}</h2>
              <p className="text-sm text-muted-foreground">by {component?.developer}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="text-right">
              <div className="text-2xl font-bold text-foreground">
                {formatPrice(component?.price)}
              </div>
              {component?.subscriptionType && (
                <div className="text-sm text-muted-foreground">
                  /{component?.subscriptionType}
                </div>
              )}
            </div>
            <Button
              variant="ghost"
              size="icon"
              iconName="X"
              iconSize={20}
              onClick={onClose}
            />
          </div>
        </div>

        {/* Content */}
        <div className="flex h-[calc(90vh-120px)]">
          {/* Left Panel - Image Gallery */}
          <div className="w-1/2 p-6 border-r border-border">
            <div className="space-y-4">
              {/* Main Image */}
              <div className="aspect-video bg-muted rounded-lg overflow-hidden">
                <Image
                  src={component?.previewImages?.[selectedImage] || component?.previewImage}
                  alt={`${component?.name} preview ${selectedImage + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Thumbnail Gallery */}
              {component?.previewImages && component?.previewImages?.length > 1 && (
                <div className="flex space-x-2 overflow-x-auto">
                  {component?.previewImages?.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImage(index)}
                      className={`flex-shrink-0 w-16 h-16 rounded-md overflow-hidden border-2 transition-quick ${
                        selectedImage === index
                          ? 'border-primary' :'border-border hover:border-muted-foreground'
                      }`}
                    >
                      <Image
                        src={image}
                        alt={`Preview ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right Panel - Details */}
          <div className="w-1/2 flex flex-col">
            {/* Tabs */}
            <div className="flex border-b border-border">
              {tabs?.map((tab) => (
                <button
                  key={tab?.id}
                  onClick={() => setActiveTab(tab?.id)}
                  className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium transition-quick ${
                    activeTab === tab?.id
                      ? 'text-primary border-b-2 border-primary' :'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Icon name={tab?.icon} size={16} />
                  <span>{tab?.label}</span>
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="flex-1 p-6 overflow-y-auto">
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">Description</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {component?.longDescription || component?.description}
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-foreground mb-3">Features</h3>
                    <ul className="space-y-2">
                      {component?.features?.map((feature, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <Icon name="Check" size={16} color="var(--color-success)" className="mt-0.5 flex-shrink-0" />
                          <span className="text-muted-foreground">{feature}</span>
                        </li>
                      )) || [
                        "Fully responsive design",
                        "TypeScript support",
                        "Customizable themes",
                        "Accessibility compliant",
                        "Comprehensive documentation"
                      ]?.map((feature, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <Icon name="Check" size={16} color="var(--color-success)" className="mt-0.5 flex-shrink-0" />
                          <span className="text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-foreground mb-3">Technical Requirements</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Icon name="Code" size={16} color="var(--color-muted-foreground)" />
                        <span className="text-muted-foreground">React 18+</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Icon name="Package" size={16} color="var(--color-muted-foreground)" />
                        <span className="text-muted-foreground">Node.js 16+</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Icon name="Palette" size={16} color="var(--color-muted-foreground)" />
                        <span className="text-muted-foreground">Tailwind CSS 3.x</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold text-foreground mb-3">Tags</h3>
                    <div className="flex flex-wrap gap-2">
                      {component?.tags?.map((tag, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 bg-muted text-muted-foreground text-sm rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'demo' && (
                <div className="space-y-4">
                  <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                    <div className="text-center space-y-3">
                      <Icon name="Play" size={48} color="var(--color-muted-foreground)" />
                      <p className="text-muted-foreground">Interactive demo would be embedded here</p>
                      <Button variant="outline" iconName="ExternalLink" iconPosition="left">
                        Open in New Tab
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'documentation' && (
                <div className="space-y-4">
                  <div className="prose prose-sm max-w-none">
                    <h3>Installation</h3>
                    <div className="bg-muted p-4 rounded-md font-mono text-sm">
                      npm install @marketplace/{component?.name?.toLowerCase()?.replace(/\s+/g, '-')}
                    </div>
                    
                    <h3>Basic Usage</h3>
                    <div className="bg-muted p-4 rounded-md font-mono text-sm">
                      {`import { ${component?.name?.replace(/\s+/g, '')} } from '@marketplace/${component?.name?.toLowerCase()?.replace(/\s+/g, '-')}';

function App() {
  return (
    <${component?.name?.replace(/\s+/g, '')} 
      // Add your props here
    />
  );
}`}
                    </div>
                    
                    <h3>Props</h3>
                    <p>Detailed API documentation would be displayed here with prop types, default values, and examples.</p>
                  </div>
                </div>
              )}

              {activeTab === 'reviews' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center space-x-2">
                        <div className="flex items-center space-x-1">
                          {renderStars(component?.rating)}
                        </div>
                        <span className="text-lg font-semibold text-foreground">
                          {component?.rating}
                        </span>
                        <span className="text-muted-foreground">
                          ({component?.reviewCount} reviews)
                        </span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" iconName="Plus" iconPosition="left">
                      Write Review
                    </Button>
                  </div>

                  <div className="space-y-4">
                    {mockReviews?.map((review) => (
                      <div key={review?.id} className="border border-border rounded-lg p-4">
                        <div className="flex items-start space-x-3">
                          <div className="w-10 h-10 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-medium">
                            {review?.avatar}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-2">
                              <div>
                                <h4 className="font-medium text-foreground">{review?.user}</h4>
                                <div className="flex items-center space-x-2">
                                  <div className="flex items-center space-x-1">
                                    {renderStars(review?.rating)}
                                  </div>
                                  <span className="text-sm text-muted-foreground">{review?.date}</span>
                                </div>
                              </div>
                            </div>
                            <p className="text-muted-foreground">{review?.comment}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="p-6 border-t border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-1">
                    <Icon name="Download" size={16} color="var(--color-muted-foreground)" />
                    <span className="text-sm text-muted-foreground">
                      {component?.downloads?.toLocaleString()} downloads
                    </span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Clock" size={16} color="var(--color-muted-foreground)" />
                    <span className="text-sm text-muted-foreground">
                      Updated {component?.lastUpdated}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Button
                    variant="outline"
                    iconName="Heart"
                    iconPosition="left"
                    iconSize={16}
                  >
                    Save
                  </Button>
                  <Button
                    variant="default"
                    iconName="ShoppingCart"
                    iconPosition="left"
                    iconSize={16}
                    onClick={() => onAddToCart(component)}
                  >
                    Add to Cart
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComponentDetailModal;