import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ComponentCard = ({ component, onPreview, onAddToCart, onViewDetails }) => {
  const [isHovered, setIsHovered] = useState(false);

  const formatPrice = (price) => {
    if (price === 0) return 'Free';
    if (price < 100) return `$${price}`;
    return `$${price?.toLocaleString()}`;
  };

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Icon
        key={i}
        name="Star"
        size={12}
        color={i < Math.floor(rating) ? '#F59E0B' : '#E5E7EB'}
        className={i < Math.floor(rating) ? 'fill-current' : ''}
      />
    ));
  };

  return (
    <div
      className="bg-card border border-border rounded-lg shadow-elevation-1 hover:shadow-elevation-2 transition-all duration-300 hover-lift overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Component Preview */}
      <div className="relative aspect-video bg-muted overflow-hidden">
        <Image
          src={component?.previewImage}
          alt={component?.name}
          className="w-full h-full object-cover"
        />
        
        {/* Overlay Actions */}
        {isHovered && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center space-x-2 animate-fade-in">
            <Button
              variant="secondary"
              size="sm"
              iconName="Eye"
              iconPosition="left"
              iconSize={14}
              onClick={() => onPreview(component)}
              className="bg-white/90 text-gray-900 hover:bg-white"
            >
              Preview
            </Button>
            <Button
              variant="default"
              size="sm"
              iconName="ExternalLink"
              iconPosition="left"
              iconSize={14}
              onClick={() => onViewDetails(component)}
            >
              Details
            </Button>
          </div>
        )}

        {/* Category Badge */}
        <div className="absolute top-2 left-2">
          <span className="px-2 py-1 bg-primary text-primary-foreground text-xs font-medium rounded-md">
            {component?.category}
          </span>
        </div>

        {/* Featured Badge */}
        {component?.featured && (
          <div className="absolute top-2 right-2">
            <div className="bg-accent text-accent-foreground px-2 py-1 rounded-md flex items-center space-x-1">
              <Icon name="Star" size={12} className="fill-current" />
              <span className="text-xs font-medium">Featured</span>
            </div>
          </div>
        )}
      </div>
      {/* Component Info */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-semibold text-foreground text-sm line-clamp-1">
            {component?.name}
          </h3>
          <div className="flex items-center space-x-1 ml-2">
            {renderStars(component?.rating)}
            <span className="text-xs text-muted-foreground ml-1">
              ({component?.reviewCount})
            </span>
          </div>
        </div>

        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
          {component?.description}
        </p>

        {/* Developer Info */}
        <div className="flex items-center space-x-2 mb-3">
          <div className="w-6 h-6 bg-muted rounded-full flex items-center justify-center">
            <Icon name="User" size={12} color="var(--color-muted-foreground)" />
          </div>
          <span className="text-xs text-muted-foreground">{component?.developer}</span>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1 mb-3">
          {component?.tags?.slice(0, 3)?.map((tag, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded-md"
            >
              {tag}
            </span>
          ))}
          {component?.tags?.length > 3 && (
            <span className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded-md">
              +{component?.tags?.length - 3}
            </span>
          )}
        </div>

        {/* Price and Actions */}
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-lg font-bold text-foreground">
              {formatPrice(component?.price)}
            </span>
            {component?.subscriptionType && (
              <span className="text-xs text-muted-foreground">
                /{component?.subscriptionType}
              </span>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              iconName="ShoppingCart"
              iconSize={14}
              onClick={() => onAddToCart(component)}
              className="hover-lift"
            />
            <Button
              variant="default"
              size="sm"
              onClick={() => onViewDetails(component)}
              className="hover-lift"
            >
              View
            </Button>
          </div>
        </div>

        {/* Download Count */}
        <div className="flex items-center justify-between mt-2 pt-2 border-t border-border">
          <div className="flex items-center space-x-1">
            <Icon name="Download" size={12} color="var(--color-muted-foreground)" />
            <span className="text-xs text-muted-foreground">
              {component?.downloads?.toLocaleString()} downloads
            </span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Clock" size={12} color="var(--color-muted-foreground)" />
            <span className="text-xs text-muted-foreground">
              Updated {component?.lastUpdated}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComponentCard;