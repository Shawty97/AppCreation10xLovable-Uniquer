import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const SearchAndFilters = ({ onSearch, onFilterChange, filters }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  const priceRangeOptions = [
    { value: 'all', label: 'All Prices' },
    { value: 'free', label: 'Free' },
    { value: '0-50', label: '$0 - $50' },
    { value: '50-100', label: '$50 - $100' },
    { value: '100+', label: '$100+' }
  ];

  const sortOptions = [
    { value: 'popular', label: 'Most Popular' },
    { value: 'newest', label: 'Newest First' },
    { value: 'rating', label: 'Highest Rated' },
    { value: 'price-low', label: 'Price: Low to High' },
    { value: 'price-high', label: 'Price: High to Low' },
    { value: 'downloads', label: 'Most Downloaded' }
  ];

  const compatibilityOptions = [
    { value: 'all', label: 'All Versions' },
    { value: 'react-18', label: 'React 18+' },
    { value: 'react-17', label: 'React 17+' },
    { value: 'typescript', label: 'TypeScript Support' }
  ];

  const ratingOptions = [
    { value: 'all', label: 'All Ratings' },
    { value: '4+', label: '4+ Stars' },
    { value: '3+', label: '3+ Stars' },
    { value: '2+', label: '2+ Stars' }
  ];

  const handleSearchChange = (e) => {
    const value = e?.target?.value;
    setSearchQuery(value);
    onSearch(value);
  };

  const handleFilterChange = (filterType, value) => {
    onFilterChange(filterType, value);
  };

  const clearAllFilters = () => {
    setSearchQuery('');
    onSearch('');
    onFilterChange('reset', null);
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 shadow-elevation-1 space-y-4">
      {/* Search Bar */}
      <div className="relative">
        <Input
          type="search"
          placeholder="Search components, features, or developers..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="pl-10"
        />
        <Icon
          name="Search"
          size={16}
          className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
        />
      </div>
      {/* Quick Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <Select
          options={sortOptions}
          value={filters?.sort}
          onChange={(value) => handleFilterChange('sort', value)}
          placeholder="Sort by"
          className="min-w-[140px]"
        />
        
        <Select
          options={priceRangeOptions}
          value={filters?.priceRange}
          onChange={(value) => handleFilterChange('priceRange', value)}
          placeholder="Price range"
          className="min-w-[120px]"
        />

        <Button
          variant="outline"
          size="sm"
          iconName={showAdvancedFilters ? 'ChevronUp' : 'ChevronDown'}
          iconPosition="right"
          iconSize={14}
          onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
        >
          Advanced
        </Button>

        {(filters?.priceRange !== 'all' || filters?.rating !== 'all' || filters?.compatibility !== 'all') && (
          <Button
            variant="ghost"
            size="sm"
            iconName="X"
            iconPosition="left"
            iconSize={14}
            onClick={clearAllFilters}
            className="text-muted-foreground hover:text-foreground"
          >
            Clear
          </Button>
        )}
      </div>
      {/* Advanced Filters */}
      {showAdvancedFilters && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4 border-t border-border animate-accordion-down">
          <Select
            label="Rating"
            options={ratingOptions}
            value={filters?.rating}
            onChange={(value) => handleFilterChange('rating', value)}
          />
          
          <Select
            label="Compatibility"
            options={compatibilityOptions}
            value={filters?.compatibility}
            onChange={(value) => handleFilterChange('compatibility', value)}
          />
          
          <div className="flex flex-col space-y-2">
            <label className="text-sm font-medium text-foreground">Update Frequency</label>
            <div className="flex flex-wrap gap-2">
              {['Recently Updated', 'Active Development', 'Stable Release']?.map((tag) => (
                <button
                  key={tag}
                  onClick={() => handleFilterChange('updateFrequency', tag)}
                  className={`px-3 py-1 text-xs rounded-full border transition-quick ${
                    filters?.updateFrequency === tag
                      ? 'bg-primary text-primary-foreground border-primary'
                      : 'bg-background text-foreground border-border hover:bg-muted'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
      {/* Active Filters Display */}
      {(searchQuery || filters?.priceRange !== 'all' || filters?.rating !== 'all') && (
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-border">
          <span className="text-sm text-muted-foreground">Active filters:</span>
          
          {searchQuery && (
            <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-md flex items-center space-x-1">
              <span>"{searchQuery}"</span>
              <button onClick={() => handleSearchChange({ target: { value: '' } })}>
                <Icon name="X" size={12} />
              </button>
            </span>
          )}
          
          {filters?.priceRange !== 'all' && (
            <span className="px-2 py-1 bg-accent/10 text-accent text-xs rounded-md flex items-center space-x-1">
              <span>{priceRangeOptions?.find(opt => opt?.value === filters?.priceRange)?.label}</span>
              <button onClick={() => handleFilterChange('priceRange', 'all')}>
                <Icon name="X" size={12} />
              </button>
            </span>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchAndFilters;