import React, { useState, useEffect } from 'react';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const FeaturedCarousel = ({ featuredComponents, onViewComponent }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    if (!isAutoPlaying || featuredComponents?.length <= 1) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % featuredComponents?.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, featuredComponents?.length]);

  const goToSlide = (index) => {
    setCurrentSlide(index);
    setIsAutoPlaying(false);
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % featuredComponents?.length);
    setIsAutoPlaying(false);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + featuredComponents?.length) % featuredComponents?.length);
    setIsAutoPlaying(false);
  };

  if (!featuredComponents?.length) return null;

  const currentComponent = featuredComponents?.[currentSlide];

  return (
    <div className="bg-card border border-border rounded-lg shadow-elevation-2 overflow-hidden">
      <div className="relative">
        {/* Main Slide */}
        <div className="relative aspect-[16/6] bg-gradient-to-r from-primary/10 to-accent/10">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full grid grid-cols-1 lg:grid-cols-2 gap-8 px-8">
              {/* Content */}
              <div className="flex flex-col justify-center space-y-4">
                <div className="flex items-center space-x-2">
                  <span className="px-3 py-1 bg-primary text-primary-foreground text-sm font-medium rounded-full">
                    Featured
                  </span>
                  <span className="px-3 py-1 bg-accent text-accent-foreground text-sm font-medium rounded-full">
                    {currentComponent?.category}
                  </span>
                </div>
                
                <h2 className="text-3xl font-bold text-foreground">
                  {currentComponent?.name}
                </h2>
                
                <p className="text-muted-foreground text-lg leading-relaxed">
                  {currentComponent?.description}
                </p>
                
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-1">
                    {Array.from({ length: 5 }, (_, i) => (
                      <Icon
                        key={i}
                        name="Star"
                        size={16}
                        color={i < Math.floor(currentComponent?.rating) ? '#F59E0B' : '#E5E7EB'}
                        className={i < Math.floor(currentComponent?.rating) ? 'fill-current' : ''}
                      />
                    ))}
                    <span className="text-sm text-muted-foreground ml-2">
                      {currentComponent?.rating} ({currentComponent?.reviewCount} reviews)
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    <Icon name="Download" size={16} color="var(--color-muted-foreground)" />
                    <span className="text-sm text-muted-foreground">
                      {currentComponent?.downloads?.toLocaleString()} downloads
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex flex-col">
                    <span className="text-2xl font-bold text-foreground">
                      {currentComponent?.price === 0 ? 'Free' : `$${currentComponent?.price}`}
                    </span>
                    {currentComponent?.subscriptionType && (
                      <span className="text-sm text-muted-foreground">
                        /{currentComponent?.subscriptionType}
                      </span>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Button
                      variant="outline"
                      iconName="Eye"
                      iconPosition="left"
                      iconSize={16}
                      onClick={() => onViewComponent(currentComponent)}
                    >
                      Preview
                    </Button>
                    <Button
                      variant="default"
                      iconName="ShoppingCart"
                      iconPosition="left"
                      iconSize={16}
                      onClick={() => onViewComponent(currentComponent)}
                    >
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Preview Image */}
              <div className="hidden lg:flex items-center justify-center">
                <div className="relative w-full max-w-md aspect-video rounded-lg overflow-hidden shadow-elevation-2">
                  <Image
                    src={currentComponent?.previewImage}
                    alt={currentComponent?.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Arrows */}
        {featuredComponents?.length > 1 && (
          <>
            <button
              onClick={prevSlide}
              className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-card/80 backdrop-blur-sm border border-border rounded-full flex items-center justify-center hover:bg-card transition-quick hover-lift"
            >
              <Icon name="ChevronLeft" size={20} />
            </button>
            <button
              onClick={nextSlide}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-card/80 backdrop-blur-sm border border-border rounded-full flex items-center justify-center hover:bg-card transition-quick hover-lift"
            >
              <Icon name="ChevronRight" size={20} />
            </button>
          </>
        )}

        {/* Slide Indicators */}
        {featuredComponents?.length > 1 && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center space-x-2">
            {featuredComponents?.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-2 h-2 rounded-full transition-quick ${
                  index === currentSlide
                    ? 'bg-primary' :'bg-muted-foreground/30 hover:bg-muted-foreground/50'
                }`}
              />
            ))}
          </div>
        )}

        {/* Auto-play Control */}
        <button
          onClick={() => setIsAutoPlaying(!isAutoPlaying)}
          className="absolute top-4 right-4 w-8 h-8 bg-card/80 backdrop-blur-sm border border-border rounded-full flex items-center justify-center hover:bg-card transition-quick"
        >
          <Icon name={isAutoPlaying ? 'Pause' : 'Play'} size={14} />
        </button>
      </div>
    </div>
  );
};

export default FeaturedCarousel;