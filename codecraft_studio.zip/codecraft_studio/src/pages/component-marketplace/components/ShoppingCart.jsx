import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const ShoppingCart = ({ isOpen, onClose, cartItems, onUpdateQuantity, onRemoveItem, onCheckout }) => {
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const subtotal = cartItems?.reduce((sum, item) => sum + (item?.price * item?.quantity), 0);
  const tax = subtotal * 0.08; // 8% tax
  const total = subtotal + tax;

  const handleCheckout = async () => {
    setIsProcessing(true);
    // Simulate checkout process
    setTimeout(() => {
      setIsProcessing(false);
      onCheckout();
    }, 2000);
  };

  const formatPrice = (price) => {
    if (price === 0) return 'Free';
    return `$${price?.toFixed(2)}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      {/* Cart Panel */}
      <div className="relative w-full max-w-md h-full bg-card border-l border-border shadow-elevation-3 animate-slide-in-right">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-lg font-semibold text-foreground flex items-center space-x-2">
            <Icon name="ShoppingCart" size={20} />
            <span>Shopping Cart</span>
            {cartItems?.length > 0 && (
              <span className="px-2 py-1 bg-primary text-primary-foreground text-xs rounded-full">
                {cartItems?.length}
              </span>
            )}
          </h2>
          <Button
            variant="ghost"
            size="icon"
            iconName="X"
            iconSize={20}
            onClick={onClose}
          />
        </div>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto">
          {cartItems?.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center space-y-4">
              <Icon name="ShoppingCart" size={48} color="var(--color-muted-foreground)" />
              <div>
                <h3 className="font-medium text-foreground mb-2">Your cart is empty</h3>
                <p className="text-sm text-muted-foreground">
                  Browse our marketplace to find amazing components
                </p>
              </div>
              <Button variant="outline" onClick={onClose}>
                Continue Shopping
              </Button>
            </div>
          ) : (
            <div className="p-6 space-y-4">
              {cartItems?.map((item) => (
                <div key={item?.id} className="flex items-start space-x-3 p-4 border border-border rounded-lg">
                  <div className="w-16 h-16 bg-muted rounded-md overflow-hidden flex-shrink-0">
                    <Image
                      src={item?.previewImage}
                      alt={item?.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-foreground text-sm line-clamp-1">
                      {item?.name}
                    </h3>
                    <p className="text-xs text-muted-foreground mb-2">
                      by {item?.developer}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => onUpdateQuantity(item?.id, Math.max(1, item?.quantity - 1))}
                          className="w-6 h-6 bg-muted rounded flex items-center justify-center hover:bg-muted-foreground/20 transition-quick"
                        >
                          <Icon name="Minus" size={12} />
                        </button>
                        <span className="text-sm font-medium text-foreground w-8 text-center">
                          {item?.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item?.id, item?.quantity + 1)}
                          className="w-6 h-6 bg-muted rounded flex items-center justify-center hover:bg-muted-foreground/20 transition-quick"
                        >
                          <Icon name="Plus" size={12} />
                        </button>
                      </div>
                      
                      <div className="text-right">
                        <div className="font-medium text-foreground">
                          {formatPrice(item?.price * item?.quantity)}
                        </div>
                        {item?.quantity > 1 && (
                          <div className="text-xs text-muted-foreground">
                            {formatPrice(item?.price)} each
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => onRemoveItem(item?.id)}
                    className="p-1 text-muted-foreground hover:text-error transition-quick"
                  >
                    <Icon name="Trash2" size={16} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {cartItems?.length > 0 && (
          <div className="border-t border-border p-6 space-y-4">
            {/* Price Breakdown */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="text-foreground">{formatPrice(subtotal)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Tax</span>
                <span className="text-foreground">{formatPrice(tax)}</span>
              </div>
              <div className="flex items-center justify-between text-lg font-semibold border-t border-border pt-2">
                <span className="text-foreground">Total</span>
                <span className="text-foreground">{formatPrice(total)}</span>
              </div>
            </div>

            {/* License Info */}
            <div className="bg-muted/50 p-3 rounded-md">
              <div className="flex items-start space-x-2">
                <Icon name="Info" size={16} color="var(--color-muted-foreground)" className="mt-0.5 flex-shrink-0" />
                <div className="text-xs text-muted-foreground">
                  <p className="font-medium mb-1">License Terms</p>
                  <p>Components include lifetime updates and commercial use rights. No attribution required.</p>
                </div>
              </div>
            </div>

            {/* Checkout Button */}
            <Button
              variant="default"
              fullWidth
              loading={isProcessing}
              iconName="CreditCard"
              iconPosition="left"
              iconSize={16}
              onClick={handleCheckout}
              disabled={isProcessing}
            >
              {isProcessing ? 'Processing...' : 'Proceed to Checkout'}
            </Button>

            {/* Payment Methods */}
            <div className="flex items-center justify-center space-x-2 text-xs text-muted-foreground">
              <Icon name="CreditCard" size={14} />
              <span>Secure payment with Stripe</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ShoppingCart;