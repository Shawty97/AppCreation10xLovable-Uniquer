import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import ComponentCard from './components/ComponentCard';
import CategoryFilter from './components/CategoryFilter';
import SearchAndFilters from './components/SearchAndFilters';
import FeaturedCarousel from './components/FeaturedCarousel';
import ComponentDetailModal from './components/ComponentDetailModal';
import ShoppingCart from './components/ShoppingCart';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import { componentService } from '../../services/componentService';

const ComponentMarketplace = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    sort: 'popular',
    priceRange: 'all',
    rating: 'all',
    compatibility: 'all',
    updateFrequency: null
  });
  const [selectedComponent, setSelectedComponent] = useState(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const componentsPerPage = 12;

  // Real data state
  const [components, setComponents] = useState([]);
  const [featuredComponents, setFeaturedComponents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [categories, setCategories] = useState([
    { name: 'All', count: 0 }
  ]);

  // Load components data
  useEffect(() => {
    loadComponents();
  }, []);

  useEffect(() => {
    if (searchQuery || selectedCategory !== 'All') {
      searchComponents();
    }
  }, [searchQuery, selectedCategory, filters]);

  const loadComponents = async () => {
    setLoading(true);
    setError('');

    try {
      // Load all components
      const { data: allComponents, error: allError } = await componentService?.getAll(100);
      
      // Load featured components
      const { data: featured, error: featuredError } = await componentService?.getFeatured(10);

      if (allError || featuredError) {
        setError('Failed to load components');
      } else {
        setComponents(allComponents || []);
        setFeaturedComponents(featured || []);
        
        // Calculate categories with counts
        const categoryMap = new Map();
        categoryMap?.set('All', allComponents?.length || 0);
        
        allComponents?.forEach(component => {
          const category = component?.products?.category || 'Other';
          categoryMap?.set(category, (categoryMap?.get(category) || 0) + 1);
        });

        const categoriesArray = Array.from(categoryMap?.entries())?.map(([name, count]) => ({
          name, count
        }));

        setCategories(categoriesArray);
      }
    } catch (err) {
      setError('Failed to load components');
    } finally {
      setLoading(false);
    }
  };

  const searchComponents = async () => {
    setLoading(true);
    setError('');

    try {
      const searchFilters = {
        category: selectedCategory === 'All' ? null : selectedCategory,
        sort: filters?.sort,
        priceRange: filters?.priceRange,
        license: filters?.license
      };

      const { data, error } = await componentService?.search(searchQuery, searchFilters);

      if (error) {
        setError('Failed to search components');
      } else {
        setComponents(data || []);
      }
    } catch (err) {
      setError('Failed to search components');
    } finally {
      setLoading(false);
    }
  };

  // Transform components for display
  const displayComponents = components?.map(component => ({
    id: component?.id,
    name: component?.component_name,
    description: component?.component_description,
    category: component?.products?.category || 'Other',
    developer: component?.user_profiles?.full_name || 'Anonymous',
    price: component?.products?.price || 0,
    rating: component?.rating || 0,
    reviewCount: Math.floor(Math.random() * 500) + 50, // Mock review count
    downloads: component?.downloads_count || 0,
    lastUpdated: new Date(component?.updated_at)?.toLocaleDateString(),
    featured: component?.is_featured,
    tags: component?.tags || [],
    tech_stack: component?.tech_stack || [],
    previewImage: `https://images.unsplash.com/photo-${Math.random() > 0.5 ? '1551288049-bebda4e38f71' : '1460925895917-afdab827c52f'}?w=400&h=300&fit=crop`,
    license_type: component?.license_type,
    preview_url: component?.preview_url,
    download_url: component?.download_url
  })) || [];

  // Pagination
  const totalPages = Math.ceil(displayComponents?.length / componentsPerPage);
  const paginatedComponents = displayComponents?.slice(
    (currentPage - 1) * componentsPerPage,
    currentPage * componentsPerPage
  );

  // Featured components
  const featuredComponentsList = featuredComponents?.map(component => ({
    id: component?.id,
    name: component?.component_name,
    description: component?.component_description,
    price: component?.products?.price || 0,
    rating: component?.rating || 0,
    downloads: component?.downloads_count || 0,
    previewImage: `https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop`,
    developer: component?.user_profiles?.full_name || 'Anonymous',
    featured: component?.is_featured
  })) || [];

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    setCurrentPage(1);
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
    setCurrentPage(1);
  };

  const handleFilterChange = (filterType, value) => {
    if (filterType === 'reset') {
      setFilters({
        sort: 'popular',
        priceRange: 'all',
        rating: 'all',
        compatibility: 'all',
        updateFrequency: null
      });
    } else {
      setFilters(prev => ({ ...prev, [filterType]: value }));
    }
    setCurrentPage(1);
  };

  const handlePreviewComponent = (component) => {
    setSelectedComponent(component);
    setIsDetailModalOpen(true);
  };

  const handleViewDetails = (component) => {
    setSelectedComponent(component);
    setIsDetailModalOpen(true);
  };

  const handleAddToCart = (component) => {
    const existingItem = cartItems?.find(item => item?.id === component?.id);
    if (existingItem) {
      setCartItems(prev =>
        prev?.map(item =>
          item?.id === component?.id
            ? { ...item, quantity: item?.quantity + 1 }
            : item
        )
      );
    } else {
      setCartItems(prev => [...prev, { ...component, quantity: 1 }]);
    }
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (componentId, quantity) => {
    setCartItems(prev =>
      prev?.map(item =>
        item?.id === componentId
          ? { ...item, quantity }
          : item
      )
    );
  };

  const handleRemoveFromCart = (componentId) => {
    setCartItems(prev => prev?.filter(item => item?.id !== componentId));
  };

  const handleCheckout = () => {
    // Simulate checkout process
    alert('Checkout successful! Components have been added to your account.');
    setCartItems([]);
    setIsCartOpen(false);
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar 
        isCollapsed={isSidebarCollapsed} 
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)} 
      />
      {/* Main Content */}
      <main className={`pt-16 transition-all duration-300 ${
        isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'
      } pb-20 lg:pb-8`}>
        <div className="p-6 space-y-6">
          {/* Page Header */}
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Component Marketplace</h1>
              <p className="text-muted-foreground mt-2">
                Discover and integrate premium components to enhance your applications
              </p>
            </div>
            
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                iconName="ShoppingCart"
                iconPosition="left"
                iconSize={16}
                onClick={() => setIsCartOpen(true)}
                className="relative"
              >
                Cart
                {cartItems?.length > 0 && (
                  <span className="absolute -top-2 -right-2 w-5 h-5 bg-primary text-primary-foreground text-xs rounded-full flex items-center justify-center">
                    {cartItems?.length}
                  </span>
                )}
              </Button>
              <Button
                variant="default"
                iconName="Upload"
                iconPosition="left"
                iconSize={16}
              >
                Submit Component
              </Button>
            </div>
          </div>

          {/* Featured Components Carousel */}
          {featuredComponents?.length > 0 && (
            <FeaturedCarousel 
              featuredComponents={featuredComponents?.map(component => ({
                id: component?.id,
                name: component?.component_name,
                description: component?.component_description,
                price: component?.products?.price || 0,
                rating: component?.rating || 0,
                downloads: component?.downloads_count || 0,
                previewImage: `https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop`,
                developer: component?.user_profiles?.full_name || 'Anonymous'
              }))}
              onViewComponent={handleViewDetails}
            />
          )}

          {/* Search and Filters */}
          <SearchAndFilters
            onSearch={handleSearch}
            onFilterChange={handleFilterChange}
            filters={filters}
          />

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Sidebar Filters */}
            <div className="lg:col-span-1">
              <CategoryFilter
                categories={categories}
                selectedCategory={selectedCategory}
                onCategoryChange={handleCategoryChange}
              />
            </div>

            {/* Components Grid */}
            <div className="lg:col-span-3 space-y-6">
              {/* Results Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <h2 className="text-lg font-semibold text-foreground">
                    {selectedCategory === 'All' ? 'All Components' : selectedCategory}
                  </h2>
                  <span className="text-sm text-muted-foreground">
                    {displayComponents?.length} components found
                  </span>
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">View:</span>
                  <Button variant="ghost" size="icon" iconName="Grid3X3" iconSize={16} />
                  <Button variant="ghost" size="icon" iconName="List" iconSize={16} />
                </div>
              </div>

              {/* Error Display */}
              {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                  {error}
                  <button 
                    onClick={loadComponents}
                    className="ml-2 underline hover:no-underline"
                  >
                    Try Again
                  </button>
                </div>
              )}

              {/* Components Grid */}
              {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {[1, 2, 3, 4, 5, 6]?.map((i) => (
                    <div key={i} className="bg-white rounded-lg border p-6 animate-pulse">
                      <div className="aspect-video bg-gray-200 rounded mb-4"></div>
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                    </div>
                  ))}
                </div>
              ) : paginatedComponents?.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {paginatedComponents?.map((component) => (
                    <ComponentCard
                      key={component?.id}
                      component={component}
                      onPreview={handlePreviewComponent}
                      onAddToCart={handleAddToCart}
                      onViewDetails={handleViewDetails}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Icon name="Search" size={48} color="var(--color-muted-foreground)" className="mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">No components found</h3>
                  <p className="text-muted-foreground mb-4">
                    Try adjusting your search criteria or browse different categories
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('All');
                      handleFilterChange('reset', null);
                    }}
                  >
                    Clear Filters
                  </Button>
                </div>
              )}

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center space-x-2">
                  <Button
                    variant="outline"
                    size="icon"
                    iconName="ChevronLeft"
                    iconSize={16}
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                  />
                  
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    const page = i + 1;
                    return (
                      <Button
                        key={page}
                        variant={currentPage === page ? 'default' : 'outline'}
                        size="icon"
                        onClick={() => handlePageChange(page)}
                      >
                        {page}
                      </Button>
                    );
                  })}
                  
                  {totalPages > 5 && (
                    <>
                      <span className="text-muted-foreground">...</span>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handlePageChange(totalPages)}
                      >
                        {totalPages}
                      </Button>
                    </>
                  )}
                  
                  <Button
                    variant="outline"
                    size="icon"
                    iconName="ChevronRight"
                    iconSize={16}
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      {/* Component Detail Modal */}
      <ComponentDetailModal
        component={selectedComponent}
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        onAddToCart={handleAddToCart}
      />
      {/* Shopping Cart */}
      <ShoppingCart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveFromCart}
        onCheckout={handleCheckout}
      />
    </div>
  );
};

export default ComponentMarketplace;