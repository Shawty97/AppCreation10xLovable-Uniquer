import React, { useState, useEffect } from 'react';
import { paymentService } from '../../../services/paymentService';
import Button from '../../../components/ui/Button';

const RevenueTracker = ({ user, revenueStats, onRefresh }) => {
  const [revenueShares, setRevenueShares] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [timeFilter, setTimeFilter] = useState('all');

  useEffect(() => {
    loadRevenueShares();
  }, [user?.id]);

  const loadRevenueShares = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await paymentService?.getSellerRevenue(user?.id);
      setRevenueShares(data);
    } catch (error) {
      console.error('Error loading revenue shares:', error);
      setError('Failed to load revenue data.');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    })?.format(amount);
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'held':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredRevenueShares = revenueShares?.filter(share => {
    if (timeFilter === 'all') return true;
    
    const shareDate = new Date(share.created_at);
    const now = new Date();
    
    switch (timeFilter) {
      case 'week':
        return (now - shareDate) <= 7 * 24 * 60 * 60 * 1000;
      case 'month':
        return (now - shareDate) <= 30 * 24 * 60 * 60 * 1000;
      case 'quarter':
        return (now - shareDate) <= 90 * 24 * 60 * 60 * 1000;
      default:
        return true;
    }
  });

  if (!revenueStats) {
    return (
      <div className="text-center py-12">
        <div className="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center">
          <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
          </svg>
        </div>
        <h3 className="mt-4 text-lg font-medium text-gray-900">No revenue data</h3>
        <p className="mt-2 text-gray-500">Start selling components to track your revenue here.</p>
        <Button 
          variant="primary" 
          className="mt-4"
          onClick={() => window.location.href = '/component-marketplace'}
        >
          List Your Components
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Revenue Tracker</h2>
          <p className="text-gray-600">Monitor your earnings from component sales</p>
        </div>
        
        <Button
          variant="outline"
          onClick={() => {
            loadRevenueShares();
            onRefresh?.();
          }}
        >
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          Refresh
        </Button>
      </div>
      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          </div>
        </div>
      )}
      {/* Revenue Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                </svg>
              </div>
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Total Revenue</dt>
                <dd className="text-lg font-semibold text-gray-900">
                  {formatCurrency(revenueStats?.totalRevenue)}
                </dd>
              </dl>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Paid Revenue</dt>
                <dd className="text-lg font-semibold text-gray-900">
                  {formatCurrency(revenueStats?.paidRevenue)}
                </dd>
              </dl>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Pending Revenue</dt>
                <dd className="text-lg font-semibold text-gray-900">
                  {formatCurrency(revenueStats?.pendingRevenue)}
                </dd>
              </dl>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
                </svg>
              </div>
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Total Sales</dt>
                <dd className="text-lg font-semibold text-gray-900">
                  {revenueStats?.transactionCount}
                </dd>
              </dl>
            </div>
          </div>
        </div>
      </div>
      {/* Revenue Breakdown */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Breakdown</h3>
        
        <div className="space-y-4">
          <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg">
            <div>
              <p className="font-medium text-green-900">Available for Payout</p>
              <p className="text-sm text-green-700">Revenue ready to be transferred</p>
            </div>
            <div className="text-right">
              <p className="text-xl font-bold text-green-900">
                {formatCurrency(revenueStats?.paidRevenue)}
              </p>
              <p className="text-sm text-green-700">
                {((revenueStats?.paidRevenue / revenueStats?.totalRevenue) * 100 || 0)?.toFixed(1)}% of total
              </p>
            </div>
          </div>

          <div className="flex justify-between items-center p-4 bg-yellow-50 rounded-lg">
            <div>
              <p className="font-medium text-yellow-900">Processing</p>
              <p className="text-sm text-yellow-700">Revenue being processed (7-14 days)</p>
            </div>
            <div className="text-right">
              <p className="text-xl font-bold text-yellow-900">
                {formatCurrency(revenueStats?.pendingRevenue)}
              </p>
              <p className="text-sm text-yellow-700">
                {((revenueStats?.pendingRevenue / revenueStats?.totalRevenue) * 100 || 0)?.toFixed(1)}% of total
              </p>
            </div>
          </div>

          <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-900">Platform Fee (10%)</p>
              <p className="text-sm text-gray-700">Service fee for using the platform</p>
            </div>
            <div className="text-right">
              <p className="text-xl font-bold text-gray-900">
                {formatCurrency((revenueStats?.totalRevenue * 0.111) || 0)}
              </p>
              <p className="text-sm text-gray-700">Deducted from each sale</p>
            </div>
          </div>
        </div>
      </div>
      {/* Revenue History */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Revenue History</h3>
          
          <select
            value={timeFilter}
            onChange={(e) => setTimeFilter(e?.target?.value)}
            className="rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
          >
            <option value="all">All time</option>
            <option value="week">Last 7 days</option>
            <option value="month">Last 30 days</option>
            <option value="quarter">Last 90 days</option>
          </select>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[...Array(5)]?.map((_, i) => (
              <div key={i} className="animate-pulse flex space-x-4">
                <div className="h-12 w-12 bg-gray-200 rounded-lg"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
                <div className="h-4 bg-gray-200 rounded w-20"></div>
              </div>
            ))}
          </div>
        ) : filteredRevenueShares?.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No revenue transactions found for the selected period.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredRevenueShares?.map((share) => (
              <div key={share?.id} className="flex items-center justify-between py-4 border-b border-gray-100 last:border-b-0">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                    </svg>
                  </div>
                  
                  <div>
                    <p className="font-medium text-gray-900">
                      {share?.component_listings?.component_name || 'Component Sale'}
                    </p>
                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      <span>{formatDate(share?.created_at)}</span>
                      <span>•</span>
                      <span>Qty: {share?.order_items?.quantity || 1}</span>
                      <span>•</span>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(share?.status)}`}>
                        {share?.status?.charAt(0)?.toUpperCase() + share?.status?.slice(1)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="space-y-1">
                    <p className="font-semibold text-gray-900">
                      {formatCurrency(share?.seller_amount)}
                    </p>
                    <p className="text-xs text-gray-500">
                      From {formatCurrency(share?.gross_amount)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      {/* Payout Information */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <div className="flex">
          <div className="flex-shrink-0">
            <svg className="h-5 w-5 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
            </svg>
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-blue-800">Payout Information</h3>
            <div className="mt-1 text-sm text-blue-700 space-y-1">
              <p>• Payouts are processed monthly on the 1st of each month</p>
              <p>• Revenue is held for 14 days before becoming available for payout</p>
              <p>• Platform fee of 10% is deducted from each sale</p>
              <p>• Minimum payout threshold is $50</p>
              <p>• Payouts are sent via bank transfer or PayPal</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RevenueTracker;