import React, { useState, useEffect } from 'react';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { useStripeContext } from '../../../contexts/StripeContext';
import { paymentService } from '../../../services/paymentService';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const CheckoutForm = ({ clientSecret, orderData, onSuccess, onError }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [paymentReady, setPaymentReady] = useState(false);

  useEffect(() => {
    if (elements) {
      const paymentElement = elements?.getElement(PaymentElement);
      if (paymentElement) {
        paymentElement?.on('ready', () => {
          setPaymentReady(true);
        });
      }
    }
  }, [elements]);

  const handleSubmit = async (event) => {
    event?.preventDefault();

    if (!stripe || !elements || !clientSecret) {
      setErrorMessage('Payment system not ready. Please try again.');
      return;
    }

    setIsProcessing(true);
    setErrorMessage('');

    try {
      const { error: stripeError, paymentIntent } = await stripe?.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location?.origin}/payment-success`,
        },
        redirect: 'if_required'
      });

      if (stripeError) {
        setErrorMessage(stripeError?.message || 'Payment failed. Please try again.');
        onError?.(stripeError);
      } else if (paymentIntent?.status === 'succeeded') {
        const confirmResult = await paymentService?.confirmPayment(paymentIntent?.id);
        onSuccess?.(confirmResult);
      }
    } catch (error) {
      console.error('Payment processing error:', error);
      setErrorMessage('An unexpected error occurred. Please try again.');
      onError?.(error);
    } finally {
      setIsProcessing(false);
    }
  };

  if (!stripe || !elements || !clientSecret) {
    return (
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-1/4"></div>
          <div className="h-10 bg-gray-200 rounded"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          <div className="h-10 bg-gray-200 rounded"></div>
        </div>
        <p className="text-sm text-gray-500 mt-4 text-center">
          Loading payment system...
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">
              Payment Details
            </label>
            <PaymentElement 
              options={{
                fields: {
                  billingDetails: 'auto'
                },
                layout: 'tabs'
              }}
            />
          </div>
        </div>

        {errorMessage && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-800 text-sm">{errorMessage}</p>
          </div>
        )}

        <Button
          type="submit"
          disabled={!paymentReady || isProcessing || !stripe || !elements}
          className="w-full"
          variant="primary"
        >
          {isProcessing ? (
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Processing Payment...
            </div>
          ) : (
            `Pay ${paymentService?.formatAmount(orderData?.total || 0, orderData?.currency || 'USD')}`
          )}
        </Button>

        <div className="flex items-center justify-center space-x-2 text-xs text-gray-500">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.031 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
          </svg>
          <span>Secured by Stripe • Your payment information is encrypted</span>
        </div>
      </form>
    </div>
  );
};

const CheckoutInterface = ({ user, onOrderUpdate }) => {
  const { stripePromise, stripeOptions } = useStripeContext();
  const [cartItems, setCartItems] = useState([]);
  const [clientSecret, setClientSecret] = useState('');
  const [orderData, setOrderData] = useState(null);
  const [billingInfo, setBillingInfo] = useState({
    firstName: '',
    lastName: '',
    email: user?.email || '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'US'
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showCheckout, setShowCheckout] = useState(false);

  useEffect(() => {
    loadCartItems();
  }, [user?.id]);

  const loadCartItems = async () => {
    try {
      setLoading(true);
      // This would typically load from shopping cart table
      // For demo, using mock data
      const mockCartItems = [
        {
          id: '1',
          name: 'React Dashboard Template',
          price: 49.99,
          quantity: 1,
          license: 'unlimited'
        },
        {
          id: '2',
          name: 'Vue.js E-commerce Components',
          price: 29.99,
          quantity: 1,
          license: 'team'
        }
      ];
      setCartItems(mockCartItems);
    } catch (error) {
      console.error('Error loading cart items:', error);
      setError('Failed to load cart items.');
    } finally {
      setLoading(false);
    }
  };

  const calculateTotal = () => {
    const subtotal = cartItems?.reduce((sum, item) => sum + (item?.price * item?.quantity), 0);
    const tax = subtotal * 0.1; // 10% tax
    return {
      subtotal,
      tax,
      total: subtotal + tax
    };
  };

  const handleCreatePaymentIntent = async () => {
    try {
      setLoading(true);
      const totals = calculateTotal();
      
      const orderData = {
        items: cartItems,
        subtotal: totals?.subtotal,
        tax: totals?.tax,
        total: totals?.total,
        currency: 'USD'
      };

      const customerInfo = {
        userId: user?.id,
        firstName: billingInfo?.firstName,
        lastName: billingInfo?.lastName,
        email: billingInfo?.email,
        billing: {
          address_line_1: billingInfo?.address,
          city: billingInfo?.city,
          state: billingInfo?.state,
          postal_code: billingInfo?.zipCode,
          country: billingInfo?.country
        }
      };

      const result = await paymentService?.createPaymentIntent(orderData, customerInfo);
      setClientSecret(result?.clientSecret);
      setOrderData({ ...orderData, orderId: result?.orderId, orderNumber: result?.orderNumber });
      setShowCheckout(true);
    } catch (error) {
      console.error('Error creating payment intent:', error);
      setError('Failed to initialize payment. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentSuccess = (result) => {
    setShowCheckout(false);
    setCartItems([]);
    onOrderUpdate?.();
    alert(`Payment successful! Order #${result?.orderNumber} has been confirmed.`);
  };

  const handlePaymentError = (error) => {
    console.error('Payment error:', error);
    setError(`Payment failed: ${error?.message}`);
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-gray-200 rounded w-1/4"></div>
            <div className="space-y-3">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-5/6"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (cartItems?.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center">
          <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
          </svg>
        </div>
        <h3 className="mt-4 text-lg font-medium text-gray-900">Your cart is empty</h3>
        <p className="mt-2 text-gray-500">Add some components to get started with checkout.</p>
        <Button 
          variant="primary" 
          className="mt-4"
          onClick={() => window.location.href = '/component-marketplace'}
        >
          Browse Components
        </Button>
      </div>
    );
  }

  const totals = calculateTotal();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Order Summary */}
      <div className="space-y-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Order Summary</h3>
          
          <div className="space-y-4">
            {cartItems?.map((item) => (
              <div key={item?.id} className="flex justify-between items-start py-3 border-b border-gray-100 last:border-b-0">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">{item?.name}</h4>
                  <p className="text-sm text-gray-500">License: {item?.license}</p>
                  <p className="text-sm text-gray-500">Quantity: {item?.quantity}</p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900">
                    ${(item?.price * item?.quantity)?.toFixed(2)}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 pt-4 border-t border-gray-200 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Subtotal</span>
              <span className="text-gray-900">${totals?.subtotal?.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Tax</span>
              <span className="text-gray-900">${totals?.tax?.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-lg font-semibold pt-2 border-t border-gray-200">
              <span className="text-gray-900">Total</span>
              <span className="text-gray-900">${totals?.total?.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Billing Information */}
        {!showCheckout && (
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Billing Information</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="First Name"
                value={billingInfo?.firstName}
                onChange={(e) => setBillingInfo(prev => ({ ...prev, firstName: e?.target?.value }))}
                required
              />
              <Input
                label="Last Name"
                value={billingInfo?.lastName}
                onChange={(e) => setBillingInfo(prev => ({ ...prev, lastName: e?.target?.value }))}
                required
              />
              <Input
                label="Email"
                type="email"
                value={billingInfo?.email}
                onChange={(e) => setBillingInfo(prev => ({ ...prev, email: e?.target?.value }))}
                className="md:col-span-2"
                required
              />
              <Input
                label="Address"
                value={billingInfo?.address}
                onChange={(e) => setBillingInfo(prev => ({ ...prev, address: e?.target?.value }))}
                className="md:col-span-2"
                required
              />
              <Input
                label="City"
                value={billingInfo?.city}
                onChange={(e) => setBillingInfo(prev => ({ ...prev, city: e?.target?.value }))}
                required
              />
              <Input
                label="State"
                value={billingInfo?.state}
                onChange={(e) => setBillingInfo(prev => ({ ...prev, state: e?.target?.value }))}
                required
              />
              <Input
                label="ZIP Code"
                value={billingInfo?.zipCode}
                onChange={(e) => setBillingInfo(prev => ({ ...prev, zipCode: e?.target?.value }))}
                required
              />
              <Input
                label="Country"
                value={billingInfo?.country}
                onChange={(e) => setBillingInfo(prev => ({ ...prev, country: e?.target?.value }))}
                required
              />
            </div>

            {error && (
              <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-red-800 text-sm">{error}</p>
              </div>
            )}

            <Button
              variant="primary"
              onClick={handleCreatePaymentIntent}
              disabled={loading || !billingInfo?.firstName || !billingInfo?.lastName || !billingInfo?.email}
              className="w-full mt-6"
            >
              Continue to Payment
            </Button>
          </div>
        )}
      </div>
      {/* Payment Form */}
      <div className="space-y-6">
        {showCheckout && clientSecret && (
          <Elements 
            stripe={stripePromise} 
            options={{ 
              clientSecret,
              ...stripeOptions,
              defaultValues: {
                billingDetails: {
                  name: `${billingInfo?.firstName} ${billingInfo?.lastName}`,
                  email: billingInfo?.email,
                  address: {
                    line1: billingInfo?.address,
                    city: billingInfo?.city,
                    state: billingInfo?.state,
                    postal_code: billingInfo?.zipCode,
                    country: billingInfo?.country
                  }
                }
              }
            }}
          >
            <CheckoutForm
              clientSecret={clientSecret}
              orderData={orderData}
              onSuccess={handlePaymentSuccess}
              onError={handlePaymentError}
            />
          </Elements>
        )}

        {/* Security Notice */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-blue-800">Secure Checkout</h3>
              <div className="mt-1 text-sm text-blue-700">
                <p>Your payment information is encrypted and secure. We use Stripe for payment processing.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutInterface;