import React, { useMemo } from 'react';

const PaymentAnalytics = ({ user, orders, revenueStats }) => {
  const analytics = useMemo(() => {
    if (!orders || orders?.length === 0) {
      return {
        totalSpent: 0,
        totalOrders: 0,
        avgOrderValue: 0,
        monthlySpend: {},
        statusBreakdown: {},
        topCategories: {},
        recentTrend: 'stable'
      };
    }

    const totalSpent = orders?.reduce((sum, order) => {
      return sum + (order?.payment_status === 'succeeded' ? order?.total_amount : 0);
    }, 0);

    const totalOrders = orders?.filter(order => order?.payment_status === 'succeeded')?.length;
    const avgOrderValue = totalOrders > 0 ? totalSpent / totalOrders : 0;

    // Monthly spending breakdown
    const monthlySpend = {};
    const statusBreakdown = {};
    const categorySpend = {};

    orders?.forEach(order => {
      const date = new Date(order.created_at);
      const monthKey = `${date?.getFullYear()}-${(date?.getMonth() + 1)?.toString()?.padStart(2, '0')}`;
      
      if (order?.payment_status === 'succeeded') {
        monthlySpend[monthKey] = (monthlySpend?.[monthKey] || 0) + order?.total_amount;
      }

      statusBreakdown[order.status] = (statusBreakdown?.[order?.status] || 0) + 1;

      // Analyze order items for categories
      order?.order_items?.forEach(item => {
        const category = item?.product_name?.includes('Dashboard') ? 'Dashboards' :
                        item?.product_name?.includes('E-commerce') ? 'E-commerce' :
                        item?.product_name?.includes('Template') ? 'Templates' : 'Components';
        
        if (order?.payment_status === 'succeeded') {
          categorySpend[category] = (categorySpend?.[category] || 0) + item?.total;
        }
      });
    });

    // Calculate trend
    const monthKeys = Object.keys(monthlySpend)?.sort();
    const recentTrend = monthKeys?.length >= 2 ? 
      (monthlySpend?.[monthKeys?.[monthKeys?.length - 1]] > monthlySpend?.[monthKeys?.[monthKeys?.length - 2]] ? 'increasing' : 'decreasing') 
      : 'stable';

    return {
      totalSpent,
      totalOrders,
      avgOrderValue,
      monthlySpend,
      statusBreakdown,
      topCategories: categorySpend,
      recentTrend
    };
  }, [orders]);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    })?.format(amount);
  };

  const getMonthName = (monthKey) => {
    const [year, month] = monthKey?.split('-');
    return new Date(year, month - 1)?.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short' 
    });
  };

  const getTrendIcon = (trend) => {
    switch (trend) {
      case 'increasing':
        return (
          <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
          </svg>
        );
      case 'decreasing':
        return (
          <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6" />
          </svg>
        );
      default:
        return (
          <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
          </svg>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Payment Analytics</h2>
        <p className="text-gray-600">Insights into your spending and purchase patterns</p>
      </div>
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                </svg>
              </div>
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Total Spent</dt>
                <dd className="text-lg font-semibold text-gray-900">{formatCurrency(analytics?.totalSpent)}</dd>
              </dl>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                </svg>
              </div>
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Total Orders</dt>
                <dd className="text-lg font-semibold text-gray-900">{analytics?.totalOrders}</dd>
              </dl>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Avg. Order Value</dt>
                <dd className="text-lg font-semibold text-gray-900">{formatCurrency(analytics?.avgOrderValue)}</dd>
              </dl>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                {getTrendIcon(analytics?.recentTrend)}
              </div>
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Spending Trend</dt>
                <dd className="text-lg font-semibold text-gray-900 capitalize">{analytics?.recentTrend}</dd>
              </dl>
            </div>
          </div>
        </div>
      </div>
      {/* Charts and Detailed Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Spending */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Monthly Spending</h3>
          
          {Object.keys(analytics?.monthlySpend)?.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No spending data available</p>
            </div>
          ) : (
            <div className="space-y-4">
              {Object.entries(analytics?.monthlySpend)?.sort(([a], [b]) => b?.localeCompare(a))?.slice(0, 6)?.map(([month, amount]) => {
                  const maxAmount = Math.max(...Object.values(analytics?.monthlySpend));
                  const percentage = maxAmount > 0 ? (amount / maxAmount) * 100 : 0;
                  
                  return (
                    <div key={month} className="flex items-center">
                      <div className="w-20 text-sm text-gray-600">{getMonthName(month)}</div>
                      <div className="flex-1 mx-4">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                      <div className="w-20 text-sm font-medium text-gray-900 text-right">
                        {formatCurrency(amount)}
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>

        {/* Order Status Breakdown */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Order Status Breakdown</h3>
          
          {Object.keys(analytics?.statusBreakdown)?.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No order data available</p>
            </div>
          ) : (
            <div className="space-y-4">
              {Object.entries(analytics?.statusBreakdown)?.map(([status, count]) => {
                const total = Object.values(analytics?.statusBreakdown)?.reduce((sum, c) => sum + c, 0);
                const percentage = total > 0 ? (count / total) * 100 : 0;
                
                const statusColors = {
                  pending: 'bg-yellow-500',
                  processing: 'bg-blue-500',
                  shipped: 'bg-purple-500',
                  delivered: 'bg-green-500',
                  cancelled: 'bg-red-500',
                  refunded: 'bg-gray-500'
                };
                
                return (
                  <div key={status} className="flex items-center">
                    <div className="w-24 text-sm text-gray-600 capitalize">{status}</div>
                    <div className="flex-1 mx-4">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full transition-all duration-300 ${statusColors?.[status] || 'bg-gray-500'}`}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                    <div className="w-16 text-sm font-medium text-gray-900 text-right">
                      {count}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Top Categories */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Spending by Category</h3>
          
          {Object.keys(analytics?.topCategories)?.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No category data available</p>
            </div>
          ) : (
            <div className="space-y-4">
              {Object.entries(analytics?.topCategories)?.sort(([,a], [,b]) => b - a)?.slice(0, 5)?.map(([category, amount]) => {
                  const totalCategorySpend = Object.values(analytics?.topCategories)?.reduce((sum, a) => sum + a, 0);
                  const percentage = totalCategorySpend > 0 ? (amount / totalCategorySpend) * 100 : 0;
                  
                  return (
                    <div key={category} className="flex items-center">
                      <div className="w-24 text-sm text-gray-600">{category}</div>
                      <div className="flex-1 mx-4">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-indigo-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                      <div className="w-20 text-sm font-medium text-gray-900 text-right">
                        {formatCurrency(amount)}
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>

        {/* Revenue Stats (if user is a seller) */}
        {revenueStats && (
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Revenue (As Seller)</h3>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="text-sm font-medium text-green-800">Total Revenue</span>
                <span className="text-lg font-bold text-green-900">
                  {formatCurrency(revenueStats?.totalRevenue)}
                </span>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span className="text-sm font-medium text-blue-800">Paid Revenue</span>
                <span className="text-lg font-bold text-blue-900">
                  {formatCurrency(revenueStats?.paidRevenue)}
                </span>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                <span className="text-sm font-medium text-yellow-800">Pending Revenue</span>
                <span className="text-lg font-bold text-yellow-900">
                  {formatCurrency(revenueStats?.pendingRevenue)}
                </span>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium text-gray-800">Total Transactions</span>
                <span className="text-lg font-bold text-gray-900">
                  {revenueStats?.transactionCount}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
      {/* Insights */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-900 mb-3">💡 Insights & Recommendations</h3>
        <div className="space-y-2 text-sm text-blue-800">
          {analytics?.totalOrders === 0 && (
            <p>• Start exploring our component marketplace to find tools that can accelerate your development.</p>
          )}
          {analytics?.totalOrders > 0 && analytics?.avgOrderValue < 50 && (
            <p>• Consider bundling purchases or upgrading to higher-tier licenses to get better value.</p>
          )}
          {analytics?.recentTrend === 'increasing' && (
            <p>• Your spending has been increasing. Consider upgrading to a subscription for potential savings.</p>
          )}
          {Object.keys(analytics?.topCategories)?.length > 0 && (
            <p>• You seem to prefer {Object.keys(analytics?.topCategories)?.[0]?.toLowerCase()} components. Check out our latest additions in this category.</p>
          )}
          {revenueStats && revenueStats?.pendingRevenue > 0 && (
            <p>• You have pending revenue from your component sales. Payouts are processed monthly.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default PaymentAnalytics;