import React, { useState } from 'react';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { useStripeContext } from '../../../contexts/StripeContext';
import { paymentService } from '../../../services/paymentService';
import Button from '../../../components/ui/Button';

const AddPaymentMethodForm = ({ user, onSuccess, onCancel }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (event) => {
    event?.preventDefault();

    if (!stripe || !elements) {
      setError('Payment system not ready. Please try again.');
      return;
    }

    setIsProcessing(true);
    setError('');

    try {
      const cardElement = elements?.getElement(CardElement);
      
      const { error: stripeError, paymentMethod } = await stripe?.createPaymentMethod({
        type: 'card',
        card: cardElement,
        billing_details: {
          email: user?.email,
        },
      });

      if (stripeError) {
        setError(stripeError?.message);
        return;
      }

      await paymentService?.savePaymentMethod(user?.id, paymentMethod?.id, paymentMethod);
      onSuccess?.();
    } catch (error) {
      console.error('Error saving payment method:', error);
      setError('Failed to save payment method. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Add New Payment Method</h3>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="p-4 border border-gray-300 rounded-lg">
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: '16px',
                  color: '#424770',
                  '::placeholder': {
                    color: '#aab7c4',
                  },
                },
                invalid: {
                  color: '#9e2146',
                },
              },
            }}
          />
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-800 text-sm">{error}</p>
          </div>
        )}

        <div className="flex space-x-3">
          <Button
            type="submit"
            disabled={!stripe || isProcessing}
            variant="primary"
            className="flex-1"
          >
            {isProcessing ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Saving...
              </div>
            ) : (
              'Save Payment Method'
            )}
          </Button>
          <Button
            type="button"
            onClick={onCancel}
            variant="outline"
            className="flex-1"
          >
            Cancel
          </Button>
        </div>
      </form>
    </div>
  );
};

const PaymentMethodsPanel = ({ user, paymentMethods, onUpdate }) => {
  const { stripePromise, stripeOptions } = useStripeContext();
  const [showAddForm, setShowAddForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSetDefault = async (paymentMethodId) => {
    try {
      setLoading(true);
      await paymentService?.setDefaultPaymentMethod(user?.id, paymentMethodId);
      onUpdate?.();
    } catch (error) {
      console.error('Error setting default payment method:', error);
      setError('Failed to set default payment method.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (paymentMethodId) => {
    if (!confirm('Are you sure you want to delete this payment method?')) {
      return;
    }

    try {
      setLoading(true);
      await paymentService?.deletePaymentMethod(user?.id, paymentMethodId);
      onUpdate?.();
    } catch (error) {
      console.error('Error deleting payment method:', error);
      setError('Failed to delete payment method.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddSuccess = () => {
    setShowAddForm(false);
    onUpdate?.();
  };

  const getCardIcon = (brand) => {
    switch (brand?.toLowerCase()) {
      case 'visa':
        return '💳';
      case 'mastercard':
        return '💳';
      case 'amex':
        return '💳';
      case 'discover':
        return '💳';
      default:
        return '💳';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Payment Methods</h2>
          <p className="text-gray-600">Manage your saved payment methods</p>
        </div>
        
        {!showAddForm && (
          <Button
            variant="primary"
            onClick={() => setShowAddForm(true)}
          >
            Add Payment Method
          </Button>
        )}
      </div>
      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          </div>
        </div>
      )}
      {/* Add Payment Method Form */}
      {showAddForm && (
        <Elements stripe={stripePromise} options={stripeOptions}>
          <AddPaymentMethodForm
            user={user}
            onSuccess={handleAddSuccess}
            onCancel={() => setShowAddForm(false)}
          />
        </Elements>
      )}
      {/* Payment Methods List */}
      <div className="space-y-4">
        {paymentMethods?.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 rounded-lg">
            <div className="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center">
              <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
              </svg>
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">No payment methods saved</h3>
            <p className="mt-2 text-gray-500">Add a payment method to make purchases easier.</p>
          </div>
        ) : (
          paymentMethods?.map((method) => (
            <div 
              key={method?.id} 
              className={`
                bg-white rounded-lg border-2 p-6 transition-colors
                ${method?.is_default ? 'border-blue-500 bg-blue-50' : 'border-gray-200'}
              `}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="text-2xl">
                    {getCardIcon(method?.card_brand)}
                  </div>
                  
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-gray-900 capitalize">
                        {method?.card_brand || method?.type}
                      </span>
                      <span className="text-gray-500">
                        •••• {method?.card_last_four}
                      </span>
                      {method?.is_default && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          Default
                        </span>
                      )}
                    </div>
                    <div className="text-sm text-gray-500">
                      Expires {method?.card_exp_month?.toString()?.padStart(2, '0')}/{method?.card_exp_year}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  {!method?.is_default && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleSetDefault(method?.id)}
                      disabled={loading}
                    >
                      Set as Default
                    </Button>
                  )}
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDelete(method?.id)}
                    disabled={loading}
                    className="text-red-600 hover:text-red-700 hover:border-red-300"
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      {/* Security Notice */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <svg className="h-5 w-5 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
            </svg>
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-blue-800">Secure Storage</h3>
            <div className="mt-1 text-sm text-blue-700">
              <p>Your payment information is securely stored by Stripe. We never store your full card details on our servers.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentMethodsPanel;