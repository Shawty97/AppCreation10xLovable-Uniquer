import React, { useState } from 'react';
import Button from '../../../components/ui/Button';

const SubscriptionManager = ({ user, subscription, onUpdate }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const subscriptionTiers = {
    free: {
      name: 'Free',
      price: 0,
      features: [
        'Access to free components',
        'Basic templates',
        'Community support',
        'Up to 3 downloads per month'
      ],
      color: 'gray'
    },
    basic: {
      name: 'Basic',
      price: 9.99,
      features: [
        'All free features',
        'Access to basic components',
        'Email support',
        'Up to 10 downloads per month',
        'Basic customization tools'
      ],
      color: 'blue'
    },
    premium: {
      name: 'Premium',
      price: 19.99,
      features: [
        'All basic features',
        'Access to premium components',
        'Priority support',
        'Unlimited downloads',
        'Advanced customization tools',
        'Export to multiple formats'
      ],
      color: 'purple'
    },
    enterprise: {
      name: 'Enterprise',
      price: 49.99,
      features: [
        'All premium features',
        'Custom components',
        'Dedicated account manager',
        'API access',
        'White-label solutions',
        'Advanced analytics',
        'Team collaboration tools'
      ],
      color: 'indigo'
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const handleUpgrade = async (tier) => {
    setLoading(true);
    setError(null);
    
    try {
      // In real implementation, this would create a Stripe subscription
      alert(`Upgrading to ${tier} plan... (This is a demo)`);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      onUpdate?.();
    } catch (error) {
      console.error('Error upgrading subscription:', error);
      setError('Failed to upgrade subscription. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async () => {
    if (!confirm('Are you sure you want to cancel your subscription? You will lose access to premium features at the end of your billing period.')) {
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      // In real implementation, this would cancel the Stripe subscription
      alert('Subscription cancelled. (This is a demo)');
      onUpdate?.();
    } catch (error) {
      console.error('Error cancelling subscription:', error);
      setError('Failed to cancel subscription. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const currentTier = subscription?.tier || 'free';
  const currentTierInfo = subscriptionTiers?.[currentTier];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Subscription Management</h2>
        <p className="text-gray-600">Manage your CodeCraft Studio subscription</p>
      </div>
      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          </div>
        </div>
      )}
      {/* Current Subscription */}
      {subscription && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Current Subscription</h3>
              <p className="text-gray-600">Your active plan details</p>
            </div>
            
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-${currentTierInfo?.color}-100 text-${currentTierInfo?.color}-800`}>
              {currentTierInfo?.name}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-500">Plan</label>
                <p className="text-lg font-semibold text-gray-900">
                  {currentTierInfo?.name} - ${currentTierInfo?.price}/month
                </p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-500">Status</label>
                <p className={`text-sm font-medium ${
                  subscription?.status === 'active' ? 'text-green-600' : 
                  subscription?.status === 'cancelled'? 'text-red-600' : 'text-yellow-600'
                }`}>
                  {subscription?.status?.charAt(0)?.toUpperCase() + subscription?.status?.slice(1)}
                </p>
              </div>
            </div>

            <div className="space-y-4">
              {subscription?.current_period_end && (
                <div>
                  <label className="text-sm font-medium text-gray-500">
                    {subscription?.status === 'cancelled' ? 'Access until' : 'Next billing date'}
                  </label>
                  <p className="text-lg font-semibold text-gray-900">
                    {formatDate(subscription?.current_period_end)}
                  </p>
                </div>
              )}

              {subscription?.trial_end && new Date(subscription.trial_end) > new Date() && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Trial ends</label>
                  <p className="text-lg font-semibold text-gray-900">
                    {formatDate(subscription?.trial_end)}
                  </p>
                </div>
              )}
            </div>
          </div>

          {subscription?.status === 'active' && (
            <div className="mt-6 pt-6 border-t border-gray-200">
              <Button
                variant="outline"
                onClick={handleCancel}
                disabled={loading}
                className="text-red-600 hover:text-red-700 hover:border-red-300"
              >
                Cancel Subscription
              </Button>
            </div>
          )}
        </div>
      )}
      {/* Subscription Plans */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          {subscription ? 'Upgrade or Change Plan' : 'Choose a Plan'}
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Object.entries(subscriptionTiers)?.map(([tier, info]) => {
            const isCurrent = currentTier === tier;
            const isUpgrade = subscriptionTiers?.[currentTier]?.price < info?.price;
            
            return (
              <div
                key={tier}
                className={`
                  relative bg-white rounded-lg border-2 p-6 transition-all duration-200
                  ${isCurrent 
                    ? `border-${info?.color}-500 ring-2 ring-${info?.color}-200` 
                    : 'border-gray-200 hover:border-gray-300'
                  }
                `}
              >
                {isCurrent && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-${info?.color}-100 text-${info?.color}-800`}>
                      Current Plan
                    </span>
                  </div>
                )}
                <div className="text-center mb-6">
                  <h4 className="text-lg font-semibold text-gray-900">{info?.name}</h4>
                  <div className="mt-2">
                    <span className="text-3xl font-bold text-gray-900">${info?.price}</span>
                    <span className="text-gray-500">/month</span>
                  </div>
                </div>
                <ul className="space-y-3 mb-6">
                  {info?.features?.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <svg className="flex-shrink-0 w-5 h-5 text-green-500 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="ml-3 text-sm text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-auto">
                  {isCurrent ? (
                    <Button variant="outline" className="w-full" disabled>
                      Current Plan
                    </Button>
                  ) : (
                    <Button
                      variant={isUpgrade ? "primary" : "outline"}
                      className="w-full"
                      onClick={() => handleUpgrade(tier)}
                      disabled={loading}
                    >
                      {loading ? (
                        <div className="flex items-center justify-center">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Processing...
                        </div>
                      ) : (
                        isUpgrade ? 'Upgrade' : 'Select Plan'
                      )}
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {/* Billing Information */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <svg className="h-5 w-5 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
            </svg>
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-blue-800">Billing Information</h3>
            <div className="mt-1 text-sm text-blue-700">
              <p>All subscriptions are billed monthly. You can change or cancel your subscription at any time. Changes take effect at the next billing cycle.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionManager;