import React, { useState } from 'react';

import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const CollaborationPanel = ({ collaborators, onAddCollaborator, isMobile }) => {
  const [inviteEmail, setInviteEmail] = useState('');
  const [chatMessage, setChatMessage] = useState('');
  const [activeTab, setActiveTab] = useState('team');

  const mockMessages = [
    {
      id: 1,
      user: 'Sarah Chen',
      message: 'The mobile layout looks great! Just noticed the header might be a bit cramped on smaller screens.',
      timestamp: new Date(Date.now() - 600000),
      type: 'message'
    },
    {
      id: 2,
      user: 'Mike Johnson',
      message: 'Added an annotation on the checkout button - it needs better contrast.',
      timestamp: new Date(Date.now() - 300000),
      type: 'annotation'
    },
    {
      id: 3,
      user: 'You',
      message: 'Thanks for the feedback! I\'ll adjust the mobile header spacing.',
      timestamp: new Date(Date.now() - 120000),
      type: 'message'
    }
  ];

  const handleInviteCollaborator = () => {
    if (!inviteEmail?.trim()) return;

    const newCollaborator = {
      email: inviteEmail,
      name: inviteEmail?.split('@')?.[0],
      role: 'reviewer',
      status: 'invited',
      invitedAt: new Date()
    };

    onAddCollaborator?.(newCollaborator);
    setInviteEmail('');
  };

  const handleSendMessage = () => {
    if (!chatMessage?.trim()) return;
    
    // In a real app, this would send the message to the collaboration service
    console.log('Sending message:', chatMessage);
    setChatMessage('');
  };

  const formatTimestamp = (timestamp) => {
    return timestamp?.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'online':
        return 'bg-green-500';
      case 'away':
        return 'bg-yellow-500';
      case 'offline':
        return 'bg-gray-400';
      default:
        return 'bg-gray-300';
    }
  };

  if (isMobile) {
    return (
      <div className="h-full flex flex-col bg-card">
        <div className="p-4 border-b border-border">
          <h2 className="text-lg font-semibold text-foreground">Collaboration</h2>
          <div className="flex space-x-2 mt-3">
            {['team', 'chat']?.map((tab) => (
              <Button
                key={tab}
                variant={activeTab === tab ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveTab(tab)}
                className="flex-1 capitalize"
              >
                {tab}
              </Button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          {activeTab === 'team' ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <Input
                  type="email"
                  placeholder="Email address..."
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e?.target?.value)}
                />
                <Button
                  variant="default"
                  iconName="Plus"
                  iconSize={14}
                  onClick={handleInviteCollaborator}
                  className="w-full"
                >
                  Invite
                </Button>
              </div>

              <div className="space-y-2">
                {collaborators?.map((collaborator) => (
                  <div key={collaborator?.id} className="flex items-center space-x-3 p-2 rounded-lg bg-secondary">
                    <div className="relative">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium text-primary-foreground">
                          {collaborator?.name?.charAt(0)?.toUpperCase()}
                        </span>
                      </div>
                      <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white ${getStatusColor(collaborator?.status)}`}></div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">
                        {collaborator?.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {collaborator?.role}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-col h-full">
              <div className="flex-1 space-y-3 mb-4">
                {mockMessages?.map((msg) => (
                  <div key={msg?.id} className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium text-foreground">{msg?.user}</span>
                      <span className="text-xs text-muted-foreground">{formatTimestamp(msg?.timestamp)}</span>
                    </div>
                    <p className="text-sm text-foreground bg-secondary rounded-lg p-2">
                      {msg?.message}
                    </p>
                  </div>
                ))}
              </div>
              
              <div className="flex space-x-2">
                <Input
                  placeholder="Type a message..."
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e?.target?.value)}
                  onKeyPress={(e) => e?.key === 'Enter' && handleSendMessage()}
                  className="flex-1"
                />
                <Button
                  variant="default"
                  iconName="Send"
                  iconSize={14}
                  onClick={handleSendMessage}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg shadow-sm border border-border h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <h2 className="text-xl font-semibold text-foreground mb-2">Team Collaboration</h2>
        <p className="text-sm text-muted-foreground">
          Work together in real-time with shared cursors and voice chat
        </p>
      </div>
      {/* Collaboration Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-6 space-y-6">
          {/* Team Members */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium text-foreground">Team Members</h3>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-xs text-muted-foreground">
                  {collaborators?.filter(c => c?.status === 'online')?.length || 0} online
                </span>
              </div>
            </div>

            <div className="space-y-3">
              {collaborators?.map((collaborator) => (
                <div key={collaborator?.id} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium text-primary-foreground">
                          {collaborator?.name?.charAt(0)?.toUpperCase()}
                        </span>
                      </div>
                      <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white ${getStatusColor(collaborator?.status)}`}></div>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{collaborator?.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {collaborator?.role} • {collaborator?.status || 'invited'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      iconName="MessageCircle"
                      iconSize={14}
                      className="h-8 w-8"
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      iconName="MoreVertical"
                      iconSize={14}
                      className="h-8 w-8"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Invite New Member */}
          <div className="bg-muted rounded-lg p-4">
            <h4 className="font-medium text-foreground mb-3">Invite Collaborator</h4>
            <div className="space-y-3">
              <Input
                type="email"
                placeholder="Enter email address..."
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e?.target?.value)}
              />
              <div className="flex space-x-2">
                <Button
                  variant="default"
                  iconName="Plus"
                  iconPosition="left"
                  iconSize={14}
                  onClick={handleInviteCollaborator}
                  disabled={!inviteEmail?.trim()}
                  className="flex-1"
                >
                  Send Invite
                </Button>
                <Button
                  variant="outline"
                  iconName="Link"
                  iconSize={14}
                  className="h-10 w-10"
                  title="Copy invite link"
                />
              </div>
            </div>
          </div>

          {/* Team Chat */}
          <div>
            <h3 className="font-medium text-foreground mb-4">Team Chat</h3>
            <div className="space-y-4 max-h-64 overflow-y-auto">
              {mockMessages?.map((message) => (
                <div key={message?.id} className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-foreground">{message?.user}</span>
                    <span className="text-xs text-muted-foreground">
                      {formatTimestamp(message?.timestamp)}
                    </span>
                    {message?.type === 'annotation' && (
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                        annotation
                      </span>
                    )}
                  </div>
                  <div className="bg-background border border-border rounded-lg p-3">
                    <p className="text-sm text-foreground">{message?.message}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 flex space-x-2">
              <Input
                placeholder="Type a message..."
                value={chatMessage}
                onChange={(e) => setChatMessage(e?.target?.value)}
                onKeyPress={(e) => e?.key === 'Enter' && handleSendMessage()}
                className="flex-1"
              />
              <Button
                variant="default"
                iconName="Send"
                iconSize={16}
                onClick={handleSendMessage}
                disabled={!chatMessage?.trim()}
                className="h-10 w-10"
              />
            </div>
          </div>

          {/* Collaboration Features */}
          <div>
            <h3 className="font-medium text-foreground mb-4">Collaboration Features</h3>
            <div className="grid grid-cols-1 gap-3">
              <Button
                variant="outline"
                iconName="Users"
                iconPosition="left"
                iconSize={16}
                className="justify-start"
              >
                Start Voice Chat
              </Button>
              <Button
                variant="outline"
                iconName="Share"
                iconPosition="left"
                iconSize={16}
                className="justify-start"
              >
                Share Session Link
              </Button>
              <Button
                variant="outline"
                iconName="Video"
                iconPosition="left"
                iconSize={16}
                className="justify-start"
              >
                Start Screen Share
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CollaborationPanel;