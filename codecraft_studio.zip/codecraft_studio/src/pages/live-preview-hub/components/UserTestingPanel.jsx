import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const UserTestingPanel = ({ sessions, onStartTesting }) => {
  const [activeTab, setActiveTab] = useState('active');
  const [newTestName, setNewTestName] = useState('');
  const [testType, setTestType] = useState('usability');

  const testTypes = [
    { value: 'usability', label: 'Usability Testing', icon: 'Users' },
    { value: 'a-b', label: 'A/B Testing', icon: 'GitCompare' },
    { value: 'feedback', label: 'Feedback Collection', icon: 'MessageSquare' },
    { value: 'heatmap', label: 'Heatmap Analysis', icon: 'Target' }
  ];

  const mockSessions = [
    {
      id: 1,
      name: 'Mobile Navigation Test',
      type: 'usability',
      status: 'active',
      participants: 12,
      startTime: new Date(Date.now() - 3600000),
      duration: '1h 15m',
      completionRate: 75
    },
    {
      id: 2,
      name: 'Checkout Flow A/B Test',
      type: 'a-b',
      status: 'completed',
      participants: 156,
      startTime: new Date(Date.now() - 86400000 * 3),
      duration: '3 days',
      completionRate: 92
    },
    {
      id: 3,
      name: 'Homepage Feedback',
      type: 'feedback',
      status: 'active',
      participants: 23,
      startTime: new Date(Date.now() - 7200000),
      duration: '2h 30m',
      completionRate: 84
    }
  ];

  const handleStartTest = () => {
    if (!newTestName?.trim()) return;

    onStartTesting?.({
      name: newTestName,
      type: testType,
      mode: 'user-testing'
    });

    setNewTestName('');
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'text-green-600 bg-green-50 border-green-200';
      case 'completed':
        return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'paused':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getTypeIcon = (type) => {
    const testType = testTypes?.find(t => t?.value === type);
    return testType?.icon || 'TestTube';
  };

  const formatDuration = (startTime) => {
    const now = new Date();
    const diff = now - startTime;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  return (
    <div className="bg-card rounded-lg shadow-sm border border-border h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-semibold text-foreground">User Testing</h2>
            <p className="text-sm text-muted-foreground">
              Collect user feedback and analyze behavior patterns
            </p>
          </div>
        </div>

        {/* New Test Creation */}
        <div className="bg-muted rounded-lg p-4">
          <h3 className="font-medium text-foreground mb-3">Start New Test</h3>
          <div className="space-y-3">
            <Input
              placeholder="Test name..."
              value={newTestName}
              onChange={(e) => setNewTestName(e?.target?.value)}
            />
            <div className="flex space-x-2">
              <Select
                options={testTypes}
                value={testType}
                onChange={setTestType}
                className="flex-1"
              />
              <Button
                variant="default"
                iconName="Play"
                iconPosition="left"
                iconSize={16}
                onClick={handleStartTest}
                disabled={!newTestName?.trim()}
              >
                Start Test
              </Button>
            </div>
          </div>
        </div>
      </div>
      {/* Tabs */}
      <div className="border-b border-border">
        <div className="flex">
          {[
            { key: 'active', label: 'Active Tests', count: mockSessions?.filter(s => s?.status === 'active')?.length },
            { key: 'completed', label: 'Completed', count: mockSessions?.filter(s => s?.status === 'completed')?.length },
            { key: 'insights', label: 'Insights', count: 0 }
          ]?.map((tab) => (
            <button
              key={tab?.key}
              className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab?.key
                  ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground'
              }`}
              onClick={() => setActiveTab(tab?.key)}
            >
              {tab?.label}
              {tab?.count > 0 && (
                <span className="ml-2 px-2 py-1 bg-muted text-muted-foreground text-xs rounded-full">
                  {tab?.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>
      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {activeTab === 'active' && (
          <div className="space-y-4">
            {mockSessions?.filter(s => s?.status === 'active')?.map((session) => (
              <div key={session?.id} className="border border-border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <Icon name={getTypeIcon(session?.type)} size={20} className="text-primary" />
                    <div>
                      <h3 className="font-medium text-foreground">{session?.name}</h3>
                      <p className="text-sm text-muted-foreground capitalize">
                        {session?.type?.replace('-', ' ')} Test
                      </p>
                    </div>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs border font-medium ${getStatusColor(session?.status)}`}>
                    {session?.status}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">{session?.participants}</div>
                    <div className="text-xs text-muted-foreground">Participants</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">
                      {formatDuration(session?.startTime)}
                    </div>
                    <div className="text-xs text-muted-foreground">Running Time</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">{session?.completionRate}%</div>
                    <div className="text-xs text-muted-foreground">Completion</div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="w-full bg-muted rounded-full h-2 mr-4">
                    <div
                      className="bg-primary h-2 rounded-full transition-all"
                      style={{ width: `${session?.completionRate}%` }}
                    />
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      iconName="Eye"
                      iconSize={14}
                    >
                      View
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      iconName="Pause"
                      iconSize={14}
                    >
                      Pause
                    </Button>
                  </div>
                </div>
              </div>
            ))}

            {mockSessions?.filter(s => s?.status === 'active')?.length === 0 && (
              <div className="text-center py-8">
                <Icon name="TestTube" size={48} className="text-muted-foreground mx-auto mb-3" />
                <h3 className="text-lg font-medium text-foreground mb-2">No Active Tests</h3>
                <p className="text-muted-foreground">
                  Start a new test to begin collecting user feedback
                </p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'completed' && (
          <div className="space-y-4">
            {mockSessions?.filter(s => s?.status === 'completed')?.map((session) => (
              <div key={session?.id} className="border border-border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <Icon name={getTypeIcon(session?.type)} size={20} className="text-muted-foreground" />
                    <div>
                      <h3 className="font-medium text-foreground">{session?.name}</h3>
                      <p className="text-sm text-muted-foreground capitalize">
                        {session?.type?.replace('-', ' ')} Test • Completed {session?.duration} ago
                      </p>
                    </div>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs border font-medium ${getStatusColor(session?.status)}`}>
                    Completed
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">{session?.participants}</div>
                    <div className="text-xs text-muted-foreground">Participants</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">{session?.duration}</div>
                    <div className="text-xs text-muted-foreground">Total Duration</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">{session?.completionRate}%</div>
                    <div className="text-xs text-muted-foreground">Completion</div>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="BarChart3"
                    iconPosition="left"
                    iconSize={14}
                    className="flex-1"
                  >
                    View Results
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Download"
                    iconSize={14}
                  >
                    Export
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'insights' && (
          <div className="space-y-6">
            {/* Key Insights */}
            <div>
              <h3 className="font-medium text-foreground mb-4">Key Insights</h3>
              <div className="space-y-3">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <Icon name="TrendingUp" size={20} className="text-blue-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-blue-900">Improved Navigation Clarity</h4>
                      <p className="text-sm text-blue-800 mt-1">
                        85% of users found the new navigation structure more intuitive than the previous version.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <Icon name="AlertTriangle" size={20} className="text-yellow-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-yellow-900">Checkout Process Friction</h4>
                      <p className="text-sm text-yellow-800 mt-1">
                        Users spend 23% more time on the payment step. Consider simplifying form fields.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <Icon name="CheckCircle" size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-green-900">High User Satisfaction</h4>
                      <p className="text-sm text-green-800 mt-1">
                        92% satisfaction rate with overall user experience and design quality.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* User Feedback Summary */}
            <div>
              <h3 className="font-medium text-foreground mb-4">Recent Feedback</h3>
              <div className="space-y-3">
                {[
                  { rating: 5, comment: "Love the new design! Much easier to find what I'm looking for." },
                  { rating: 4, comment: "Great improvements, but the checkout could be faster." },
                  { rating: 5, comment: "Mobile experience is fantastic now." },
                  { rating: 3, comment: "Good overall, but some buttons are hard to click on mobile." }
                ]?.map((feedback, index) => (
                  <div key={index} className="bg-secondary rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-1">
                        {[...Array(5)]?.map((_, i) => (
                          <Icon
                            key={i}
                            name="Star"
                            size={14}
                            className={i < feedback?.rating ? "text-yellow-400 fill-current" : "text-gray-300"}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground">2 hours ago</span>
                    </div>
                    <p className="text-sm text-foreground">{feedback?.comment}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserTestingPanel;