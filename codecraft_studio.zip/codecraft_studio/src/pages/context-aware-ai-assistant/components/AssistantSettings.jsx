import React, { useState } from 'react';
import { Settings, Brain, Save, RefreshCw, Zap, MessageCircle, Code } from 'lucide-react';
import Icon from '../../../components/AppIcon';


const AssistantSettings = ({ preferences, onUpdatePreferences }) => {
  const [formData, setFormData] = useState({
    learning_enabled: preferences?.learning_enabled ?? true,
    assistance_level: preferences?.assistance_level || 'balanced',
    preferred_frameworks: preferences?.preferred_frameworks || ['react'],
    coding_style_preferences: preferences?.coding_style_preferences || {
      indentation: '2_spaces',
      quotes: 'single',
      semicolons: true,
      component_style: 'functional'
    },
    voice_settings: preferences?.voice_settings || {
      enabled: true,
      language: 'en-US',
      speed: 'normal'
    },
    interaction_patterns: preferences?.interaction_patterns || {
      proactive_suggestions: true,
      context_memory_depth: 'medium',
      response_format: 'detailed'
    }
  });

  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState('');

  const frameworks = [
    { value: 'react', label: 'React', icon: '⚛️' },
    { value: 'vue', label: 'Vue.js', icon: '💚' },
    { value: 'angular', label: 'Angular', icon: '🔺' },
    { value: 'svelte', label: 'Svelte', icon: '🧡' },
    { value: 'next', label: 'Next.js', icon: '▲' },
    { value: 'nuxt', label: 'Nuxt.js', icon: '💚' },
    { value: 'typescript', label: 'TypeScript', icon: '💙' },
    { value: 'javascript', label: 'JavaScript', icon: '💛' }
  ];

  const assistanceLevels = [
    {
      value: 'concise',
      label: 'Concise',
      description: 'Brief, to-the-point responses',
      icon: Zap
    },
    {
      value: 'balanced',
      label: 'Balanced',
      description: 'Moderate detail with examples',
      icon: MessageCircle
    },
    {
      value: 'detailed',
      label: 'Detailed',
      description: 'Comprehensive explanations with context',
      icon: Code
    }
  ];

  const handleInputChange = (field, value, nested = null) => {
    if (nested) {
      setFormData(prev => ({
        ...prev,
        [field]: {
          ...prev?.[field],
          [nested]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: value
      }));
    }
  };

  const handleFrameworkToggle = (framework) => {
    const current = formData?.preferred_frameworks || [];
    const updated = current?.includes(framework)
      ? current?.filter(f => f !== framework)
      : [...current, framework];
    
    setFormData(prev => ({
      ...prev,
      preferred_frameworks: updated
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveMessage('');

    try {
      await onUpdatePreferences?.(formData);
      setSaveMessage('Settings saved successfully!');
    } catch (error) {
      setSaveMessage('Failed to save settings. Please try again.');
    } finally {
      setIsSaving(false);
      setTimeout(() => setSaveMessage(''), 3000);
    }
  };

  const handleReset = () => {
    setFormData({
      learning_enabled: true,
      assistance_level: 'balanced',
      preferred_frameworks: ['react'],
      coding_style_preferences: {
        indentation: '2_spaces',
        quotes: 'single',
        semicolons: true,
        component_style: 'functional'
      },
      voice_settings: {
        enabled: true,
        language: 'en-US',
        speed: 'normal'
      },
      interaction_patterns: {
        proactive_suggestions: true,
        context_memory_depth: 'medium',
        response_format: 'detailed'
      }
    });
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Settings className="h-8 w-8 text-purple-600" />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Assistant Settings</h2>
            <p className="text-gray-600">Customize your AI assistant's behavior and preferences</p>
          </div>
        </div>

        {saveMessage && (
          <div className={`px-4 py-2 rounded-lg text-sm font-medium ${
            saveMessage?.includes('success') 
              ? 'bg-green-100 text-green-800' :'bg-red-100 text-red-800'
          }`}>
            {saveMessage}
          </div>
        )}
      </div>
      {/* Learning Settings */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <Brain className="h-6 w-6 text-blue-600" />
          <h3 className="text-lg font-semibold text-gray-900">Learning & Adaptation</h3>
        </div>

        <div className="space-y-6">
          {/* Learning Toggle */}
          <div className="flex items-center justify-between">
            <div>
              <label className="text-sm font-medium text-gray-900">Enable Learning</label>
              <p className="text-sm text-gray-600">
                Allow the assistant to learn from your interactions and improve over time
              </p>
            </div>
            <button
              onClick={() => handleInputChange('learning_enabled', !formData?.learning_enabled)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                formData?.learning_enabled ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  formData?.learning_enabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Assistance Level */}
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-3">
              Assistance Level
            </label>
            <div className="grid md:grid-cols-3 gap-4">
              {assistanceLevels?.map((level) => {
                const Icon = level?.icon;
                return (
                  <button
                    key={level?.value}
                    onClick={() => handleInputChange('assistance_level', level?.value)}
                    className={`p-4 border rounded-lg text-left transition-colors ${
                      formData?.assistance_level === level?.value
                        ? 'border-blue-500 bg-blue-50 text-blue-900' :'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center space-x-2 mb-2">
                      <Icon className="h-5 w-5" />
                      <span className="font-medium">{level?.label}</span>
                    </div>
                    <p className="text-sm text-gray-600">{level?.description}</p>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
      {/* Framework Preferences */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <Code className="h-6 w-6 text-green-600" />
          <h3 className="text-lg font-semibold text-gray-900">Development Preferences</h3>
        </div>

        <div className="space-y-6">
          {/* Preferred Frameworks */}
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-3">
              Preferred Frameworks & Technologies
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {frameworks?.map((framework) => (
                <button
                  key={framework?.value}
                  onClick={() => handleFrameworkToggle(framework?.value)}
                  className={`p-3 border rounded-lg text-center transition-colors ${
                    formData?.preferred_frameworks?.includes(framework?.value)
                      ? 'border-green-500 bg-green-50 text-green-900' :'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="text-xl mb-1">{framework?.icon}</div>
                  <div className="text-sm font-medium">{framework?.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Coding Style */}
          <div>
            <h4 className="text-sm font-medium text-gray-900 mb-4">Coding Style Preferences</h4>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm text-gray-700 mb-1">Indentation</label>
                <select
                  value={formData?.coding_style_preferences?.indentation || '2_spaces'}
                  onChange={(e) => handleInputChange('coding_style_preferences', e?.target?.value, 'indentation')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="2_spaces">2 Spaces</option>
                  <option value="4_spaces">4 Spaces</option>
                  <option value="tabs">Tabs</option>
                </select>
              </div>

              <div>
                <label className="block text-sm text-gray-700 mb-1">Quote Style</label>
                <select
                  value={formData?.coding_style_preferences?.quotes || 'single'}
                  onChange={(e) => handleInputChange('coding_style_preferences', e?.target?.value, 'quotes')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="single">Single Quotes</option>
                  <option value="double">Double Quotes</option>
                </select>
              </div>

              <div>
                <label className="block text-sm text-gray-700 mb-1">Component Style</label>
                <select
                  value={formData?.coding_style_preferences?.component_style || 'functional'}
                  onChange={(e) => handleInputChange('coding_style_preferences', e?.target?.value, 'component_style')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="functional">Functional Components</option>
                  <option value="class">Class Components</option>
                  <option value="mixed">Mixed</option>
                </select>
              </div>

              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-700">Use Semicolons</label>
                <button
                  onClick={() => handleInputChange('coding_style_preferences', !formData?.coding_style_preferences?.semicolons, 'semicolons')}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    formData?.coding_style_preferences?.semicolons ? 'bg-blue-600' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      formData?.coding_style_preferences?.semicolons ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Interaction Patterns */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <MessageCircle className="h-6 w-6 text-purple-600" />
          <h3 className="text-lg font-semibold text-gray-900">Interaction Preferences</h3>
        </div>

        <div className="space-y-6">
          {/* Proactive Suggestions */}
          <div className="flex items-center justify-between">
            <div>
              <label className="text-sm font-medium text-gray-900">Proactive Suggestions</label>
              <p className="text-sm text-gray-600">
                Receive helpful suggestions even when not asking specific questions
              </p>
            </div>
            <button
              onClick={() => handleInputChange('interaction_patterns', !formData?.interaction_patterns?.proactive_suggestions, 'proactive_suggestions')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                formData?.interaction_patterns?.proactive_suggestions ? 'bg-purple-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  formData?.interaction_patterns?.proactive_suggestions ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Context Memory Depth */}
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-3">
              Context Memory Depth
            </label>
            <div className="grid grid-cols-3 gap-3">
              {['shallow', 'medium', 'deep']?.map((depth) => (
                <button
                  key={depth}
                  onClick={() => handleInputChange('interaction_patterns', depth, 'context_memory_depth')}
                  className={`p-3 border rounded-lg text-center capitalize transition-colors ${
                    formData?.interaction_patterns?.context_memory_depth === depth
                      ? 'border-purple-500 bg-purple-50 text-purple-900' :'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {depth}
                </button>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              How much conversation history to consider when responding
            </p>
          </div>

          {/* Response Format */}
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-1">
              Default Response Format
            </label>
            <select
              value={formData?.interaction_patterns?.response_format || 'detailed'}
              onChange={(e) => handleInputChange('interaction_patterns', e?.target?.value, 'response_format')}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              <option value="brief">Brief Responses</option>
              <option value="detailed">Detailed Explanations</option>
              <option value="code_focused">Code-Focused</option>
              <option value="tutorial">Tutorial Style</option>
            </select>
          </div>
        </div>
      </div>
      {/* Voice Settings */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <MessageCircle className="h-6 w-6 text-orange-600" />
          <h3 className="text-lg font-semibold text-gray-900">Voice Integration</h3>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <label className="text-sm font-medium text-gray-900">Enable Voice Features</label>
              <p className="text-sm text-gray-600">
                Integration with voice-to-app creator and speech recognition
              </p>
            </div>
            <button
              onClick={() => handleInputChange('voice_settings', !formData?.voice_settings?.enabled, 'enabled')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                formData?.voice_settings?.enabled ? 'bg-orange-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  formData?.voice_settings?.enabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-700 mb-1">Language</label>
              <select
                value={formData?.voice_settings?.language || 'en-US'}
                onChange={(e) => handleInputChange('voice_settings', e?.target?.value, 'language')}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="en-US">English (US)</option>
                <option value="en-GB">English (UK)</option>
                <option value="es-ES">Spanish</option>
                <option value="fr-FR">French</option>
              </select>
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-1">Speech Speed</label>
              <select
                value={formData?.voice_settings?.speed || 'normal'}
                onChange={(e) => handleInputChange('voice_settings', e?.target?.value, 'speed')}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="slow">Slow</option>
                <option value="normal">Normal</option>
                <option value="fast">Fast</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      {/* Action Buttons */}
      <div className="flex items-center justify-between pt-6 border-t border-gray-200">
        <button
          onClick={handleReset}
          className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Reset to Defaults
        </button>

        <button
          onClick={handleSave}
          disabled={isSaving}
          className="inline-flex items-center px-6 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {isSaving ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
              Saving...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Save Settings
            </>
          )}
        </button>
      </div>
      {/* Help Section */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h4 className="font-medium text-blue-800 mb-3">💡 Settings Tips</h4>
        <div className="grid md:grid-cols-2 gap-4 text-sm text-blue-700">
          <div>
            <h5 className="font-medium mb-2">Learning Settings:</h5>
            <ul className="space-y-1">
              <li>• Enable learning for personalized responses</li>
              <li>• Higher assistance levels provide more detail</li>
              <li>• Framework preferences improve code suggestions</li>
            </ul>
          </div>
          <div>
            <h5 className="font-medium mb-2">Interaction Settings:</h5>
            <ul className="space-y-1">
              <li>• Proactive suggestions offer unsolicited help</li>
              <li>• Deep context memory remembers more history</li>
              <li>• Voice integration enables speech features</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssistantSettings;