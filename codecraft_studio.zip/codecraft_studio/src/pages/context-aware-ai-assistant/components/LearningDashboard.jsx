import React, { useState, useEffect } from 'react';
import { TrendingUp, Brain, Target, Award, BarChart3, Clock, Code, MessageCircle, Lightbulb } from 'lucide-react';

const LearningDashboard = ({ conversations = [], preferences }) => {
  const [analytics, setAnalytics] = useState({
    totalInteractions: 0,
    accuracyScore: 0,
    learningProgress: 0,
    topCategories: [],
    weeklyActivity: [],
    improvementAreas: []
  });

  useEffect(() => {
    calculateAnalytics();
  }, [conversations, preferences]);

  const calculateAnalytics = () => {
    if (!conversations || conversations?.length === 0) {
      setAnalytics({
        totalInteractions: 0,
        accuracyScore: 85,
        learningProgress: 15,
        topCategories: [],
        weeklyActivity: [],
        improvementAreas: []
      });
      return;
    }

    // Calculate metrics from conversations
    const totalMessages = conversations?.reduce((sum, conv) => sum + (conv?.total_messages || 0), 0);
    const avgMessagesPerConv = totalMessages / conversations?.length;

    // Mock analytics for demo - in real app this would be calculated from actual data
    const mockAnalytics = {
      totalInteractions: conversations?.length,
      accuracyScore: Math.min(95, 75 + (conversations?.length * 2)), // Improves with usage
      learningProgress: Math.min(100, (conversations?.length * 5)), // Progress based on interactions
      
      topCategories: [
        { name: 'Code Review', count: 12, percentage: 35, color: 'bg-blue-500' },
        { name: 'Project Guidance', count: 8, percentage: 25, color: 'bg-green-500' },
        { name: 'General Help', count: 7, percentage: 20, color: 'bg-purple-500' },
        { name: 'Voice Creation', count: 5, percentage: 15, color: 'bg-orange-500' },
        { name: 'Debug Assistance', count: 2, percentage: 5, color: 'bg-red-500' }
      ],
      
      weeklyActivity: [
        { day: 'Mon', interactions: 3, quality: 8 },
        { day: 'Tue', interactions: 5, quality: 9 },
        { day: 'Wed', interactions: 2, quality: 7 },
        { day: 'Thu', interactions: 7, quality: 9 },
        { day: 'Fri', interactions: 4, quality: 8 },
        { day: 'Sat', interactions: 1, quality: 6 },
        { day: 'Sun', interactions: 0, quality: 0 }
      ],
      
      improvementAreas: [
        {
          area: 'Code Quality Suggestions',
          current: 75,
          target: 90,
          trend: 'improving',
          description: 'Learning your coding style to provide better suggestions'
        },
        {
          area: 'Context Understanding',
          current: 88,
          target: 95,
          trend: 'stable',
          description: 'Understanding project context and user intent'
        },
        {
          area: 'Response Relevance',
          current: 82,
          target: 92,
          trend: 'improving',
          description: 'Providing more relevant and actionable responses'
        }
      ],
      
      learningInsights: [
        {
          type: 'pattern',
          title: 'Preferred Technologies',
          insight: 'You primarily work with React and focus on component optimization',
          confidence: 0.89
        },
        {
          type: 'timing',
          title: 'Peak Productivity',
          insight: 'Most active during weekday afternoons, typically asking complex questions',
          confidence: 0.76
        },
        {
          type: 'style',
          title: 'Communication Style',
          insight: 'Prefers detailed explanations with code examples',
          confidence: 0.92
        }
      ]
    };

    setAnalytics(mockAnalytics);
  };

  const getProgressColor = (percentage) => {
    if (percentage >= 80) return 'bg-green-500';
    if (percentage >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getTrendIcon = (trend) => {
    switch (trend) {
      case 'improving': return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'declining': return <TrendingUp className="h-4 w-4 text-red-500 rotate-180" />;
      default: return <Target className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <Brain className="h-8 w-8 text-purple-600" />
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Learning Dashboard</h2>
          <p className="text-gray-600">Track how your AI assistant learns and improves</p>
        </div>
      </div>
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-lg p-6 border-l-4 border-purple-500">
          <div className="flex items-center space-x-2 mb-2">
            <MessageCircle className="h-5 w-5 text-purple-600" />
            <span className="text-sm font-medium text-gray-600">Total Conversations</span>
          </div>
          <div className="text-3xl font-bold text-gray-900">{analytics?.totalInteractions}</div>
          <div className="text-sm text-gray-500">+{Math.max(0, analytics?.totalInteractions - 5)} this week</div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 border-l-4 border-green-500">
          <div className="flex items-center space-x-2 mb-2">
            <Target className="h-5 w-5 text-green-600" />
            <span className="text-sm font-medium text-gray-600">Accuracy Score</span>
          </div>
          <div className="text-3xl font-bold text-gray-900">{analytics?.accuracyScore}%</div>
          <div className="text-sm text-green-600">+{Math.min(5, Math.floor(analytics?.totalInteractions / 2))}% this week</div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 border-l-4 border-blue-500">
          <div className="flex items-center space-x-2 mb-2">
            <Brain className="h-5 w-5 text-blue-600" />
            <span className="text-sm font-medium text-gray-600">Learning Progress</span>
          </div>
          <div className="text-3xl font-bold text-gray-900">{analytics?.learningProgress}%</div>
          <div className="text-sm text-blue-600">Continuously improving</div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 border-l-4 border-orange-500">
          <div className="flex items-center space-x-2 mb-2">
            <Award className="h-5 w-5 text-orange-600" />
            <span className="text-sm font-medium text-gray-600">Quality Rating</span>
          </div>
          <div className="text-3xl font-bold text-gray-900">4.7/5</div>
          <div className="text-sm text-orange-600">Based on interactions</div>
        </div>
      </div>
      {/* Learning Progress Visualization */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Conversation Categories */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <BarChart3 className="h-5 w-5 mr-2 text-purple-600" />
            Conversation Categories
          </h3>
          
          <div className="space-y-4">
            {analytics?.topCategories?.map((category, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-4 h-4 rounded ${category?.color}`} />
                  <span className="text-sm font-medium text-gray-700">{category?.name}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="text-sm text-gray-600">{category?.count} times</div>
                  <div className="text-sm font-medium text-gray-900">{category?.percentage}%</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Weekly Activity */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Clock className="h-5 w-5 mr-2 text-blue-600" />
            Weekly Activity
          </h3>
          
          <div className="space-y-3">
            {analytics?.weeklyActivity?.map((day, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="text-sm font-medium text-gray-700 w-8">{day?.day}</div>
                <div className="flex-1 mx-3">
                  <div className="bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full ${getProgressColor(day?.interactions * 10)}`}
                      style={{ width: `${Math.min(100, day?.interactions * 15)}%` }}
                    />
                  </div>
                </div>
                <div className="text-sm text-gray-600 w-16 text-right">
                  {day?.interactions} chats
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Improvement Areas */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
          <TrendingUp className="h-5 w-5 mr-2 text-green-600" />
          Learning Areas & Progress
        </h3>
        
        <div className="grid gap-6">
          {analytics?.improvementAreas?.map((area, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <h4 className="font-medium text-gray-900">{area?.area}</h4>
                  {getTrendIcon(area?.trend)}
                </div>
                <div className="text-sm text-gray-600">
                  {area?.current}% / {area?.target}%
                </div>
              </div>
              
              <div className="mb-3">
                <div className="bg-gray-200 rounded-full h-3">
                  <div 
                    className={`h-3 rounded-full ${getProgressColor(area?.current)}`}
                    style={{ width: `${area?.current}%` }}
                  />
                </div>
              </div>
              
              <p className="text-sm text-gray-600">{area?.description}</p>
            </div>
          ))}
        </div>
      </div>
      {/* Learning Insights */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
          <Lightbulb className="h-5 w-5 mr-2 text-yellow-600" />
          AI Learning Insights
        </h3>
        
        <div className="grid md:grid-cols-3 gap-6">
          {analytics?.learningInsights?.map((insight, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                {insight?.type === 'pattern' && <Code className="h-4 w-4 text-blue-600" />}
                {insight?.type === 'timing' && <Clock className="h-4 w-4 text-green-600" />}
                {insight?.type === 'style' && <MessageCircle className="h-4 w-4 text-purple-600" />}
                <h4 className="font-medium text-gray-900">{insight?.title}</h4>
              </div>
              <p className="text-sm text-gray-700 mb-3">{insight?.insight}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">Confidence</span>
                <span className="text-xs font-medium text-gray-700">
                  {Math.round(insight?.confidence * 100)}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Learning Settings */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h4 className="font-medium text-blue-800 mb-4 flex items-center">
          <Brain className="h-5 w-5 mr-2" />
          Learning Configuration
        </h4>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h5 className="font-medium text-blue-800 mb-2">Current Settings</h5>
            <ul className="space-y-1 text-sm text-blue-700">
              <li>• Learning: <strong>{preferences?.learning_enabled ? 'Enabled' : 'Disabled'}</strong></li>
              <li>• Assistance Level: <strong>{preferences?.assistance_level || 'Balanced'}</strong></li>
              <li>• Preferred Frameworks: <strong>{preferences?.preferred_frameworks?.join(', ') || 'Auto-detect'}</strong></li>
            </ul>
          </div>
          
          <div>
            <h5 className="font-medium text-blue-800 mb-2">Learning Tips</h5>
            <ul className="space-y-1 text-sm text-blue-700">
              <li>• More interactions = better understanding</li>
              <li>• Provide feedback on responses for improvement</li>
              <li>• Share project context for better assistance</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LearningDashboard;