import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { aiAssistantService } from '../../services/aiService';
import ConversationInterface from './components/ConversationInterface';
import ContextualRecommendations from './components/ContextualRecommendations';
import LearningDashboard from './components/LearningDashboard';
import AssistantSettings from './components/AssistantSettings';
import { Bot, Brain, Settings, History, MessageCircle, Lightbulb, TrendingUp } from 'lucide-react';

const ContextAwareAIAssistant = () => {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState('chat');
  const [conversations, setConversations] = useState([]);
  const [currentConversation, setCurrentConversation] = useState(null);
  const [preferences, setPreferences] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Load initial data
  useEffect(() => {
    if (isAuthenticated) {
      loadInitialData();
    }
  }, [isAuthenticated]);

  const loadInitialData = async () => {
    setIsLoading(true);
    try {
      const [convResult, prefResult] = await Promise.all([
        aiAssistantService?.getConversations(20),
        aiAssistantService?.getUserPreferences()
      ]);

      if (convResult?.error) throw convResult?.error;
      if (prefResult?.error) throw prefResult?.error;

      setConversations(convResult?.data || []);
      setPreferences(prefResult?.data);
      
      // Load contextual recommendations using AI
      await loadRecommendations();
    } catch (err) {
      setError('Failed to load assistant data');
    } finally {
      setIsLoading(false);
    }
  };

  const loadRecommendations = async () => {
    try {
      if (isAuthenticated && import.meta.env?.VITE_OPENAI_API_KEY) {
        // Use real AI analysis for recommendations
        const { data, error } = await aiAssistantService?.analyzeUserPatterns();
        
        if (!error && data?.analysis) {
          // Process AI analysis into recommendations
          const aiRecommendations = parseAIAnalysisToRecommendations(data?.analysis, data?.conversationCount);
          setRecommendations(aiRecommendations);
          return;
        }
      }

      // Fallback to mock recommendations
      const mockRecommendations = [
        {
          id: 1,
          type: 'component',
          title: 'Add User Authentication',
          description: 'Based on your recent projects, consider adding user auth to improve security',
          confidence: 0.85,
          category: 'security'
        },
        {
          id: 2,
          type: 'improvement',
          title: 'Optimize Component Performance',
          description: 'Your dashboard components could benefit from React.memo for better performance',
          confidence: 0.72,
          category: 'performance'
        },
        {
          id: 3,
          type: 'feature',
          title: 'Dark Mode Implementation',
          description: 'Popular request: Add dark mode toggle to your applications',
          confidence: 0.91,
          category: 'ui/ux'
        }
      ];
      setRecommendations(mockRecommendations);
    } catch (err) {
      console.error('Failed to load recommendations:', err);
      setRecommendations([]);
    }
  };

  const parseAIAnalysisToRecommendations = (analysis, conversationCount) => {
    // Parse AI analysis text and convert to structured recommendations
    const recommendations = [];
    
    // Extract suggestions from AI analysis
    const lines = analysis?.split('\n');
    let currentId = 1;
    
    lines?.forEach(line => {
      if (line?.includes('suggest') || line?.includes('recommend') || line?.includes('consider')) {
        const title = line?.substring(0, 50) + '...';
        const confidence = Math.random() * 0.3 + 0.7; // 0.7-1.0 range
        
        recommendations?.push({
          id: currentId++,
          type: 'ai_suggestion',
          title: title,
          description: line,
          confidence: confidence,
          category: 'ai_insight',
          source: 'pattern_analysis'
        });
      }
    });

    // Add fallback if no suggestions parsed
    if (recommendations?.length === 0) {
      recommendations?.push({
        id: 1,
        type: 'insight',
        title: 'Continue Building',
        description: `Based on your ${conversationCount} conversations, keep exploring AI-powered development`,
        confidence: 0.8,
        category: 'general',
        source: 'ai_analysis'
      });
    }

    return recommendations?.slice(0, 5); // Limit to 5 recommendations
  };

  const handleNewConversation = async (title, type = 'general_help', projectId = null) => {
    try {
      const { data, error } = await aiAssistantService?.createConversation(title, type, projectId);
      if (error) throw error;

      setCurrentConversation(data);
      setConversations(prev => [data, ...prev]);
      setActiveTab('chat');
    } catch (err) {
      setError('Failed to create conversation');
    }
  };

  const handleSendMessage = async (message, conversationId) => {
    try {
      const { data, error } = await aiAssistantService?.sendMessage(conversationId, message, true);
      if (error) throw error;

      // Update current conversation
      setCurrentConversation(data?.conversation);
      
      // Update conversations list
      setConversations(prev => 
        prev?.map(conv => 
          conv?.id === conversationId ? data?.conversation : conv
        )
      );

      return data?.message;
    } catch (err) {
      setError('Failed to send message');
      throw err;
    }
  };

  const handleUpdatePreferences = async (updates) => {
    try {
      const { data, error } = await aiAssistantService?.updatePreferences(updates);
      if (error) throw error;
      
      setPreferences(data);
      
      // Reload recommendations when preferences change
      await loadRecommendations();
    } catch (err) {
      setError('Failed to update preferences');
    }
  };

  // Demo credentials for development
  const demoContent = !isAuthenticated && (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
      <h3 className="text-lg font-semibold text-blue-800 mb-2">Demo Mode</h3>
      <p className="text-blue-600 mb-4">
        You are viewing the Context-Aware AI Assistant in demo mode. Sign in and add your OpenAI API key to access personalized AI features.
      </p>
      <div className="bg-white p-4 rounded border">
        <h4 className="font-medium text-gray-800 mb-2">Demo Credentials:</h4>
        <p className="text-sm text-gray-600">Admin: admin@codecraft.com / adminpass123</p>
        <p className="text-sm text-gray-600">User: user@codecraft.com / userpass123</p>
      </div>
    </div>
  );

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          {demoContent}
          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                <Bot className="h-8 w-8 text-blue-600" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Context-Aware AI Assistant</h1>
              <p className="text-lg text-gray-600 mb-8">
                Personalized development guidance powered by GPT-5 that learns and adapts to your unique coding style
              </p>
              <div className="grid md:grid-cols-3 gap-6 text-left">
                <div className="flex items-start space-x-3">
                  <Brain className="h-6 w-6 text-blue-600 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Intelligent Context</h3>
                    <p className="text-gray-600 text-sm">Remembers your projects, preferences, and patterns</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Lightbulb className="h-6 w-6 text-blue-600 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Proactive Suggestions</h3>
                    <p className="text-gray-600 text-sm">Offers AI-powered improvements before you ask</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <TrendingUp className="h-6 w-6 text-blue-600 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Continuous Learning</h3>
                    <p className="text-gray-600 text-sm">Adapts to your evolving development style using GPT-5</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your AI assistant...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 rounded-lg">
                <Bot className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">AI Assistant</h1>
                <p className="text-gray-600">
                  {import.meta.env?.VITE_OPENAI_API_KEY 
                    ? "Your GPT-5 powered development companion" :"Your personalized development companion"
                  }
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                {preferences?.learning_enabled ? (
                  <span className="flex items-center text-green-600">
                    <Brain className="h-4 w-4 mr-1" />
                    {import.meta.env?.VITE_OPENAI_API_KEY ? 'AI Learning Active' : 'Learning Active'}
                  </span>
                ) : (
                  <span className="flex items-center text-gray-500">
                    <Brain className="h-4 w-4 mr-1" />
                    Learning Paused
                  </span>
                )}
              </div>
              
              <button
                onClick={() => setActiveTab('settings')}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </button>
            </div>
          </div>

          {/* Navigation tabs */}
          <div className="flex space-x-8 mt-6 border-b border-gray-200">
            <button
              onClick={() => setActiveTab('chat')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'chat' ?'border-blue-500 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <MessageCircle className="h-4 w-4 mr-2 inline" />
              Chat Assistant
            </button>
            <button
              onClick={() => setActiveTab('recommendations')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'recommendations' ?'border-blue-500 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Lightbulb className="h-4 w-4 mr-2 inline" />
              AI Recommendations
            </button>
            <button
              onClick={() => setActiveTab('learning')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'learning' ?'border-blue-500 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <TrendingUp className="h-4 w-4 mr-2 inline" />
              Learning Dashboard
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'history' ?'border-blue-500 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <History className="h-4 w-4 mr-2 inline" />
              Conversation History
            </button>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Error Display */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex">
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Error</h3>
                <p className="text-sm text-red-700 mt-1">{error}</p>
              </div>
              <button
                onClick={() => setError(null)}
                className="ml-auto text-red-600 hover:text-red-800"
              >
                ×
              </button>
            </div>
          </div>
        )}

        {/* API Key Status Banner */}
        {!import.meta.env?.VITE_OPENAI_API_KEY && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
            <div className="flex items-center">
              <div className="ml-3">
                <h3 className="text-sm font-medium text-amber-800">Limited Mode</h3>
                <p className="text-sm text-amber-700 mt-1">
                  Add your OpenAI API key in environment variables to unlock full AI-powered features including personalized recommendations and advanced pattern analysis.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Main Content */}
        {activeTab === 'chat' && (
          <ConversationInterface
            conversations={conversations}
            currentConversation={currentConversation}
            onNewConversation={handleNewConversation}
            onSendMessage={handleSendMessage}
            onSelectConversation={setCurrentConversation}
            preferences={preferences}
          />
        )}

        {activeTab === 'recommendations' && (
          <ContextualRecommendations
            recommendations={recommendations}
            preferences={preferences}
            onRefreshRecommendations={loadRecommendations}
          />
        )}

        {activeTab === 'learning' && (
          <LearningDashboard
            conversations={conversations}
            preferences={preferences}
          />
        )}

        {activeTab === 'settings' && (
          <AssistantSettings
            preferences={preferences}
            onUpdatePreferences={handleUpdatePreferences}
          />
        )}

        {activeTab === 'history' && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Conversation History</h2>
            <div className="space-y-4">
              {conversations?.map((conversation) => (
                <div key={conversation?.id} className="border rounded-lg p-4 hover:border-blue-200 hover:bg-blue-50/30 cursor-pointer transition-colors"
                     onClick={() => {setCurrentConversation(conversation); setActiveTab('chat');}}>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-gray-900">
                      {conversation?.title || 'Untitled Conversation'}
                    </h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      conversation?.conversation_type === 'project_guidance' ? 'bg-purple-100 text-purple-800' :
                      conversation?.conversation_type === 'code_review'? 'bg-green-100 text-green-800' : 
                      conversation?.conversation_type === 'code_generation'? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {conversation?.conversation_type?.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <span>{conversation?.total_messages} messages</span>
                    <span>{new Date(conversation.updated_at)?.toLocaleDateString()}</span>
                  </div>
                  {conversation?.projects && (
                    <div className="mt-2 text-sm text-gray-600">
                      Project: {conversation?.projects?.name}
                    </div>
                  )}
                </div>
              ))}
              
              {(!conversations || conversations?.length === 0) && (
                <div className="text-center py-12">
                  <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No conversations yet</h3>
                  <p className="text-gray-600">Start chatting with your AI assistant!</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ContextAwareAIAssistant;