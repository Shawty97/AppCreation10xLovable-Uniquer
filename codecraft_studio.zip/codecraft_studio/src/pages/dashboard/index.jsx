import React, { useState, useEffect } from 'react';
import { Plus, Zap, TrendingUp, BookOpen, Globe } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { projectService } from '../../services/projectService';

import { announcementService } from '../../services/announcementService';
import { dashboardService } from '../../services/dashboardService';
import { onboardingService } from '../../services/onboardingService';
import { ProjectCard } from './components/ProjectCard';
import StatsCard from './components/StatsCard';
import ActivityFeed from './components/ActivityFeed';
import AIAppGenerator from './components/AIAppGenerator';
import QuickStartTutorials from './components/QuickStartTutorials';
import AnnouncementCard from './components/AnnouncementCard';
import OnboardingFlow from '../../components/OnboardingFlow';

export default function Dashboard() {
  const { user, userProfile, loading: authLoading } = useAuth();
  const [projects, setProjects] = useState([]);
  const [activities, setActivities] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [stats, setStats] = useState({
    totalProjects: 0,
    publishedProjects: 0,
    draftProjects: 0,
    totalViews: 0,
    totalDeployments: 0,
    successfulDeployments: 0,
    aiConversations: 0,
    totalSpent: 0
  });

  // Load user's data
  useEffect(() => {
    if (user?.id) {
      loadDashboardData();
      checkOnboardingStatus();
    }
  }, [user?.id]);

  const loadDashboardData = async () => {
    if (!user?.id) return;
    
    setLoading(true);
    setError('');
    
    try {
      // Load comprehensive dashboard data
      const [statsRes, activitiesRes, projectsRes, announcementsRes] = await Promise.all([
        dashboardService?.getStats(user?.id),
        dashboardService?.getRecentActivity(user?.id, 10),
        projectService?.getAll(user?.id),
        announcementService?.getAnnouncements(5)
      ]);

      // Handle stats
      if (statsRes?.error) {
        setError('Failed to load dashboard statistics');
      } else if (statsRes?.data) {
        setStats({
          totalProjects: statsRes?.data?.projects?.total,
          publishedProjects: statsRes?.data?.projects?.published,
          draftProjects: statsRes?.data?.projects?.draft,
          totalDeployments: statsRes?.data?.deployments?.total,
          successfulDeployments: statsRes?.data?.deployments?.successful,
          aiConversations: statsRes?.data?.aiConversations?.total,
          totalSpent: statsRes?.data?.marketplace?.totalSpent,
          totalViews: Math.floor(Math.random() * 1000) // Mock view count for now
        });
      }

      // Handle activities (fallback to empty array if error)
      setActivities(activitiesRes?.data || []);
      
      // Handle projects (fallback to empty array if error) 
      setProjects(projectsRes?.data || []);
      
      // Handle announcements (fallback to empty array if error)
      setAnnouncements(announcementsRes?.data || []);
      
    } catch (err) {
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const checkOnboardingStatus = async () => {
    try {
      const { data, error } = await onboardingService?.getOnboardingStatus(user?.id);
      
      if (!error && data && !data?.isComplete) {
        setShowOnboarding(true);
      }
    } catch (err) {
      // Silently fail onboarding check
    }
  };

  const handleOnboardingComplete = () => {
    setShowOnboarding(false);
    // Reload dashboard data to reflect any changes from onboarding
    loadDashboardData();
  };

  const handleProjectUpdate = (updatedProject) => {
    setProjects(prev => prev?.map(p => 
      p?.id === updatedProject?.id ? updatedProject : p
    ));
  };

  const handleProjectDelete = (projectId) => {
    setProjects(prev => prev?.filter(p => p?.id !== projectId));
    setStats(prev => ({
      ...prev,
      totalProjects: Math.max(prev?.totalProjects - 1, 0)
    }));
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Onboarding Flow */}
      {showOnboarding && (
        <OnboardingFlow onComplete={handleOnboardingComplete} />
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Welcome back, {userProfile?.full_name || user?.email || 'Creator'}! 👋
              </h1>
              <p className="text-gray-600 mt-1">
                Let's build something amazing today
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              {userProfile?.role && (
                <span className={`px-3 py-1 text-xs font-medium rounded-full ${
                  userProfile?.role === 'admin' ? 'bg-purple-100 text-purple-800' :
                  userProfile?.role === 'premium' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {userProfile?.role?.toUpperCase()} USER
                </span>
              )}
              
              <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2">
                <Plus className="w-4 h-4" />
                New Project
              </button>
            </div>
          </div>
        </div>

        {/* Enhanced Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total Projects"
            value={stats?.totalProjects}
            icon={<Zap className="w-5 h-5" />}
            color="blue"
            change="+12%"
            subtitle="All your projects"
            trend="up"
            trendValue={12}
            actionLabel="View Projects"
            onAction={() => {}}
          />
          <StatsCard
            title="Published"
            value={stats?.publishedProjects}
            icon={<Globe className="w-5 h-5" />}
            color="green"
            change="+8%"
            subtitle="Live projects"
            trend="up"
            trendValue={8}
            actionLabel="Manage Published"
            onAction={() => {}}
          />
          <StatsCard
            title="Deployments"
            value={stats?.totalDeployments}
            icon={<TrendingUp className="w-5 h-5" />}
            color="purple"
            change="+24%"
            subtitle={`${stats?.successfulDeployments} successful`}
            trend="up"
            trendValue={24}
            actionLabel="View Deployments"
            onAction={() => {}}
          />
          <StatsCard
            title="AI Conversations"
            value={stats?.aiConversations}
            icon={<BookOpen className="w-5 h-5" />}
            color="yellow"
            change="+15%"
            subtitle="Total conversations"
            trend="up"
            trendValue={15}
            actionLabel="Start Chat"
            onAction={() => {}}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* AI App Generator */}
            <AIAppGenerator onGenerate={(projectData) => console.log('Generated project:', projectData)} />

            {/* Recent Projects */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Your Projects</h2>
                <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                  View All
                </button>
              </div>

              {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                  {error}
                  <button 
                    onClick={loadDashboardData}
                    className="ml-2 underline hover:no-underline"
                  >
                    Try Again
                  </button>
                </div>
              )}

              {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[1, 2, 3, 4]?.map((i) => (
                    <div key={i} className="bg-white rounded-lg border p-6 animate-pulse">
                      <div className="aspect-video bg-gray-200 rounded mb-4"></div>
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                    </div>
                  ))}
                </div>
              ) : projects?.length === 0 ? (
                <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
                  <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                  </svg>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No projects yet</h3>
                  <p className="text-gray-600 mb-4">Create your first project to get started</p>
                  <button 
                    onClick={() => setShowOnboarding(true)}
                    className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
                  >
                    Get Started
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {projects?.slice(0, 6)?.map((project) => (
                    <ProjectCard
                      key={project?.id}
                      project={project}
                      onUpdate={handleProjectUpdate}
                      onDelete={handleProjectDelete}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <AnnouncementCard announcements={announcements} />
            <QuickStartTutorials tutorials={[]} />
            <ActivityFeed activities={activities} />
          </div>
        </div>
      </div>
    </div>
  );
}