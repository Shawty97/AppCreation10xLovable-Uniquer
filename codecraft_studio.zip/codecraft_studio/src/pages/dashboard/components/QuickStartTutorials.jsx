import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickStartTutorials = ({ tutorials }) => {
  const [completedTutorials, setCompletedTutorials] = useState(new Set());

  const handleMarkComplete = (tutorialId) => {
    setCompletedTutorials(prev => new Set([...prev, tutorialId]));
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'beginner':
        return 'text-success bg-success/10';
      case 'intermediate':
        return 'text-warning bg-warning/10';
      case 'advanced':
        return 'text-error bg-error/10';
      default:
        return 'text-muted-foreground bg-muted';
    }
  };

  const getDifficultyIcon = (difficulty) => {
    switch (difficulty) {
      case 'beginner':
        return 'Circle';
      case 'intermediate':
        return 'CircleDot';
      case 'advanced':
        return 'Target';
      default:
        return 'Circle';
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg shadow-elevation-1">
      <div className="p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Icon name="GraduationCap" size={20} className="text-primary" />
          <h2 className="text-lg font-semibold text-foreground">Quick Start Tutorials</h2>
        </div>
      </div>
      <div className="p-4">
        {tutorials?.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="BookOpen" size={48} className="text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No tutorials available</p>
          </div>
        ) : (
          <div className="space-y-4">
            {tutorials?.map((tutorial) => {
              const isCompleted = completedTutorials?.has(tutorial?.id);
              
              return (
                <div 
                  key={tutorial?.id} 
                  className={`p-4 border rounded-lg transition-smooth ${
                    isCompleted 
                      ? 'bg-success/5 border-success/20' :'bg-muted/30 border-border hover:border-primary/30'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start space-x-3 flex-1">
                      <div className={`p-2 rounded-md ${
                        isCompleted ? 'bg-success text-success-foreground' : 'bg-primary/10'
                      }`}>
                        <Icon 
                          name={isCompleted ? 'CheckCircle' : tutorial?.icon} 
                          size={16} 
                          className={isCompleted ? 'text-success-foreground' : 'text-primary'}
                        />
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className={`font-medium ${
                            isCompleted ? 'text-success line-through' : 'text-foreground'
                          }`}>
                            {tutorial?.title}
                          </h3>
                          <div className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(tutorial?.difficulty)}`}>
                            <div className="flex items-center space-x-1">
                              <Icon name={getDifficultyIcon(tutorial?.difficulty)} size={10} />
                              <span>{tutorial?.difficulty}</span>
                            </div>
                          </div>
                        </div>
                        
                        <p className="text-sm text-muted-foreground mb-2">
                          {tutorial?.description}
                        </p>
                        
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <div className="flex items-center space-x-1">
                            <Icon name="Clock" size={12} />
                            <span>{tutorial?.duration}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Icon name="Users" size={12} />
                            <span>{tutorial?.completedBy} completed</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {!isCompleted && (
                        <Button
                          variant="outline"
                          size="sm"
                          iconName="Play"
                          iconPosition="left"
                          iconSize={14}
                          onClick={() => window.open(tutorial?.url, '_blank')}
                        >
                          Start Tutorial
                        </Button>
                      )}
                      
                      {isCompleted && (
                        <Button
                          variant="ghost"
                          size="sm"
                          iconName="RotateCcw"
                          iconPosition="left"
                          iconSize={14}
                          onClick={() => window.open(tutorial?.url, '_blank')}
                        >
                          Review
                        </Button>
                      )}
                    </div>

                    {!isCompleted && (
                      <Button
                        variant="ghost"
                        size="sm"
                        iconName="Check"
                        iconSize={14}
                        onClick={() => handleMarkComplete(tutorial?.id)}
                        className="text-success hover:text-success"
                      >
                        Mark Complete
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default QuickStartTutorials;