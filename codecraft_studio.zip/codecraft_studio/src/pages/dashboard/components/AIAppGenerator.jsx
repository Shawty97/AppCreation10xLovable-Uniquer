import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const AIAppGenerator = ({ onGenerate }) => {
  const [description, setDescription] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [appType, setAppType] = useState('web-app');
  const [features, setFeatures] = useState([]);

  const appTypes = [
    { value: 'web-app', label: 'Web Application', icon: 'Globe' },
    { value: 'landing-page', label: 'Landing Page', icon: 'Layout' },
    { value: 'dashboard', label: 'Dashboard', icon: 'BarChart3' },
    { value: 'e-commerce', label: 'E-commerce', icon: 'ShoppingCart' },
    { value: 'blog', label: 'Blog/CMS', icon: 'FileText' },
    { value: 'portfolio', label: 'Portfolio', icon: 'User' }
  ];

  const availableFeatures = [
    'User Authentication',
    'Payment Integration',
    'Email Notifications',
    'File Upload',
    'Real-time Chat',
    'Analytics Dashboard',
    'Search Functionality',
    'Social Media Integration',
    'Multi-language Support',
    'Mobile Responsive'
  ];

  const handleGenerate = async () => {
    if (!description?.trim()) return;
    
    setIsGenerating(true);
    
    // Simulate AI generation process
    setTimeout(() => {
      const generatedApp = {
        name: `AI Generated App - ${Date.now()}`,
        description: description?.trim(),
        type: appTypes?.find(t => t?.value === appType)?.label || 'Web Application',
        features: features,
        status: 'draft',
        thumbnail: `https://images.unsplash.com/photo-1551650975-87deedd944c3?w=400&h=300&fit=crop`,
        lastModified: new Date(),
        views: 0
      };
      
      onGenerate(generatedApp);
      setDescription('');
      setFeatures([]);
      setIsGenerating(false);
    }, 3000);
  };

  const toggleFeature = (feature) => {
    setFeatures(prev => 
      prev?.includes(feature) 
        ? prev?.filter(f => f !== feature)
        : [...prev, feature]
    );
  };

  return (
    <div className="bg-gradient-to-br from-primary/5 to-accent/5 border border-primary/20 rounded-lg shadow-elevation-2">
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="p-2 bg-primary/10 rounded-md">
            <Icon name="Sparkles" size={24} className="text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-foreground">AI App Generator</h2>
            <p className="text-sm text-muted-foreground">Describe your app idea and let AI build it for you</p>
          </div>
        </div>

        <div className="space-y-4">
          <Input
            label="Describe Your App"
            type="text"
            placeholder="e.g., A task management app for small teams with real-time collaboration..."
            value={description}
            onChange={(e) => setDescription(e?.target?.value)}
            className="text-base"
          />

          {/* Advanced Options Toggle */}
          <Button
            variant="ghost"
            size="sm"
            iconName={showAdvanced ? 'ChevronUp' : 'ChevronDown'}
            iconPosition="right"
            iconSize={16}
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="text-primary hover:text-primary"
          >
            Advanced Options
          </Button>

          {showAdvanced && (
            <div className="space-y-4 p-4 bg-card/50 border border-border/50 rounded-lg">
              {/* App Type Selection */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  App Type
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {appTypes?.map((type) => (
                    <button
                      key={type?.value}
                      onClick={() => setAppType(type?.value)}
                      className={`p-3 border rounded-lg text-sm font-medium transition-quick flex items-center space-x-2 ${
                        appType === type?.value
                          ? 'bg-primary text-primary-foreground border-primary'
                          : 'bg-card text-foreground border-border hover:border-primary/30'
                      }`}
                    >
                      <Icon name={type?.icon} size={16} />
                      <span>{type?.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Feature Selection */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Desired Features ({features?.length} selected)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {availableFeatures?.map((feature) => (
                    <button
                      key={feature}
                      onClick={() => toggleFeature(feature)}
                      className={`p-2 border rounded-md text-sm transition-quick text-left ${
                        features?.includes(feature)
                          ? 'bg-primary/10 text-primary border-primary/30' :'bg-card text-foreground border-border hover:border-primary/30'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <Icon 
                          name={features?.includes(feature) ? 'CheckSquare' : 'Square'} 
                          size={14} 
                        />
                        <span>{feature}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          <Button
            variant="default"
            size="lg"
            loading={isGenerating}
            iconName="Sparkles"
            iconPosition="left"
            iconSize={20}
            onClick={handleGenerate}
            disabled={!description?.trim() || isGenerating}
            className="w-full"
          >
            {isGenerating ? 'Generating Your App...' : 'Generate App with AI'}
          </Button>

          {isGenerating && (
            <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="animate-spin">
                  <Icon name="Loader2" size={20} className="text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">AI is working on your app...</p>
                  <p className="text-xs text-muted-foreground">This may take a few moments</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIAppGenerator;