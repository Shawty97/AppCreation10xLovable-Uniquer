import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const StatsCard = ({ title, value, subtitle, icon, trend, trendValue, actionLabel, onAction, isLimitApproaching = false }) => {
  const getTrendColor = (trend) => {
    switch (trend) {
      case 'up':
        return 'text-success';
      case 'down':
        return 'text-error';
      default:
        return 'text-muted-foreground';
    }
  };

  const getTrendIcon = (trend) => {
    switch (trend) {
      case 'up':
        return 'TrendingUp';
      case 'down':
        return 'TrendingDown';
      default:
        return 'Minus';
    }
  };

  return (
    <div className={`bg-card border rounded-lg p-6 shadow-elevation-1 hover-lift transition-smooth ${
      isLimitApproaching ? 'border-warning' : 'border-border'
    }`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-md ${isLimitApproaching ? 'bg-warning/10' : 'bg-primary/10'}`}>
            <Icon 
              name={icon} 
              size={20} 
              className={isLimitApproaching ? 'text-warning' : 'text-primary'} 
            />
          </div>
          <div>
            <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
            <p className="text-2xl font-bold text-foreground">{value}</p>
          </div>
        </div>
        
        {trend && (
          <div className={`flex items-center space-x-1 ${getTrendColor(trend)}`}>
            <Icon name={getTrendIcon(trend)} size={16} />
            <span className="text-sm font-medium">{trendValue}</span>
          </div>
        )}
      </div>

      {subtitle && (
        <p className="text-sm text-muted-foreground mb-4">{subtitle}</p>
      )}

      {isLimitApproaching && (
        <div className="mb-4 p-3 bg-warning/10 border border-warning/20 rounded-md">
          <div className="flex items-center space-x-2">
            <Icon name="AlertTriangle" size={16} className="text-warning" />
            <p className="text-sm text-warning-foreground">
              Approaching plan limit
            </p>
          </div>
        </div>
      )}

      {actionLabel && onAction && (
        <Button
          variant={isLimitApproaching ? "warning" : "outline"}
          size="sm"
          onClick={onAction}
          className="w-full"
        >
          {actionLabel}
        </Button>
      )}
    </div>
  );
};

export default StatsCard;