import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AnnouncementCard = ({ announcements }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [dismissedIds, setDismissedIds] = useState(new Set());

  const visibleAnnouncements = announcements?.filter(
    announcement => !dismissedIds?.has(announcement?.id)
  );

  const handleDismiss = (id) => {
    setDismissedIds(prev => new Set([...prev, id]));
    if (currentIndex >= visibleAnnouncements?.length - 1) {
      setCurrentIndex(Math.max(0, currentIndex - 1));
    }
  };

  const handleNext = () => {
    setCurrentIndex((prev) => 
      prev < visibleAnnouncements?.length - 1 ? prev + 1 : 0
    );
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => 
      prev > 0 ? prev - 1 : visibleAnnouncements?.length - 1
    );
  };

  const getAnnouncementIcon = (type) => {
    switch (type) {
      case 'feature':
        return 'Sparkles';
      case 'update':
        return 'RefreshCw';
      case 'maintenance':
        return 'Wrench';
      case 'promotion':
        return 'Gift';
      default:
        return 'Bell';
    }
  };

  const getAnnouncementColor = (type) => {
    switch (type) {
      case 'feature':
        return 'text-success bg-success/10 border-success/20';
      case 'update':
        return 'text-primary bg-primary/10 border-primary/20';
      case 'maintenance':
        return 'text-warning bg-warning/10 border-warning/20';
      case 'promotion':
        return 'text-accent bg-accent/10 border-accent/20';
      default:
        return 'text-muted-foreground bg-muted border-border';
    }
  };

  if (visibleAnnouncements?.length === 0) {
    return null;
  }

  const currentAnnouncement = visibleAnnouncements?.[currentIndex];

  return (
    <div className="bg-card border border-border rounded-lg shadow-elevation-1">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Bell" size={20} className="text-primary" />
            <h2 className="text-lg font-semibold text-foreground">Announcements</h2>
          </div>
          
          {visibleAnnouncements?.length > 1 && (
            <div className="flex items-center space-x-1">
              <Button
                variant="ghost"
                size="icon"
                iconName="ChevronLeft"
                iconSize={16}
                onClick={handlePrev}
                className="h-8 w-8"
              />
              <span className="text-xs text-muted-foreground px-2">
                {currentIndex + 1} of {visibleAnnouncements?.length}
              </span>
              <Button
                variant="ghost"
                size="icon"
                iconName="ChevronRight"
                iconSize={16}
                onClick={handleNext}
                className="h-8 w-8"
              />
            </div>
          )}
        </div>
      </div>
      <div className="p-4">
        <div className={`p-4 rounded-lg border ${getAnnouncementColor(currentAnnouncement?.type)}`}>
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center space-x-2">
              <Icon 
                name={getAnnouncementIcon(currentAnnouncement?.type)} 
                size={18} 
                className={currentAnnouncement?.type === 'feature' ? 'text-success' : 
                          currentAnnouncement?.type === 'update' ? 'text-primary' :
                          currentAnnouncement?.type === 'maintenance' ? 'text-warning' :
                          currentAnnouncement?.type === 'promotion' ? 'text-accent' : 'text-muted-foreground'}
              />
              <h3 className="font-semibold text-foreground">{currentAnnouncement?.title}</h3>
            </div>
            
            <Button
              variant="ghost"
              size="icon"
              iconName="X"
              iconSize={14}
              onClick={() => handleDismiss(currentAnnouncement?.id)}
              className="h-6 w-6 text-muted-foreground hover:text-foreground"
            />
          </div>

          <p className="text-sm text-foreground mb-3">
            {currentAnnouncement?.message}
          </p>

          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">
              {new Date(currentAnnouncement.date)?.toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric'
              })}
            </span>
            
            {currentAnnouncement?.actionLabel && currentAnnouncement?.actionUrl && (
              <Button
                variant="outline"
                size="sm"
                iconName="ExternalLink"
                iconPosition="right"
                iconSize={14}
                onClick={() => window.open(currentAnnouncement?.actionUrl, '_blank')}
              >
                {currentAnnouncement?.actionLabel}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnnouncementCard;