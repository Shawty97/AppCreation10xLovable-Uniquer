import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';
import { cn } from '../../../utils/cn';

const TemplateManager = () => {
  const [activeTab, setActiveTab] = useState('saved'); // saved, community, custom

  // Mock template data
  const savedTemplates = [
    {
      id: '1',
      name: 'E-commerce Starter',
      type: 'web',
      thumbnail: null,
      downloads: 245,
      lastUpdated: '2 days ago'
    },
    {
      id: '2',
      name: 'Mobile App Template',
      type: 'mobile',
      thumbnail: null,
      downloads: 189,
      lastUpdated: '1 week ago'
    }
  ];

  const communityTemplates = [
    {
      id: '3',
      name: 'SaaS Dashboard Pro',
      type: 'web',
      thumbnail: null,
      downloads: 1250,
      rating: 4.8,
      author: 'DesignCorp',
      price: 'Free'
    },
    {
      id: '4',
      name: 'Restaurant App Kit',
      type: 'mobile',
      thumbnail: null,
      downloads: 890,
      rating: 4.6,
      author: 'FoodTech',
      price: '$29'
    }
  ];

  const customTemplates = [
    {
      id: '5',
      name: 'My Custom Layout',
      type: 'web',
      thumbnail: null,
      createdDate: '3 days ago',
      components: 12
    }
  ];

  const getTypeIcon = (type) => {
    switch (type) {
      case 'web': return 'Globe';
      case 'mobile': return 'Smartphone';
      case 'desktop': return 'Monitor';
      default: return 'FileText';
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'web': return 'text-blue-500';
      case 'mobile': return 'text-green-500';
      case 'desktop': return 'text-purple-500';
      default: return 'text-muted-foreground';
    }
  };

  const renderTemplateCard = (template, type) => (
    <motion.div
      key={template?.id}
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
      className="bg-muted/20 rounded-lg p-4 hover:bg-muted/40 transition-colors cursor-pointer"
    >
      {/* Thumbnail */}
      <div className="w-full h-24 bg-muted rounded-lg mb-3 flex items-center justify-center">
        <Icon name="ImageIcon" size={24} className="text-muted-foreground" />
      </div>

      {/* Template Info */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h4 className="font-medium text-foreground text-sm truncate">
            {template?.name}
          </h4>
          <Icon 
            name={getTypeIcon(template?.type)} 
            size={14} 
            className={getTypeColor(template?.type)} 
          />
        </div>

        {type === 'saved' && (
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{template?.downloads} downloads</span>
            <span>{template?.lastUpdated}</span>
          </div>
        )}

        {type === 'community' && (
          <div className="space-y-1">
            <div className="flex items-center space-x-1">
              <Icon name="Star" size={12} className="text-warning fill-current" />
              <span className="text-xs text-muted-foreground">{template?.rating}</span>
              <span className="text-xs text-muted-foreground">•</span>
              <span className="text-xs text-muted-foreground">{template?.downloads} downloads</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">by {template?.author}</span>
              <span className={cn(
                "text-xs px-2 py-1 rounded-full",
                template?.price === 'Free' 
                  ? "bg-success/20 text-success" :"bg-primary/20 text-primary"
              )}>
                {template?.price}
              </span>
            </div>
          </div>
        )}

        {type === 'custom' && (
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{template?.components} components</span>
            <span>{template?.createdDate}</span>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex space-x-2 mt-3">
        <Button variant="outline" size="xs" fullWidth>
          <Icon name="Eye" size={12} className="mr-1" />
          Preview
        </Button>
        <Button size="xs" fullWidth>
          <Icon name="Download" size={12} className="mr-1" />
          Use
        </Button>
      </div>
    </motion.div>
  );

  const tabs = [
    { id: 'saved', label: 'Saved', count: savedTemplates?.length },
    { id: 'community', label: 'Community', count: communityTemplates?.length },
    { id: 'custom', label: 'Custom', count: customTemplates?.length }
  ];

  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-warning/20 rounded-xl flex items-center justify-center">
          <Icon name="Layers" size={20} className="text-warning" />
        </div>
        <div>
          <h3 className="font-medium text-foreground">Templates</h3>
          <p className="text-sm text-muted-foreground">Reusable components</p>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex bg-muted/20 rounded-lg p-1 mb-6">
        {tabs?.map((tab) => (
          <button
            key={tab?.id}
            onClick={() => setActiveTab(tab?.id)}
            className={cn(
              'flex-1 py-2 px-3 text-xs font-medium rounded-md transition-colors relative',
              activeTab === tab?.id
                ? 'bg-background text-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground'
            )}
          >
            {tab?.label}
            {tab?.count > 0 && (
              <span className={cn(
                "ml-1 px-1.5 py-0.5 rounded-full text-xs",
                activeTab === tab?.id
                  ? "bg-primary/20 text-primary" :"bg-muted text-muted-foreground"
              )}>
                {tab?.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Template Grid */}
      <div className="space-y-4">
        {activeTab === 'saved' && (
          <div className="grid grid-cols-1 gap-4">
            {savedTemplates?.map(template => renderTemplateCard(template, 'saved'))}
          </div>
        )}

        {activeTab === 'community' && (
          <div className="grid grid-cols-1 gap-4">
            {communityTemplates?.map(template => renderTemplateCard(template, 'community'))}
          </div>
        )}

        {activeTab === 'custom' && (
          <div className="grid grid-cols-1 gap-4">
            {customTemplates?.length > 0 ? (
              customTemplates?.map(template => renderTemplateCard(template, 'custom'))
            ) : (
              <div className="text-center py-8">
                <div className="w-12 h-12 bg-muted/50 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Icon name="Plus" size={24} className="text-muted-foreground" />
                </div>
                <p className="text-sm text-muted-foreground mb-3">
                  No custom templates yet
                </p>
                <Button variant="outline" size="sm">
                  <Icon name="Plus" size={14} className="mr-2" />
                  Create Template
                </Button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="mt-6 pt-6 border-t border-border">
        <div className="space-y-2">
          <Button variant="outline" size="sm" fullWidth>
            <Icon name="Search" size={16} className="mr-2" />
            Browse All Templates
          </Button>
          <Button variant="ghost" size="sm" fullWidth>
            <Icon name="Upload" size={16} className="mr-2" />
            Upload Template
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TemplateManager;