import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';
import { cn } from '../../../utils/cn';

const VersionControl = ({ project }) => {
  const [commitMessage, setCommitMessage] = useState('');
  const [showCommitForm, setShowCommitForm] = useState(false);

  // Mock commit history
  const commitHistory = [
    {
      id: '1',
      hash: 'a1b2c3d',
      message: 'Add new landing page design',
      author: 'Alice Johnson',
      date: new Date(Date.now() - 2 * 60 * 60 * 1000),
      branch: 'main',
      changes: { added: 5, modified: 3, deleted: 1 }
    },
    {
      id: '2',
      hash: 'e4f5g6h',
      message: 'Update user authentication flow',
      author: 'Bob Smith',
      date: new Date(Date.now() - 6 * 60 * 60 * 1000),
      branch: 'feature/auth',
      changes: { added: 2, modified: 8, deleted: 0 }
    },
    {
      id: '3',
      hash: 'i7j8k9l',
      message: 'Fix responsive design issues',
      author: 'Alice Johnson',
      date: new Date(Date.now() - 24 * 60 * 60 * 1000),
      branch: 'main',
      changes: { added: 0, modified: 12, deleted: 3 }
    }
  ];

  const branches = [
    { name: 'main', isActive: true, commits: 15, lastUpdate: '2 hours ago' },
    { name: 'feature/auth', isActive: false, commits: 8, lastUpdate: '6 hours ago' },
    { name: 'feature/dashboard', isActive: false, commits: 5, lastUpdate: '1 day ago' }
  ];

  const formatDate = (date) => {
    const now = new Date();
    const diffMs = now - date;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffHours < 1) return 'Just now';
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays === 1) return 'Yesterday';
    return `${diffDays} days ago`;
  };

  const handleCommit = async (e) => {
    e?.preventDefault();
    if (!commitMessage?.trim()) return;

    console.log('Creating commit:', commitMessage);
    setCommitMessage('');
    setShowCommitForm(false);
  };

  const handleBranchSwitch = (branchName) => {
    console.log('Switching to branch:', branchName);
  };

  const handleRollback = (commitHash) => {
    console.log('Rolling back to commit:', commitHash);
  };

  if (!project) {
    return (
      <div className="bg-card rounded-xl border border-border p-8 text-center">
        <div className="w-16 h-16 bg-muted/50 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Icon name="GitBranch" size={32} className="text-muted-foreground" />
        </div>
        <h3 className="font-medium text-foreground mb-2">Version Control</h3>
        <p className="text-sm text-muted-foreground">
          Select a project to view version history
        </p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-accent/20 rounded-xl flex items-center justify-center">
            <Icon name="GitBranch" size={20} className="text-accent" />
          </div>
          <div>
            <h3 className="font-medium text-foreground">Version Control</h3>
            <p className="text-sm text-muted-foreground">{project?.name}</p>
          </div>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowCommitForm(!showCommitForm)}
        >
          <Icon name="GitCommit" size={16} className="mr-2" />
          Commit
        </Button>
      </div>
      {/* Commit Form */}
      {showCommitForm && (
        <motion.form
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          onSubmit={handleCommit}
          className="mb-6 p-4 bg-muted/30 rounded-lg"
        >
          <div className="space-y-3">
            <Input
              type="text"
              placeholder="Describe your changes..."
              value={commitMessage}
              onChange={(e) => setCommitMessage(e?.target?.value)}
              required
            />
            <div className="flex space-x-2">
              <Button type="submit" size="sm">
                <Icon name="Check" size={16} className="mr-2" />
                Commit Changes
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                size="sm"
                onClick={() => setShowCommitForm(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        </motion.form>
      )}
      {/* Branches */}
      <div className="mb-6">
        <h4 className="text-sm font-medium text-foreground mb-3">Branches</h4>
        <div className="space-y-2">
          {branches?.map((branch) => (
            <div
              key={branch?.name}
              className={cn(
                "flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors",
                branch?.isActive 
                  ? "bg-primary/10 border border-primary/20" :"bg-muted/20 hover:bg-muted/40"
              )}
              onClick={() => !branch?.isActive && handleBranchSwitch(branch?.name)}
            >
              <div className="flex items-center space-x-3">
                <Icon 
                  name="GitBranch" 
                  size={16} 
                  className={branch?.isActive ? "text-primary" : "text-muted-foreground"} 
                />
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-medium text-foreground">{branch?.name}</span>
                    {branch?.isActive && (
                      <span className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded-full">
                        Current
                      </span>
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {branch?.commits} commits • {branch?.lastUpdate}
                  </div>
                </div>
              </div>
              
              {!branch?.isActive && (
                <Icon name="ArrowRight" size={16} className="text-muted-foreground" />
              )}
            </div>
          ))}
        </div>
      </div>
      {/* Commit History */}
      <div>
        <h4 className="text-sm font-medium text-foreground mb-3">Recent Commits</h4>
        <div className="space-y-3">
          {commitHistory?.map((commit) => (
            <motion.div
              key={commit?.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-start space-x-3 p-3 bg-muted/20 rounded-lg"
            >
              <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                <Icon name="GitCommit" size={16} className="text-primary" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="font-mono text-xs bg-muted px-2 py-1 rounded">
                    {commit?.hash}
                  </span>
                  <span className="text-xs bg-accent/20 text-accent px-2 py-1 rounded-full">
                    {commit?.branch}
                  </span>
                </div>

                <div className="font-medium text-foreground mb-1">
                  {commit?.message}
                </div>

                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <span>{commit?.author}</span>
                  <span>{formatDate(commit?.date)}</span>
                  <div className="flex items-center space-x-2">
                    {commit?.changes?.added > 0 && (
                      <span className="text-success">+{commit?.changes?.added}</span>
                    )}
                    {commit?.changes?.modified > 0 && (
                      <span className="text-warning">~{commit?.changes?.modified}</span>
                    )}
                    {commit?.changes?.deleted > 0 && (
                      <span className="text-destructive">-{commit?.changes?.deleted}</span>
                    )}
                  </div>
                </div>
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleRollback(commit?.hash)}
              >
                <Icon name="RotateCcw" size={14} />
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VersionControl;