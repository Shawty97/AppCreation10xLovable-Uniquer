import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const ProjectActions = ({ selectedProject, onAction }) => {
  const [isProcessing, setIsProcessing] = useState(false);

  const quickActions = [
    {
      id: 'edit',
      label: 'Edit Project',
      icon: 'Edit',
      variant: 'default',
      description: 'Open in visual builder'
    },
    {
      id: 'preview',
      label: 'Preview',
      icon: 'Eye',
      variant: 'outline',
      description: 'Live preview mode'
    },
    {
      id: 'deploy',
      label: 'Deploy',
      icon: 'Rocket',
      variant: 'success',
      description: 'Publish to production'
    },
    {
      id: 'duplicate',
      label: 'Duplicate',
      icon: 'Copy',
      variant: 'outline',
      description: 'Create a copy'
    }
  ];

  const handleAction = async (actionId) => {
    if (!selectedProject && ['edit', 'preview', 'deploy']?.includes(actionId)) {
      return;
    }

    setIsProcessing(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      onAction?.(actionId, selectedProject ? [selectedProject?.id] : []);
    } catch (error) {
      console.error('Action failed:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center">
          <Icon name="Zap" size={20} className="text-primary" />
        </div>
        <div>
          <h3 className="font-medium text-foreground">Quick Actions</h3>
          <p className="text-sm text-muted-foreground">
            {selectedProject ? `For ${selectedProject?.name}` : 'Select a project'}
          </p>
        </div>
      </div>
      <div className="space-y-3">
        {quickActions?.map((action) => (
          <motion.div
            key={action?.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Button
              variant={action?.variant}
              fullWidth
              size="lg"
              disabled={isProcessing || (!selectedProject && ['edit', 'preview', 'deploy']?.includes(action?.id))}
              onClick={() => handleAction(action?.id)}
              className="justify-start h-auto p-4"
            >
              <div className="flex items-center space-x-3">
                <Icon name={action?.icon} size={20} />
                <div className="text-left">
                  <div className="font-medium">{action?.label}</div>
                  <div className="text-xs opacity-70">{action?.description}</div>
                </div>
              </div>
            </Button>
          </motion.div>
        ))}
      </div>
      {/* Additional Tools */}
      <div className="mt-6 pt-6 border-t border-border">
        <h4 className="text-sm font-medium text-foreground mb-3">Project Tools</h4>
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant="ghost"
            size="sm"
            fullWidth
            disabled={!selectedProject}
            onClick={() => handleAction('export')}
          >
            <Icon name="Download" size={16} className="mr-2" />
            Export
          </Button>
          <Button
            variant="ghost"
            size="sm"
            fullWidth
            disabled={!selectedProject}
            onClick={() => handleAction('share')}
          >
            <Icon name="Share" size={16} className="mr-2" />
            Share
          </Button>
          <Button
            variant="ghost"
            size="sm"
            fullWidth
            disabled={!selectedProject}
            onClick={() => handleAction('settings')}
          >
            <Icon name="Settings" size={16} className="mr-2" />
            Settings
          </Button>
          <Button
            variant="ghost"
            size="sm"
            fullWidth
            disabled={!selectedProject}
            onClick={() => handleAction('archive')}
          >
            <Icon name="Archive" size={16} className="mr-2" />
            Archive
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProjectActions;