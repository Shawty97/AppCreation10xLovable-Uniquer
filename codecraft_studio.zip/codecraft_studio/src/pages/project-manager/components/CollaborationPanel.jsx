import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';
import { cn } from '../../../utils/cn';

const CollaborationPanel = ({ project, projects }) => {
  const [inviteEmail, setInviteEmail] = useState('');
  const [showInvite, setShowInvite] = useState(false);

  // Mock collaborator data
  const mockCollaborators = [
    {
      id: 'user1',
      name: 'Alice Johnson',
      email: 'alice@example.com',
      avatar: null,
      role: 'owner',
      status: 'online',
      lastActive: new Date()
    },
    {
      id: 'user2',
      name: 'Bob Smith',
      email: 'bob@example.com',
      avatar: null,
      role: 'editor',
      status: 'away',
      lastActive: new Date(Date.now() - 30 * 60 * 1000)
    },
    {
      id: 'user3',
      name: 'Carol Davis',
      email: 'carol@example.com',
      avatar: null,
      role: 'viewer',
      status: 'offline',
      lastActive: new Date(Date.now() - 2 * 60 * 60 * 1000)
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'online': return 'bg-success';
      case 'away': return 'bg-warning';
      case 'offline': return 'bg-muted-foreground';
      default: return 'bg-muted-foreground';
    }
  };

  const getRoleColor = (role) => {
    switch (role) {
      case 'owner': return 'bg-primary text-primary-foreground';
      case 'editor': return 'bg-success text-success-foreground';
      case 'viewer': return 'bg-muted text-muted-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const formatLastActive = (date) => {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMins / 60);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return date?.toLocaleDateString();
  };

  const handleInvite = async (e) => {
    e?.preventDefault();
    if (!inviteEmail) return;

    console.log('Inviting:', inviteEmail);
    setInviteEmail('');
    setShowInvite(false);
  };

  const activeCollaborators = project 
    ? mockCollaborators?.filter(user => project?.collaborators?.includes(user?.id))
    : [];

  const totalActiveUsers = projects?.reduce((acc, proj) => {
    return acc + proj?.collaborators?.length;
  }, 0);

  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-success/20 rounded-xl flex items-center justify-center">
            <Icon name="Users" size={20} className="text-success" />
          </div>
          <div>
            <h3 className="font-medium text-foreground">Team</h3>
            <p className="text-sm text-muted-foreground">
              {project ? `${activeCollaborators?.length} members` : `${totalActiveUsers} total active`}
            </p>
          </div>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowInvite(!showInvite)}
        >
          <Icon name="UserPlus" size={16} className="mr-2" />
          Invite
        </Button>
      </div>
      {/* Invite Form */}
      {showInvite && (
        <motion.form
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          onSubmit={handleInvite}
          className="mb-6 p-4 bg-muted/30 rounded-lg"
        >
          <div className="flex space-x-2">
            <Input
              type="email"
              placeholder="Enter email address"
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e?.target?.value)}
              className="flex-1"
            />
            <Button type="submit" size="sm">
              Send
            </Button>
          </div>
        </motion.form>
      )}
      {/* Team Members */}
      <div className="space-y-4">
        {project && activeCollaborators?.length > 0 ? (
          activeCollaborators?.map((user) => (
            <motion.div
              key={user?.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center justify-between p-3 bg-muted/20 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                {/* Avatar */}
                <div className="relative">
                  <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center">
                    <span className="text-sm font-medium text-primary">
                      {user?.name?.split(' ')?.map(n => n?.[0])?.join('')}
                    </span>
                  </div>
                  <div className={cn(
                    "absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-card",
                    getStatusColor(user?.status)
                  )} />
                </div>

                {/* User Info */}
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-medium text-foreground">{user?.name}</span>
                    <span className={cn(
                      "text-xs px-2 py-1 rounded-full",
                      getRoleColor(user?.role)
                    )}>
                      {user?.role}
                    </span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {user?.status === 'online' ? 'Active now' : formatLastActive(user?.lastActive)}
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center space-x-1">
                <Button variant="ghost" size="sm">
                  <Icon name="MessageCircle" size={14} />
                </Button>
                <Button variant="ghost" size="sm">
                  <Icon name="MoreHorizontal" size={14} />
                </Button>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-muted/50 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Icon name="Users" size={32} className="text-muted-foreground" />
            </div>
            <h4 className="font-medium text-foreground mb-2">
              {project ? 'No Team Members' : 'Select a Project'}
            </h4>
            <p className="text-sm text-muted-foreground mb-4">
              {project 
                ? 'Invite team members to collaborate' :'Choose a project to view team members'
              }
            </p>
            {project && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowInvite(true)}
              >
                <Icon name="UserPlus" size={16} className="mr-2" />
                Invite Team
              </Button>
            )}
          </div>
        )}
      </div>
      {/* Team Stats */}
      <div className="mt-6 pt-6 border-t border-border">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-lg font-semibold text-foreground">
              {projects?.length}
            </div>
            <div className="text-xs text-muted-foreground">Projects</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-foreground">
              {totalActiveUsers}
            </div>
            <div className="text-xs text-muted-foreground">Active Users</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-foreground">
              {Math.round(totalActiveUsers / Math.max(projects?.length, 1))}
            </div>
            <div className="text-xs text-muted-foreground">Avg/Project</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CollaborationPanel;