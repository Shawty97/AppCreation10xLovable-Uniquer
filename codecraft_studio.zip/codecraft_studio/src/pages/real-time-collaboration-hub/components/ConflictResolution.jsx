import React, { useState } from 'react';
import { AlertTriangle, Users, Clock, CheckCircle, GitBranch, FileText, Merge } from 'lucide-react';

const ConflictResolution = ({ conflicts = [] }) => {
  const [selectedConflict, setSelectedConflict] = useState(null);
  const [resolutionAction, setResolutionAction] = useState('');

  const getConflictSeverity = (type) => {
    switch (type) {
      case 'simultaneous_edit': return { level: 'high', color: 'red' };
      case 'merge_conflict': return { level: 'medium', color: 'yellow' };
      case 'version_mismatch': return { level: 'low', color: 'blue' };
      default: return { level: 'medium', color: 'yellow' };
    }
  };

  const handleResolveConflict = (conflictId, action) => {
    // Mock conflict resolution
    console.log(`Resolving conflict ${conflictId} with action: ${action}`);
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = Math.floor((now - timestamp) / 1000);
    
    if (diff < 60) return `${diff}s ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    return `${Math.floor(diff / 3600)}h ago`;
  };

  return (
    <div className="space-y-6">
      {/* Conflict Overview */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2 text-orange-600" />
            Conflict Resolution System
          </h3>
          
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">
              {conflicts?.length || 0} active conflicts
            </span>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              Auto-resolve Compatible
            </button>
          </div>
        </div>

        {/* Conflict Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <div className="text-2xl font-bold text-red-600">2</div>
            <div className="text-sm text-red-700">High Priority</div>
          </div>
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600">1</div>
            <div className="text-sm text-yellow-700">Medium Priority</div>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">0</div>
            <div className="text-sm text-blue-700">Low Priority</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">15</div>
            <div className="text-sm text-green-700">Resolved Today</div>
          </div>
        </div>
      </div>
      {/* Active Conflicts */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h4 className="font-semibold text-gray-900">Active Conflicts</h4>
        </div>

        <div className="divide-y divide-gray-200">
          {conflicts?.map((conflict) => {
            const severity = getConflictSeverity(conflict?.type);
            const isSelected = selectedConflict === conflict?.id;
            
            return (
              <div key={conflict?.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-${severity?.color}-100 text-${severity?.color}-800`}>
                        {severity?.level} priority
                      </span>
                      <span className="text-sm text-gray-600 flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {formatTimeAgo(conflict?.timestamp)}
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-2 mb-3">
                      <FileText className="w-5 h-5 text-gray-400" />
                      <span className="font-medium text-gray-900">{conflict?.file}</span>
                      <span className="text-gray-500">Line {conflict?.line}</span>
                    </div>
                    
                    <div className="flex items-center space-x-2 mb-4">
                      <Users className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-600">
                        Conflict between: {conflict?.users?.join(', ')}
                      </span>
                    </div>
                    
                    {/* Conflict Type Description */}
                    <div className="bg-gray-50 rounded-lg p-4 mb-4">
                      {conflict?.type === 'simultaneous_edit' && (
                        <div>
                          <h5 className="font-medium text-gray-900 mb-2">Simultaneous Edit Conflict</h5>
                          <p className="text-sm text-gray-600">
                            Multiple users edited the same code section at the same time. 
                            Review changes and choose the correct version.
                          </p>
                        </div>
                      )}
                    </div>
                    
                    <button
                      onClick={() => setSelectedConflict(isSelected ? null : conflict?.id)}
                      className="text-blue-600 hover:text-blue-700 font-medium text-sm"
                    >
                      {isSelected ? 'Hide Details' : 'View Details & Resolve'}
                    </button>
                  </div>
                  
                  <div className="flex space-x-2 ml-4">
                    <button
                      onClick={() => handleResolveConflict(conflict?.id, 'accept_mine')}
                      className="px-3 py-1 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors text-sm"
                    >
                      <CheckCircle className="w-4 h-4 inline mr-1" />
                      Accept Mine
                    </button>
                    <button
                      onClick={() => handleResolveConflict(conflict?.id, 'accept_theirs')}
                      className="px-3 py-1 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors text-sm"
                    >
                      <Merge className="w-4 h-4 inline mr-1" />
                      Accept Theirs
                    </button>
                    <button
                      onClick={() => handleResolveConflict(conflict?.id, 'merge')}
                      className="px-3 py-1 bg-purple-100 text-purple-800 rounded-lg hover:bg-purple-200 transition-colors text-sm"
                    >
                      <GitBranch className="w-4 h-4 inline mr-1" />
                      Merge Both
                    </button>
                  </div>
                </div>
                {/* Detailed Resolution Panel */}
                {isSelected && (
                  <div className="mt-6 border-t border-gray-200 pt-6">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {/* Left Side - Original Code */}
                      <div>
                        <h5 className="font-medium text-gray-900 mb-3 flex items-center">
                          <span className="w-3 h-3 bg-red-500 rounded-full mr-2"></span>
                          {conflict?.users?.[0]}'s Version
                        </h5>
                        <div className="bg-gray-900 rounded-lg p-4 overflow-x-auto">
                          <pre className="text-sm text-gray-100">
{`const Header = () => {
  return (
    <header className="bg-blue-600 text-white">
      <h1>My App Header</h1>
    </header>
  );
};`}
                          </pre>
                        </div>
                      </div>
                      
                      {/* Right Side - Conflicting Code */}
                      <div>
                        <h5 className="font-medium text-gray-900 mb-3 flex items-center">
                          <span className="w-3 h-3 bg-blue-500 rounded-full mr-2"></span>
                          {conflict?.users?.[1]}'s Version
                        </h5>
                        <div className="bg-gray-900 rounded-lg p-4 overflow-x-auto">
                          <pre className="text-sm text-gray-100">
{`const Header = () => {
  return (
    <header className="bg-green-600 text-white shadow-lg">
      <h1>CodeCraft Studio</h1>
    </header>
  );
};`}
                          </pre>
                        </div>
                      </div>
                    </div>
                    
                    {/* Merge Suggestions */}
                    <div className="mt-6">
                      <h5 className="font-medium text-gray-900 mb-3">AI Merge Suggestions</h5>
                      <div className="space-y-3">
                        <div className="flex items-start space-x-3 p-4 bg-green-50 rounded-lg">
                          <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                          <div>
                            <div className="font-medium text-green-900">Recommended Merge</div>
                            <div className="text-sm text-green-700 mt-1">
                              Combine both changes: Use "CodeCraft Studio" title with green background and shadow
                            </div>
                          </div>
                          <button className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700 transition-colors">
                            Apply
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          
          {conflicts?.length === 0 && (
            <div className="p-12 text-center">
              <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Active Conflicts</h3>
              <p className="text-gray-600">All team edits are in sync. Great collaboration!</p>
            </div>
          )}
        </div>
      </div>
      {/* Resolution History */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h4 className="font-semibold text-gray-900 mb-4">Recent Resolutions</h4>
        
        <div className="space-y-4">
          <div className="flex items-center space-x-4 p-4 bg-green-50 rounded-lg">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <div className="flex-1">
              <div className="font-medium text-green-900">Button.jsx conflict resolved</div>
              <div className="text-sm text-green-700">Alex Chen merged both versions • 2 minutes ago</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4 p-4 bg-green-50 rounded-lg">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <div className="flex-1">
              <div className="font-medium text-green-900">styles.css conflict auto-resolved</div>
              <div className="text-sm text-green-700">No overlapping changes detected • 5 minutes ago</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConflictResolution;