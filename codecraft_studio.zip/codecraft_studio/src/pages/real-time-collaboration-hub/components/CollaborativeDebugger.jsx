import React, { useState } from 'react';
import { Bug, Play, Pause, Square, SkipForward, SkipBack, Eye, Users, Zap, CheckCircle, Clock, Code, Terminal } from 'lucide-react';

const CollaborativeDebugger = ({ collaborators = [] }) => {
  const [isDebugging, setIsDebugging] = useState(false);
  const [currentLine, setCurrentLine] = useState(23);
  const [breakpoints, setBreakpoints] = useState([15, 23, 45]);
  const [watchVariables, setWatchVariables] = useState([
    { name: 'userInput', value: '"Hello World"', type: 'string' },
    { name: 'counter', value: '5', type: 'number' },
    { name: 'isValid', value: 'true', type: 'boolean' }
  ]);
  const [callStack, setCallStack] = useState([
    { function: 'handleSubmit', line: 23, file: 'Form.jsx' },
    { function: 'validateInput', line: 15, file: 'validation.js' },
    { function: 'main', line: 45, file: 'App.jsx' }
  ]);

  const handleDebugAction = (action) => {
    switch (action) {
      case 'start':
        setIsDebugging(true);
        break;
      case 'pause':
        setIsDebugging(false);
        break;
      case 'step':
        setCurrentLine(currentLine + 1);
        break;
      case 'stepBack':
        setCurrentLine(Math.max(1, currentLine - 1));
        break;
      case 'stop':
        setIsDebugging(false);
        setCurrentLine(1);
        break;
      default:
        break;
    }
  };

  const toggleBreakpoint = (line) => {
    setBreakpoints(prev => 
      prev?.includes(line) 
        ? prev?.filter(bp => bp !== line)
        : [...prev, line]
    );
  };

  const mockCode = `import React, { useState } from 'react';

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});

  const validateInput = () => {
    const newErrors = {};
    
    if (!email.includes('@')) {
      newErrors.email = 'Invalid email format';
    }
    
    if (password.length < 8) {
      newErrors.password = 'Password too short';
    }
    
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validateInput();
    
    if (Object.keys(validationErrors).length === 0) {
      // Submit form
      console.log('Form submitted successfully');
    } else {
      setErrors(validationErrors);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input 
        type="email" 
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input 
        type="password" 
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button type="submit">Login</button>
    </form>
  );
};`?.split('\n');

  return (
    <div className="space-y-6">
      {/* Debug Controls */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Bug className="w-5 h-5 mr-2 text-red-600" />
            Collaborative Debugging Tools
          </h3>
          
          <div className="flex items-center space-x-2">
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
              isDebugging ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
            }`}>
              {isDebugging ? 'Debugging Active' : 'Ready to Debug'}
            </span>
          </div>
        </div>

        {/* Debug Toolbar */}
        <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg mb-6">
          <button
            onClick={() => handleDebugAction(isDebugging ? 'pause' : 'start')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
              isDebugging
                ? 'bg-yellow-600 text-white hover:bg-yellow-700' :'bg-green-600 text-white hover:bg-green-700'
            }`}
          >
            {isDebugging ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isDebugging ? 'Pause' : 'Start Debug'}</span>
          </button>

          <button
            onClick={() => handleDebugAction('stepBack')}
            disabled={!isDebugging}
            className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            title="Step Back"
          >
            <SkipBack className="w-5 h-5" />
          </button>

          <button
            onClick={() => handleDebugAction('step')}
            disabled={!isDebugging}
            className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            title="Step Forward"
          >
            <SkipForward className="w-5 h-5" />
          </button>

          <button
            onClick={() => handleDebugAction('stop')}
            className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
            title="Stop Debug"
          >
            <Square className="w-5 h-5" />
          </button>

          <div className="flex items-center space-x-2 ml-auto">
            <span className="text-sm text-gray-600">Current line:</span>
            <span className="font-mono font-bold text-blue-600">{currentLine}</span>
          </div>
        </div>

        {/* Active Debuggers */}
        <div className="mb-6">
          <h4 className="font-medium text-gray-900 mb-3 flex items-center">
            <Users className="w-4 h-4 mr-2 text-blue-600" />
            Active Debug Sessions
          </h4>
          
          <div className="space-y-2">
            {collaborators?.slice(0, 2)?.map((collaborator, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <img
                    src={collaborator?.avatar}
                    alt={collaborator?.name}
                    className="w-6 h-6 rounded-full"
                  />
                  <span className="font-medium text-blue-900">{collaborator?.name}</span>
                  <span className="text-sm text-blue-700">debugging Form.jsx:25</span>
                </div>
                
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                    Join Session
                  </button>
                </div>
              </div>
            ))}
            
            {(!collaborators || collaborators?.length === 0) && (
              <p className="text-gray-500 text-sm">No active debug sessions</p>
            )}
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Code View with Breakpoints */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-4 border-b border-gray-200 flex items-center justify-between">
            <h4 className="font-semibold text-gray-900 flex items-center">
              <Code className="w-4 h-4 mr-2" />
              Code View - LoginForm.jsx
            </h4>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">Shared breakpoints</span>
              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
            </div>
          </div>

          <div className="p-4">
            <div className="font-mono text-sm bg-gray-900 text-gray-100 rounded-lg overflow-hidden">
              {mockCode?.map((line, index) => {
                const lineNumber = index + 1;
                const hasBreakpoint = breakpoints?.includes(lineNumber);
                const isCurrentLine = lineNumber === currentLine && isDebugging;
                
                return (
                  <div
                    key={lineNumber}
                    className={`flex items-center ${
                      isCurrentLine ? 'bg-yellow-600' : ''
                    } ${hasBreakpoint ? 'bg-red-900' : ''} hover:bg-gray-800 transition-colors`}
                  >
                    <button
                      onClick={() => toggleBreakpoint(lineNumber)}
                      className="w-8 flex-shrink-0 text-center text-xs text-gray-500 hover:text-white p-1"
                    >
                      {hasBreakpoint ? '●' : lineNumber}
                    </button>
                    <pre className="flex-1 p-2 overflow-x-auto">
                      <code className={isCurrentLine ? 'text-black font-bold' : ''}>
                        {line}
                      </code>
                    </pre>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Debug Information Panel */}
        <div className="space-y-6">
          {/* Variables Watch */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-4 border-b border-gray-200">
              <h4 className="font-semibold text-gray-900 flex items-center">
                <Eye className="w-4 h-4 mr-2" />
                Watch Variables
              </h4>
            </div>
            
            <div className="p-4">
              <div className="space-y-3">
                {watchVariables?.map((variable, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <div className="font-mono text-sm font-medium text-gray-900">
                        {variable?.name}
                      </div>
                      <div className="text-xs text-gray-600">{variable?.type}</div>
                    </div>
                    <div className="font-mono text-sm text-blue-600">
                      {variable?.value}
                    </div>
                  </div>
                ))}
              </div>
              
              <button className="mt-4 w-full text-center text-blue-600 hover:text-blue-700 text-sm font-medium py-2 border border-dashed border-blue-300 rounded-lg hover:bg-blue-50 transition-colors">
                + Add Variable to Watch
              </button>
            </div>
          </div>

          {/* Call Stack */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-4 border-b border-gray-200">
              <h4 className="font-semibold text-gray-900 flex items-center">
                <Terminal className="w-4 h-4 mr-2" />
                Call Stack
              </h4>
            </div>
            
            <div className="p-4">
              <div className="space-y-2">
                {callStack?.map((frame, index) => (
                  <div key={index} className={`p-3 rounded-lg ${index === 0 ? 'bg-blue-50 border border-blue-200' : 'bg-gray-50'}`}>
                    <div className="font-mono text-sm font-medium text-gray-900">
                      {frame?.function}()
                    </div>
                    <div className="text-xs text-gray-600">
                      {frame?.file}:{frame?.line}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Synchronized Execution */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h4 className="font-semibold text-gray-900 mb-4 flex items-center">
          <Zap className="w-4 h-4 mr-2 text-yellow-600" />
          Synchronized Execution
        </h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h5 className="font-medium text-gray-900 mb-3">Debug Synchronization</h5>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Sync breakpoints across team</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" defaultChecked />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Follow team leader</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
          </div>
          
          <div>
            <h5 className="font-medium text-gray-900 mb-3">Session Status</h5>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-sm">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-gray-600">Connected to debug server</span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <Clock className="w-4 h-4 text-blue-600" />
                <span className="text-gray-600">Session time: 15:32</span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <Users className="w-4 h-4 text-purple-600" />
                <span className="text-gray-600">{collaborators?.length || 0} participants</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CollaborativeDebugger;