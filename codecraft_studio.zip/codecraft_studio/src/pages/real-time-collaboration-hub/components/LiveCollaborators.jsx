import React, { useState } from 'react';
import { Eye, Edit3, MousePointer, FileText, Clock, Users } from 'lucide-react';

const LiveCollaborators = ({ collaborators = [] }) => {
  const [selectedFile, setSelectedFile] = useState('all');

  const getStatusColor = (status) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'editing': return 'bg-blue-500';
      case 'viewing': return 'bg-yellow-500';
      case 'away': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'editing': return Edit3;
      case 'viewing': return Eye;
      default: return MousePointer;
    }
  };

  const files = [...new Set(collaborators.map(c => c.currentFile))];

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Users className="w-5 h-5 mr-2 text-blue-600" />
            Live Collaborators
          </h3>
          <div className="flex items-center space-x-2">
            <select 
              value={selectedFile}
              onChange={(e) => setSelectedFile(e?.target?.value)}
              className="text-sm border border-gray-300 rounded-lg px-3 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Files</option>
              {files?.map(file => (
                <option key={file} value={file}>{file}</option>
              ))}
            </select>
          </div>
        </div>
        
        {/* Real-time Workspace Preview */}
        <div className="relative bg-gray-50 rounded-lg p-6 mb-6" style={{ height: '300px' }}>
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg"></div>
          <div className="relative">
            <h4 className="text-sm font-medium text-gray-700 mb-3">Shared Workspace</h4>
            
            {/* Simulated cursors and selections */}
            {collaborators?.filter(c => selectedFile === 'all' || c?.currentFile === selectedFile)?.map((collaborator) => {
              const StatusIcon = getStatusIcon(collaborator?.status);
              return (
                <div key={collaborator?.id} className="mb-4">
                  {/* User cursor indicator */}
                  <div 
                    className="absolute animate-pulse"
                    style={{ 
                      left: `${collaborator?.cursor?.x || 50}px`, 
                      top: `${collaborator?.cursor?.y || 50}px` 
                    }}
                  >
                    <div className="flex items-center space-x-1">
                      <MousePointer className="w-4 h-4 text-blue-600" />
                      <div className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-medium">
                        {collaborator?.name}
                      </div>
                    </div>
                  </div>
                  {/* Selection indicator */}
                  {collaborator?.status === 'editing' && (
                    <div 
                      className="absolute bg-blue-200 opacity-50 rounded"
                      style={{
                        left: `${(collaborator?.cursor?.x || 50) + 20}px`,
                        top: `${(collaborator?.cursor?.y || 50) + 30}px`,
                        width: '120px',
                        height: '20px'
                      }}
                    />
                  )}
                </div>
              );
            })}
            
            {/* Mock code preview */}
            <div className="mt-16 space-y-2 font-mono text-sm text-gray-600">
              <div>import React from 'react'
;</div>
              <div className="text-blue-600">const Header = () => {'{}'}</div>
              <div className="ml-4">return (</div>
              <div className="ml-8 bg-yellow-100 px-2 py-0.5 rounded">&lt;header className="..."&gt;</div>
              <div className="ml-8">  &lt;h1&gt;CodeCraft Studio&lt;/h1&gt;</div>
              <div className="ml-8">&lt;/header&gt;</div>
              <div className="ml-4">);</div>
              <div>{'}'};</div>
            </div>
          </div>
        </div>
      </div>
      {/* Collaborator List */}
      <div className="p-6">
        <div className="space-y-4">
          {collaborators?.filter(c => selectedFile === 'all' || c?.currentFile === selectedFile)?.map((collaborator) => {
            const StatusIcon = getStatusIcon(collaborator?.status);
            
            return (
              <div key={collaborator?.id} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="relative">
                  <img
                    src={collaborator?.avatar}
                    alt={collaborator?.name}
                    className="w-10 h-10 rounded-full"
                  />
                  <div className={`absolute -bottom-1 -right-1 w-4 h-4 ${getStatusColor(collaborator?.status)} border-2 border-white rounded-full`}></div>
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <h4 className="font-medium text-gray-900">{collaborator?.name}</h4>
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {collaborator?.role}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-3 mt-1">
                    <div className="flex items-center space-x-1 text-sm text-gray-600">
                      <StatusIcon className="w-4 h-4" />
                      <span className="capitalize">{collaborator?.status}</span>
                    </div>
                    
                    <div className="flex items-center space-x-1 text-sm text-gray-600">
                      <FileText className="w-4 h-4" />
                      <span>{collaborator?.currentFile}</span>
                    </div>
                  </div>
                  
                  {collaborator?.status === 'editing' && collaborator?.selection && (
                    <div className="mt-2 text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded">
                      Editing lines {collaborator?.selection?.start}-{collaborator?.selection?.end}
                    </div>
                  )}
                </div>
                <div className="text-sm text-gray-500">
                  <Clock className="w-4 h-4 inline mr-1" />
                  Active
                </div>
              </div>
            );
          })}
        </div>
        
        {collaborators?.length === 0 && (
          <div className="text-center py-8">
            <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No collaborators active</p>
            <button className="mt-2 text-blue-600 hover:text-blue-700 text-sm font-medium">
              Invite team members
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default LiveCollaborators;