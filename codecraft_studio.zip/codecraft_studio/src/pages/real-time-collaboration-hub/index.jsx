import React, { useState, useEffect } from 'react';
import { MessageSquare, Share2, GitBranch, Settings, Activity, Video, Mic, Monitor, Play, Pause, AlertCircle, Code, Bug } from 'lucide-react';
import Header from 'components/ui/Header';
import Sidebar from 'components/ui/Sidebar';
import LiveCollaborators from './components/LiveCollaborators';
import ChatPanel from './components/ChatPanel';
import ScreenShare from './components/ScreenShare';
import ConflictResolution from './components/ConflictResolution';
import ActivityFeed from './components/ActivityFeed';
import PermissionManager from './components/PermissionManager';
import CollaborativeDebugger from './components/CollaborativeDebugger';
import VersionControlIntegration from './components/VersionControlIntegration';
import Icon from '../../components/AppIcon';


const RealTimeCollaborationHub = () => {
  const [activeView, setActiveView] = useState('workspace');
  const [collaborators, setCollaborators] = useState([]);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [conflicts, setConflicts] = useState([]);
  const [activities, setActivities] = useState([]);
  const [permissions, setPermissions] = useState({});

  useEffect(() => {
    // Mock real-time data
    setCollaborators([
      {
        id: 1,
        name: 'Alex Chen',
        avatar: '/api/placeholder/32/32',
        status: 'online',
        cursor: { x: 245, y: 156 },
        selection: { start: 15, end: 28 },
        currentFile: 'components/Header.jsx',
        role: 'owner'
      },
      {
        id: 2,
        name: 'Sarah Kim',
        avatar: '/api/placeholder/32/32',
        status: 'editing',
        cursor: { x: 456, y: 234 },
        selection: { start: 45, end: 67 },
        currentFile: 'pages/Dashboard.jsx',
        role: 'editor'
      },
      {
        id: 3,
        name: 'Mike Johnson',
        avatar: '/api/placeholder/32/32',
        status: 'viewing',
        cursor: { x: 123, y: 789 },
        currentFile: 'utils/helpers.js',
        role: 'viewer'
      }
    ]);

    setConflicts([
      {
        id: 1,
        file: 'components/Button.jsx',
        line: 23,
        users: ['Alex Chen', 'Sarah Kim'],
        timestamp: new Date(Date.now() - 5000),
        type: 'simultaneous_edit'
      }
    ]);

    setActivities([
      {
        id: 1,
        user: 'Alex Chen',
        action: 'modified',
        target: 'Header component',
        timestamp: new Date(Date.now() - 30000),
        type: 'edit'
      },
      {
        id: 2,
        user: 'Sarah Kim',
        action: 'commented on',
        target: 'Dashboard refactor',
        timestamp: new Date(Date.now() - 120000),
        type: 'comment'
      },
      {
        id: 3,
        user: 'Mike Johnson',
        action: 'joined session',
        target: 'Project Alpha',
        timestamp: new Date(Date.now() - 300000),
        type: 'session'
      }
    ]);
  }, []);

  const handleScreenShareToggle = () => {
    setIsScreenSharing(!isScreenSharing);
  };

  const handleRecordingToggle = () => {
    setIsRecording(!isRecording);
  };

  const tabItems = [
    { id: 'workspace', label: 'Workspace', icon: Code },
    { id: 'chat', label: 'Chat', icon: MessageSquare },
    { id: 'screen-share', label: 'Screen Share', icon: Share2 },
    { id: 'conflicts', label: 'Conflicts', icon: AlertCircle, count: conflicts?.length },
    { id: 'activity', label: 'Activity', icon: Activity },
    { id: 'permissions', label: 'Permissions', icon: Settings },
    { id: 'debug', label: 'Debug', icon: Bug },
    { id: 'version', label: 'Version Control', icon: GitBranch }
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar onToggleCollapse={() => {}} />
      <div className="flex-1 flex flex-col">
        <Header />
        
        <div className="flex-1 flex">
          {/* Main Collaboration Workspace */}
          <div className="flex-1 flex flex-col">
            {/* Collaboration Toolbar */}
            <div className="bg-white border-b border-gray-200 px-6 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <h1 className="text-2xl font-bold text-gray-900">
                    Real-time Collaboration Hub
                  </h1>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-sm text-gray-600">
                      {collaborators?.length} active collaborators
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  {/* Voice/Video Controls */}
                  <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
                    <Mic className="w-5 h-5" />
                  </button>
                  <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
                    <Video className="w-5 h-5" />
                  </button>
                  
                  {/* Screen Share */}
                  <button 
                    onClick={handleScreenShareToggle}
                    className={`p-2 rounded-lg transition-colors ${
                      isScreenSharing 
                        ? 'text-blue-600 bg-blue-50' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    <Monitor className="w-5 h-5" />
                  </button>
                  
                  {/* Recording */}
                  <button 
                    onClick={handleRecordingToggle}
                    className={`p-2 rounded-lg transition-colors ${
                      isRecording 
                        ? 'text-red-600 bg-red-50' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    {isRecording ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  </button>
                  
                  {/* Live Collaborators Mini View */}
                  <div className="flex items-center -space-x-2">
                    {collaborators?.slice(0, 3)?.map((collaborator) => (
                      <img
                        key={collaborator?.id}
                        src={collaborator?.avatar}
                        alt={collaborator?.name}
                        className="w-8 h-8 rounded-full border-2 border-white ring-2 ring-gray-200"
                      />
                    ))}
                    {collaborators?.length > 3 && (
                      <div className="w-8 h-8 rounded-full bg-gray-200 border-2 border-white ring-2 ring-gray-200 flex items-center justify-center text-xs font-medium text-gray-600">
                        +{collaborators?.length - 3}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Tab Navigation */}
            <div className="bg-white border-b border-gray-200">
              <nav className="flex space-x-8 px-6">
                {tabItems?.map((tab) => {
                  const Icon = tab?.icon;
                  const isActive = activeView === tab?.id;
                  
                  return (
                    <button
                      key={tab?.id}
                      onClick={() => setActiveView(tab?.id)}
                      className={`relative flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                        isActive
                          ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{tab?.label}</span>
                      {tab?.count > 0 && (
                        <span className="bg-red-100 text-red-800 text-xs font-medium px-2 py-0.5 rounded-full">
                          {tab?.count}
                        </span>
                      )}
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 p-6 overflow-auto">
              {activeView === 'workspace' && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2">
                    <LiveCollaborators collaborators={collaborators} />
                  </div>
                  <div>
                    <ChatPanel />
                  </div>
                </div>
              )}
              
              {activeView === 'chat' && (
                <ChatPanel fullView />
              )}
              
              {activeView === 'screen-share' && (
                <ScreenShare 
                  isActive={isScreenSharing}
                  isRecording={isRecording}
                  collaborators={collaborators}
                />
              )}
              
              {activeView === 'conflicts' && (
                <ConflictResolution conflicts={conflicts} />
              )}
              
              {activeView === 'activity' && (
                <ActivityFeed activities={activities} />
              )}
              
              {activeView === 'permissions' && (
                <PermissionManager 
                  collaborators={collaborators}
                  permissions={permissions}
                  onUpdatePermissions={setPermissions}
                />
              )}
              
              {activeView === 'debug' && (
                <CollaborativeDebugger collaborators={collaborators} />
              )}
              
              {activeView === 'version' && (
                <VersionControlIntegration />
              )}
            </div>
          </div>

          {/* Real-time Status Panel */}
          <div className="w-80 bg-white border-l border-gray-200 p-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Live Status</h3>
            
            {/* Connection Status */}
            <div className="mb-6">
              <div className="flex items-center space-x-2 mb-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm font-medium text-gray-900">Connected</span>
              </div>
              <p className="text-xs text-gray-600">
                Real-time sync active • Last update: now
              </p>
            </div>

            {/* Active Sessions */}
            <div className="mb-6">
              <h4 className="text-sm font-medium text-gray-900 mb-3">Active Sessions</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-blue-50 rounded-lg">
                  <span className="text-sm text-blue-900">Voice Chat</span>
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="text-xs text-blue-700">2 active</span>
                  </div>
                </div>
                {isScreenSharing && (
                  <div className="flex items-center justify-between p-2 bg-green-50 rounded-lg">
                    <span className="text-sm text-green-900">Screen Share</span>
                    <div className="flex items-center space-x-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-xs text-green-700">Active</span>
                    </div>
                  </div>
                )}
                {isRecording && (
                  <div className="flex items-center justify-between p-2 bg-red-50 rounded-lg">
                    <span className="text-sm text-red-900">Recording</span>
                    <div className="flex items-center space-x-1">
                      <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                      <span className="text-xs text-red-700">00:05:23</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Actions */}
            <div>
              <h4 className="text-sm font-medium text-gray-900 mb-3">Quick Actions</h4>
              <div className="space-y-2">
                <button className="w-full text-left p-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg transition-colors">
                  Share project link
                </button>
                <button className="w-full text-left p-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg transition-colors">
                  Export session logs
                </button>
                <button className="w-full text-left p-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg transition-colors">
                  Create meeting summary
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RealTimeCollaborationHub;