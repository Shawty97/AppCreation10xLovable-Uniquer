import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';


const TwoFactorSetup = ({ email, onComplete, onBack }) => {
  const [step, setStep] = useState(1); // 1: QR Code, 2: Verification, 3: Backup Codes
  const [verificationCode, setVerificationCode] = useState('');
  const [backupCodes, setBackupCodes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [qrCodeData, setQrCodeData] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    // Generate QR code data (this would typically come from your backend)
    setQrCodeData(`otpauth://totp/YourApp:${email}?secret=BASE32SECRET&issuer=YourApp`);
    
    // Generate backup codes
    const codes = Array.from({ length: 8 }, () => 
      Array.from({ length: 2 }, () => Math.random()?.toString(36)?.substr(2, 4))?.join('-')
    );
    setBackupCodes(codes);
  }, [email]);

  const handleVerifyCode = async () => {
    if (!verificationCode || verificationCode?.length !== 6) {
      setError('Please enter a 6-digit verification code');
      return;
    }

    setLoading(true);
    setError('');

    try {
      // Simulate API verification
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock verification (in real app, verify with backend)
      if (verificationCode === '123456') {
        setStep(3);
      } else {
        setError('Invalid verification code. Please try again.');
      }
    } catch (err) {
      setError('Verification failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleComplete = () => {
    onComplete?.();
  };

  const copyBackupCodes = async () => {
    const codesText = backupCodes?.join('\n');
    try {
      await navigator?.clipboard?.writeText(codesText);
    } catch (err) {
      // Fallback for browsers that don't support clipboard API console.log('Backup codes:', codesText);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Header */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-2xl mb-4 shadow-elevation-2"
          >
            <Icon name="Shield" size={32} className="text-primary-foreground" />
          </motion.div>
          <h1 className="text-2xl font-semibold text-foreground mb-2">
            Two-Factor Authentication
          </h1>
          <p className="text-muted-foreground">
            Add an extra layer of security to your account
          </p>
        </div>

        {/* Setup Card */}
        <div className="bg-card rounded-2xl shadow-elevation-3 border border-border p-6">
          {step === 1 && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-center space-y-6"
            >
              <div>
                <h3 className="text-lg font-medium text-foreground mb-2">
                  Scan QR Code
                </h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Use your authenticator app to scan this QR code
                </p>
              </div>

              {/* QR Code Placeholder */}
              <div className="flex justify-center">
                <div className="w-48 h-48 bg-muted rounded-2xl border-2 border-dashed border-border flex items-center justify-center">
                  <div className="text-center">
                    <Icon name="QrCode" size={48} className="text-muted-foreground mx-auto mb-2" />
                    <p className="text-xs text-muted-foreground">QR Code</p>
                  </div>
                </div>
              </div>

              {/* Manual Code */}
              <div className="bg-muted/50 rounded-lg p-4">
                <p className="text-xs text-muted-foreground mb-2">
                  Can't scan? Enter this code manually:
                </p>
                <code className="text-sm font-mono bg-background px-2 py-1 rounded border">
                  BASE32SECRET
                </code>
              </div>

              <Button
                onClick={() => setStep(2)}
                fullWidth
                size="lg"
              >
                Continue
              </Button>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6"
            >
              <div className="text-center">
                <h3 className="text-lg font-medium text-foreground mb-2">
                  Enter Verification Code
                </h3>
                <p className="text-sm text-muted-foreground">
                  Enter the 6-digit code from your authenticator app
                </p>
              </div>

              <div className="space-y-4">
                <Input
                  type="text"
                  placeholder="000000"
                  value={verificationCode}
                  onChange={(e) => {
                    const value = e?.target?.value?.replace(/\D/g, '');
                    if (value?.length <= 6) {
                      setVerificationCode(value);
                      setError('');
                    }
                  }}
                  className="text-center text-lg tracking-widest font-mono"
                  maxLength="6"
                  error={error}
                />

                <div className="flex space-x-3">
                  <Button
                    variant="outline"
                    onClick={onBack}
                    fullWidth
                  >
                    Back
                  </Button>
                  <Button
                    onClick={handleVerifyCode}
                    loading={loading}
                    disabled={verificationCode?.length !== 6}
                    fullWidth
                  >
                    Verify
                  </Button>
                </div>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6"
            >
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-success/20 rounded-xl mb-4">
                  <Icon name="CheckCircle" size={24} className="text-success" />
                </div>
                <h3 className="text-lg font-medium text-foreground mb-2">
                  2FA Setup Complete!
                </h3>
                <p className="text-sm text-muted-foreground">
                  Save these backup codes in a secure location
                </p>
              </div>

              {/* Backup Codes */}
              <div className="bg-muted/50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-medium text-foreground">
                    Backup Recovery Codes
                  </h4>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={copyBackupCodes}
                  >
                    <Icon name="Copy" size={14} className="mr-1" />
                    Copy
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {backupCodes?.map((code, index) => (
                    <code key={index} className="text-xs font-mono bg-background px-2 py-1 rounded text-center">
                      {code}
                    </code>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-3">
                  Each code can only be used once. Keep them safe!
                </p>
              </div>

              <Button
                onClick={handleComplete}
                fullWidth
                size="lg"
              >
                Complete Setup
              </Button>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default TwoFactorSetup;