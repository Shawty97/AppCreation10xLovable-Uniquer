import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const SecurityFeatures = () => {
  const features = [
    {
      icon: 'Shield',
      title: 'Enterprise Security',
      description: 'Bank-level encryption and security protocols'
    },
    {
      icon: 'Lock',
      title: 'Data Protection',
      description: 'Your data is encrypted and never shared'
    },
    {
      icon: 'Eye',
      title: 'Privacy First',
      description: 'Complete privacy with optional anonymous mode'
    },
    {
      icon: 'Zap',
      title: 'Rate Limiting',
      description: 'Protection against brute force attacks'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="mt-8 grid grid-cols-2 gap-4"
    >
      {features?.map((feature, index) => (
        <motion.div
          key={feature?.title}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 + index * 0.1 }}
          className="flex items-start space-x-3 p-4 bg-card/50 rounded-xl border border-border/50"
        >
          <div className="flex-shrink-0 w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center">
            <Icon name={feature?.icon} size={16} className="text-primary" />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm font-medium text-foreground mb-1">
              {feature?.title}
            </h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              {feature?.description}
            </p>
          </div>
        </motion.div>
      ))}
    </motion.div>
  );
};

export default SecurityFeatures;