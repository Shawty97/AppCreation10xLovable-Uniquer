import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { voiceService } from '../../services/aiService';
import VoiceRecorder from './components/VoiceRecorder';
import SpeechVisualization from './components/SpeechVisualization';
import VoiceCommandLibrary from './components/VoiceCommandLibrary';
import RequirementsDisplay from './components/RequirementsDisplay';
import VoiceTrainingModule from './components/VoiceTrainingModule';
import { Mic, Settings, Languages, Zap, Brain } from 'lucide-react';

const VoiceToAppCreator = () => {
  const { user, isAuthenticated } = useAuth();
  const [currentSession, setCurrentSession] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [voiceSessions, setVoiceSessions] = useState([]);
  const [voiceCommands, setVoiceCommands] = useState([]);
  const [activeTab, setActiveTab] = useState('create');
  const [transcript, setTranscript] = useState('');
  const [extractedRequirements, setExtractedRequirements] = useState(null);
  const [error, setError] = useState(null);
  const [showSettings, setShowSettings] = useState(false);

  // Voice settings
  const [voiceSettings, setVoiceSettings] = useState({
    language: 'en-US',
    sensitivity: 0.7,
    pauseThreshold: 2000,
    enableRealTimeTranscription: true
  });

  // Load data on component mount
  useEffect(() => {
    if (isAuthenticated) {
      loadVoiceSessions();
      loadVoiceCommands();
    }
  }, [isAuthenticated]);

  const loadVoiceSessions = async () => {
    try {
      const { data, error } = await voiceService?.getVoiceSessions(10);
      if (error) throw error;
      setVoiceSessions(data || []);
    } catch (err) {
      setError('Failed to load voice sessions');
    }
  };

  const loadVoiceCommands = async () => {
    try {
      const { data, error } = await voiceService?.getVoiceCommands();
      if (error) throw error;
      setVoiceCommands(data || []);
    } catch (err) {
      setError('Failed to load voice commands');
    }
  };

  const handleStartRecording = async () => {
    try {
      setError(null);
      const sessionName = `Voice Session ${new Date()?.toLocaleString()}`;
      const { data, error } = await voiceService?.createVoiceSession(sessionName);
      
      if (error) throw error;
      
      setCurrentSession(data);
      setIsRecording(true);
      setTranscript('');
      setExtractedRequirements(null);
    } catch (err) {
      setError('Failed to start voice session');
    }
  };

  const handleStopRecording = async (audioBlob) => {
    if (!currentSession || !audioBlob) return;

    try {
      setIsRecording(false);
      setIsProcessing(true);
      
      const { data, error } = await voiceService?.processVoiceInput(audioBlob, currentSession?.id);
      
      if (error) {
        // Handle specific OpenAI API errors
        if (error?.message?.includes('OpenAI API key')) {
          setError('OpenAI API key not configured. Add VITE_OPENAI_API_KEY to your environment to enable voice processing.');
        } else {
          setError('Failed to process voice input: ' + error?.message);
        }
        return;
      }
      
      setTranscript(data?.transcript);
      setExtractedRequirements(data?.requirements);
      setCurrentSession(data?.session);
      
      // Reload sessions to show updated data
      await loadVoiceSessions();
    } catch (err) {
      setError('Failed to process voice input');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAddCustomCommand = async (command) => {
    try {
      const { error } = await voiceService?.addVoiceCommand(
        command?.phrase,
        command?.category,
        command?.description,
        command?.actionData
      );
      
      if (error) throw error;
      
      await loadVoiceCommands();
    } catch (err) {
      setError('Failed to add custom command');
    }
  };

  // Demo credentials for development
  const demoContent = !isAuthenticated && (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
      <h3 className="text-lg font-semibold text-blue-800 mb-2">Demo Mode</h3>
      <p className="text-blue-600 mb-4">
        You are viewing the Voice-to-App Creator in demo mode. Sign in and add your OpenAI API key to access full voice processing capabilities.
      </p>
      <div className="bg-white p-4 rounded border">
        <h4 className="font-medium text-gray-800 mb-2">Demo Credentials:</h4>
        <p className="text-sm text-gray-600">Admin: admin@codecraft.com / adminpass123</p>
        <p className="text-sm text-gray-600">User: user@codecraft.com / userpass123</p>
      </div>
    </div>
  );

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          {demoContent}
          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-100 rounded-full mb-4">
                <Mic className="h-8 w-8 text-purple-600" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Voice-to-App Creator</h1>
              <p className="text-lg text-gray-600 mb-8">
                Transform your ideas into applications using GPT-5 powered speech recognition and AI requirement extraction
              </p>
              <div className="grid md:grid-cols-3 gap-6 text-left">
                <div className="flex items-start space-x-3">
                  <Zap className="h-6 w-6 text-purple-600 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Real-time Speech Processing</h3>
                    <p className="text-gray-600 text-sm">OpenAI Whisper for accurate speech-to-text conversion</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Brain className="h-6 w-6 text-purple-600 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">AI-Powered Analysis</h3>
                    <p className="text-gray-600 text-sm">GPT-5 extracts requirements and generates structured components</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Languages className="h-6 w-6 text-purple-600 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Multi-language Support</h3>
                    <p className="text-gray-600 text-sm">Voice training and accent adaptation for global users</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-100 rounded-lg">
                <Mic className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Voice-to-App Creator</h1>
                <p className="text-gray-600">
                  {import.meta.env?.VITE_OPENAI_API_KEY 
                    ? "Transform voice commands into professional applications with GPT-5" 
                    : "Transform voice commands into professional applications"
                  }
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              {!import.meta.env?.VITE_OPENAI_API_KEY && (
                <div className="text-sm text-amber-600 bg-amber-50 px-3 py-1 rounded-full">
                  Limited Mode - Add API Key
                </div>
              )}
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </button>
            </div>
          </div>

          {/* Navigation tabs */}
          <div className="flex space-x-8 mt-6 border-b border-gray-200">
            <button
              onClick={() => setActiveTab('create')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'create' ?'border-purple-500 text-purple-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Voice Creator
            </button>
            <button
              onClick={() => setActiveTab('commands')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'commands' ?'border-purple-500 text-purple-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Command Library
            </button>
            <button
              onClick={() => setActiveTab('training')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'training' ?'border-purple-500 text-purple-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Voice Training
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'history' ?'border-purple-500 text-purple-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Session History
            </button>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Error Display */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex">
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Error</h3>
                <p className="text-sm text-red-700 mt-1">{error}</p>
              </div>
              <button
                onClick={() => setError(null)}
                className="ml-auto text-red-600 hover:text-red-800"
              >
                ×
              </button>
            </div>
          </div>
        )}

        {/* API Key Warning */}
        {!import.meta.env?.VITE_OPENAI_API_KEY && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
            <div className="flex items-center">
              <div className="ml-3">
                <h3 className="text-sm font-medium text-amber-800">Voice Processing Limited</h3>
                <p className="text-sm text-amber-700 mt-1">
                  Add your OpenAI API key to environment variables to unlock full voice-to-text transcription and AI requirement extraction using Whisper and GPT-5.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Main Content */}
        {activeTab === 'create' && (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Voice Recording Section */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Voice Input</h2>
                
                <VoiceRecorder
                  onStartRecording={handleStartRecording}
                  onStopRecording={handleStopRecording}
                  isRecording={isRecording}
                  isProcessing={isProcessing}
                  settings={voiceSettings}
                />

                {/* Speech Visualization */}
                <div className="mt-6">
                  <SpeechVisualization
                    isRecording={isRecording}
                    transcript={transcript}
                    isProcessing={isProcessing}
                  />
                </div>

                {/* Real-time Transcript */}
                {transcript && (
                  <div className="mt-6">
                    <h3 className="text-lg font-medium text-gray-900 mb-3">Transcript</h3>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <p className="text-gray-700">{transcript}</p>
                    </div>
                  </div>
                )}

                {/* Extracted Requirements */}
                {extractedRequirements && (
                  <div className="mt-6">
                    <RequirementsDisplay requirements={extractedRequirements} />
                  </div>
                )}
              </div>
            </div>

            {/* Quick Commands & Status */}
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Commands</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">"Create component"</span>
                    <span className="text-purple-600">Component</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">"Add navigation"</span>
                    <span className="text-blue-600">Navigation</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">"Make it responsive"</span>
                    <span className="text-green-600">Styling</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">"Dark mode toggle"</span>
                    <span className="text-orange-600">Feature</span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Session Status</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">AI Processing</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      import.meta.env?.VITE_OPENAI_API_KEY 
                        ? 'bg-green-100 text-green-800' :'bg-yellow-100 text-yellow-800'
                    }`}>
                      {import.meta.env?.VITE_OPENAI_API_KEY ? 'GPT-5 Ready' : 'Limited Mode'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Current Session</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      currentSession 
                        ? isRecording 
                          ? 'bg-red-100 text-red-800' 
                          : isProcessing 
                          ? 'bg-yellow-100 text-yellow-800' :'bg-green-100 text-green-800' :'bg-gray-100 text-gray-800'
                    }`}>
                      {currentSession 
                        ? isRecording 
                          ? 'Recording' 
                          : isProcessing 
                          ? 'Processing' :'Completed' :'Ready'
                      }
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Total Sessions</span>
                    <span className="font-medium">{voiceSessions?.length || 0}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Available Commands</span>
                    <span className="font-medium">{voiceCommands?.length || 0}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'commands' && (
          <VoiceCommandLibrary
            commands={voiceCommands}
            onAddCommand={handleAddCustomCommand}
          />
        )}

        {activeTab === 'training' && (
          <VoiceTrainingModule
            settings={voiceSettings}
            onUpdateSettings={setVoiceSettings}
          />
        )}

        {activeTab === 'history' && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Voice Session History</h2>
            <div className="space-y-4">
              {voiceSessions?.map((session) => (
                <div key={session?.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-gray-900">
                      {session?.session_name || 'Unnamed Session'}
                    </h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      session?.status === 'completed' ? 'bg-green-100 text-green-800' :
                      session?.status === 'error'? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {session?.status}
                    </span>
                  </div>
                  {session?.transcript && (
                    <p className="text-gray-600 text-sm mb-2">{session?.transcript}</p>
                  )}
                  {session?.extracted_requirements && (
                    <div className="mt-2 text-xs text-gray-500">
                      <span className="font-medium">AI Analysis:</span> {session?.extracted_requirements?.components?.length || 0} components, {session?.extracted_requirements?.features?.length || 0} features
                    </div>
                  )}
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>{new Date(session.created_at)?.toLocaleString()}</span>
                    {session?.duration_seconds && (
                      <span>{session?.duration_seconds}s</span>
                    )}
                  </div>
                </div>
              ))}
              
              {(!voiceSessions || voiceSessions?.length === 0) && (
                <div className="text-center py-12">
                  <Mic className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No voice sessions yet</h3>
                  <p className="text-gray-600">Start creating applications with your voice!</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VoiceToAppCreator;