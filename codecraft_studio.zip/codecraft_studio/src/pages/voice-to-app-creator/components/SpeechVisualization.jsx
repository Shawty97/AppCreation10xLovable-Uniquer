import React, { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX, Activity } from 'lucide-react';

const SpeechVisualization = ({ isRecording, transcript, isProcessing }) => {
  const canvasRef = useRef(null);
  const animationFrameRef = useRef(null);
  const [showTranscript, setShowTranscript] = useState(true);
  const [words, setWords] = useState([]);

  useEffect(() => {
    if (transcript) {
      // Split transcript into words with animation timing
      const transcriptWords = transcript?.split(' ')?.map((word, index) => ({
        text: word,
        id: index,
        animated: false
      }));
      setWords(transcriptWords);

      // Animate words appearing one by one
      transcriptWords?.forEach((word, index) => {
        setTimeout(() => {
          setWords(prev => prev?.map(w => 
            w?.id === index ? { ...w, animated: true } : w
          ));
        }, index * 100);
      });
    }
  }, [transcript]);

  useEffect(() => {
    const canvas = canvasRef?.current;
    if (!canvas) return;

    const ctx = canvas?.getContext('2d');
    const width = canvas?.width;
    const height = canvas?.height;

    let animationData = {
      wavePoints: Array.from({ length: 100 }, () => Math.random() * 0.5),
      time: 0
    };

    const drawWaveform = () => {
      ctx?.clearRect(0, 0, width, height);
      
      if (isRecording || isProcessing) {
        // Create animated waveform
        const gradient = ctx?.createLinearGradient(0, 0, width, 0);
        gradient?.addColorStop(0, 'rgba(147, 51, 234, 0.8)');
        gradient?.addColorStop(0.5, 'rgba(168, 85, 247, 0.6)');
        gradient?.addColorStop(1, 'rgba(196, 181, 253, 0.4)');
        
        ctx.fillStyle = gradient;
        ctx.strokeStyle = 'rgba(147, 51, 234, 0.9)';
        ctx.lineWidth = 2;

        // Draw animated wave
        ctx?.beginPath();
        ctx?.moveTo(0, height / 2);

        for (let i = 0; i < animationData?.wavePoints?.length; i++) {
          const x = (i / (animationData?.wavePoints?.length - 1)) * width;
          const baseY = height / 2;
          
          let amplitude;
          if (isProcessing) {
            // Processing animation - more organized waves
            amplitude = Math.sin(animationData?.time * 0.02 + i * 0.3) * 30;
          } else if (isRecording) {
            // Recording animation - chaotic but controlled
            amplitude = (Math.sin(animationData?.time * 0.05 + i * 0.2) + 
                        Math.sin(animationData?.time * 0.03 + i * 0.5) * 0.5) * 40;
          } else {
            amplitude = 0;
          }
          
          const y = baseY + amplitude;
          
          if (i === 0) {
            ctx?.moveTo(x, y);
          } else {
            ctx?.lineTo(x, y);
          }
        }
        
        ctx?.stroke();

        // Draw reflection
        ctx?.save();
        ctx?.scale(1, -1);
        ctx?.translate(0, -height);
        ctx.globalAlpha = 0.3;
        ctx?.stroke();
        ctx?.restore();

        animationData.time++;
      } else {
        // Static state - draw a flat line
        ctx.strokeStyle = 'rgba(156, 163, 175, 0.5)';
        ctx.lineWidth = 1;
        ctx?.beginPath();
        ctx?.moveTo(0, height / 2);
        ctx?.lineTo(width, height / 2);
        ctx?.stroke();
      }

      animationFrameRef.current = requestAnimationFrame(drawWaveform);
    };

    drawWaveform();

    return () => {
      if (animationFrameRef?.current) {
        cancelAnimationFrame(animationFrameRef?.current);
      }
    };
  }, [isRecording, isProcessing]);

  return (
    <div className="bg-gray-50 rounded-lg p-6 border">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <div className={`p-2 rounded-lg ${
            isRecording ? 'bg-red-100 text-red-600' : isProcessing ?'bg-yellow-100 text-yellow-600': 'bg-gray-100 text-gray-600'
          }`}>
            {isRecording ? (
              <Volume2 className="h-5 w-5" />
            ) : isProcessing ? (
              <div className="w-5 h-5 border-2 border-yellow-600 border-t-transparent rounded-full animate-spin" />
            ) : (
              <VolumeX className="h-5 w-5" />
            )}
          </div>
          <div>
            <h3 className="font-medium text-gray-900">
              {isRecording ? 'Listening...' : isProcessing ?'Processing...': 'Audio Visualization'}
            </h3>
            <p className="text-sm text-gray-600">
              {isRecording ? 'Speak clearly about your app requirements' : isProcessing ?'AI is analyzing your speech': 'Ready to capture your voice input'}
            </p>
          </div>
        </div>
        
        {transcript && (
          <button
            onClick={() => setShowTranscript(!showTranscript)}
            className="text-sm text-purple-600 hover:text-purple-700 font-medium"
          >
            {showTranscript ? 'Hide' : 'Show'} Transcript
          </button>
        )}
      </div>
      {/* Waveform Visualization */}
      <div className="mb-6">
        <canvas
          ref={canvasRef}
          width={800}
          height={120}
          className="w-full h-20 rounded-lg bg-white border"
          style={{ maxHeight: '80px' }}
        />
      </div>
      {/* Real-time Transcript */}
      {transcript && showTranscript && (
        <div className="bg-white rounded-lg p-4 border">
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-medium text-gray-900 flex items-center">
              <Activity className="h-4 w-4 mr-2" />
              Live Transcript
            </h4>
            <span className="text-xs text-gray-500">
              {words?.length} words
            </span>
          </div>
          
          <div className="text-gray-700 leading-relaxed">
            {words?.map((word, index) => (
              <span
                key={word?.id}
                className={`inline-block mr-2 transition-all duration-300 ${
                  word?.animated 
                    ? 'opacity-100 transform translate-y-0' 
                    : 'opacity-0 transform translate-y-2'
                }`}
                style={{
                  transitionDelay: `${index * 50}ms`
                }}
              >
                {word?.text}
              </span>
            ))}
          </div>

          {/* Typing indicator */}
          {isRecording && (
            <div className="flex items-center mt-2 text-purple-600">
              <div className="flex space-x-1 mr-2">
                <div className="w-1 h-1 bg-purple-600 rounded-full animate-bounce"></div>
                <div className="w-1 h-1 bg-purple-600 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-1 h-1 bg-purple-600 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
              <span className="text-xs font-medium">Listening...</span>
            </div>
          )}
        </div>
      )}
      {/* Audio Quality Indicator */}
      <div className="flex items-center justify-between text-xs text-gray-500 mt-4">
        <div className="flex items-center space-x-4">
          <span className={`flex items-center ${
            isRecording ? 'text-green-600' : 'text-gray-500'
          }`}>
            <div className={`w-2 h-2 rounded-full mr-1 ${
              isRecording ? 'bg-green-500' : 'bg-gray-400'
            }`} />
            Audio Input
          </span>
          
          <span className={`flex items-center ${
            transcript ? 'text-blue-600' : 'text-gray-500'
          }`}>
            <div className={`w-2 h-2 rounded-full mr-1 ${
              transcript ? 'bg-blue-500' : 'bg-gray-400'
            }`} />
            Speech Recognition
          </span>
          
          <span className={`flex items-center ${
            isProcessing ? 'text-yellow-600' : 'text-gray-500'
          }`}>
            <div className={`w-2 h-2 rounded-full mr-1 ${
              isProcessing ? 'bg-yellow-500' : 'bg-gray-400'
            }`} />
            AI Processing
          </span>
        </div>
        
        {isRecording && (
          <div className="flex items-center text-red-600">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-1" />
            REC
          </div>
        )}
      </div>
    </div>
  );
};

export default SpeechVisualization;