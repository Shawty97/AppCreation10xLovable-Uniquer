import React, { useState, useRef, useEffect } from 'react';
import { Mic, Square } from 'lucide-react';

const VoiceRecorder = ({ onStartRecording, onStopRecording, isRecording, isProcessing, settings }) => {
  const [audioLevel, setAudioLevel] = useState(0);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const streamRef = useRef(null);
  const animationFrameRef = useRef(null);
  const timerRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);

  useEffect(() => {
    return () => {
      // Cleanup
      if (animationFrameRef?.current) {
        cancelAnimationFrame(animationFrameRef?.current);
      }
      if (timerRef?.current) {
        clearInterval(timerRef?.current);
      }
      if (streamRef?.current) {
        streamRef?.current?.getTracks()?.forEach(track => track?.stop());
      }
      if (audioContextRef?.current) {
        audioContextRef?.current?.close();
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      // Request microphone access
      const stream = await navigator.mediaDevices?.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: 48000,
          channelCount: 1
        } 
      });
      
      streamRef.current = stream;

      // Set up audio analysis for visualization
      audioContextRef.current = new AudioContext();
      analyserRef.current = audioContextRef?.current?.createAnalyser();
      const source = audioContextRef?.current?.createMediaStreamSource(stream);
      source?.connect(analyserRef?.current);
      
      analyserRef.current.fftSize = 256;
      const bufferLength = analyserRef?.current?.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      // Audio level monitoring
      const updateAudioLevel = () => {
        if (analyserRef?.current && isRecording) {
          analyserRef?.current?.getByteFrequencyData(dataArray);
          const average = dataArray?.reduce((acc, val) => acc + val, 0) / bufferLength;
          setAudioLevel(average);
          animationFrameRef.current = requestAnimationFrame(updateAudioLevel);
        }
      };

      // Set up MediaRecorder
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });
      
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event?.data?.size > 0) {
          audioChunksRef?.current?.push(event?.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        onStopRecording?.(audioBlob);
        
        // Cleanup
        if (streamRef?.current) {
          streamRef?.current?.getTracks()?.forEach(track => track?.stop());
        }
        if (audioContextRef?.current) {
          audioContextRef?.current?.close();
        }
        setAudioLevel(0);
        setRecordingTime(0);
      };

      // Start recording
      await onStartRecording?.();
      mediaRecorder?.start();
      updateAudioLevel();

      // Start timer
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Could not access microphone. Please ensure microphone permissions are granted.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef?.current && mediaRecorderRef?.current?.state === 'recording') {
      mediaRecorderRef?.current?.stop();
    }
    
    if (animationFrameRef?.current) {
      cancelAnimationFrame(animationFrameRef?.current);
    }
    
    if (timerRef?.current) {
      clearInterval(timerRef?.current);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins?.toString()?.padStart(2, '0')}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const getAudioLevelStyle = () => {
    const intensity = Math.min(audioLevel / 128, 1); // Normalize to 0-1
    return {
      transform: `scale(${1 + intensity * 0.3})`,
      boxShadow: `0 0 ${intensity * 30}px rgba(147, 51, 234, ${intensity * 0.6})`
    };
  };

  return (
    <div className="text-center">
      {/* Main Recording Button */}
      <div className="relative inline-flex items-center justify-center mb-6">
        <button
          onClick={isRecording ? stopRecording : startRecording}
          disabled={isProcessing}
          className={`relative w-24 h-24 rounded-full transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-purple-200 ${
            isProcessing
              ? 'bg-gray-400 cursor-not-allowed'
              : isRecording
              ? 'bg-red-500 hover:bg-red-600 text-white' :'bg-purple-600 hover:bg-purple-700 text-white'
          }`}
          style={isRecording ? getAudioLevelStyle() : {}}
        >
          {isProcessing ? (
            <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin" />
          ) : isRecording ? (
            <Square className="h-8 w-8" />
          ) : (
            <Mic className="h-8 w-8" />
          )}
        </button>

        {/* Audio Level Rings */}
        {isRecording && (
          <>
            <div className="absolute w-32 h-32 border-2 border-purple-300 rounded-full animate-ping opacity-30" />
            <div className="absolute w-40 h-40 border-2 border-purple-200 rounded-full animate-ping opacity-20" 
                 style={{ animationDelay: '0.5s' }} />
          </>
        )}
      </div>
      {/* Status Text */}
      <div className="mb-4">
        {isProcessing ? (
          <div className="text-lg font-medium text-purple-600">
            Processing your voice input...
          </div>
        ) : isRecording ? (
          <div className="space-y-1">
            <div className="text-lg font-medium text-red-600">Recording</div>
            <div className="text-2xl font-mono text-gray-900">{formatTime(recordingTime)}</div>
          </div>
        ) : (
          <div className="text-lg text-gray-600">
            Click to start voice input
          </div>
        )}
      </div>
      {/* Audio Level Indicator */}
      {isRecording && (
        <div className="flex justify-center items-center space-x-1 mb-4">
          {Array.from({ length: 20 }, (_, i) => (
            <div
              key={i}
              className={`w-1 bg-purple-500 rounded-full transition-all duration-75 ${
                audioLevel > (i * 6.4) ? 'opacity-100' : 'opacity-30'
              }`}
              style={{
                height: `${Math.max(4, Math.min(32, (audioLevel / 128) * 32))}px`
              }}
            />
          ))}
        </div>
      )}
      {/* Instructions */}
      <div className="text-sm text-gray-500 max-w-md mx-auto">
        {isRecording ? (
          <p>Speak clearly about your app idea. Describe components, features, and styling preferences.</p>
        ) : isProcessing ? (
          <p>AI is analyzing your voice input and extracting requirements...</p>
        ) : (
          <p>
            Start recording and describe your app idea. 
            Use natural language to specify components, features, and design preferences.
          </p>
        )}
      </div>
      {/* Voice Settings Quick Info */}
      {settings && (
        <div className="mt-4 p-3 bg-gray-50 rounded-lg text-xs text-gray-600">
          <div className="flex justify-center space-x-4">
            <span>Language: {settings?.language || 'en-US'}</span>
            <span>Sensitivity: {Math.round((settings?.sensitivity || 0.7) * 100)}%</span>
            {settings?.enableRealTimeTranscription && <span>Real-time: ON</span>}
          </div>
        </div>
      )}
      {/* Browser Support Check */}
      {!navigator.mediaDevices?.getUserMedia && (
        <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-yellow-800 text-sm">
            Voice recording requires a modern browser with microphone support. 
            Please ensure you're using Chrome, Firefox, Safari, or Edge.
          </p>
        </div>
      )}
    </div>
  );
};

export default VoiceRecorder;