import React, { useState } from 'react';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import ComponentLibrary from './components/ComponentLibrary';
import CanvasWorkspace from './components/CanvasWorkspace';
import PropertiesPanel from './components/PropertiesPanel';
import LayersPanel from './components/LayersPanel';
import BuilderToolbar from './components/BuilderToolbar';

const VisualBuilder = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [componentLibraryCollapsed, setComponentLibraryCollapsed] = useState(false);
  const [propertiesPanelCollapsed, setPropertiesPanelCollapsed] = useState(false);
  const [selectedComponent, setSelectedComponent] = useState(null);
  const [canvasComponents, setCanvasComponents] = useState([
    {
      id: 'comp-1',
      type: 'container',
      name: 'Main Container',
      x: 50,
      y: 50,
      width: 600,
      height: 400,
      visible: true,
      styles: { 
        backgroundColor: '#ffffff', 
        border: '1px solid #e2e8f0', 
        borderRadius: '8px' 
      },
      children: [
        {
          id: 'comp-2',
          type: 'button',
          name: 'Primary Button',
          x: 20,
          y: 20,
          width: 120,
          height: 40,
          visible: true,
          styles: { 
            backgroundColor: '#2563eb', 
            color: '#ffffff', 
            borderRadius: '6px' 
          },
          content: 'Click Me'
        }
      ]
    }
  ]);

  const collaborators = [
    { id: 1, name: 'Sarah Chen', avatar: 'SC', active: true },
    { id: 2, name: 'Mike Johnson', avatar: 'MJ', active: true },
    { id: 3, name: 'Emma Davis', avatar: 'ED', active: true }
  ];

  const handleComponentSelect = (component) => {
    setSelectedComponent(component);
  };

  const handleComponentUpdate = (updatedComponent) => {
    setCanvasComponents(prev => 
      prev?.map(comp => 
        comp?.id === updatedComponent?.id ? updatedComponent : comp
      )
    );
    setSelectedComponent(updatedComponent);
  };

  const handleComponentToggleVisibility = (componentId) => {
    setCanvasComponents(prev =>
      prev?.map(comp =>
        comp?.id === componentId
          ? { ...comp, visible: !comp?.visible }
          : comp
      )
    );
  };

  const handleSave = async () => {
    // Simulate save operation
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log('Project saved successfully');
        resolve();
      }, 1000);
    });
  };

  const handlePreview = (isPreviewMode) => {
    console.log('Preview mode:', isPreviewMode);
  };

  const handlePublish = () => {
    console.log('Publishing project...');
  };

  const handleUndo = () => {
    console.log('Undo action');
  };

  const handleRedo = () => {
    console.log('Redo action');
  };

  const handleDragStart = (component) => {
    console.log('Dragging component:', component);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="flex pt-16">
        <Sidebar 
          isCollapsed={sidebarCollapsed} 
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)} 
        />
        
        <div 
          className={`flex-1 flex flex-col transition-all duration-300 ${
            sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'
          }`}
        >
          {/* Builder Toolbar */}
          <BuilderToolbar
            onSave={handleSave}
            onPreview={handlePreview}
            onPublish={handlePublish}
            onUndo={handleUndo}
            onRedo={handleRedo}
            collaborators={collaborators}
          />

          {/* Main Builder Interface */}
          <div className="flex-1 flex overflow-hidden">
            {/* Component Library */}
            <ComponentLibrary
              isCollapsed={componentLibraryCollapsed}
              onToggleCollapse={() => setComponentLibraryCollapsed(!componentLibraryCollapsed)}
              onDragStart={handleDragStart}
            />

            {/* Layers Panel */}
            <LayersPanel
              components={canvasComponents}
              selectedComponent={selectedComponent}
              onComponentSelect={handleComponentSelect}
              onComponentToggleVisibility={handleComponentToggleVisibility}
              onComponentReorder={() => {}} // Add this missing required prop
            />

            {/* Canvas Workspace */}
            <CanvasWorkspace
              selectedComponent={selectedComponent}
              onComponentSelect={handleComponentSelect}
              onComponentUpdate={handleComponentUpdate}
            />

            {/* Properties Panel */}
            <PropertiesPanel
              selectedComponent={selectedComponent}
              onComponentUpdate={handleComponentUpdate}
              isCollapsed={propertiesPanelCollapsed}
              onToggleCollapse={() => setPropertiesPanelCollapsed(!propertiesPanelCollapsed)}
            />
          </div>
        </div>
      </div>

      {/* Mobile Bottom Navigation Spacer */}
      <div className="h-16 lg:hidden"></div>
    </div>
  );
};

export default VisualBuilder;