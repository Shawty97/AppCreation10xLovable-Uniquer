import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const BuilderToolbar = ({ onSave, onPreview, onPublish, onUndo, onRedo, collaborators }) => {
  const [saveStatus, setSaveStatus] = useState('saved'); // 'saving', 'saved', 'error'
  const [isPreviewMode, setIsPreviewMode] = useState(false);

  const handleSave = async () => {
    setSaveStatus('saving');
    try {
      await onSave();
      setSaveStatus('saved');
    } catch (error) {
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('saved'), 3000);
    }
  };

  const handlePreview = () => {
    setIsPreviewMode(!isPreviewMode);
    onPreview && onPreview(!isPreviewMode);
  };

  const getSaveStatusIcon = () => {
    switch (saveStatus) {
      case 'saving':
        return 'Loader2';
      case 'error':
        return 'AlertCircle';
      default:
        return 'Check';
    }
  };

  const getSaveStatusText = () => {
    switch (saveStatus) {
      case 'saving':
        return 'Saving...';
      case 'error':
        return 'Save failed';
      default:
        return 'All changes saved';
    }
  };

  return (
    <div className="h-14 bg-card border-b border-border flex items-center justify-between px-6 shadow-elevation-1">
      {/* Left Section - Project Info & Actions */}
      <div className="flex items-center space-x-4">
        {/* Project Name */}
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
            <Icon name="Code" size={16} color="white" />
          </div>
          <div>
            <h1 className="text-sm font-semibold text-foreground">E-commerce Dashboard</h1>
            <p className="text-xs text-muted-foreground">Last edited 2 minutes ago</p>
          </div>
        </div>

        <div className="w-px h-6 bg-border"></div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-1">
          <Button
            variant="ghost"
            size="sm"
            iconName="Undo"
            iconSize={16}
            onClick={onUndo}
            className="hover-lift"
            title="Undo (Ctrl+Z)"
          />
          <Button
            variant="ghost"
            size="sm"
            iconName="Redo"
            iconSize={16}
            onClick={onRedo}
            className="hover-lift"
            title="Redo (Ctrl+Y)"
          />
          
          <div className="w-px h-6 bg-border mx-2"></div>
          
          <Button
            variant="ghost"
            size="sm"
            iconName={isPreviewMode ? 'Edit' : 'Eye'}
            iconSize={16}
            onClick={handlePreview}
            className={`hover-lift ${isPreviewMode ? 'bg-primary text-primary-foreground' : ''}`}
          >
            {isPreviewMode ? 'Edit' : 'Preview'}
          </Button>
        </div>
      </div>
      {/* Center Section - Save Status */}
      <div className="flex items-center space-x-2">
        <Icon 
          name={getSaveStatusIcon()} 
          size={14} 
          className={`${
            saveStatus === 'saving' ? 'animate-spin' : ''
          } ${
            saveStatus === 'error' ? 'text-destructive' : 'text-success'
          }`}
        />
        <span className={`text-xs ${
          saveStatus === 'error' ? 'text-destructive' : 'text-muted-foreground'
        }`}>
          {getSaveStatusText()}
        </span>
      </div>
      {/* Right Section - Collaboration & Publish */}
      <div className="flex items-center space-x-4">
        {/* Collaborators */}
        {collaborators && collaborators?.length > 0 && (
          <div className="flex items-center space-x-2">
            <div className="flex -space-x-2">
              {collaborators?.slice(0, 3)?.map((collaborator) => (
                <div
                  key={collaborator?.id}
                  className="w-8 h-8 bg-success text-success-foreground rounded-full flex items-center justify-center text-xs font-medium border-2 border-card shadow-elevation-1"
                  title={`${collaborator?.name} is editing`}
                >
                  {collaborator?.avatar}
                </div>
              ))}
              {collaborators?.length > 3 && (
                <div className="w-8 h-8 bg-muted text-muted-foreground rounded-full flex items-center justify-center text-xs font-medium border-2 border-card">
                  +{collaborators?.length - 3}
                </div>
              )}
            </div>
            <Button
              variant="ghost"
              size="sm"
              iconName="UserPlus"
              iconSize={16}
              className="hover-lift"
            >
              Share
            </Button>
          </div>
        )}

        <div className="w-px h-6 bg-border"></div>

        {/* Publish Actions */}
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            iconName="Save"
            iconPosition="left"
            iconSize={16}
            onClick={handleSave}
            disabled={saveStatus === 'saving'}
            className="hover-lift"
          >
            Save
          </Button>
          
          <div className="relative group">
            <Button
              variant="default"
              size="sm"
              iconName="Rocket"
              iconPosition="left"
              iconSize={16}
              onClick={onPublish}
              className="hover-lift"
            >
              Publish
            </Button>
            
            {/* Publish Dropdown */}
            <div className="absolute right-0 top-full mt-1 w-48 bg-popover border border-border rounded-md shadow-elevation-3 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none group-hover:pointer-events-auto z-50">
              <div className="py-2">
                <button className="flex items-center space-x-3 w-full px-4 py-2 text-sm text-popover-foreground hover:bg-muted transition-quick">
                  <Icon name="Globe" size={16} />
                  <div className="text-left">
                    <div className="font-medium">Publish to Web</div>
                    <div className="text-xs text-muted-foreground">Make your app live</div>
                  </div>
                </button>
                <button className="flex items-center space-x-3 w-full px-4 py-2 text-sm text-popover-foreground hover:bg-muted transition-quick">
                  <Icon name="Download" size={16} />
                  <div className="text-left">
                    <div className="font-medium">Export Code</div>
                    <div className="text-xs text-muted-foreground">Download React code</div>
                  </div>
                </button>
                <button className="flex items-center space-x-3 w-full px-4 py-2 text-sm text-popover-foreground hover:bg-muted transition-quick">
                  <Icon name="Settings" size={16} />
                  <div className="text-left">
                    <div className="font-medium">Deploy Settings</div>
                    <div className="text-xs text-muted-foreground">Configure deployment</div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BuilderToolbar;