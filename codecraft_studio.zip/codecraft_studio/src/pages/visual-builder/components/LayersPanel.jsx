import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const LayersPanel = ({ components, selectedComponent, onComponentSelect, onComponentReorder, onComponentToggleVisibility }) => {
  const [expandedComponents, setExpandedComponents] = useState(new Set(['comp-1']));

  const toggleExpanded = (componentId) => {
    const newExpanded = new Set(expandedComponents);
    if (newExpanded?.has(componentId)) {
      newExpanded?.delete(componentId);
    } else {
      newExpanded?.add(componentId);
    }
    setExpandedComponents(newExpanded);
  };

  const getComponentIcon = (type) => {
    const icons = {
      container: 'Square',
      button: 'MousePointer',
      input: 'Type',
      textarea: 'AlignLeft',
      image: 'Image',
      card: 'CreditCard',
      grid: 'Grid3X3',
      flexbox: 'AlignJustify',
      section: 'Rectangle',
      header: 'AlignTop',
      footer: 'AlignBottom'
    };
    return icons?.[type] || 'Square';
  };

  const renderLayerItem = (component, level = 0) => {
    const isSelected = selectedComponent?.id === component?.id;
    const isExpanded = expandedComponents?.has(component?.id);
    const hasChildren = component?.children && component?.children?.length > 0;

    return (
      <div key={component?.id} className="select-none">
        <div
          className={`flex items-center space-x-2 px-2 py-1.5 rounded-md cursor-pointer transition-quick hover:bg-muted group ${
            isSelected ? 'bg-primary/10 text-primary' : 'text-foreground hover:text-foreground'
          }`}
          style={{ paddingLeft: `${8 + level * 16}px` }}
          onClick={() => onComponentSelect(component)}
        >
          {/* Expand/Collapse Button */}
          {hasChildren ? (
            <button
              onClick={(e) => {
                e?.stopPropagation();
                toggleExpanded(component?.id);
              }}
              className="w-4 h-4 flex items-center justify-center hover:bg-muted-foreground/20 rounded transition-quick"
            >
              <Icon 
                name={isExpanded ? 'ChevronDown' : 'ChevronRight'} 
                size={12} 
                className="transition-transform duration-200"
              />
            </button>
          ) : (
            <div className="w-4 h-4"></div>
          )}

          {/* Component Icon */}
          <div className={`w-5 h-5 flex items-center justify-center rounded ${
            isSelected ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
          }`}>
            <Icon name={getComponentIcon(component?.type)} size={12} />
          </div>

          {/* Component Name */}
          <span className="flex-1 text-sm font-medium truncate">
            {component?.name || `${component?.type?.charAt(0)?.toUpperCase()}${component?.type?.slice(1)}`}
          </span>

          {/* Actions */}
          <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={(e) => {
                e?.stopPropagation();
                onComponentToggleVisibility && onComponentToggleVisibility(component?.id);
              }}
              className="w-5 h-5 flex items-center justify-center hover:bg-muted-foreground/20 rounded transition-quick"
              title={component?.visible !== false ? 'Hide component' : 'Show component'}
            >
              <Icon 
                name={component?.visible !== false ? 'Eye' : 'EyeOff'} 
                size={12} 
                className={component?.visible === false ? 'text-muted-foreground' : ''}
              />
            </button>
            <button
              onClick={(e) => {
                e?.stopPropagation();
                // Handle component duplication
              }}
              className="w-5 h-5 flex items-center justify-center hover:bg-muted-foreground/20 rounded transition-quick"
              title="Duplicate component"
            >
              <Icon name="Copy" size={12} />
            </button>
            <button
              onClick={(e) => {
                e?.stopPropagation();
                // Handle component deletion
              }}
              className="w-5 h-5 flex items-center justify-center hover:bg-destructive/20 hover:text-destructive rounded transition-quick"
              title="Delete component"
            >
              <Icon name="Trash2" size={12} />
            </button>
          </div>
        </div>
        {/* Children */}
        {hasChildren && isExpanded && (
          <div className="ml-2">
            {component?.children?.map(child => renderLayerItem(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-foreground">Layers</h3>
          <div className="flex items-center space-x-1">
            <Button
              variant="ghost"
              size="icon"
              iconName="Plus"
              iconSize={12}
              className="w-6 h-6"
              title="Add layer"
            />
            <Button
              variant="ghost"
              size="icon"
              iconName="Search"
              iconSize={12}
              className="w-6 h-6"
              title="Search layers"
            />
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Icon 
            name="Search" 
            size={14} 
            className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" 
          />
          <input
            type="text"
            placeholder="Search layers..."
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-background border border-border rounded-md focus:outline-none focus:ring-1 focus:ring-ring focus:border-transparent"
          />
        </div>
      </div>
      {/* Layers List */}
      <div className="flex-1 overflow-y-auto p-2">
        {components && components?.length > 0 ? (
          <div className="space-y-1">
            {components?.map(component => renderLayerItem(component))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Icon name="Layers" size={24} className="mx-auto text-muted-foreground mb-2" />
            <p className="text-xs text-muted-foreground">No components yet</p>
            <p className="text-xs text-muted-foreground mt-1">Add components to see them here</p>
          </div>
        )}
      </div>
      {/* Footer Actions */}
      <div className="p-3 border-t border-border">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>{components?.length || 0} components</span>
          <div className="flex items-center space-x-2">
            <button
              className="hover:text-foreground transition-quick"
              title="Expand all"
            >
              <Icon name="ChevronsDown" size={12} />
            </button>
            <button
              className="hover:text-foreground transition-quick"
              title="Collapse all"
            >
              <Icon name="ChevronsUp" size={12} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LayersPanel;