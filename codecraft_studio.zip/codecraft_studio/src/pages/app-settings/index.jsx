import React, { useState } from 'react';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import GeneralSettings from './components/GeneralSettings';
import DomainHostingSettings from './components/DomainHostingSettings';
import DatabaseSettings from './components/DatabaseSettings';
import SecuritySettings from './components/SecuritySettings';
import PerformanceSettings from './components/PerformanceSettings';
import VersionControlSettings from './components/VersionControlSettings';

const AppSettings = () => {
  const [activeTab, setActiveTab] = useState('general');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const tabs = [
    {
      id: 'general',
      label: 'General',
      icon: 'Settings',
      description: 'App information, SEO, and branding'
    },
    {
      id: 'domain',
      label: 'Domain & Hosting',
      icon: 'Globe',
      description: 'Custom domains, SSL, and deployment'
    },
    {
      id: 'database',
      label: 'Database',
      icon: 'Database',
      description: 'Connection, backups, and performance'
    },
    {
      id: 'security',
      label: 'Security',
      icon: 'Shield',
      description: 'Authentication, roles, and API keys'
    },
    {
      id: 'performance',
      label: 'Performance',
      icon: 'Zap',
      description: 'Optimization, analytics, and monitoring'
    },
    {
      id: 'version',
      label: 'Version Control',
      icon: 'GitBranch',
      description: 'History, rollbacks, and branches'
    }
  ];

  const handleTabChange = (tabId) => {
    if (hasUnsavedChanges) {
      const confirmed = window.confirm('You have unsaved changes. Are you sure you want to leave this tab?');
      if (!confirmed) return;
    }
    setActiveTab(tabId);
    setHasUnsavedChanges(false);
  };

  const handleSaveAll = () => {
    console.log('Saving all settings...');
    setHasUnsavedChanges(false);
  };

  const handleResetSettings = () => {
    const confirmed = window.confirm('Are you sure you want to reset all settings to default values?');
    if (confirmed) {
      console.log('Resetting settings...');
      setHasUnsavedChanges(false);
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'general':
        return <GeneralSettings />;
      case 'domain':
        return <DomainHostingSettings />;
      case 'database':
        return <DatabaseSettings />;
      case 'security':
        return <SecuritySettings />;
      case 'performance':
        return <PerformanceSettings />;
      case 'version':
        return <VersionControlSettings />;
      default:
        return <GeneralSettings />;
    }
  };

  const getActiveTabInfo = () => {
    return tabs?.find(tab => tab?.id === activeTab);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar 
        isCollapsed={isSidebarCollapsed} 
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)} 
      />
      <main className={`pt-16 transition-all duration-300 ${
        isSidebarCollapsed ? 'lg:pl-16' : 'lg:pl-60'
      } pb-20 lg:pb-8`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold text-foreground">App Settings</h1>
                <p className="text-muted-foreground mt-1">
                  Configure your application settings and preferences
                </p>
              </div>
              
              {hasUnsavedChanges && (
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-2 text-warning">
                    <Icon name="AlertCircle" size={16} />
                    <span className="text-sm font-medium">Unsaved changes</span>
                  </div>
                  <Button
                    variant="default"
                    onClick={handleSaveAll}
                    iconName="Save"
                    iconPosition="left"
                  >
                    Save All
                  </Button>
                </div>
              )}
            </div>

            {/* Breadcrumb */}
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <span>Dashboard</span>
              <Icon name="ChevronRight" size={14} />
              <span>Settings</span>
              <Icon name="ChevronRight" size={14} />
              <span className="text-foreground font-medium">{getActiveTabInfo()?.label}</span>
            </div>
          </div>

          {/* Settings Navigation */}
          <div className="bg-card border border-border rounded-lg mb-8">
            {/* Desktop Tabs */}
            <div className="hidden lg:block border-b border-border">
              <nav className="flex space-x-0">
                {tabs?.map((tab) => (
                  <button
                    key={tab?.id}
                    onClick={() => handleTabChange(tab?.id)}
                    className={`flex items-center space-x-3 px-6 py-4 text-sm font-medium border-b-2 transition-colors hover:text-foreground hover:bg-muted/50 ${
                      activeTab === tab?.id
                        ? 'border-primary text-primary bg-primary/5' :'border-transparent text-muted-foreground'
                    }`}
                  >
                    <Icon name={tab?.icon} size={18} />
                    <div className="text-left">
                      <div>{tab?.label}</div>
                      <div className="text-xs text-muted-foreground font-normal">{tab?.description}</div>
                    </div>
                  </button>
                ))}
              </nav>
            </div>

            {/* Mobile Dropdown */}
            <div className="lg:hidden p-4 border-b border-border">
              <div className="relative">
                <select
                  value={activeTab}
                  onChange={(e) => handleTabChange(e?.target?.value)}
                  className="w-full px-4 py-3 bg-input border border-border rounded-md text-foreground focus:outline-none focus:ring-2 focus:ring-ring appearance-none"
                >
                  {tabs?.map((tab) => (
                    <option key={tab?.id} value={tab?.id}>
                      {tab?.label} - {tab?.description}
                    </option>
                  ))}
                </select>
                <Icon 
                  name="ChevronDown" 
                  size={16} 
                  className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-muted-foreground"
                />
              </div>
            </div>

            {/* Tab Content */}
            <div className="p-6">
              {renderTabContent()}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-1">Quick Actions</h3>
                <p className="text-sm text-muted-foreground">Common settings management tasks</p>
              </div>
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  onClick={handleResetSettings}
                  iconName="RotateCcw"
                  iconPosition="left"
                >
                  Reset to Default
                </Button>
                <Button
                  variant="outline"
                  iconName="Download"
                  iconPosition="left"
                >
                  Export Settings
                </Button>
                <Button
                  variant="outline"
                  iconName="Upload"
                  iconPosition="left"
                >
                  Import Settings
                </Button>
              </div>
            </div>
          </div>

          {/* Settings Info */}
          <div className="mt-6 bg-muted/50 border border-border rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <Icon name="Info" size={16} color="var(--color-primary)" className="mt-0.5" />
              <div className="text-sm">
                <p className="text-foreground font-medium mb-1">Settings Auto-Save</p>
                <p className="text-muted-foreground">
                  Most settings are automatically saved when changed. Critical settings like security and database 
                  configurations require manual confirmation before applying changes.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AppSettings;