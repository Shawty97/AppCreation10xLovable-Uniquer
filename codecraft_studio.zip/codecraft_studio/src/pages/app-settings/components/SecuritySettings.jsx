import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const SecuritySettings = () => {
  const [authSettings, setAuthSettings] = useState({
    provider: "email",
    twoFactorEnabled: true,
    sessionTimeout: "24",
    passwordPolicy: "strong",
    socialLogin: ["google", "github"]
  });

  const [apiSettings, setApiSettings] = useState({
    rateLimitEnabled: true,
    requestsPerMinute: "100",
    apiKeyRotation: "90",
    corsOrigins: "https://mystore.example.com, https://admin.mystore.example.com"
  });

  const [userRoles] = useState([
    { id: 1, name: "Admin", permissions: 15, users: 2, color: "bg-error" },
    { id: 2, name: "Editor", permissions: 8, users: 5, color: "bg-warning" },
    { id: 3, name: "Viewer", permissions: 3, users: 12, color: "bg-success" }
  ]);

  const [apiKeys] = useState([
    { id: 1, name: "Production API", key: "pk_live_••••••••••••••••", created: "2025-09-15", lastUsed: "2 hours ago", status: "active" },
    { id: 2, name: "Development API", key: "pk_test_••••••••••••••••", created: "2025-09-20", lastUsed: "1 day ago", status: "active" },
    { id: 3, name: "Mobile App API", key: "pk_mobile_••••••••••••••", created: "2025-09-25", lastUsed: "5 minutes ago", status: "active" }
  ]);

  const [securityLogs] = useState([
    { id: 1, event: "Failed login attempt", user: "unknown@example.com", ip: "192.168.1.100", timestamp: "5 minutes ago", severity: "warning" },
    { id: 2, event: "API key created", user: "admin@example.com", ip: "10.0.0.1", timestamp: "2 hours ago", severity: "info" },
    { id: 3, event: "Password changed", user: "user@example.com", ip: "192.168.1.50", timestamp: "1 day ago", severity: "info" }
  ]);

  const authProviderOptions = [
    { value: 'email', label: 'Email & Password' },
    { value: 'oauth', label: 'OAuth (Google, GitHub)' },
    { value: 'saml', label: 'SAML SSO' },
    { value: 'ldap', label: 'LDAP' },
    { value: 'custom', label: 'Custom Authentication' }
  ];

  const sessionTimeoutOptions = [
    { value: '1', label: '1 Hour' },
    { value: '8', label: '8 Hours' },
    { value: '24', label: '24 Hours' },
    { value: '168', label: '1 Week' },
    { value: '720', label: '30 Days' }
  ];

  const passwordPolicyOptions = [
    { value: 'basic', label: 'Basic (8+ characters)' },
    { value: 'strong', label: 'Strong (8+ chars, mixed case, numbers)' },
    { value: 'complex', label: 'Complex (12+ chars, symbols required)' }
  ];

  const handleAuthSettingsChange = (field, value) => {
    setAuthSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleApiSettingsChange = (field, value) => {
    setApiSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleGenerateApiKey = () => {
    console.log('Generating new API key...');
  };

  const handleRevokeApiKey = (keyId) => {
    console.log('Revoking API key:', keyId);
  };

  const handleCreateRole = () => {
    console.log('Opening create role dialog...');
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'error': return 'text-error';
      case 'warning': return 'text-warning';
      case 'info': return 'text-primary';
      default: return 'text-muted-foreground';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'error': return 'AlertCircle';
      case 'warning': return 'AlertTriangle';
      case 'info': return 'Info';
      default: return 'Circle';
    }
  };

  return (
    <div className="space-y-8">
      {/* Authentication Settings Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Icon name="Shield" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Authentication Settings</h3>
            <p className="text-sm text-muted-foreground">Configure user authentication and security policies</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <Select
              label="Authentication Provider"
              options={authProviderOptions}
              value={authSettings?.provider}
              onChange={(value) => handleAuthSettingsChange('provider', value)}
            />

            <Select
              label="Session Timeout"
              options={sessionTimeoutOptions}
              value={authSettings?.sessionTimeout}
              onChange={(value) => handleAuthSettingsChange('sessionTimeout', value)}
              description="Automatic logout after inactivity"
            />

            <Select
              label="Password Policy"
              options={passwordPolicyOptions}
              value={authSettings?.passwordPolicy}
              onChange={(value) => handleAuthSettingsChange('passwordPolicy', value)}
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="text-sm font-medium text-foreground">Two-Factor Authentication</h4>
                <p className="text-xs text-muted-foreground">Require 2FA for all users</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${authSettings?.twoFactorEnabled ? 'bg-success' : 'bg-muted-foreground'}`} />
                <span className="text-sm font-medium text-foreground">{authSettings?.twoFactorEnabled ? 'Enabled' : 'Disabled'}</span>
              </div>
            </div>

            <div className="bg-muted rounded-lg p-4">
              <h4 className="text-sm font-medium text-foreground mb-3">Social Login Providers</h4>
              <div className="space-y-2">
                {['google', 'github', 'microsoft', 'apple']?.map((provider) => (
                  <div key={provider} className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Icon name={provider === 'google' ? 'Chrome' : provider === 'github' ? 'Github' : 'Globe'} size={16} />
                      <span className="text-sm text-foreground capitalize">{provider}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${authSettings?.socialLogin?.includes(provider) ? 'bg-success' : 'bg-muted-foreground'}`} />
                      <span className="text-xs text-muted-foreground">{authSettings?.socialLogin?.includes(provider) ? 'Active' : 'Inactive'}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* User Roles & Permissions Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
              <Icon name="Users" size={20} color="white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">User Roles & Permissions</h3>
              <p className="text-sm text-muted-foreground">Manage user access levels and permissions</p>
            </div>
          </div>
          <Button
            variant="outline"
            onClick={handleCreateRole}
            iconName="Plus"
            iconPosition="left"
          >
            Create Role
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {userRoles?.map((role) => (
            <div key={role?.id} className="bg-muted rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${role?.color}`} />
                  <h4 className="text-sm font-medium text-foreground">{role?.name}</h4>
                </div>
                <Button variant="ghost" size="icon" iconName="MoreHorizontal" iconSize={16} />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Permissions</span>
                  <span className="text-xs text-foreground">{role?.permissions}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Users</span>
                  <span className="text-xs text-foreground">{role?.users}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* API Security Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-success rounded-lg flex items-center justify-center">
              <Icon name="Key" size={20} color="white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">API Security</h3>
              <p className="text-sm text-muted-foreground">Manage API keys and access controls</p>
            </div>
          </div>
          <Button
            variant="outline"
            onClick={handleGenerateApiKey}
            iconName="Plus"
            iconPosition="left"
          >
            Generate API Key
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="text-sm font-medium text-foreground">Rate Limiting</h4>
                <p className="text-xs text-muted-foreground">Protect against API abuse</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${apiSettings?.rateLimitEnabled ? 'bg-success' : 'bg-muted-foreground'}`} />
                <span className="text-sm font-medium text-foreground">{apiSettings?.rateLimitEnabled ? 'Enabled' : 'Disabled'}</span>
              </div>
            </div>

            <Input
              label="Requests Per Minute"
              type="number"
              placeholder="100"
              value={apiSettings?.requestsPerMinute}
              onChange={(e) => handleApiSettingsChange('requestsPerMinute', e?.target?.value)}
              description="Maximum API requests per minute per key"
            />

            <Input
              label="API Key Rotation (Days)"
              type="number"
              placeholder="90"
              value={apiSettings?.apiKeyRotation}
              onChange={(e) => handleApiSettingsChange('apiKeyRotation', e?.target?.value)}
              description="Automatic key rotation interval"
            />
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">CORS Origins</label>
              <textarea
                className="w-full px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none"
                rows={4}
                placeholder="https://example.com, https://app.example.com"
                value={apiSettings?.corsOrigins}
                onChange={(e) => handleApiSettingsChange('corsOrigins', e?.target?.value)}
              />
              <p className="text-xs text-muted-foreground mt-1">Comma-separated list of allowed origins</p>
            </div>
          </div>
        </div>

        {/* API Keys List */}
        <div>
          <h4 className="text-sm font-medium text-foreground mb-3">Active API Keys</h4>
          <div className="space-y-2">
            {apiKeys?.map((apiKey) => (
              <div key={apiKey?.id} className="bg-muted rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-1">
                      <h5 className="text-sm font-medium text-foreground">{apiKey?.name}</h5>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-success rounded-full" />
                        <span className="text-xs text-success capitalize">{apiKey?.status}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                      <span>Key: {apiKey?.key}</span>
                      <span>Created: {apiKey?.created}</span>
                      <span>Last used: {apiKey?.lastUsed}</span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRevokeApiKey(apiKey?.id)}
                    iconName="Trash2"
                    iconSize={14}
                    className="text-error hover:text-error"
                  >
                    Revoke
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Security Logs Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-warning rounded-lg flex items-center justify-center">
            <Icon name="FileText" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Security Logs</h3>
            <p className="text-sm text-muted-foreground">Monitor security events and access attempts</p>
          </div>
        </div>

        <div className="space-y-2">
          {securityLogs?.map((log) => (
            <div key={log?.id} className="bg-muted rounded-lg p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3">
                  <Icon 
                    name={getSeverityIcon(log?.severity)} 
                    size={16} 
                    className={getSeverityColor(log?.severity)}
                  />
                  <div>
                    <h5 className="text-sm font-medium text-foreground">{log?.event}</h5>
                    <div className="flex items-center space-x-4 text-xs text-muted-foreground mt-1">
                      <span>User: {log?.user}</span>
                      <span>IP: {log?.ip}</span>
                    </div>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">{log?.timestamp}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 text-center">
          <Button variant="outline" iconName="Eye" iconPosition="left">
            View All Logs
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SecuritySettings;