import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

import Select from '../../../components/ui/Select';

const VersionControlSettings = () => {
  const [versionSettings, setVersionSettings] = useState({
    autoVersioning: true,
    versioningScheme: "semantic",
    branchProtection: true,
    autoBackup: true,
    maxVersions: "50"
  });

  const [currentVersion] = useState({
    version: "1.2.3",
    branch: "main",
    lastCommit: "feat: Add user dashboard analytics",
    commitHash: "a7b3c9d",
    author: "John Doe",
    timestamp: "2025-10-01T12:30:00Z"
  });

  const [versionHistory] = useState([
    {
      id: 1,
      version: "1.2.3",
      type: "release",
      message: "feat: Add user dashboard analytics",
      author: "John Doe",
      timestamp: "2025-10-01T12:30:00Z",
      changes: 15,
      status: "current"
    },
    {
      id: 2,
      version: "1.2.2",
      type: "hotfix",
      message: "fix: Resolve payment gateway timeout issue",
      author: "Sarah Chen",
      timestamp: "2025-09-28T16:45:00Z",
      changes: 3,
      status: "deployed"
    },
    {
      id: 3,
      version: "1.2.1",
      type: "patch",
      message: "fix: Update mobile responsive layout",
      author: "Mike Johnson",
      timestamp: "2025-09-25T10:15:00Z",
      changes: 8,
      status: "deployed"
    },
    {
      id: 4,
      version: "1.2.0",
      type: "feature",
      message: "feat: Implement advanced search functionality",
      author: "John Doe",
      timestamp: "2025-09-20T14:20:00Z",
      changes: 42,
      status: "deployed"
    },
    {
      id: 5,
      version: "1.1.9",
      type: "patch",
      message: "fix: Improve database query performance",
      author: "Sarah Chen",
      timestamp: "2025-09-15T11:30:00Z",
      changes: 12,
      status: "archived"
    }
  ]);

  const [branches] = useState([
    { name: "main", commits: 156, lastUpdate: "2 hours ago", protected: true, status: "active" },
    { name: "develop", commits: 89, lastUpdate: "30 minutes ago", protected: false, status: "active" },
    { name: "feature/user-profiles", commits: 12, lastUpdate: "1 day ago", protected: false, status: "active" },
    { name: "hotfix/payment-fix", commits: 3, lastUpdate: "3 days ago", protected: false, status: "merged" }
  ]);

  const versioningSchemeOptions = [
    { value: 'semantic', label: 'Semantic Versioning (x.y.z)' },
    { value: 'timestamp', label: 'Timestamp Based' },
    { value: 'incremental', label: 'Incremental Numbers' },
    { value: 'custom', label: 'Custom Format' }
  ];

  const maxVersionsOptions = [
    { value: '25', label: '25 Versions' },
    { value: '50', label: '50 Versions' },
    { value: '100', label: '100 Versions' },
    { value: 'unlimited', label: 'Unlimited' }
  ];

  const handleVersionSettingsChange = (field, value) => {
    setVersionSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleCreateVersion = () => {
    console.log('Creating new version...');
  };

  const handleRollback = (versionId) => {
    console.log('Rolling back to version:', versionId);
  };

  const handleCreateBranch = () => {
    console.log('Creating new branch...');
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleString();
  };

  const getVersionTypeColor = (type) => {
    switch (type) {
      case 'release': return 'bg-success text-success-foreground';
      case 'feature': return 'bg-primary text-primary-foreground';
      case 'hotfix': return 'bg-error text-error-foreground';
      case 'patch': return 'bg-warning text-warning-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'current': return 'text-success';
      case 'deployed': return 'text-primary';
      case 'archived': return 'text-muted-foreground';
      default: return 'text-foreground';
    }
  };

  const getBranchStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-success';
      case 'merged': return 'bg-primary';
      case 'stale': return 'bg-warning';
      default: return 'bg-muted-foreground';
    }
  };

  return (
    <div className="space-y-8">
      {/* Current Version Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-success rounded-lg flex items-center justify-center">
            <Icon name="GitBranch" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Current Version</h3>
            <p className="text-sm text-muted-foreground">Active version and latest changes</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="bg-muted rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-lg font-bold text-foreground">v{currentVersion?.version}</h4>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-success rounded-full" />
                  <span className="text-sm text-success">Live</span>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Branch</span>
                  <span className="text-foreground font-mono">{currentVersion?.branch}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Commit</span>
                  <span className="text-foreground font-mono">{currentVersion?.commitHash}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Author</span>
                  <span className="text-foreground">{currentVersion?.author}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Updated</span>
                  <span className="text-foreground">{formatDate(currentVersion?.timestamp)}</span>
                </div>
              </div>
            </div>

            <div className="bg-muted rounded-lg p-4">
              <h5 className="text-sm font-medium text-foreground mb-2">Latest Commit</h5>
              <p className="text-sm text-muted-foreground">{currentVersion?.lastCommit}</p>
            </div>
          </div>

          <div className="space-y-4">
            <Button
              variant="default"
              fullWidth
              onClick={handleCreateVersion}
              iconName="Plus"
              iconPosition="left"
            >
              Create New Version
            </Button>

            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" iconName="Download" iconPosition="left">
                Export
              </Button>
              <Button variant="outline" iconName="Copy" iconPosition="left">
                Clone
              </Button>
            </div>

            <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="Info" size={16} color="var(--color-primary)" />
                <span className="text-sm font-medium text-primary">Auto-versioning Enabled</span>
              </div>
              <p className="text-xs text-muted-foreground">New versions are automatically created on deployment</p>
            </div>
          </div>
        </div>
      </div>
      {/* Version Control Settings Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Icon name="Settings" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Version Control Settings</h3>
            <p className="text-sm text-muted-foreground">Configure versioning behavior and policies</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <Select
              label="Versioning Scheme"
              options={versioningSchemeOptions}
              value={versionSettings?.versioningScheme}
              onChange={(value) => handleVersionSettingsChange('versioningScheme', value)}
            />

            <Select
              label="Maximum Versions to Keep"
              options={maxVersionsOptions}
              value={versionSettings?.maxVersions}
              onChange={(value) => handleVersionSettingsChange('maxVersions', value)}
              description="Older versions will be automatically archived"
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="text-sm font-medium text-foreground">Auto Versioning</h4>
                <p className="text-xs text-muted-foreground">Create versions on deployment</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${versionSettings?.autoVersioning ? 'bg-success' : 'bg-muted-foreground'}`} />
                <span className="text-sm font-medium text-foreground">{versionSettings?.autoVersioning ? 'On' : 'Off'}</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="text-sm font-medium text-foreground">Branch Protection</h4>
                <p className="text-xs text-muted-foreground">Protect main branch from direct commits</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${versionSettings?.branchProtection ? 'bg-success' : 'bg-muted-foreground'}`} />
                <span className="text-sm font-medium text-foreground">{versionSettings?.branchProtection ? 'On' : 'Off'}</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="text-sm font-medium text-foreground">Auto Backup</h4>
                <p className="text-xs text-muted-foreground">Backup before major changes</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${versionSettings?.autoBackup ? 'bg-success' : 'bg-muted-foreground'}`} />
                <span className="text-sm font-medium text-foreground">{versionSettings?.autoBackup ? 'On' : 'Off'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Version History Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
              <Icon name="History" size={20} color="white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">Version History</h3>
              <p className="text-sm text-muted-foreground">Track changes and manage rollbacks</p>
            </div>
          </div>
          <Button variant="outline" iconName="Filter" iconPosition="left">
            Filter
          </Button>
        </div>

        <div className="space-y-3">
          {versionHistory?.map((version) => (
            <div key={version?.id} className="bg-muted rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <span className="text-lg font-bold text-foreground">v{version?.version}</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getVersionTypeColor(version?.type)}`}>
                      {version?.type}
                    </span>
                    <span className={`text-sm font-medium ${getStatusColor(version?.status)}`}>
                      {version?.status}
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {version?.status !== 'current' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleRollback(version?.id)}
                      iconName="RotateCcw"
                      iconSize={14}
                    >
                      Rollback
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" iconName="MoreHorizontal" iconSize={16} />
                </div>
              </div>
              
              <div className="mt-3">
                <p className="text-sm text-foreground mb-2">{version?.message}</p>
                <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                  <span>By {version?.author}</span>
                  <span>{formatDate(version?.timestamp)}</span>
                  <span>{version?.changes} changes</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 text-center">
          <Button variant="outline" iconName="Eye" iconPosition="left">
            View All Versions
          </Button>
        </div>
      </div>
      {/* Branch Management Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-warning rounded-lg flex items-center justify-center">
              <Icon name="GitBranch" size={20} color="white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">Branch Management</h3>
              <p className="text-sm text-muted-foreground">Manage development branches and merges</p>
            </div>
          </div>
          <Button
            variant="outline"
            onClick={handleCreateBranch}
            iconName="Plus"
            iconPosition="left"
          >
            Create Branch
          </Button>
        </div>

        <div className="space-y-3">
          {branches?.map((branch, index) => (
            <div key={index} className="bg-muted rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Icon name="GitBranch" size={16} color="var(--color-foreground)" />
                    <span className="font-medium text-foreground font-mono">{branch?.name}</span>
                    {branch?.protected && (
                      <Icon name="Shield" size={14} color="var(--color-success)" title="Protected branch" />
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${getBranchStatusColor(branch?.status)}`} />
                    <span className="text-sm text-muted-foreground capitalize">{branch?.status}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <span>{branch?.commits} commits</span>
                  <span>Updated {branch?.lastUpdate}</span>
                  <Button variant="ghost" size="icon" iconName="MoreHorizontal" iconSize={16} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VersionControlSettings;