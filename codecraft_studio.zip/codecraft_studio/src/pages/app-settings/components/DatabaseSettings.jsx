import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const DatabaseSettings = () => {
  const [connectionData, setConnectionData] = useState({
    provider: "postgresql",
    host: "db.codecraft.app",
    port: "5432",
    database: "ecommerce_dashboard",
    username: "app_user",
    password: "••••••••••••",
    ssl: true,
    connectionPool: "10"
  });

  const [backupSettings, setBackupSettings] = useState({
    autoBackup: true,
    frequency: "daily",
    retention: "30",
    lastBackup: "2025-10-01T10:30:00Z",
    backupSize: "245 MB"
  });

  const [performanceMetrics] = useState({
    activeConnections: 7,
    maxConnections: 100,
    queryTime: "12ms",
    cacheHitRate: "94.2%",
    storageUsed: "1.2 GB",
    storageLimit: "10 GB"
  });

  const providerOptions = [
    { value: 'postgresql', label: 'PostgreSQL' },
    { value: 'mysql', label: 'MySQL' },
    { value: 'mongodb', label: 'MongoDB' },
    { value: 'sqlite', label: 'SQLite' },
    { value: 'redis', label: 'Redis' },
    { value: 'firebase', label: 'Firebase Firestore' }
  ];

  const frequencyOptions = [
    { value: 'hourly', label: 'Every Hour' },
    { value: 'daily', label: 'Daily' },
    { value: 'weekly', label: 'Weekly' },
    { value: 'monthly', label: 'Monthly' }
  ];

  const retentionOptions = [
    { value: '7', label: '7 Days' },
    { value: '30', label: '30 Days' },
    { value: '90', label: '90 Days' },
    { value: '365', label: '1 Year' }
  ];

  const recentQueries = [
    { id: 1, query: "SELECT * FROM products WHERE category = 'electronics'", duration: "8ms", timestamp: "2 minutes ago" },
    { id: 2, query: "UPDATE orders SET status = 'shipped' WHERE id = 12345", duration: "15ms", timestamp: "5 minutes ago" },
    { id: 3, query: "SELECT COUNT(*) FROM users WHERE created_at > '2025-09-01'", duration: "22ms", timestamp: "8 minutes ago" }
  ];

  const handleConnectionDataChange = (field, value) => {
    setConnectionData(prev => ({ ...prev, [field]: value }));
  };

  const handleBackupSettingsChange = (field, value) => {
    setBackupSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleTestConnection = () => {
    console.log('Testing database connection...');
  };

  const handleCreateBackup = () => {
    console.log('Creating manual backup...');
  };

  const handleRestoreBackup = () => {
    console.log('Opening restore backup dialog...');
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleString();
  };

  return (
    <div className="space-y-8">
      {/* Connection Settings Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Icon name="Database" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Database Connection</h3>
            <p className="text-sm text-muted-foreground">Configure your database connection settings</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <Select
              label="Database Provider"
              options={providerOptions}
              value={connectionData?.provider}
              onChange={(value) => handleConnectionDataChange('provider', value)}
            />

            <Input
              label="Host"
              type="text"
              placeholder="localhost"
              value={connectionData?.host}
              onChange={(e) => handleConnectionDataChange('host', e?.target?.value)}
              required
            />

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Port"
                type="number"
                placeholder="5432"
                value={connectionData?.port}
                onChange={(e) => handleConnectionDataChange('port', e?.target?.value)}
              />
              <Input
                label="Connection Pool"
                type="number"
                placeholder="10"
                value={connectionData?.connectionPool}
                onChange={(e) => handleConnectionDataChange('connectionPool', e?.target?.value)}
              />
            </div>

            <Input
              label="Database Name"
              type="text"
              placeholder="my_database"
              value={connectionData?.database}
              onChange={(e) => handleConnectionDataChange('database', e?.target?.value)}
              required
            />
          </div>

          <div className="space-y-4">
            <Input
              label="Username"
              type="text"
              placeholder="db_user"
              value={connectionData?.username}
              onChange={(e) => handleConnectionDataChange('username', e?.target?.value)}
              required
            />

            <Input
              label="Password"
              type="password"
              placeholder="••••••••••••"
              value={connectionData?.password}
              onChange={(e) => handleConnectionDataChange('password', e?.target?.value)}
              required
            />

            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="text-sm font-medium text-foreground">SSL Connection</h4>
                <p className="text-xs text-muted-foreground">Encrypt database connections</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${connectionData?.ssl ? 'bg-success' : 'bg-muted-foreground'}`} />
                <span className="text-sm font-medium text-foreground">{connectionData?.ssl ? 'Enabled' : 'Disabled'}</span>
              </div>
            </div>

            <div className="space-y-3">
              <Button
                variant="outline"
                fullWidth
                onClick={handleTestConnection}
                iconName="Zap"
                iconPosition="left"
              >
                Test Connection
              </Button>
              <div className="bg-success/10 border border-success/20 rounded-lg p-3">
                <div className="flex items-center space-x-2">
                  <Icon name="CheckCircle" size={16} color="var(--color-success)" />
                  <span className="text-sm font-medium text-success">Connection Status: Active</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Backup Settings Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
            <Icon name="Archive" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Backup Configuration</h3>
            <p className="text-sm text-muted-foreground">Manage automated backups and data recovery</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="text-sm font-medium text-foreground">Automatic Backups</h4>
                <p className="text-xs text-muted-foreground">Schedule regular database backups</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${backupSettings?.autoBackup ? 'bg-success' : 'bg-muted-foreground'}`} />
                <span className="text-sm font-medium text-foreground">{backupSettings?.autoBackup ? 'Enabled' : 'Disabled'}</span>
              </div>
            </div>

            <Select
              label="Backup Frequency"
              options={frequencyOptions}
              value={backupSettings?.frequency}
              onChange={(value) => handleBackupSettingsChange('frequency', value)}
            />

            <Select
              label="Retention Period"
              options={retentionOptions}
              value={backupSettings?.retention}
              onChange={(value) => handleBackupSettingsChange('retention', value)}
              description="How long to keep backup files"
            />
          </div>

          <div className="space-y-4">
            <div className="bg-muted rounded-lg p-4">
              <h4 className="text-sm font-medium text-foreground mb-3">Last Backup</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Date & Time</span>
                  <span className="text-sm text-foreground">{formatDate(backupSettings?.lastBackup)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Backup Size</span>
                  <span className="text-sm text-foreground">{backupSettings?.backupSize}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Status</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-success rounded-full" />
                    <span className="text-sm text-success">Completed</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <Button
                variant="outline"
                fullWidth
                onClick={handleCreateBackup}
                iconName="Download"
                iconPosition="left"
              >
                Create Backup Now
              </Button>
              <Button
                variant="outline"
                fullWidth
                onClick={handleRestoreBackup}
                iconName="Upload"
                iconPosition="left"
              >
                Restore from Backup
              </Button>
            </div>
          </div>
        </div>
      </div>
      {/* Performance Metrics Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-success rounded-lg flex items-center justify-center">
            <Icon name="BarChart3" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Performance Metrics</h3>
            <p className="text-sm text-muted-foreground">Monitor database performance and usage</p>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="Activity" size={20} color="var(--color-primary)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{performanceMetrics?.activeConnections}</div>
            <div className="text-xs text-muted-foreground">Active Connections</div>
            <div className="text-xs text-muted-foreground">of {performanceMetrics?.maxConnections} max</div>
          </div>

          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="Zap" size={20} color="var(--color-accent)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{performanceMetrics?.queryTime}</div>
            <div className="text-xs text-muted-foreground">Avg Query Time</div>
          </div>

          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="Target" size={20} color="var(--color-success)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{performanceMetrics?.cacheHitRate}</div>
            <div className="text-xs text-muted-foreground">Cache Hit Rate</div>
          </div>

          <div className="bg-muted rounded-lg p-4 text-center lg:col-span-2">
            <div className="flex items-center justify-center mb-2">
              <Icon name="HardDrive" size={20} color="var(--color-secondary)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{performanceMetrics?.storageUsed}</div>
            <div className="text-xs text-muted-foreground">Storage Used of {performanceMetrics?.storageLimit}</div>
            <div className="w-full bg-border rounded-full h-2 mt-2">
              <div className="bg-primary h-2 rounded-full" style={{ width: '12%' }} />
            </div>
          </div>
        </div>

        {/* Recent Queries */}
        <div>
          <h4 className="text-sm font-medium text-foreground mb-3">Recent Queries</h4>
          <div className="space-y-2">
            {recentQueries?.map((query) => (
              <div key={query?.id} className="bg-muted rounded-lg p-3">
                <div className="flex items-start justify-between mb-1">
                  <code className="text-xs text-foreground bg-card px-2 py-1 rounded font-mono flex-1 mr-3">
                    {query?.query}
                  </code>
                  <div className="flex items-center space-x-3 text-xs text-muted-foreground">
                    <span>{query?.duration}</span>
                    <span>{query?.timestamp}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DatabaseSettings;