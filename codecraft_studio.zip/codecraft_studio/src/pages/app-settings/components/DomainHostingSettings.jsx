import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const DomainHostingSettings = () => {
  const [domainData, setDomainData] = useState({
    customDomain: "mystore.example.com",
    subdomain: "mystore-dashboard",
    sslEnabled: true,
    sslStatus: "active",
    dnsConfigured: true
  });

  const [deploymentData, setDeploymentData] = useState({
    platform: "vercel",
    environment: "production",
    autoDeployment: true,
    buildCommand: "npm run build",
    outputDirectory: "dist"
  });

  const [hostingMetrics] = useState({
    uptime: "99.9%",
    responseTime: "245ms",
    bandwidth: "2.4 GB",
    visitors: "1,247",
    lastDeployment: "2 hours ago"
  });

  const platformOptions = [
    { value: 'vercel', label: 'Vercel' },
    { value: 'netlify', label: 'Netlify' },
    { value: 'aws', label: 'AWS S3 + CloudFront' },
    { value: 'firebase', label: 'Firebase Hosting' },
    { value: 'github', label: 'GitHub Pages' },
    { value: 'custom', label: 'Custom Server' }
  ];

  const environmentOptions = [
    { value: 'production', label: 'Production' },
    { value: 'staging', label: 'Staging' },
    { value: 'development', label: 'Development' }
  ];

  const dnsRecords = [
    { type: 'A', name: '@', value: '76.76.19.123', status: 'active' },
    { type: 'CNAME', name: 'www', value: 'mystore.example.com', status: 'active' },
    { type: 'TXT', name: '@', value: 'v=spf1 include:_spf.google.com ~all', status: 'active' }
  ];

  const handleDomainDataChange = (field, value) => {
    setDomainData(prev => ({ ...prev, [field]: value }));
  };

  const handleDeploymentDataChange = (field, value) => {
    setDeploymentData(prev => ({ ...prev, [field]: value }));
  };

  const handleDeployNow = () => {
    console.log('Deploying application...');
  };

  const handleConfigureDNS = () => {
    console.log('Opening DNS configuration wizard...');
  };

  const handleRenewSSL = () => {
    console.log('Renewing SSL certificate...');
  };

  return (
    <div className="space-y-8">
      {/* Domain Configuration Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Icon name="Globe" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Domain Configuration</h3>
            <p className="text-sm text-muted-foreground">Manage your custom domain and DNS settings</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <Input
              label="Custom Domain"
              type="text"
              placeholder="yourdomain.com"
              value={domainData?.customDomain}
              onChange={(e) => handleDomainDataChange('customDomain', e?.target?.value)}
              description="Your custom domain name"
            />

            <Input
              label="Subdomain"
              type="text"
              placeholder="app-name"
              value={domainData?.subdomain}
              onChange={(e) => handleDomainDataChange('subdomain', e?.target?.value)}
              description="Free subdomain: app-name.codecraft.app"
            />

            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="text-sm font-medium text-foreground">SSL Certificate</h4>
                <p className="text-xs text-muted-foreground">Secure your domain with HTTPS</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${domainData?.sslStatus === 'active' ? 'bg-success' : 'bg-warning'}`} />
                <span className="text-sm font-medium text-foreground capitalize">{domainData?.sslStatus}</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-success/10 border border-success/20 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="CheckCircle" size={16} color="var(--color-success)" />
                <span className="text-sm font-medium text-success">Domain Status: Active</span>
              </div>
              <p className="text-xs text-muted-foreground">Your domain is properly configured and accessible</p>
            </div>

            <div className="space-y-3">
              <Button
                variant="outline"
                fullWidth
                onClick={handleConfigureDNS}
                iconName="Settings"
                iconPosition="left"
              >
                Configure DNS
              </Button>
              <Button
                variant="outline"
                fullWidth
                onClick={handleRenewSSL}
                iconName="Shield"
                iconPosition="left"
              >
                Renew SSL Certificate
              </Button>
            </div>
          </div>
        </div>

        {/* DNS Records */}
        <div className="mt-6">
          <h4 className="text-sm font-medium text-foreground mb-3">DNS Records</h4>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-2 text-muted-foreground font-medium">Type</th>
                  <th className="text-left py-2 text-muted-foreground font-medium">Name</th>
                  <th className="text-left py-2 text-muted-foreground font-medium">Value</th>
                  <th className="text-left py-2 text-muted-foreground font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {dnsRecords?.map((record, index) => (
                  <tr key={index} className="border-b border-border/50">
                    <td className="py-2 font-mono text-xs bg-muted px-2 rounded">{record?.type}</td>
                    <td className="py-2 text-foreground">{record?.name}</td>
                    <td className="py-2 text-muted-foreground font-mono text-xs">{record?.value}</td>
                    <td className="py-2">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-success rounded-full" />
                        <span className="text-xs text-success capitalize">{record?.status}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      {/* Deployment Settings Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
            <Icon name="Rocket" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Deployment Settings</h3>
            <p className="text-sm text-muted-foreground">Configure how your app is built and deployed</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <Select
              label="Deployment Platform"
              options={platformOptions}
              value={deploymentData?.platform}
              onChange={(value) => handleDeploymentDataChange('platform', value)}
            />

            <Select
              label="Environment"
              options={environmentOptions}
              value={deploymentData?.environment}
              onChange={(value) => handleDeploymentDataChange('environment', value)}
            />

            <Input
              label="Build Command"
              type="text"
              placeholder="npm run build"
              value={deploymentData?.buildCommand}
              onChange={(e) => handleDeploymentDataChange('buildCommand', e?.target?.value)}
              description="Command to build your application"
            />

            <Input
              label="Output Directory"
              type="text"
              placeholder="dist"
              value={deploymentData?.outputDirectory}
              onChange={(e) => handleDeploymentDataChange('outputDirectory', e?.target?.value)}
              description="Directory containing built files"
            />
          </div>

          <div className="space-y-4">
            <div className="bg-muted rounded-lg p-4">
              <h4 className="text-sm font-medium text-foreground mb-3">Deployment Status</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Last Deployment</span>
                  <span className="text-sm text-foreground">{hostingMetrics?.lastDeployment}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Build Status</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-success rounded-full" />
                    <span className="text-sm text-success">Success</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Auto Deploy</span>
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${deploymentData?.autoDeployment ? 'bg-success' : 'bg-muted-foreground'}`} />
                    <span className="text-sm text-foreground">{deploymentData?.autoDeployment ? 'Enabled' : 'Disabled'}</span>
                  </div>
                </div>
              </div>
            </div>

            <Button
              variant="default"
              fullWidth
              onClick={handleDeployNow}
              iconName="Upload"
              iconPosition="left"
            >
              Deploy Now
            </Button>
          </div>
        </div>
      </div>
      {/* Hosting Metrics Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-success rounded-lg flex items-center justify-center">
            <Icon name="BarChart3" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Hosting Metrics</h3>
            <p className="text-sm text-muted-foreground">Monitor your app's performance and usage</p>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="Activity" size={20} color="var(--color-success)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{hostingMetrics?.uptime}</div>
            <div className="text-xs text-muted-foreground">Uptime</div>
          </div>

          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="Zap" size={20} color="var(--color-accent)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{hostingMetrics?.responseTime}</div>
            <div className="text-xs text-muted-foreground">Avg Response</div>
          </div>

          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="HardDrive" size={20} color="var(--color-primary)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{hostingMetrics?.bandwidth}</div>
            <div className="text-xs text-muted-foreground">Bandwidth Used</div>
          </div>

          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="Users" size={20} color="var(--color-secondary)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{hostingMetrics?.visitors}</div>
            <div className="text-xs text-muted-foreground">Monthly Visitors</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DomainHostingSettings;