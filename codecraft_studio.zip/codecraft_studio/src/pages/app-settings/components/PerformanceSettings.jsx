import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const PerformanceSettings = () => {
  const [optimizationSettings, setOptimizationSettings] = useState({
    caching: true,
    compression: true,
    imageOptimization: true,
    lazyLoading: true,
    minification: true,
    cdnEnabled: true
  });

  const [analyticsSettings, setAnalyticsSettings] = useState({
    provider: "google",
    trackingId: "GA-XXXX-XXXX-X",
    heatmapEnabled: true,
    errorTracking: true,
    performanceMonitoring: true
  });

  const [performanceMetrics] = useState({
    loadTime: "1.2s",
    firstContentfulPaint: "0.8s",
    largestContentfulPaint: "1.5s",
    cumulativeLayoutShift: "0.05",
    firstInputDelay: "12ms",
    performanceScore: 94
  });

  const [optimizationRecommendations] = useState([
    {
      id: 1,
      type: "critical",
      title: "Optimize Large Images",
      description: "3 images larger than 500KB detected. Consider using WebP format and compression.",
      impact: "High",
      effort: "Low"
    },
    {
      id: 2,
      type: "warning",
      title: "Reduce JavaScript Bundle Size",
      description: "Main bundle is 2.1MB. Consider code splitting and tree shaking.",
      impact: "Medium",
      effort: "Medium"
    },
    {
      id: 3,
      type: "info",
      title: "Enable Service Worker",
      description: "Implement service worker for offline functionality and caching.",
      impact: "Medium",
      effort: "High"
    }
  ]);

  const analyticsProviderOptions = [
    { value: 'google', label: 'Google Analytics' },
    { value: 'mixpanel', label: 'Mixpanel' },
    { value: 'amplitude', label: 'Amplitude' },
    { value: 'hotjar', label: 'Hotjar' },
    { value: 'custom', label: 'Custom Analytics' }
  ];

  const handleOptimizationChange = (field, value) => {
    setOptimizationSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleAnalyticsChange = (field, value) => {
    setAnalyticsSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleRunOptimization = () => {
    console.log('Running performance optimization...');
  };

  const handleGenerateReport = () => {
    console.log('Generating performance report...');
  };

  const getRecommendationColor = (type) => {
    switch (type) {
      case 'critical': return 'border-error bg-error/10';
      case 'warning': return 'border-warning bg-warning/10';
      case 'info': return 'border-primary bg-primary/10';
      default: return 'border-border bg-muted';
    }
  };

  const getRecommendationIcon = (type) => {
    switch (type) {
      case 'critical': return 'AlertCircle';
      case 'warning': return 'AlertTriangle';
      case 'info': return 'Info';
      default: return 'Circle';
    }
  };

  const getRecommendationIconColor = (type) => {
    switch (type) {
      case 'critical': return 'var(--color-error)';
      case 'warning': return 'var(--color-warning)';
      case 'info': return 'var(--color-primary)';
      default: return 'var(--color-muted-foreground)';
    }
  };

  const getPerformanceScoreColor = (score) => {
    if (score >= 90) return 'text-success';
    if (score >= 70) return 'text-warning';
    return 'text-error';
  };

  return (
    <div className="space-y-8">
      {/* Performance Metrics Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-success rounded-lg flex items-center justify-center">
            <Icon name="Zap" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Performance Metrics</h3>
            <p className="text-sm text-muted-foreground">Real-time performance monitoring and Core Web Vitals</p>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="Clock" size={20} color="var(--color-primary)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{performanceMetrics?.loadTime}</div>
            <div className="text-xs text-muted-foreground">Page Load Time</div>
          </div>

          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="Eye" size={20} color="var(--color-accent)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{performanceMetrics?.firstContentfulPaint}</div>
            <div className="text-xs text-muted-foreground">First Contentful Paint</div>
          </div>

          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="Image" size={20} color="var(--color-success)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{performanceMetrics?.largestContentfulPaint}</div>
            <div className="text-xs text-muted-foreground">Largest Contentful Paint</div>
          </div>

          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="Move" size={20} color="var(--color-warning)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{performanceMetrics?.cumulativeLayoutShift}</div>
            <div className="text-xs text-muted-foreground">Cumulative Layout Shift</div>
          </div>

          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="MousePointer" size={20} color="var(--color-secondary)" />
            </div>
            <div className="text-2xl font-bold text-foreground">{performanceMetrics?.firstInputDelay}</div>
            <div className="text-xs text-muted-foreground">First Input Delay</div>
          </div>

          <div className="bg-muted rounded-lg p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Icon name="Award" size={20} color="var(--color-success)" />
            </div>
            <div className={`text-2xl font-bold ${getPerformanceScoreColor(performanceMetrics?.performanceScore)}`}>
              {performanceMetrics?.performanceScore}
            </div>
            <div className="text-xs text-muted-foreground">Performance Score</div>
          </div>
        </div>

        <div className="flex items-center justify-center space-x-3">
          <Button
            variant="outline"
            onClick={handleGenerateReport}
            iconName="FileText"
            iconPosition="left"
          >
            Generate Report
          </Button>
          <Button
            variant="default"
            onClick={handleRunOptimization}
            iconName="Zap"
            iconPosition="left"
          >
            Run Optimization
          </Button>
        </div>
      </div>
      {/* Optimization Settings Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Icon name="Settings" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Optimization Settings</h3>
            <p className="text-sm text-muted-foreground">Configure automatic performance optimizations</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(optimizationSettings)?.map(([key, value]) => (
            <div key={key} className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="text-sm font-medium text-foreground capitalize">
                  {key?.replace(/([A-Z])/g, ' $1')?.trim()}
                </h4>
                <p className="text-xs text-muted-foreground">
                  {key === 'caching' && 'Browser and server-side caching'}
                  {key === 'compression' && 'Gzip/Brotli compression'}
                  {key === 'imageOptimization' && 'Automatic image compression'}
                  {key === 'lazyLoading' && 'Lazy load images and components'}
                  {key === 'minification' && 'Minify CSS, JS, and HTML'}
                  {key === 'cdnEnabled' && 'Content Delivery Network'}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${value ? 'bg-success' : 'bg-muted-foreground'}`} />
                <span className="text-sm font-medium text-foreground">{value ? 'On' : 'Off'}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Analytics Integration Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
            <Icon name="BarChart3" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Analytics Integration</h3>
            <p className="text-sm text-muted-foreground">Monitor user behavior and app performance</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <Select
              label="Analytics Provider"
              options={analyticsProviderOptions}
              value={analyticsSettings?.provider}
              onChange={(value) => handleAnalyticsChange('provider', value)}
            />

            <Input
              label="Tracking ID"
              type="text"
              placeholder="GA-XXXX-XXXX-X"
              value={analyticsSettings?.trackingId}
              onChange={(e) => handleAnalyticsChange('trackingId', e?.target?.value)}
              description="Your analytics tracking identifier"
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="text-sm font-medium text-foreground">Heatmap Tracking</h4>
                <p className="text-xs text-muted-foreground">Track user interactions and clicks</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${analyticsSettings?.heatmapEnabled ? 'bg-success' : 'bg-muted-foreground'}`} />
                <span className="text-sm font-medium text-foreground">{analyticsSettings?.heatmapEnabled ? 'On' : 'Off'}</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="text-sm font-medium text-foreground">Error Tracking</h4>
                <p className="text-xs text-muted-foreground">Monitor JavaScript errors and crashes</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${analyticsSettings?.errorTracking ? 'bg-success' : 'bg-muted-foreground'}`} />
                <span className="text-sm font-medium text-foreground">{analyticsSettings?.errorTracking ? 'On' : 'Off'}</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div>
                <h4 className="text-sm font-medium text-foreground">Performance Monitoring</h4>
                <p className="text-xs text-muted-foreground">Real-time performance metrics</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${analyticsSettings?.performanceMonitoring ? 'bg-success' : 'bg-muted-foreground'}`} />
                <span className="text-sm font-medium text-foreground">{analyticsSettings?.performanceMonitoring ? 'On' : 'Off'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Optimization Recommendations Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-warning rounded-lg flex items-center justify-center">
            <Icon name="Lightbulb" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Optimization Recommendations</h3>
            <p className="text-sm text-muted-foreground">AI-powered suggestions to improve performance</p>
          </div>
        </div>

        <div className="space-y-4">
          {optimizationRecommendations?.map((recommendation) => (
            <div key={recommendation?.id} className={`border rounded-lg p-4 ${getRecommendationColor(recommendation?.type)}`}>
              <div className="flex items-start space-x-3">
                <Icon 
                  name={getRecommendationIcon(recommendation?.type)} 
                  size={20} 
                  color={getRecommendationIconColor(recommendation?.type)}
                />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-medium text-foreground">{recommendation?.title}</h4>
                    <div className="flex items-center space-x-3 text-xs">
                      <span className="text-muted-foreground">Impact: <span className="font-medium">{recommendation?.impact}</span></span>
                      <span className="text-muted-foreground">Effort: <span className="font-medium">{recommendation?.effort}</span></span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">{recommendation?.description}</p>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      Learn More
                    </Button>
                    <Button variant="default" size="sm">
                      Apply Fix
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PerformanceSettings;