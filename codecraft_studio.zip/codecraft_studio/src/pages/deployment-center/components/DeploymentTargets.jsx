import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

import Select from '../../../components/ui/Select';

const DeploymentTargets = ({ onDeploy }) => {
  const [selectedTargets, setSelectedTargets] = useState({});
  const [deploymentConfig, setDeploymentConfig] = useState({});

  const deploymentTargets = [
    {
      id: 'vercel',
      name: 'Vercel',
      description: 'Fast, reliable hosting for frontend frameworks and static sites',
      icon: 'Triangle',
      category: 'Web Hosting',
      pricing: 'Free tier available',
      features: ['Auto SSL', 'CDN', 'Analytics', 'Serverless Functions'],
      status: 'available',
      connected: true
    },
    {
      id: 'netlify',
      name: 'Netlify',
      description: 'All-in-one platform for automating modern web projects',
      icon: 'Globe',
      category: 'Web Hosting',
      pricing: 'Free tier available',
      features: ['Form Handling', 'Split Testing', 'Edge Functions', 'Identity'],
      status: 'available',
      connected: true
    },
    {
      id: 'aws',
      name: 'Amazon Web Services',
      description: 'Comprehensive cloud computing platform',
      icon: 'Cloud',
      category: 'Cloud Platform',
      pricing: 'Pay as you go',
      features: ['S3 Static Hosting', 'CloudFront CDN', 'Lambda', 'RDS'],
      status: 'available',
      connected: false
    },
    {
      id: 'firebase',
      name: 'Firebase Hosting',
      description: 'Fast and secure web hosting by Google',
      icon: 'Flame',
      category: 'Web Hosting',
      pricing: 'Free tier available',
      features: ['Global CDN', 'SSL Certificates', 'Custom Domains', 'Analytics'],
      status: 'available',
      connected: false
    },
    {
      id: 'github-pages',
      name: 'GitHub Pages',
      description: 'Static site hosting directly from GitHub repository',
      icon: 'Github',
      category: 'Static Hosting',
      pricing: 'Free',
      features: ['Custom Domains', 'HTTPS', 'Jekyll Support', 'Actions CI/CD'],
      status: 'available',
      connected: true
    },
    {
      id: 'ios-store',
      name: 'Apple App Store',
      description: 'Distribute your app to iOS users worldwide',
      icon: 'Smartphone',
      category: 'Mobile Distribution',
      pricing: '$99/year',
      features: ['App Review', 'In-App Purchases', 'TestFlight', 'App Analytics'],
      status: 'coming-soon',
      connected: false
    },
    {
      id: 'google-play',
      name: 'Google Play Store',
      description: 'Reach Android users across the globe',
      icon: 'Play',
      category: 'Mobile Distribution',
      pricing: '$25 one-time',
      features: ['App Bundle', 'In-App Billing', 'Play Console', 'Crash Reporting'],
      status: 'coming-soon',
      connected: false
    },
    {
      id: 'pwa',
      name: 'Progressive Web App',
      description: 'Deploy as a PWA for app-like experience',
      icon: 'Monitor',
      category: 'Web App',
      pricing: 'Free',
      features: ['Offline Support', 'Push Notifications', 'App Install', 'Native Feel'],
      status: 'available',
      connected: true
    }
  ];

  const environments = [
    { value: 'production', label: 'Production' },
    { value: 'staging', label: 'Staging' },
    { value: 'development', label: 'Development' }
  ];

  const handleTargetSelect = (targetId) => {
    setSelectedTargets(prev => ({
      ...prev,
      [targetId]: !prev?.[targetId]
    }));
  };

  const handleConnect = (targetId) => {
    // Simulate connection process
    console.log(`Connecting to ${targetId}...`);
  };

  const handleDeploy = (targetId, environment = 'production') => {
    if (onDeploy) {
      onDeploy(targetId, environment);
    }
  };

  const categorizedTargets = deploymentTargets?.reduce((acc, target) => {
    if (!acc?.[target?.category]) {
      acc[target?.category] = [];
    }
    acc?.[target?.category]?.push(target);
    return acc;
  }, {});

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Deployment Targets</h2>
          <p className="text-muted-foreground">
            Choose where to deploy your application with one-click publishing
          </p>
        </div>
        <Button
          variant="default"
          iconName="Plus"
          iconPosition="left"
          iconSize={16}
          onClick={() => console.log('Add custom target')}
        >
          Add Custom Target
        </Button>
      </div>
      {/* Deployment Categories */}
      {Object?.entries(categorizedTargets)?.map(([category, targets]) => (
        <div key={category} className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground border-b border-border pb-2">
            {category}
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {targets?.map((target) => (
              <div
                key={target?.id}
                className={`bg-card border rounded-lg p-6 transition-all duration-200 hover:shadow-elevation-2 ${
                  selectedTargets?.[target?.id] ? 'border-primary ring-2 ring-primary/20' : 'border-border'
                } ${target?.status === 'coming-soon' ? 'opacity-60' : ''}`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${
                      target?.connected ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'
                    }`}>
                      <Icon name={target?.icon} size={20} />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{target?.name}</h4>
                      <p className="text-sm text-muted-foreground">{target?.pricing}</p>
                    </div>
                  </div>
                  
                  {target?.status === 'coming-soon' && (
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-warning/10 text-warning">
                      Coming Soon
                    </span>
                  )}
                </div>

                <p className="text-sm text-muted-foreground mb-4">
                  {target?.description}
                </p>

                {/* Features */}
                <div className="mb-4">
                  <div className="flex flex-wrap gap-1">
                    {target?.features?.slice(0, 3)?.map((feature, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-2 py-1 rounded text-xs bg-muted text-muted-foreground"
                      >
                        {feature}
                      </span>
                    ))}
                    {target?.features?.length > 3 && (
                      <span className="inline-flex items-center px-2 py-1 rounded text-xs bg-muted text-muted-foreground">
                        +{target?.features?.length - 3} more
                      </span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="space-y-2">
                  {target?.connected ? (
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Select
                          options={environments}
                          value={deploymentConfig?.[target?.id]?.environment || 'production'}
                          onChange={(value) => setDeploymentConfig(prev => ({
                            ...prev,
                            [target?.id]: { ...prev?.[target?.id], environment: value }
                          }))}
                          className="flex-1 text-sm"
                        />
                      </div>
                      <Button
                        variant="default"
                        size="sm"
                        className="w-full"
                        onClick={() => handleDeploy(target?.id, deploymentConfig?.[target?.id]?.environment)}
                        disabled={target?.status === 'coming-soon'}
                      >
                        Deploy
                      </Button>
                    </div>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => handleConnect(target?.id)}
                      disabled={target?.status === 'coming-soon'}
                    >
                      Connect
                    </Button>
                  )}
                </div>

                {/* Connection Status */}
                <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                  <div className="flex items-center space-x-2 text-xs">
                    <div className={`w-2 h-2 rounded-full ${
                      target?.connected ? 'bg-success' : 'bg-muted-foreground'
                    }`} />
                    <span className="text-muted-foreground">
                      {target?.connected ? 'Connected' : 'Not Connected'}
                    </span>
                  </div>
                  {target?.connected && (
                    <Button
                      variant="ghost"
                      size="sm"
                      iconName="Settings"
                      iconSize={12}
                      className="h-6 w-6 p-0"
                      onClick={() => console.log(`Configure ${target?.id}`)}
                    />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
      {/* Batch Deployment */}
      {Object?.keys(selectedTargets)?.some(key => selectedTargets?.[key]) && (
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Batch Deployment</h3>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground">
                Deploy to {Object?.keys(selectedTargets)?.filter(key => selectedTargets?.[key])?.length} selected targets
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <Select
                options={environments}
                value="production"
                onChange={() => {}}
                placeholder="Select environment..."
              />
              <Button
                variant="default"
                iconName="Rocket"
                iconPosition="left"
                iconSize={16}
                onClick={() => {
                  Object?.keys(selectedTargets)?.forEach(targetId => {
                    if (selectedTargets?.[targetId]) {
                      handleDeploy(targetId, 'production');
                    }
                  });
                }}
              >
                Deploy All
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DeploymentTargets;