import React, { useState, useEffect } from 'react';
import { deploymentService } from '../../../services/deploymentService';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const DeploymentTargetsManager = ({ projectId, onTargetCreated }) => {
  const [targets, setTargets] = useState([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    provider: 'vercel',
    custom_domain: '',
    ssl_enabled: true,
    environment_vars: {}
  });

  useEffect(() => {
    if (projectId) {
      loadTargets();
    }
  }, [projectId]);

  const loadTargets = async () => {
    try {
      setLoading(true);
      const data = await deploymentService?.getDeploymentTargets(projectId);
      setTargets(data || []);
    } catch (err) {
      setError('Failed to load deployment targets: ' + err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTarget = async (e) => {
    e?.preventDefault();
    
    if (!formData?.name || !formData?.provider) {
      setError('Name and provider are required');
      return;
    }

    try {
      setError('');
      setLoading(true);
      
      const newTarget = await deploymentService?.createDeploymentTarget({
        ...formData,
        project_id: projectId,
        provider_config: getProviderConfig(formData?.provider)
      });
      
      setTargets(prev => [newTarget, ...prev]);
      setShowCreateForm(false);
      setFormData({
        name: '',
        provider: 'vercel',
        custom_domain: '',
        ssl_enabled: true,
        environment_vars: {}
      });
      
      onTargetCreated?.(newTarget);
    } catch (err) {
      setError('Failed to create target: ' + err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteTarget = async (targetId) => {
    if (!confirm('Are you sure you want to delete this deployment target?')) return;

    try {
      setError('');
      await deploymentService?.deleteDeploymentTarget(targetId);
      setTargets(prev => prev?.filter(t => t?.id !== targetId));
    } catch (err) {
      setError('Failed to delete target: ' + err?.message);
    }
  };

  const handleToggleTarget = async (targetId, isActive) => {
    try {
      setError('');
      const updated = await deploymentService?.updateDeploymentTarget(targetId, {
        is_active: !isActive
      });
      
      setTargets(prev => prev?.map(t => 
        t?.id === targetId ? { ...t, is_active: updated?.is_active } : t
      ));
    } catch (err) {
      setError('Failed to update target: ' + err?.message);
    }
  };

  const getProviderConfig = (provider) => {
    const configs = {
      vercel: { team_id: null, org_slug: null },
      netlify: { team_id: null, site_id: null },
      custom: { webhook_url: null, api_key: null }
    };
    return configs?.[provider] || {};
  };

  const getProviderIcon = (provider) => {
    const icons = {
      vercel: '▲',
      netlify: '◆',
      custom: '🔧'
    };
    return icons?.[provider] || '🔧';
  };

  const getProviderColor = (provider) => {
    const colors = {
      vercel: 'bg-black text-white',
      netlify: 'bg-teal-600 text-white',
      custom: 'bg-purple-600 text-white'
    };
    return colors?.[provider] || 'bg-gray-600 text-white';
  };

  if (loading && targets?.length === 0) {
    return (
      <div className="space-y-4">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Deployment Targets</h2>
          <p className="text-sm text-gray-500">Configure where your project gets deployed</p>
        </div>
        <Button
          onClick={() => setShowCreateForm(true)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          ➕ Add Target
        </Button>
      </div>
      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-600">{error}</p>
        </div>
      )}
      {/* Create Form Modal */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Add Deployment Target</h3>
              
              <form onSubmit={handleCreateTarget} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Target Name
                  </label>
                  <Input
                    type="text"
                    value={formData?.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e?.target?.value }))}
                    placeholder="e.g., Production, Staging"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Provider
                  </label>
                  <Select
                    value={formData?.provider}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, provider: value }))}
                    required
                  >
                    <option value="vercel">▲ Vercel</option>
                    <option value="netlify">◆ Netlify</option>
                    <option value="custom">🔧 Custom</option>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Custom Domain (optional)
                  </label>
                  <Input
                    type="text"
                    value={formData?.custom_domain}
                    onChange={(e) => setFormData(prev => ({ ...prev, custom_domain: e?.target?.value }))}
                    placeholder="e.g., myapp.com"
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="ssl_enabled"
                    checked={formData?.ssl_enabled}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, ssl_enabled: checked }))}
                  />
                  <label htmlFor="ssl_enabled" className="text-sm text-gray-700">
                    Enable SSL/HTTPS
                  </label>
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowCreateForm(false);
                      setError('');
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={loading}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {loading ? 'Creating...' : 'Create Target'}
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
      {/* Targets List */}
      <div className="space-y-3">
        {targets?.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 rounded-lg">
            <span className="text-6xl">🎯</span>
            <h3 className="text-lg font-medium text-gray-900 mt-4">No deployment targets</h3>
            <p className="text-gray-500 mt-2">Add a deployment target to get started</p>
          </div>
        ) : (
          targets?.map((target) => (
            <div key={target?.id} className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`px-3 py-1 rounded-lg text-sm font-medium ${getProviderColor(target?.provider)}`}>
                    {getProviderIcon(target?.provider)} {target?.provider}
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-gray-900">{target?.name}</h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      {target?.custom_domain && (
                        <span>🌐 {target?.custom_domain}</span>
                      )}
                      {target?.ssl_enabled && (
                        <span>🔒 SSL</span>
                      )}
                      <span className={target?.is_active ? 'text-green-600' : 'text-gray-400'}>
                        {target?.is_active ? '✅ Active' : '⏸️ Inactive'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleToggleTarget(target?.id, target?.is_active)}
                  >
                    {target?.is_active ? 'Disable' : 'Enable'}
                  </Button>
                  
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDeleteTarget(target?.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    🗑️ Delete
                  </Button>
                </div>
              </div>

              {target?.last_deployed_at && (
                <div className="mt-3 pt-3 border-t border-gray-200">
                  <p className="text-sm text-gray-500">
                    Last deployed: {new Date(target.last_deployed_at)?.toLocaleString()}
                  </p>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default DeploymentTargetsManager;