import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const DomainSetup = ({ selectedProject }) => {
  const [domains, setDomains] = useState([
    {
      id: 1,
      domain: 'myapp.com',
      environment: 'production',
      status: 'active',
      sslStatus: 'active',
      provider: 'cloudflare',
      dnsRecords: [
        { type: 'A', name: '@', value: '192.168.1.1', ttl: 300 },
        { type: 'CNAME', name: 'www', value: 'myapp.com', ttl: 300 }
      ],
      lastVerified: new Date(Date.now() - 86400000)
    },
    {
      id: 2,
      domain: 'staging.myapp.com',
      environment: 'staging',
      status: 'active',
      sslStatus: 'active',
      provider: 'netlify',
      dnsRecords: [
        { type: 'CNAME', name: 'staging', value: 'magical-site-123.netlify.app', ttl: 300 }
      ],
      lastVerified: new Date(Date.now() - 3600000)
    },
    {
      id: 3,
      domain: 'blog.myapp.com',
      environment: 'production',
      status: 'pending',
      sslStatus: 'pending',
      provider: 'vercel',
      dnsRecords: [
        { type: 'CNAME', name: 'blog', value: 'cname.vercel-dns.com', ttl: 300 }
      ],
      lastVerified: null
    }
  ]);

  const [showAddDomain, setShowAddDomain] = useState(false);
  const [newDomain, setNewDomain] = useState({
    domain: '',
    environment: 'production',
    provider: 'vercel'
  });
  const [dnsWizardOpen, setDnsWizardOpen] = useState(false);
  const [selectedDomain, setSelectedDomain] = useState(null);

  const statusColors = {
    active: 'text-success bg-success/10',
    pending: 'text-warning bg-warning/10',
    error: 'text-destructive bg-destructive/10',
    inactive: 'text-muted-foreground bg-muted'
  };

  const providers = [
    { value: 'vercel', label: 'Vercel' },
    { value: 'netlify', label: 'Netlify' },
    { value: 'cloudflare', label: 'Cloudflare' },
    { value: 'aws', label: 'Amazon Route 53' },
    { value: 'custom', label: 'Custom DNS' }
  ];

  const environments = [
    { value: 'production', label: 'Production' },
    { value: 'staging', label: 'Staging' },
    { value: 'development', label: 'Development' }
  ];

  const handleAddDomain = () => {
    if (newDomain?.domain) {
      const domain = {
        id: Date.now(),
        ...newDomain,
        status: 'pending',
        sslStatus: 'pending',
        dnsRecords: [],
        lastVerified: null
      };
      setDomains(prev => [...prev, domain]);
      setNewDomain({ domain: '', environment: 'production', provider: 'vercel' });
      setShowAddDomain(false);
    }
  };

  const handleVerifyDomain = (domainId) => {
    setDomains(prev => prev?.map(d => 
      d?.id === domainId 
        ? { ...d, status: 'active', sslStatus: 'active', lastVerified: new Date() }
        : d
    ));
  };

  const handleDeleteDomain = (domainId) => {
    setDomains(prev => prev?.filter(d => d?.id !== domainId));
  };

  const openDnsWizard = (domain) => {
    setSelectedDomain(domain);
    setDnsWizardOpen(true);
  };

  const DnsWizard = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-card border border-border rounded-lg p-6 w-full max-w-2xl max-h-96 overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">DNS Configuration</h3>
          <Button
            variant="ghost"
            size="sm"
            iconName="X"
            iconSize={16}
            onClick={() => setDnsWizardOpen(false)}
          />
        </div>

        <div className="space-y-4">
          <div className="bg-muted border border-border rounded-lg p-4">
            <h4 className="font-medium text-foreground mb-2">Step 1: Add DNS Records</h4>
            <p className="text-sm text-muted-foreground mb-3">
              Add these DNS records to your domain provider:
            </p>
            
            <div className="space-y-2">
              {selectedDomain?.dnsRecords?.map((record, index) => (
                <div key={index} className="grid grid-cols-4 gap-3 text-sm font-mono">
                  <div className="bg-card p-2 rounded border border-border">{record?.type}</div>
                  <div className="bg-card p-2 rounded border border-border">{record?.name}</div>
                  <div className="bg-card p-2 rounded border border-border">{record?.value}</div>
                  <div className="bg-card p-2 rounded border border-border">{record?.ttl}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-muted border border-border rounded-lg p-4">
            <h4 className="font-medium text-foreground mb-2">Step 2: SSL Certificate</h4>
            <p className="text-sm text-muted-foreground mb-3">
              SSL certificate will be automatically provisioned after DNS verification.
            </p>
            <div className="flex items-center space-x-2">
              <Icon name="Shield" size={16} className="text-success" />
              <span className="text-sm text-foreground">Let's Encrypt SSL (Free)</span>
            </div>
          </div>

          <div className="bg-muted border border-border rounded-lg p-4">
            <h4 className="font-medium text-foreground mb-2">Step 3: CDN Optimization</h4>
            <p className="text-sm text-muted-foreground mb-3">
              Content Delivery Network will be configured for optimal performance.
            </p>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Icon name="Zap" size={14} className="text-primary" />
                <span className="text-sm text-foreground">Global edge caching</span>
              </div>
              <div className="flex items-center space-x-2">
                <Icon name="Gauge" size={14} className="text-primary" />
                <span className="text-sm text-foreground">Performance analytics</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end space-x-3 mt-6">
          <Button variant="outline" onClick={() => setDnsWizardOpen(false)}>
            Close
          </Button>
          <Button variant="default" onClick={() => handleVerifyDomain(selectedDomain?.id)}>
            Verify Domain
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Custom Domains</h2>
          <p className="text-muted-foreground">
            Configure custom domains with SSL certificates and CDN optimization
          </p>
        </div>
        <Button
          variant="default"
          iconName="Plus"
          iconPosition="left"
          iconSize={16}
          onClick={() => setShowAddDomain(true)}
        >
          Add Domain
        </Button>
      </div>
      {/* Add Domain Form */}
      {showAddDomain && (
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Add Custom Domain</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Domain Name
              </label>
              <Input
                placeholder="example.com"
                value={newDomain?.domain}
                onChange={(e) => setNewDomain(prev => ({ ...prev, domain: e?.target?.value }))}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Environment
              </label>
              <Select
                options={environments}
                value={newDomain?.environment}
                onChange={(value) => setNewDomain(prev => ({ ...prev, environment: value }))}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                DNS Provider
              </label>
              <Select
                options={providers}
                value={newDomain?.provider}
                onChange={(value) => setNewDomain(prev => ({ ...prev, provider: value }))}
              />
            </div>
          </div>
          <div className="flex items-center justify-end space-x-3 mt-4">
            <Button variant="outline" onClick={() => setShowAddDomain(false)}>
              Cancel
            </Button>
            <Button variant="default" onClick={handleAddDomain}>
              Add Domain
            </Button>
          </div>
        </div>
      )}
      {/* Domains List */}
      <div className="space-y-4">
        {domains?.map((domain) => (
          <div key={domain?.id} className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-foreground">{domain?.domain}</h3>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${statusColors?.[domain?.status]}`}>
                    {domain?.status}
                  </span>
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-muted text-muted-foreground">
                    {domain?.environment}
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Provider:</span>
                    <span className="ml-2 text-foreground font-medium capitalize">{domain?.provider}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">SSL Status:</span>
                    <div className="flex items-center space-x-2 ml-2">
                      <Icon 
                        name={domain?.sslStatus === 'active' ? 'Shield' : 'ShieldAlert'} 
                        size={14} 
                        className={domain?.sslStatus === 'active' ? 'text-success' : 'text-warning'} 
                      />
                      <span className="text-foreground font-medium capitalize">{domain?.sslStatus}</span>
                    </div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Last Verified:</span>
                    <span className="ml-2 text-foreground">
                      {domain?.lastVerified ? domain?.lastVerified?.toLocaleDateString() : 'Never'}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  iconName="Settings"
                  iconSize={16}
                  onClick={() => openDnsWizard(domain)}
                >
                  DNS Setup
                </Button>
                {domain?.status === 'pending' && (
                  <Button
                    variant="default"
                    size="sm"
                    iconName="CheckCircle"
                    iconSize={16}
                    onClick={() => handleVerifyDomain(domain?.id)}
                  >
                    Verify
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  iconName="Trash2"
                  iconSize={16}
                  className="text-destructive hover:text-destructive"
                  onClick={() => handleDeleteDomain(domain?.id)}
                />
              </div>
            </div>

            {/* DNS Records */}
            {domain?.dnsRecords?.length > 0 && (
              <div className="mt-4 pt-4 border-t border-border">
                <h4 className="text-sm font-medium text-foreground mb-3">DNS Records</h4>
                <div className="grid grid-cols-4 gap-3 text-xs text-muted-foreground mb-2 font-medium">
                  <div>Type</div>
                  <div>Name</div>
                  <div>Value</div>
                  <div>TTL</div>
                </div>
                {domain?.dnsRecords?.map((record, index) => (
                  <div key={index} className="grid grid-cols-4 gap-3 text-sm font-mono mb-2">
                    <div className="text-foreground">{record?.type}</div>
                    <div className="text-foreground">{record?.name}</div>
                    <div className="text-foreground truncate">{record?.value}</div>
                    <div className="text-foreground">{record?.ttl}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Performance Metrics */}
            <div className="mt-4 pt-4 border-t border-border">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Response Time</span>
                  <span className="text-foreground font-medium">127ms</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Uptime</span>
                  <span className="text-success font-medium">99.9%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">CDN Cache</span>
                  <span className="text-foreground font-medium">94%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Bandwidth</span>
                  <span className="text-foreground font-medium">2.1 GB</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      {domains?.length === 0 && (
        <div className="text-center py-12">
          <Icon name="Globe" size={64} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No custom domains</h3>
          <p className="text-muted-foreground mb-6">
            Add a custom domain to make your app accessible at your own URL
          </p>
          <Button
            variant="default"
            iconName="Plus"
            iconPosition="left"
            iconSize={16}
            onClick={() => setShowAddDomain(true)}
          >
            Add Your First Domain
          </Button>
        </div>
      )}
      {dnsWizardOpen && <DnsWizard />}
    </div>
  );
};

export default DomainSetup;