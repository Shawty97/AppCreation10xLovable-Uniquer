import React, { useState, useEffect } from 'react';
import { deploymentService } from '../../../services/deploymentService';

const PerformanceMonitor = ({ deploymentId, projectId }) => {
  const [metrics, setMetrics] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedMetric, setSelectedMetric] = useState(null);

  useEffect(() => {
    if (deploymentId) {
      loadMetrics();
    }
  }, [deploymentId]);

  const loadMetrics = async () => {
    try {
      setLoading(true);
      setError('');
      const data = await deploymentService?.getDeploymentMetrics(deploymentId);
      setMetrics(data || []);
      if (data?.length > 0) {
        setSelectedMetric(data?.[0]);
      }
    } catch (err) {
      setError('Failed to load performance metrics: ' + err?.message);
    } finally {
      setLoading(false);
    }
  };

  const formatBytes = (bytes) => {
    if (!bytes) return 'N/A';
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i))?.toFixed(2)} ${sizes?.[i]}`;
  };

  const formatTime = (ms) => {
    if (!ms) return 'N/A';
    return ms >= 1000 ? `${(ms / 1000)?.toFixed(2)}s` : `${ms}ms`;
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600 bg-green-100';
    if (score >= 70) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getScoreGrade = (score) => {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-gray-200 rounded w-1/3"></div>
          <div className="h-40 bg-gray-200 rounded"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (!deploymentId) {
    return (
      <div className="p-6 text-center">
        <span className="text-6xl">📊</span>
        <h3 className="text-lg font-medium text-gray-900 mt-4">Select a Deployment</h3>
        <p className="text-gray-500 mt-2">Choose a deployment to view its performance metrics</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-gray-900">Performance Monitor</h2>
        <p className="text-sm text-gray-500">Analyze your deployment performance and optimization opportunities</p>
      </div>
      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-600">{error}</p>
        </div>
      )}
      {metrics?.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <span className="text-6xl">📊</span>
          <h3 className="text-lg font-medium text-gray-900 mt-4">No performance data</h3>
          <p className="text-gray-500 mt-2">Performance metrics will appear after deployment analysis</p>
        </div>
      ) : (
        <>
          {/* Metrics Selector */}
          {metrics?.length > 1 && (
            <div className="flex space-x-2">
              {metrics?.map((metric, index) => (
                <button
                  key={metric?.id}
                  onClick={() => setSelectedMetric(metric)}
                  className={`px-3 py-1 rounded text-sm font-medium ${
                    selectedMetric?.id === metric?.id
                      ? 'bg-blue-600 text-white' :'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  Report #{index + 1}
                  <span className="ml-2 text-xs">
                    {new Date(metric?.measured_at)?.toLocaleDateString()}
                  </span>
                </button>
              ))}
            </div>
          )}

          {selectedMetric && (
            <>
              {/* Lighthouse Scores */}
              {selectedMetric?.lighthouse_score && (
                <div className="bg-white rounded-lg shadow-sm border p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Lighthouse Scores</h3>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {Object.entries(selectedMetric?.lighthouse_score)?.map(([key, score]) => (
                      <div key={key} className="text-center">
                        <div className="relative inline-block">
                          <div className="w-20 h-20 rounded-full border-4 border-gray-200 flex items-center justify-center">
                            <div className={`w-16 h-16 rounded-full flex items-center justify-center ${getScoreColor(score)}`}>
                              <span className="text-2xl font-bold">{getScoreGrade(score)}</span>
                            </div>
                          </div>
                          <div className="absolute -bottom-1 -right-1 bg-white rounded-full px-2 py-1 text-xs font-medium border">
                            {score}
                          </div>
                        </div>
                        <p className="text-sm font-medium text-gray-900 mt-2 capitalize">
                          {key?.replace('_', ' ')}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Performance Metrics */}
              <div className="bg-white rounded-lg shadow-sm border p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Core Web Vitals</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">
                      {formatTime(selectedMetric?.load_time_ms)}
                    </div>
                    <p className="text-sm font-medium text-gray-900 mt-1">Load Time</p>
                    <p className="text-xs text-gray-500">Time to fully load</p>
                  </div>

                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">
                      {formatTime(selectedMetric?.first_paint_ms)}
                    </div>
                    <p className="text-sm font-medium text-gray-900 mt-1">First Paint</p>
                    <p className="text-xs text-gray-500">Time to first visual</p>
                  </div>

                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">
                      {formatTime(selectedMetric?.time_to_interactive_ms)}
                    </div>
                    <p className="text-sm font-medium text-gray-900 mt-1">Interactive</p>
                    <p className="text-xs text-gray-500">Time to interactive</p>
                  </div>
                </div>

                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">
                      {selectedMetric?.bundle_size_mb ? `${selectedMetric?.bundle_size_mb} MB` : 'N/A'}
                    </div>
                    <p className="text-sm font-medium text-gray-900 mt-1">Bundle Size</p>
                    <p className="text-xs text-gray-500">Total JavaScript size</p>
                  </div>

                  <div className="text-center p-4 bg-red-50 rounded-lg">
                    <div className="text-2xl font-bold text-red-600">
                      {selectedMetric?.cumulative_layout_shift ? selectedMetric?.cumulative_layout_shift?.toFixed(3) : 'N/A'}
                    </div>
                    <p className="text-sm font-medium text-gray-900 mt-1">Layout Shift</p>
                    <p className="text-xs text-gray-500">Cumulative Layout Shift</p>
                  </div>
                </div>
              </div>

              {/* Additional Metrics */}
              {selectedMetric?.metrics_data && (
                <div className="bg-white rounded-lg shadow-sm border p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Additional Metrics</h3>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {Object.entries(selectedMetric?.metrics_data)?.map(([key, value]) => (
                      <div key={key} className="p-3 bg-gray-50 rounded-lg">
                        <p className="text-lg font-bold text-gray-900">{value}</p>
                        <p className="text-sm text-gray-600 capitalize">{key?.replace('_', ' ')}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recommendations */}
              <div className="bg-white rounded-lg shadow-sm border p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">🎯 Optimization Recommendations</h3>
                
                <div className="space-y-3">
                  {selectedMetric?.bundle_size_mb > 3 && (
                    <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-sm font-medium text-yellow-800">
                        📦 Large Bundle Size Detected
                      </p>
                      <p className="text-xs text-yellow-700 mt-1">
                        Consider code splitting or tree shaking to reduce bundle size
                      </p>
                    </div>
                  )}

                  {selectedMetric?.load_time_ms > 3000 && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-sm font-medium text-red-800">
                        ⚡ Slow Load Time Detected
                      </p>
                      <p className="text-xs text-red-700 mt-1">
                        Optimize images, enable compression, and use CDN for faster loading
                      </p>
                    </div>
                  )}

                  {selectedMetric?.lighthouse_score?.performance < 70 && (
                    <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                      <p className="text-sm font-medium text-orange-800">
                        🎭 Performance Score Below Threshold
                      </p>
                      <p className="text-xs text-orange-700 mt-1">
                        Review Core Web Vitals and consider implementing lazy loading
                      </p>
                    </div>
                  )}

                  {(!selectedMetric?.bundle_size_mb || selectedMetric?.bundle_size_mb <= 3) &&
                   (!selectedMetric?.load_time_ms || selectedMetric?.load_time_ms <= 3000) &&
                   selectedMetric?.lighthouse_score?.performance >= 70 && (
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                      <p className="text-sm font-medium text-green-800">
                        ✅ Great Performance!
                      </p>
                      <p className="text-xs text-green-700 mt-1">
                        Your deployment meets performance best practices
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Measurement Info */}
              <div className="text-center text-sm text-gray-500">
                <p>
                  Measured at: {new Date(selectedMetric?.measured_at)?.toLocaleString()}
                </p>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
};

export default PerformanceMonitor;