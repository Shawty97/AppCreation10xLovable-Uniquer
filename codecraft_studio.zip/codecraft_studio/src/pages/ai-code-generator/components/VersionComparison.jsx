import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const VersionComparison = ({ versions, onClose, onSelectVersion }) => {
  const [selectedVersions, setSelectedVersions] = useState([
    versions?.[versions?.length - 1]?.id,
    versions?.[versions?.length - 2]?.id
  ]?.filter(Boolean));

  const handleVersionSelect = (versionId) => {
    setSelectedVersions(prev => {
      if (prev?.includes(versionId)) {
        return prev?.filter(id => id !== versionId);
      }
      if (prev?.length >= 2) {
        return [prev?.[1], versionId];
      }
      return [...prev, versionId];
    });
  };

  const handleUseVersion = (version) => {
    onSelectVersion?.(version);
    onClose?.();
  };

  const formatTimestamp = (timestamp) => {
    return timestamp?.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getVersionDifferences = (v1, v2) => {
    if (!v1 || !v2) return [];
    
    const differences = [];
    
    if (v1?.name !== v2?.name) {
      differences?.push({
        type: 'name',
        field: 'Application Name',
        old: v2?.name,
        new: v1?.name
      });
    }
    
    if (v1?.codeStats?.files !== v2?.codeStats?.files) {
      differences?.push({
        type: 'files',
        field: 'File Count',
        old: v2?.codeStats?.files,
        new: v1?.codeStats?.files,
        change: v1?.codeStats?.files - v2?.codeStats?.files
      });
    }
    
    if (v1?.codeStats?.lines !== v2?.codeStats?.lines) {
      differences?.push({
        type: 'lines',
        field: 'Lines of Code',
        old: v2?.codeStats?.lines,
        new: v1?.codeStats?.lines,
        change: v1?.codeStats?.lines - v2?.codeStats?.lines
      });
    }
    
    if (v1?.codeStats?.components !== v2?.codeStats?.components) {
      differences?.push({
        type: 'components',
        field: 'Components',
        old: v2?.codeStats?.components,
        new: v1?.codeStats?.components,
        change: v1?.codeStats?.components - v2?.codeStats?.components
      });
    }
    
    return differences;
  };

  const selectedVersionObjects = selectedVersions?.map(id => 
    versions?.find(v => v?.id === id)
  )?.filter(Boolean);

  const differences = selectedVersionObjects?.length === 2 ? 
    getVersionDifferences(selectedVersionObjects?.[0], selectedVersionObjects?.[1]) : [];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-border rounded-lg shadow-elevation-2 w-full max-w-6xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-foreground">Version Comparison</h2>
              <p className="text-muted-foreground">
                Compare different versions of your generated application
              </p>
            </div>
            <Button
              variant="ghost"
              iconName="X"
              iconSize={20}
              onClick={onClose}
              className="h-10 w-10"
            />
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 divide-y lg:divide-y-0 lg:divide-x divide-border">
            {/* Version List */}
            <div className="p-6">
              <h3 className="font-medium text-foreground mb-4">
                Select Versions to Compare ({selectedVersions?.length}/2)
              </h3>
              <div className="space-y-3">
                {versions?.map((version, index) => (
                  <div
                    key={version?.id}
                    className={`border border-border rounded-lg p-4 cursor-pointer transition-all ${
                      selectedVersions?.includes(version?.id)
                        ? 'border-primary bg-primary/5' :'hover:border-primary/50'
                    }`}
                    onClick={() => handleVersionSelect(version?.id)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium text-foreground">
                          Version {versions?.length - index}
                        </span>
                        {index === 0 && (
                          <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                            Latest
                          </span>
                        )}
                      </div>
                      <div className="flex items-center space-x-1">
                        {selectedVersions?.includes(version?.id) && (
                          <Icon name="Check" size={16} className="text-primary" />
                        )}
                      </div>
                    </div>
                    
                    <p className="text-xs text-muted-foreground mb-2">
                      {formatTimestamp(version?.generatedAt)}
                    </p>
                    
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="bg-muted rounded p-2">
                        <div className="text-sm font-medium text-foreground">
                          {version?.codeStats?.files}
                        </div>
                        <div className="text-xs text-muted-foreground">Files</div>
                      </div>
                      <div className="bg-muted rounded p-2">
                        <div className="text-sm font-medium text-foreground">
                          {version?.codeStats?.lines?.toLocaleString()}
                        </div>
                        <div className="text-xs text-muted-foreground">Lines</div>
                      </div>
                      <div className="bg-muted rounded p-2">
                        <div className="text-sm font-medium text-foreground">
                          {version?.codeStats?.components}
                        </div>
                        <div className="text-xs text-muted-foreground">Comps</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Comparison View */}
            <div className="lg:col-span-2 p-6">
              {selectedVersionObjects?.length === 2 ? (
                <div className="space-y-6">
                  {/* Version Headers */}
                  <div className="grid grid-cols-2 gap-6">
                    {selectedVersionObjects?.map((version, index) => (
                      <div key={version?.id} className="text-center">
                        <h3 className="text-lg font-semibold text-foreground mb-1">
                          Version {versions?.indexOf(version) + 1}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {formatTimestamp(version?.generatedAt)}
                        </p>
                        <Button
                          variant="outline"
                          size="sm"
                          iconName="Check"
                          iconPosition="left"
                          iconSize={14}
                          onClick={() => handleUseVersion(version)}
                          className="mt-2"
                        >
                          Use This Version
                        </Button>
                      </div>
                    ))}
                  </div>

                  {/* Differences */}
                  {differences?.length > 0 ? (
                    <div>
                      <h4 className="font-medium text-foreground mb-3">Changes</h4>
                      <div className="space-y-3">
                        {differences?.map((diff, index) => (
                          <div key={index} className="bg-secondary rounded-lg p-3">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm font-medium text-foreground">
                                {diff?.field}
                              </span>
                              {diff?.change && (
                                <span className={`text-xs px-2 py-1 rounded-full ${
                                  diff?.change > 0 
                                    ? 'bg-green-100 text-green-800' :'bg-red-100 text-red-800'
                                }`}>
                                  {diff?.change > 0 ? '+' : ''}{diff?.change}
                                </span>
                              )}
                            </div>
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <span className="text-muted-foreground">Before:</span>
                                <span className="ml-2 text-foreground">{diff?.old}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">After:</span>
                                <span className="ml-2 text-foreground">{diff?.new}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Icon name="GitCompare" size={48} className="text-muted-foreground mx-auto mb-3" />
                      <h4 className="text-lg font-medium text-foreground mb-2">
                        No Differences Found
                      </h4>
                      <p className="text-muted-foreground">
                        The selected versions appear to be identical
                      </p>
                    </div>
                  )}

                  {/* Side by Side Preview */}
                  <div>
                    <h4 className="font-medium text-foreground mb-3">Preview Comparison</h4>
                    <div className="grid grid-cols-2 gap-4">
                      {selectedVersionObjects?.map((version) => (
                        <div key={version?.id} className="bg-muted rounded-lg aspect-video flex items-center justify-center">
                          <div className="text-center">
                            <Icon name="Eye" size={32} className="text-muted-foreground mx-auto mb-2" />
                            <p className="text-sm text-muted-foreground">
                              {version?.name}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <Icon name="GitCompare" size={64} className="text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">
                    Select Two Versions to Compare
                  </h3>
                  <p className="text-muted-foreground">
                    Choose exactly two versions from the left panel to see their differences
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="p-6 border-t border-border">
          <div className="flex justify-end">
            <Button
              variant="outline"
              onClick={onClose}
            >
              Close Comparison
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VersionComparison;