import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const CodeExportModal = ({ app, framework, onClose }) => {
  const [exportFormat, setExportFormat] = useState('zip');
  const [includeAssets, setIncludeAssets] = useState(true);
  const [includeDocumentation, setIncludeDocumentation] = useState(true);
  const [includeDependencies, setIncludeDependencies] = useState(true);
  const [deploymentPlatform, setDeploymentPlatform] = useState('');
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);

  const exportFormats = [
    { value: 'zip', label: 'ZIP Archive', icon: 'Archive' },
    { value: 'github', label: 'GitHub Repository', icon: 'Github' },
    { value: 'codesandbox', label: 'CodeSandbox', icon: 'Code' }
  ];

  const deploymentPlatforms = [
    { value: '', label: 'Manual Deployment' },
    { value: 'vercel', label: 'Vercel', icon: 'Zap' },
    { value: 'netlify', label: 'Netlify', icon: 'Globe' },
    { value: 'github-pages', label: 'GitHub Pages', icon: 'Github' },
    { value: 'firebase', label: 'Firebase Hosting', icon: 'Flame' }
  ];

  const handleExport = async () => {
    setIsExporting(true);
    setExportProgress(0);

    // Simulate export progress
    const progressInterval = setInterval(() => {
      setExportProgress(prev => {
        if (prev >= 95) {
          clearInterval(progressInterval);
          return 95;
        }
        return prev + Math.random() * 20;
      });
    }, 300);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      setExportProgress(100);
      
      // Simulate file download
      setTimeout(() => {
        const mockExport = {
          framework,
          format: exportFormat,
          filename: `${app?.name?.replace(/\s+/g, '-')?.toLowerCase()}-${Date.now()}`,
          size: Math.floor(Math.random() * 10000) + 5000 // KB
        };

        if (exportFormat === 'zip') {
          // Create mock download link
          const link = document.createElement('a');
          link.href = '#';
          link.download = `${mockExport?.filename}.zip`;
          link?.click();
        } else if (exportFormat === 'github') {
          // Open GitHub repository creation
          window.open('https://github.com/new', '_blank');
        } else if (exportFormat === 'codesandbox') {
          // Open CodeSandbox
          window.open('https://codesandbox.io/s/new', '_blank');
        }

        setIsExporting(false);
        setExportProgress(0);
        onClose?.();
      }, 1000);

    } catch (error) {
      console.error('Export error:', error);
      setIsExporting(false);
      setExportProgress(0);
    }

    clearInterval(progressInterval);
  };

  const getFileStructure = () => {
    const baseFiles = [
      'package.json',
      'index.html',
      'vite.config.js',
      'tailwind.config.js',
      'src/App.jsx',
      'src/main.jsx',
      'src/index.css'
    ];

    const componentFiles = app?.components?.map(comp => 
      `src/components/${comp?.name}.jsx`
    ) || [];

    const pageFiles = app?.pages?.map(page => 
      `src/pages/${page?.name}.jsx`
    ) || [];

    const assetFiles = includeAssets ? [
      'public/favicon.ico',
      'public/logo.svg',
      'public/manifest.json'
    ] : [];

    const docFiles = includeDocumentation ? [
      'README.md',
      'CHANGELOG.md',
      'docs/deployment.md'
    ] : [];

    return [...baseFiles, ...componentFiles, ...pageFiles, ...assetFiles, ...docFiles];
  };

  const estimatedSize = () => {
    const fileCount = getFileStructure()?.length;
    const baseSize = fileCount * 50; // Average 50KB per file
    const assetSize = includeAssets ? 2000 : 0; // 2MB for assets
    const dependencySize = includeDependencies ? 15000 : 0; // 15MB for node_modules
    return Math.floor((baseSize + assetSize + dependencySize) / 1024); // Convert to MB
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-border rounded-lg shadow-elevation-2 w-full max-w-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-foreground">Export Application</h2>
              <p className="text-muted-foreground">
                Download your generated {framework?.toUpperCase()} application
              </p>
            </div>
            <Button
              variant="ghost"
              iconName="X"
              iconSize={20}
              onClick={onClose}
              className="h-10 w-10"
            />
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Export Progress */}
          {isExporting && (
            <div className="bg-muted rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">
                  Preparing your export...
                </span>
                <span className="text-sm text-muted-foreground">
                  {Math.round(exportProgress)}%
                </span>
              </div>
              <div className="w-full bg-background rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${exportProgress}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {exportProgress < 30 && "Bundling components..."}
                {exportProgress >= 30 && exportProgress < 60 && "Generating files..."}
                {exportProgress >= 60 && exportProgress < 90 && "Preparing download..."}
                {exportProgress >= 90 && "Almost ready..."}
              </p>
            </div>
          )}

          {/* Export Options */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Export Format
              </label>
              <Select
                options={exportFormats}
                value={exportFormat}
                onChange={setExportFormat}
                placeholder="Select export format..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Deployment Platform (Optional)
              </label>
              <Select
                options={deploymentPlatforms}
                value={deploymentPlatform}
                onChange={setDeploymentPlatform}
                placeholder="Choose deployment platform..."
              />
              {deploymentPlatform && (
                <p className="text-xs text-muted-foreground mt-1">
                  We'll include platform-specific configuration files
                </p>
              )}
            </div>
          </div>

          {/* Include Options */}
          <div className="space-y-3">
            <h3 className="font-medium text-foreground">Include in Export</h3>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-assets"
                  checked={includeAssets}
                  onCheckedChange={setIncludeAssets}
                />
                <label htmlFor="include-assets" className="text-sm text-foreground cursor-pointer">
                  Static assets and images
                </label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-docs"
                  checked={includeDocumentation}
                  onCheckedChange={setIncludeDocumentation}
                />
                <label htmlFor="include-docs" className="text-sm text-foreground cursor-pointer">
                  Documentation and README
                </label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-deps"
                  checked={includeDependencies}
                  onCheckedChange={setIncludeDependencies}
                />
                <label htmlFor="include-deps" className="text-sm text-foreground cursor-pointer">
                  Dependencies (node_modules)
                </label>
              </div>
            </div>
          </div>

          {/* File Structure Preview */}
          <div className="space-y-3">
            <h3 className="font-medium text-foreground">File Structure</h3>
            <div className="bg-muted rounded-lg p-4 max-h-48 overflow-y-auto">
              <div className="text-sm font-mono text-muted-foreground space-y-1">
                {getFileStructure()?.map((file, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Icon 
                      name={file?.includes('/') ? 'Folder' : 'File'} 
                      size={12} 
                    />
                    <span>{file}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Export Summary */}
          <div className="bg-secondary rounded-lg p-4">
            <h3 className="font-medium text-foreground mb-3">Export Summary</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Framework:</span>
                <span className="ml-2 font-medium text-foreground">
                  {framework?.toUpperCase()}
                </span>
              </div>
              <div>
                <span className="text-muted-foreground">Files:</span>
                <span className="ml-2 font-medium text-foreground">
                  {getFileStructure()?.length}
                </span>
              </div>
              <div>
                <span className="text-muted-foreground">Est. Size:</span>
                <span className="ml-2 font-medium text-foreground">
                  ~{estimatedSize()} MB
                </span>
              </div>
              <div>
                <span className="text-muted-foreground">Format:</span>
                <span className="ml-2 font-medium text-foreground">
                  {exportFormats?.find(f => f?.value === exportFormat)?.label}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="p-6 border-t border-border">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={onClose}
              disabled={isExporting}
            >
              Cancel
            </Button>
            <Button
              variant="default"
              iconName={isExporting ? "Loader2" : "Download"}
              iconPosition="left"
              iconSize={16}
              onClick={handleExport}
              disabled={isExporting}
              className={isExporting ? 'animate-spin' : ''}
            >
              {isExporting ? 'Exporting...' : 'Export Application'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CodeExportModal;