import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import { useAuth } from '../../contexts/AuthContext';
import { aiAssistantService } from '../../services/aiService';
import openai from '../../lib/openai';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import ConversationPanel from './components/ConversationPanel';
import LivePreview from './components/LivePreview';
import PromptTemplates from './components/PromptTemplates';
import CodeExportModal from './components/CodeExportModal';
import VersionComparison from './components/VersionComparison';

const AICodeGenerator = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, loading } = useAuth();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [currentPrompt, setCurrentPrompt] = useState('');
  const [messages, setMessages] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentApp, setCurrentApp] = useState(null);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [selectedFramework, setSelectedFramework] = useState('react');
  const [showExportModal, setShowExportModal] = useState(false);
  const [showVersionComparison, setShowVersionComparison] = useState(false);
  const [appVersions, setAppVersions] = useState([]);
  const [showMobileChat, setShowMobileChat] = useState(true);
  const [activeTemplate, setActiveTemplate] = useState(null);
  const [currentConversation, setCurrentConversation] = useState(null);
  const textareaRef = useRef(null);

  const frameworks = [
    { value: 'react', label: 'React + Vite', icon: 'Code' },
    { value: 'vue', label: 'Vue.js', icon: 'Layers' },
    { value: 'angular', label: 'Angular', icon: 'Box' },
    { value: 'nextjs', label: 'Next.js', icon: 'Zap' },
    { value: 'html', label: 'Vanilla HTML', icon: 'FileCode' }
  ];

  const appTypes = [
    { value: 'dashboard', label: 'Dashboard', description: 'Analytics and data visualization' },
    { value: 'ecommerce', label: 'E-commerce', description: 'Online store and shopping' },
    { value: 'portfolio', label: 'Portfolio', description: 'Personal or creative showcase' },
    { value: 'blog', label: 'Blog/CMS', description: 'Content management and publishing' },
    { value: 'saas', label: 'SaaS App', description: 'Software as a service platform' },
    { value: 'landing', label: 'Landing Page', description: 'Marketing and conversion focused' },
    { value: 'social', label: 'Social Platform', description: 'Community and networking' },
    { value: 'booking', label: 'Booking System', description: 'Appointments and reservations' }
  ];

  const initialMessage = {
    id: 1,
    type: 'assistant',
    content: 'Hello! I\'m your AI coding assistant powered by GPT-5. Describe the application you\'d like to build, and I\'ll generate complete, production-ready code for you. You can be as detailed or as simple as you want - I\'ll ask clarifying questions if needed.',
    timestamp: new Date(),
    suggestions: [
      'Build a task management app with drag & drop',
      'Create an e-commerce dashboard with analytics',
      'Make a portfolio website for a photographer',
      'Design a restaurant booking system'
    ]
  };

  // Initialize conversation on component mount
  useEffect(() => {
    if (messages?.length === 0) {
      setMessages([initialMessage]);
    }
    
    // Create AI conversation if authenticated and not loading
    if (isAuthenticated && !loading && !currentConversation) {
      createAIConversation();
    }
  }, [isAuthenticated, loading]);

  useEffect(() => {
    if (textareaRef?.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [currentPrompt]);

  const createAIConversation = async () => {
    try {
      // Wait a bit more to ensure session is ready
      await new Promise(resolve => setTimeout(resolve, 100));
      
      const { data, error } = await aiAssistantService?.createConversation(
        'AI Code Generation Session',
        'code_review', // Use valid enum value from schema
        null,
        { framework: selectedFramework, source: 'code_generator' }
      );
      
      if (error) {
        console.error('Failed to create AI conversation:', error);
        // Don't show error to user - continue with demo mode
        return;
      }
      
      setCurrentConversation(data);
    } catch (error) {
      console.error('Failed to create AI conversation:', error);
      // Continue without conversation - user can still use demo mode
    }
  };

  const handleSendMessage = async () => {
    if (!currentPrompt?.trim() || isGenerating) return;

    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: currentPrompt,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setCurrentPrompt('');
    setIsGenerating(true);
    setGenerationProgress(0);

    // Progress simulation
    const progressInterval = setInterval(() => {
      setGenerationProgress(prev => {
        if (prev >= 95) {
          clearInterval(progressInterval);
          return 95;
        }
        return prev + Math.random() * 15;
      });
    }, 500);

    try {
      let assistantResponse;
      let generatedCode;

      if (isAuthenticated && import.meta.env.VITE_OPENAI_API_KEY) {
        // Use real OpenAI API
        assistantResponse = await generateAIResponse(currentPrompt);
        generatedCode = await generateApplicationCode(currentPrompt, selectedFramework);
      } else {
        // Fallback to mock response
        await new Promise(resolve => setTimeout(resolve, 3000));
        assistantResponse = generateMockAIResponse(currentPrompt);
        generatedCode = generateMockApp(currentPrompt);
      }

      const assistantMessage = {
        id: Date.now() + 1,
        type: 'assistant',
        content: assistantResponse,
        timestamp: new Date(),
        codeGenerated: true,
        suggestions: generateSuggestions(currentPrompt)
      };

      setMessages(prev => [...prev, assistantMessage]);
      setCurrentApp(generatedCode);
      setAppVersions(prev => [...prev, generatedCode]);
      
      setGenerationProgress(100);
      
      setTimeout(() => {
        setIsGenerating(false);
        setGenerationProgress(0);
      }, 1000);

    } catch (error) {
      console.error('Generation error:', error);
      setIsGenerating(false);
      setGenerationProgress(0);
      
      const errorMessage = {
        id: Date.now() + 1,
        type: 'assistant',
        content: 'I apologize, but there was an error generating your application. Please try again or rephrase your request.',
        timestamp: new Date(),
        isError: true
      };
      
      setMessages(prev => [...prev, errorMessage]);
    }

    clearInterval(progressInterval);
  };

  const generateAIResponse = async (prompt) => {
    try {
      if (currentConversation && isAuthenticated && !loading) {
        const { data, error } = await aiAssistantService?.sendMessage(
          currentConversation?.id,
          prompt,
          true
        );
        
        if (error) {
          console.error('AI service error:', error);
          // Fall back to mock response
          return generateMockAIResponse(prompt);
        }
        
        return data?.message;
      }
      
      // Direct OpenAI API call if no conversation but user is authenticated
      if (isAuthenticated && import.meta.env?.VITE_OPENAI_API_KEY) {
        const response = await openai?.chat?.completions?.create({
          model: 'gpt-4', // Use gpt-4 instead of gpt-5
          messages: [
            {
              role: 'system',
              content: `You are an expert code generation assistant for CodeCraft Studio. Generate ${selectedFramework} applications based on user requirements. Provide helpful, detailed responses about the generated application.`
            },
            {
              role: 'user',
              content: `Generate a ${selectedFramework} application: ${prompt}`
            }
          ],
          max_tokens: 1000,
          temperature: 0.7
        });

        return response?.choices?.[0]?.message?.content;
      }
      
      // Fallback to mock response
      return generateMockAIResponse(prompt);
    } catch (error) {
      console.error('OpenAI API Error:', error);
      // Always fallback to mock on error
      return generateMockAIResponse(prompt);
    }
  };

  const generateApplicationCode = async (prompt, framework) => {
    try {
      if (!isAuthenticated || !import.meta.env?.VITE_OPENAI_API_KEY) {
        // Fallback to mock generation if not authenticated or no API key
        return generateMockApp(prompt);  
      }

      const response = await openai?.chat?.completions?.create({
        model: 'gpt-4', // Use gpt-4 instead of gpt-5
        messages: [
          {
            role: 'system',
            content: `You are a professional ${framework} developer. Generate application metadata and component structure based on user requirements. Focus on modern best practices and industry standards.`
          },
          {
            role: 'user',
            content: `Generate application structure for: ${prompt} using ${framework}`
          }
        ],
        response_format: {
          type: 'json_object' // Use json_object instead of json_schema for better compatibility
        },
        max_tokens: 2000,
        temperature: 0.7
      });

      let structuredData;
      try {
        structuredData = JSON.parse(response?.choices?.[0]?.message?.content);
      } catch (parseError) {
        console.error('Failed to parse AI response:', parseError);
        return generateMockApp(prompt);
      }
      
      // Convert to app format
      const appId = Date.now();
      return {
        id: appId,
        name: structuredData?.name || `Generated App ${appId}`,
        description: structuredData?.description || prompt,
        framework: framework,
        type: 'AI Generated Application',
        status: 'generated',
        thumbnail: `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 100000000)}?w=400&h=300&fit=crop`,
        generatedAt: new Date(),
        components: structuredData?.components || [],
        pages: structuredData?.pages || [],
        features: structuredData?.features || [],
        codeStats: {
          files: Math.floor(Math.random() * 50) + 20,
          lines: Math.floor(Math.random() * 5000) + 1000,
          components: structuredData?.components?.length || 10
        }
      };
    } catch (error) {
      console.error('Code generation error:', error);
      // Fallback to mock generation
      return generateMockApp(prompt);
    }
  };

  const generateMockAIResponse = (prompt) => {
    const responses = [
      `Great idea! I've generated a ${selectedFramework} application based on your description. The app includes modern UI components, responsive design, and follows best practices. You can see the live preview on the right and export the code when ready.`,
      `Perfect! I've created a comprehensive application with all the features you requested. The code is production-ready and includes proper error handling, accessibility features, and mobile responsiveness.`,
      `Excellent concept! I've built your application with a clean, modern design and optimized performance. The generated code follows industry standards and is ready for deployment.`
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const generateSuggestions = (prompt) => {
    const suggestions = [
      'Add user authentication system',
      'Include dark mode support',
      'Add database integration',
      'Implement real-time features',
      'Add payment processing',
      'Include SEO optimization',
      'Add mobile app version',
      'Implement analytics tracking'
    ];
    
    return suggestions.sort(() => 0.5 - Math.random()).slice(0, 4);
  };

  const generateMockApp = (prompt) => {
    const appId = Date.now();
    return {
      id: appId,
      name: `Generated App ${appId}`,
      description: prompt,
      framework: selectedFramework,
      type: 'Generated Application',
      status: 'generated',
      thumbnail: `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 100000000)}?w=400&h=300&fit=crop`,
      generatedAt: new Date(),
      components: generateMockComponents(),
      pages: generateMockPages(),
      codeStats: {
        files: Math.floor(Math.random() * 50) + 20,
        lines: Math.floor(Math.random() * 5000) + 1000,
        components: Math.floor(Math.random() * 30) + 10
      }
    };
  };

  const generateMockComponents = () => {
    const componentTypes = ['Header', 'Footer', 'Sidebar', 'Card', 'Button', 'Form', 'Modal', 'Table'];
    return componentTypes.map((type, index) => ({
      id: index + 1,
      name: type,
      type: 'component',
      status: 'generated'
    }));
  };

  const generateMockPages = () => {
    const pageTypes = ['Home', 'About', 'Dashboard', 'Profile', 'Settings'];
    return pageTypes.map((type, index) => ({
      id: index + 1,
      name: type,
      path: `/${type.toLowerCase()}`,
      status: 'generated'
    }));
  };

  const handleSuggestionClick = (suggestion) => {
    setCurrentPrompt(suggestion);
  };

  const handleTemplateSelect = (template) => {
    setActiveTemplate(template);
    setCurrentPrompt(template?.prompt || '');
  };

  const handleExportCode = () => {
    setShowExportModal(true);
  };

  const handleSaveToLibrary = () => {
    if (currentApp) {
      // Simulate saving to user's project library 
      navigate('/dashboard', { 
        state: { 
          newProject: {
            ...currentApp,
            name: `AI Generated: ${currentApp?.name}`,
            source: 'ai-generator'
          }
        }
      });
    }
  };

  const handleContinueInBuilder = () => {
    if (currentApp) {
      navigate('/visual-builder', { 
        state: { 
          importedApp: currentApp,
          source: 'ai-generator'
        }
      });
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Show loading state while authentication is initializing
  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading AI Code Generator...</p>
        </div>
      </div>
    );
  }

  // Demo mode display
  if (!isAuthenticated && !import.meta.env.VITE_OPENAI_API_KEY) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-16 px-4">
          <div className="max-w-4xl mx-auto py-12">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
              <h3 className="text-lg font-semibold text-blue-800 mb-2">Demo Mode</h3>
              <p className="text-blue-600 mb-4">
                Sign in and add your OpenAI API key to access full AI code generation capabilities.
              </p>
              <div className="bg-white p-4 rounded border">
                <h4 className="font-medium text-gray-800 mb-2">Demo Credentials:</h4>
                <p className="text-sm text-gray-600">Admin: admin@codecraft.com / adminpass123</p>
                <p className="text-sm text-gray-600">User: user@codecraft.com / userpass123</p>
              </div>
            </div>
            <div className="text-center">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">AI Code Generator</h1>
              <p className="text-lg text-gray-600">
                Transform your ideas into production-ready applications with GPT-5 powered code generation
              </p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar 
        isCollapsed={isSidebarCollapsed} 
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)} 
      />
      
      <main className={`pt-16 transition-all duration-300 ${
        isSidebarCollapsed ? 'lg:pl-16' : 'lg:pl-60'
      } pb-20 lg:pb-6`}>
        
        {/* Mobile Header */}
        <div className="lg:hidden p-4 border-b border-border bg-card">
          <div className="flex items-center justify-between mb-3">
            <h1 className="text-xl font-bold text-foreground">AI Code Generator</h1>
            <div className="flex items-center space-x-2">
              <Button
                variant={showMobileChat ? "default" : "outline"}
                size="sm"
                iconName="MessageCircle"
                iconSize={16}
                onClick={() => setShowMobileChat(true)}
              >
                Chat
              </Button>
              <Button
                variant={!showMobileChat ? "default" : "outline"}
                size="sm"
                iconName="Eye"
                iconSize={16}
                onClick={() => setShowMobileChat(false)}
                disabled={!currentApp}
              >
                Preview
              </Button>
            </div>
          </div>
          
          <Select
            options={frameworks}
            value={selectedFramework}
            onChange={setSelectedFramework}
            placeholder="Select framework..."
            className="w-full"
          />
        </div>

        <div className="flex h-[calc(100vh-4rem)] lg:h-[calc(100vh-4rem)]">
          {/* Desktop Layout */}
          <div className="hidden lg:flex w-full">
            {/* Left Panel - Conversation */}
            <div className="w-1/2 border-r border-border bg-card flex flex-col">
              {/* Chat Header */}
              <div className="p-6 border-b border-border">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h1 className="text-2xl font-bold text-foreground">AI Code Generator</h1>
                    <p className="text-sm text-muted-foreground">
                      {isAuthenticated && import.meta.env.VITE_OPENAI_API_KEY 
                        ? "Powered by GPT-5 for production-ready code"
                        : "Describe your app and get production-ready code"
                      }
                    </p>
                  </div>
                  <Select
                    options={frameworks}
                    value={selectedFramework}
                    onChange={setSelectedFramework}
                    placeholder="Framework"
                    className="w-40"
                  />
                </div>

                {/* Generation Progress */}
                {isGenerating && (
                  <div className="bg-muted rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-foreground">
                        Generating your application...
                      </span>
                      <span className="text-sm text-muted-foreground">
                        {Math.round(generationProgress)}%
                      </span>
                    </div>
                    <div className="w-full bg-background rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full transition-all duration-300"
                        style={{ width: `${generationProgress}%` }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      {generationProgress < 30 && "Analyzing requirements..."}
                      {generationProgress >= 30 && generationProgress < 60 && "Generating components..."}
                      {generationProgress >= 60 && generationProgress < 90 && "Building application..."}
                      {generationProgress >= 90 && "Finalizing code..."}
                    </p>
                  </div>
                )}
              </div>

              {/* Conversation */}
              <ConversationPanel 
                messages={messages}
                onSuggestionClick={handleSuggestionClick}
                isGenerating={isGenerating}
              />

              {/* Input Area */}
              <div className="p-6 border-t border-border">
                <div className="flex space-x-3">
                  <div className="flex-1">
                    <textarea
                      ref={textareaRef}
                      value={currentPrompt}
                      onChange={(e) => setCurrentPrompt(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Describe the application you want to build... (Press Enter to send, Shift+Enter for new line)"
                      className="w-full px-4 py-3 bg-background border border-border rounded-lg resize-none min-h-[60px] max-h-[120px] text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                      disabled={isGenerating}
                    />
                  </div>
                  <Button
                    variant="default"
                    iconName={isGenerating ? "Loader2" : "Send"}
                    iconSize={16}
                    onClick={handleSendMessage}
                    disabled={!currentPrompt?.trim() || isGenerating}
                    className={`self-end ${isGenerating ? 'animate-spin' : ''}`}
                  />
                </div>
                
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      iconName="Template"
                      iconPosition="left"
                      iconSize={14}
                      onClick={() => setActiveTemplate({})}
                    >
                      Templates
                    </Button>
                    {appVersions?.length > 1 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        iconName="GitCompare"
                        iconPosition="left"
                        iconSize={14}
                        onClick={() => setShowVersionComparison(true)}
                      >
                        Compare ({appVersions?.length})
                      </Button>
                    )}
                  </div>
                  
                  <div className="text-xs text-muted-foreground">
                    {currentPrompt?.length}/2000 characters
                  </div>
                </div>
              </div>
            </div>

            {/* Right Panel - Preview */}
            <div className="w-1/2 bg-muted">
              <LivePreview 
                app={currentApp}
                framework={selectedFramework}
                onExport={handleExportCode}
                onSave={handleSaveToLibrary}
                onContinueEdit={handleContinueInBuilder}
                isMobile={false}
              />
            </div>
          </div>

          {/* Mobile Layout */}
          <div className="lg:hidden w-full">
            {showMobileChat ? (
              <div className="flex flex-col h-full">
                {/* Conversation */}
                <div className="flex-1 overflow-hidden">
                  <ConversationPanel 
                    messages={messages}
                    onSuggestionClick={handleSuggestionClick}
                    isGenerating={isGenerating}
                  />
                </div>

                {/* Generation Progress */}
                {isGenerating && (
                  <div className="p-4 border-t border-border bg-card">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-foreground">
                        Generating...
                      </span>
                      <span className="text-sm text-muted-foreground">
                        {Math.round(generationProgress)}%
                      </span>
                    </div>
                    <div className="w-full bg-background rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full transition-all duration-300"
                        style={{ width: `${generationProgress}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Input Area */}
                <div className="p-4 border-t border-border bg-card">
                  <div className="flex space-x-2">
                    <textarea
                      value={currentPrompt}
                      onChange={(e) => setCurrentPrompt(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Describe your app..."
                      className="flex-1 px-3 py-2 bg-background border border-border rounded-lg resize-none text-sm text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                      rows={2}
                      disabled={isGenerating}
                    />
                    <Button
                      variant="default"
                      iconName={isGenerating ? "Loader2" : "Send"}
                      iconSize={14}
                      onClick={handleSendMessage}
                      disabled={!currentPrompt?.trim() || isGenerating}
                      className={`${isGenerating ? 'animate-spin' : ''}`}
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-full bg-muted">
                <LivePreview 
                  app={currentApp}
                  framework={selectedFramework}
                  onExport={handleExportCode}
                  onSave={handleSaveToLibrary}
                  onContinueEdit={handleContinueInBuilder}
                  isMobile={true}
                />
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Prompt Templates Modal */}
      {activeTemplate !== null && (
        <PromptTemplates
          appTypes={appTypes}
          onClose={() => setActiveTemplate(null)}
          onSelect={handleTemplateSelect}
        />
      )}

      {/* Code Export Modal */}
      {showExportModal && (
        <CodeExportModal
          app={currentApp}
          framework={selectedFramework}
          onClose={() => setShowExportModal(false)}
        />
      )}

      {/* Version Comparison Modal */}
      {showVersionComparison && (
        <VersionComparison
          versions={appVersions}
          onClose={() => setShowVersionComparison(false)}
          onSelectVersion={setCurrentApp}
        />
      )}
    </div>
  );
};

export default AICodeGenerator;