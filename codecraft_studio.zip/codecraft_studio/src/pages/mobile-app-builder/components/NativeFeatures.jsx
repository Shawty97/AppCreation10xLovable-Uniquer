import React, { useState } from 'react';
import { Camera, MapPin, Bell, Fingerprint, Battery, Vibrate, Wifi, Share2, FileText, Shield, Lock, Volume2, Compass, Sun, Smartphone, Info, Settings } from 'lucide-react';

const NativeFeatures = () => {
  const [activeCategory, setActiveCategory] = useState('media');
  const [enabledFeatures, setEnabledFeatures] = useState(new Set(['camera', 'location', 'notifications']));

  const categories = [
    { id: 'media', name: 'Media', icon: Camera },
    { id: 'location', name: 'Location', icon: MapPin },
    { id: 'communication', name: 'Communication', icon: Bell },
    { id: 'sensors', name: 'Sensors', icon: Compass },
    { id: 'security', name: 'Security', icon: Shield },
    { id: 'system', name: 'System', icon: Settings }
  ];

  const features = {
    media: [
      {
        id: 'camera',
        name: 'Camera Access',
        icon: Camera,
        description: 'Take photos and record videos',
        platforms: ['ios', 'android'],
        permissions: ['NSCameraUsageDescription', 'android.permission.CAMERA'],
        complexity: 'easy',
        codeExample: `// Take a photo
const takePhoto = async () => {
  const result = await ImagePicker.launchCameraAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    quality: 1
  });
};`
      },
      {
        id: 'photo-library',
        name: 'Photo Library',
        icon: FileText,
        description: 'Access device photo library',
        platforms: ['ios', 'android'],
        permissions: ['NSPhotoLibraryUsageDescription', 'android.permission.READ_EXTERNAL_STORAGE'],
        complexity: 'easy',
        codeExample: `// Select from library
const pickImage = async () => {
  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images
  });
};`
      },
      {
        id: 'audio-record',
        name: 'Audio Recording',
        icon: Volume2,
        description: 'Record and playback audio',
        platforms: ['ios', 'android'],
        permissions: ['NSMicrophoneUsageDescription', 'android.permission.RECORD_AUDIO'],
        complexity: 'medium',
        codeExample: `// Record audio
const recording = new Audio.Recording();
await recording.prepareToRecordAsync();
await recording.startAsync();`
      }
    ],
    location: [
      {
        id: 'location',
        name: 'GPS Location',
        icon: MapPin,
        description: 'Get current location coordinates',
        platforms: ['ios', 'android'],
        permissions: ['NSLocationWhenInUseUsageDescription', 'android.permission.ACCESS_FINE_LOCATION'],
        complexity: 'easy',
        codeExample: `// Get current location
const location = await Location.getCurrentPositionAsync({
  accuracy: Location.Accuracy.High
});`
      },
      {
        id: 'geofencing',
        name: 'Geofencing',
        icon: MapPin,
        description: 'Monitor entry/exit from geographic areas',
        platforms: ['ios', 'android'],
        permissions: ['NSLocationAlwaysAndWhenInUseUsageDescription', 'android.permission.ACCESS_BACKGROUND_LOCATION'],
        complexity: 'hard',
        codeExample: `// Setup geofence
await Location.startGeofencingAsync('taskName', [
  { latitude: 37.78, longitude: -122.43, radius: 100 }
]);`
      },
      {
        id: 'maps',
        name: 'Map Integration',
        icon: Compass,
        description: 'Display interactive maps',
        platforms: ['ios', 'android'],
        permissions: [],
        complexity: 'medium',
        codeExample: `// Display map
<MapView
  initialRegion={{
    latitude: 37.78825,
    longitude: -122.4324
  }}
/>`
      }
    ],
    communication: [
      {
        id: 'notifications',
        name: 'Push Notifications',
        icon: Bell,
        description: 'Send and receive push notifications',
        platforms: ['ios', 'android'],
        permissions: ['aps-environment', 'com.google.android.c2dm.permission.RECEIVE'],
        complexity: 'medium',
        codeExample: `// Send notification
await Notifications.scheduleNotificationAsync({
  content: {
    title: "Hello!",
    body: "Your notification message"
  },
  trigger: { seconds: 2 }
});`
      },
      {
        id: 'local-notifications',
        name: 'Local Notifications',
        icon: Bell,
        description: 'Schedule local device notifications',
        platforms: ['ios', 'android'],
        permissions: [],
        complexity: 'easy',
        codeExample: `// Schedule local notification
await Notifications.scheduleNotificationAsync({
  content: { title: "Reminder", body: "Time to check in!" },
  trigger: { hour: 9, minute: 0, repeats: true }
});`
      },
      {
        id: 'share',
        name: 'Native Sharing',
        icon: Share2,
        description: 'Share content with other apps',
        platforms: ['ios', 'android'],
        permissions: [],
        complexity: 'easy',
        codeExample: `// Share content
await Sharing.shareAsync('https://example.com', {
  mimeType: 'text/plain',
  dialogTitle: 'Share this link'
});`
      }
    ],
    sensors: [
      {
        id: 'accelerometer',
        name: 'Accelerometer',
        icon: Smartphone,
        description: 'Detect device motion and orientation',
        platforms: ['ios', 'android'],
        permissions: [],
        complexity: 'medium',
        codeExample: `// Monitor accelerometer
Accelerometer.addListener(accelerometerData => {
  console.log(accelerometerData);
});`
      },
      {
        id: 'gyroscope',
        name: 'Gyroscope',
        icon: Compass,
        description: 'Detect device rotation',
        platforms: ['ios', 'android'],
        permissions: [],
        complexity: 'medium',
        codeExample: `// Monitor gyroscope
Gyroscope.addListener(gyroscopeData => {
  console.log(gyroscopeData);
});`
      },
      {
        id: 'brightness',
        name: 'Screen Brightness',
        icon: Sun,
        description: 'Control screen brightness',
        platforms: ['ios', 'android'],
        permissions: [],
        complexity: 'easy',
        codeExample: `// Set brightness
await Brightness.setBrightnessAsync(0.8);
const brightness = await Brightness.getBrightnessAsync();`
      }
    ],
    security: [
      {
        id: 'biometric',
        name: 'Biometric Auth',
        icon: Fingerprint,
        description: 'Fingerprint and Face ID authentication',
        platforms: ['ios', 'android'],
        permissions: ['NSFaceIDUsageDescription', 'android.permission.USE_FINGERPRINT'],
        complexity: 'medium',
        codeExample: `// Authenticate with biometrics
const result = await LocalAuthentication.authenticateAsync({
  promptMessage: 'Authenticate with biometrics'
});`
      },
      {
        id: 'keychain',
        name: 'Secure Storage',
        icon: Lock,
        description: 'Store sensitive data securely',
        platforms: ['ios', 'android'],
        permissions: [],
        complexity: 'easy',
        codeExample: `// Store securely
await SecureStore.setItemAsync('key', 'value');
const value = await SecureStore.getItemAsync('key');`
      }
    ],
    system: [
      {
        id: 'haptic',
        name: 'Haptic Feedback',
        icon: Vibrate,
        description: 'Device vibration and haptic feedback',
        platforms: ['ios', 'android'],
        permissions: ['android.permission.VIBRATE'],
        complexity: 'easy',
        codeExample: `// Trigger haptic feedback
await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);`
      },
      {
        id: 'battery',
        name: 'Battery Status',
        icon: Battery,
        description: 'Monitor device battery level',
        platforms: ['ios', 'android'],
        permissions: [],
        complexity: 'easy',
        codeExample: `// Get battery level
const batteryLevel = await Battery.getBatteryLevelAsync();
const batteryState = await Battery.getBatteryStateAsync();`
      },
      {
        id: 'network',
        name: 'Network Status',
        icon: Wifi,
        description: 'Monitor network connectivity',
        platforms: ['ios', 'android'],
        permissions: [],
        complexity: 'easy',
        codeExample: `// Check network status
const networkState = await Network.getNetworkStateAsync();
console.log(networkState.isConnected);`
      }
    ]
  };

  const toggleFeature = (featureId) => {
    const newEnabledFeatures = new Set(enabledFeatures);
    if (newEnabledFeatures?.has(featureId)) {
      newEnabledFeatures?.delete(featureId);
    } else {
      newEnabledFeatures?.add(featureId);
    }
    setEnabledFeatures(newEnabledFeatures);
  };

  const getComplexityColor = (complexity) => {
    switch (complexity) {
      case 'easy': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'hard': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const currentFeatures = features?.[activeCategory] || [];

  return (
    <div className="h-full flex flex-col">
      {/* Category Navigation */}
      <div className="border-b border-gray-200">
        <nav className="flex overflow-x-auto">
          {categories?.map((category) => (
            <button
              key={category?.id}
              onClick={() => setActiveCategory(category?.id)}
              className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeCategory === category?.id
                  ? 'border-purple-600 text-purple-600 bg-purple-50' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <category.icon className="h-4 w-4" />
              <span>{category?.name}</span>
            </button>
          ))}
        </nav>
      </div>
      {/* Feature List */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
            <div className="flex items-start space-x-3">
              <Info className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-blue-900">Native Features</h4>
                <p className="text-sm text-blue-700 mt-1">
                  Enable device-specific capabilities. Each feature may require permissions and affect app store approval.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {currentFeatures?.map((feature) => (
              <div key={feature?.id} className="border border-gray-200 rounded-lg overflow-hidden">
                <div className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3 flex-1">
                      <div className={`p-2 rounded-lg ${
                        enabledFeatures?.has(feature?.id) ? 'bg-purple-100' : 'bg-gray-100'
                      }`}>
                        <feature.icon className={`h-5 w-5 ${
                          enabledFeatures?.has(feature?.id) ? 'text-purple-600' : 'text-gray-600'
                        }`} />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="text-sm font-medium text-gray-900">{feature?.name}</h3>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${getComplexityColor(feature?.complexity)}`}>
                            {feature?.complexity}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{feature?.description}</p>
                        
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <div className="flex items-center space-x-1">
                            <Smartphone className="h-3 w-3" />
                            <span>{feature?.platforms?.join(', ')?.toUpperCase()}</span>
                          </div>
                          
                          {feature?.permissions?.length > 0 && (
                            <div className="flex items-center space-x-1">
                              <Shield className="h-3 w-3" />
                              <span>{feature?.permissions?.length} permission{feature?.permissions?.length !== 1 ? 's' : ''}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <label className="relative inline-flex items-center cursor-pointer ml-4">
                      <input
                        type="checkbox"
                        className="sr-only peer"
                        checked={enabledFeatures?.has(feature?.id)}
                        onChange={() => toggleFeature(feature?.id)}
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                    </label>
                  </div>
                  
                  {enabledFeatures?.has(feature?.id) && (
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <h4 className="text-xs font-medium text-gray-700 mb-2">Code Example:</h4>
                      <pre className="bg-gray-50 rounded-lg p-3 text-xs text-gray-800 overflow-x-auto">
                        <code>{feature?.codeExample}</code>
                      </pre>
                      
                      {feature?.permissions?.length > 0 && (
                        <div className="mt-3">
                          <h4 className="text-xs font-medium text-gray-700 mb-1">Required Permissions:</h4>
                          <div className="flex flex-wrap gap-1">
                            {feature?.permissions?.map((permission, index) => (
                              <span key={index} className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">
                                {permission}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Summary */}
      <div className="border-t border-gray-200 p-4 bg-gray-50">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-4 text-gray-600">
            <span>{enabledFeatures?.size} features enabled</span>
            <span>•</span>
            <span>{currentFeatures?.length} available in {categories?.find(c => c?.id === activeCategory)?.name}</span>
          </div>
          
          <button className="text-purple-600 hover:text-purple-700 font-medium">
            Generate Integration Code
          </button>
        </div>
      </div>
    </div>
  );
};

export default NativeFeatures;