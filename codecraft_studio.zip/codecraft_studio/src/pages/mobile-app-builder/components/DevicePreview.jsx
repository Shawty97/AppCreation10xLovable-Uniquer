import React, { useState } from 'react';
import { Smartphone, Wifi, Battery, Signal } from 'lucide-react';

const DevicePreview = ({ device, isBuilding }) => {
  const [showNotch, setShowNotch] = useState(true);
  
  if (!device) return null;

  const deviceStyles = {
    iphone: {
      frame: 'bg-gray-800 rounded-[3rem] p-2',
      screen: 'bg-black rounded-[2.5rem] overflow-hidden',
      notch: 'w-32 h-6 bg-black rounded-b-2xl mx-auto relative'
    },
    android: {
      frame: 'bg-gray-700 rounded-[2rem] p-2',
      screen: 'bg-black rounded-[1.5rem] overflow-hidden',
      notch: 'w-24 h-4 bg-black rounded-b-xl mx-auto relative'
    },
    ipad: {
      frame: 'bg-gray-800 rounded-[2rem] p-3',
      screen: 'bg-black rounded-[1.5rem] overflow-hidden',
      notch: null
    },
    desktop: {
      frame: 'bg-gray-800 rounded-lg p-1',
      screen: 'bg-black rounded-md overflow-hidden',
      notch: null
    }
  };

  const currentStyle = deviceStyles?.[device?.id] || deviceStyles?.iphone;

  return (
    <div className="flex flex-col items-center space-y-4">
      {/* Device Frame */}
      <div 
        className={`${currentStyle?.frame} shadow-2xl transition-all duration-300 ${isBuilding ? 'animate-pulse' : ''}`}
        style={{
          width: device?.id === 'desktop' ? '800px' : device?.id === 'ipad' ? '400px' : '280px',
          height: device?.id === 'desktop' ? '500px' : device?.id === 'ipad' ? '550px' : '580px'
        }}
      >
        {/* Screen */}
        <div className={`${currentStyle?.screen} w-full h-full relative`}>
          {/* Status Bar */}
          <div className="absolute top-0 left-0 right-0 z-10">
            {currentStyle?.notch && (
              <div className={currentStyle?.notch}>
                <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-12 h-1 bg-gray-600 rounded-full" />
              </div>
            )}
            
            <div className="flex items-center justify-between px-6 py-2 text-white text-sm">
              <div className="flex items-center space-x-1">
                <span className="font-medium">9:41</span>
              </div>
              
              <div className="flex items-center space-x-1">
                <Signal className="h-4 w-4" />
                <Wifi className="h-4 w-4" />
                <Battery className="h-4 w-4" />
              </div>
            </div>
          </div>

          {/* App Content */}
          <div className="pt-16 h-full bg-white">
            {isBuilding ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-16 w-16 border-4 border-purple-500 border-t-transparent mx-auto mb-4"></div>
                  <p className="text-gray-600 font-medium">Building your app...</p>
                  <p className="text-sm text-gray-500 mt-2">This may take a few moments</p>
                </div>
              </div>
            ) : (
              <>
                {/* Navigation Bar */}
                <div className="bg-purple-600 text-white px-6 py-4">
                  <h1 className="text-xl font-semibold">My Awesome App</h1>
                </div>

                {/* Sample Content */}
                <div className="p-6 space-y-6">
                  <div className="bg-gray-50 rounded-xl p-4">
                    <h2 className="text-lg font-semibold text-gray-900 mb-2">Welcome Dashboard</h2>
                    <p className="text-gray-600 text-sm">Start building your mobile app with drag & drop components</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg text-center">
                      <div className="w-8 h-8 bg-blue-500 rounded-lg mx-auto mb-2"></div>
                      <p className="text-sm font-medium">Features</p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg text-center">
                      <div className="w-8 h-8 bg-green-500 rounded-lg mx-auto mb-2"></div>
                      <p className="text-sm font-medium">Analytics</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center space-x-3 p-3 bg-white rounded-lg border border-gray-200">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                        <Smartphone className="h-5 w-5 text-purple-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">Native Integration</p>
                        <p className="text-sm text-gray-500">Camera, GPS, Push notifications</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 p-3 bg-white rounded-lg border border-gray-200">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <Wifi className="h-5 w-5 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">Real-time Sync</p>
                        <p className="text-sm text-gray-500">Cloud synchronization</p>
                      </div>
                    </div>
                  </div>

                  {/* Bottom Tab Bar (Mobile Only) */}
                  {(device?.id === 'iphone' || device?.id === 'android') && (
                    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
                      <div className="flex items-center justify-around py-2">
                        <div className="flex flex-col items-center p-2">
                          <div className="w-6 h-6 bg-purple-600 rounded mb-1"></div>
                          <span className="text-xs text-purple-600 font-medium">Home</span>
                        </div>
                        <div className="flex flex-col items-center p-2">
                          <div className="w-6 h-6 bg-gray-300 rounded mb-1"></div>
                          <span className="text-xs text-gray-500">Search</span>
                        </div>
                        <div className="flex flex-col items-center p-2">
                          <div className="w-6 h-6 bg-gray-300 rounded mb-1"></div>
                          <span className="text-xs text-gray-500">Profile</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
      {/* Device Info */}
      <div className="text-center">
        <p className="font-medium text-gray-900">{device?.name}</p>
        <p className="text-sm text-gray-500">{device?.width} × {device?.height}</p>
      </div>
    </div>
  );
};

export default DevicePreview;