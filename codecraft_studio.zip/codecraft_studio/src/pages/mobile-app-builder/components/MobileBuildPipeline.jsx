import React, { useState, useEffect } from 'react';
import { Play, Square, Download, Upload, CheckCircle, AlertCircle, Clock, Smartphone, Apple, Package, Settings, Terminal, Loader2, Bug, TestTube, Eye, RefreshCw, ExternalLink } from 'lucide-react';

const MobileBuildPipeline = () => {
  const [isBuilding, setIsBuilding] = useState(false);
  const [buildProgress, setBuildProgress] = useState(0);
  const [activePlatform, setActivePlatform] = useState('both');
  const [buildHistory, setBuildHistory] = useState([
    { id: 1, version: '1.0.2', platform: 'iOS', status: 'success', date: '2024-01-15', duration: '4m 32s' },
    { id: 2, version: '1.0.2', platform: 'Android', status: 'success', date: '2024-01-15', duration: '3m 18s' },
    { id: 3, version: '1.0.1', platform: 'iOS', status: 'failed', date: '2024-01-14', duration: '2m 45s' },
  ]);

  const platforms = [
    { id: 'ios', name: 'iOS', icon: Apple, color: 'blue' },
    { id: 'android', name: 'Android', icon: Smartphone, color: 'green' },
    { id: 'both', name: 'Both Platforms', icon: Package, color: 'purple' }
  ];

  const buildSteps = [
    { id: 'setup', name: 'Environment Setup', icon: Settings, status: 'completed' },
    { id: 'dependencies', name: 'Installing Dependencies', icon: Download, status: 'completed' },
    { id: 'compile', name: 'Compiling Code', icon: Terminal, status: 'running' },
    { id: 'test', name: 'Running Tests', icon: TestTube, status: 'pending' },
    { id: 'package', name: 'Creating Package', icon: Package, status: 'pending' },
    { id: 'sign', name: 'Code Signing', icon: CheckCircle, status: 'pending' },
    { id: 'upload', name: 'Upload Artifacts', icon: Upload, status: 'pending' }
  ];

  const buildConfig = {
    buildType: 'Release',
    targetSdk: {
      ios: '17.0',
      android: '34'
    },
    optimization: true,
    testing: true,
    signing: true,
    distribution: 'App Store'
  };

  useEffect(() => {
    let interval;
    if (isBuilding && buildProgress < 100) {
      interval = setInterval(() => {
        setBuildProgress(prev => Math.min(prev + Math.random() * 5, 100));
      }, 500);
    }
    return () => clearInterval(interval);
  }, [isBuilding, buildProgress]);

  const startBuild = () => {
    setIsBuilding(true);
    setBuildProgress(0);
    // Simulate build completion
    setTimeout(() => {
      setIsBuilding(false);
      setBuildProgress(100);
      // Add to history
      const newBuild = {
        id: Date.now(),
        version: '1.0.3',
        platform: activePlatform,
        status: 'success',
        date: new Date()?.toISOString()?.split('T')?.[0],
        duration: '3m 42s'
      };
      setBuildHistory([newBuild, ...buildHistory]);
    }, 8000);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'success': return 'text-green-600 bg-green-100';
      case 'failed': return 'text-red-600 bg-red-100';
      case 'running': return 'text-blue-600 bg-blue-100';
      case 'pending': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'success': case'completed': return CheckCircle;
      case 'failed': return AlertCircle;
      case 'running': return Loader2;
      case 'pending': return Clock;
      default: return Clock;
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Build Configuration */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium text-gray-900">Build Configuration</h3>
          <button className="text-sm text-purple-600 hover:text-purple-700 flex items-center space-x-1">
            <Settings className="h-4 w-4" />
            <span>Configure</span>
          </button>
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-600">Build Type:</span>
            <span className="ml-2 font-medium">{buildConfig?.buildType}</span>
          </div>
          <div>
            <span className="text-gray-600">Distribution:</span>
            <span className="ml-2 font-medium">{buildConfig?.distribution}</span>
          </div>
          <div>
            <span className="text-gray-600">iOS Target:</span>
            <span className="ml-2 font-medium">{buildConfig?.targetSdk?.ios}</span>
          </div>
          <div>
            <span className="text-gray-600">Android Target:</span>
            <span className="ml-2 font-medium">API {buildConfig?.targetSdk?.android}</span>
          </div>
        </div>
      </div>
      {/* Platform Selector & Build Controls */}
      <div className="p-4 border-b border-gray-200 space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Target Platform
          </label>
          <div className="flex space-x-2">
            {platforms?.map((platform) => (
              <button
                key={platform?.id}
                onClick={() => setActivePlatform(platform?.id)}
                disabled={isBuilding}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg border transition-all disabled:opacity-50 ${
                  activePlatform === platform?.id
                    ? `border-${platform?.color}-300 bg-${platform?.color}-50 text-${platform?.color}-700`
                    : 'border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50'
                }`}
              >
                <platform.icon className="h-4 w-4" />
                <span className="text-sm font-medium">{platform?.name}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {!isBuilding ? (
            <button
              onClick={startBuild}
              className="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 transition-colors flex items-center space-x-2"
            >
              <Play className="h-4 w-4" />
              <span>Start Build</span>
            </button>
          ) : (
            <button
              onClick={() => setIsBuilding(false)}
              className="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center space-x-2"
            >
              <Square className="h-4 w-4" />
              <span>Stop Build</span>
            </button>
          )}
          
          <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors text-sm">
            Quick Test
          </button>
          
          <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors text-sm">
            View Logs
          </button>
        </div>
      </div>
      {/* Build Progress */}
      {(isBuilding || buildProgress > 0) && (
        <div className="p-4 border-b border-gray-200">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-gray-900">
                {isBuilding ? 'Building...' : 'Build Complete'}
              </h3>
              <span className="text-sm text-gray-600">
                {Math.round(buildProgress)}%
              </span>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-purple-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${buildProgress}%` }}
              />
            </div>

            <div className="space-y-2">
              {buildSteps?.map((step) => {
                const StepIcon = getStatusIcon(step?.status);
                return (
                  <div key={step?.id} className="flex items-center space-x-3 text-sm">
                    <StepIcon className={`h-4 w-4 ${
                      step?.status === 'running' ? 'animate-spin text-blue-600' :
                      step?.status === 'completed' ? 'text-green-600' :
                      step?.status === 'failed' ? 'text-red-600' : 'text-gray-400'
                    }`} />
                    <span className={step?.status === 'running' ? 'text-gray-900 font-medium' : 'text-gray-600'}>
                      {step?.name}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
      {/* Build History */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-gray-900">Build History</h3>
            <button className="text-sm text-purple-600 hover:text-purple-700 flex items-center space-x-1">
              <RefreshCw className="h-4 w-4" />
              <span>Refresh</span>
            </button>
          </div>

          <div className="space-y-3">
            {buildHistory?.map((build) => {
              const StatusIcon = getStatusIcon(build?.status);
              return (
                <div key={build?.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <StatusIcon className={`h-5 w-5 ${
                        build?.status === 'success' ? 'text-green-600' :
                        build?.status === 'failed' ? 'text-red-600' : 'text-gray-600'
                      }`} />
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-medium text-gray-900">v{build?.version}</span>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${getStatusColor(build?.status)}`}>
                            {build?.status}
                          </span>
                        </div>
                        <div className="text-sm text-gray-600">
                          {build?.platform} • {build?.date} • {build?.duration}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {build?.status === 'success' && (
                        <>
                          <button className="text-sm text-gray-600 hover:text-gray-800 flex items-center space-x-1">
                            <Download className="h-4 w-4" />
                            <span>Download</span>
                          </button>
                          <button className="text-sm text-gray-600 hover:text-gray-800 flex items-center space-x-1">
                            <ExternalLink className="h-4 w-4" />
                            <span>Deploy</span>
                          </button>
                        </>
                      )}
                      {build?.status === 'failed' && (
                        <button className="text-sm text-red-600 hover:text-red-700 flex items-center space-x-1">
                          <Bug className="h-4 w-4" />
                          <span>Debug</span>
                        </button>
                      )}
                      <button className="text-sm text-gray-600 hover:text-gray-800 flex items-center space-x-1">
                        <Eye className="h-4 w-4" />
                        <span>Logs</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {buildHistory?.length === 0 && (
            <div className="text-center py-12">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h4 className="font-medium text-gray-900 mb-2">No builds yet</h4>
              <p className="text-gray-600 text-sm mb-4">
                Start your first build to see the history here
              </p>
              <button
                onClick={startBuild}
                className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
              >
                Start First Build
              </button>
            </div>
          )}
        </div>
      </div>
      {/* Quick Stats */}
      <div className="border-t border-gray-200 p-4 bg-gray-50">
        <div className="grid grid-cols-3 gap-4 text-center text-sm">
          <div>
            <div className="text-lg font-semibold text-green-600">
              {buildHistory?.filter(b => b?.status === 'success')?.length}
            </div>
            <div className="text-gray-600">Successful</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-red-600">
              {buildHistory?.filter(b => b?.status === 'failed')?.length}
            </div>
            <div className="text-gray-600">Failed</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-gray-900">
              ~3m 30s
            </div>
            <div className="text-gray-600">Avg Time</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MobileBuildPipeline;