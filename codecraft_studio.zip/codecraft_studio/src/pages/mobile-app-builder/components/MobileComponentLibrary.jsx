import React, { useState } from 'react';
import { Navigation, SquareStack, Type, Image, ToggleLeft, Calendar, MapPin, BarChart3, Search, Grid3X3, List, Camera, Video, Music, MessageCircle, Zap } from 'lucide-react';

const MobileComponentLibrary = () => {
  const [selectedCategory, setSelectedCategory] = useState('navigation');
  const [searchTerm, setSearchTerm] = useState('');

  const categories = [
    { id: 'navigation', name: 'Navigation', icon: Navigation },
    { id: 'layout', name: 'Layout', icon: SquareStack },
    { id: 'input', name: 'Input', icon: Type },
    { id: 'media', name: 'Media', icon: Image },
    { id: 'data', name: 'Data Display', icon: BarChart3 },
    { id: 'native', name: 'Native', icon: Zap }
  ];

  const components = {
    navigation: [
      { id: 'tab-bar', name: 'Tab Bar', icon: Navigation, description: 'Bottom navigation tabs' },
      { id: 'drawer', name: 'Side Drawer', icon: List, description: 'Sliding navigation menu' },
      { id: 'header', name: 'App Header', icon: SquareStack, description: 'Top navigation bar' },
      { id: 'breadcrumb', name: 'Breadcrumb', icon: Navigation, description: 'Navigation trail' }
    ],
    layout: [
      { id: 'container', name: 'Container', icon: SquareStack, description: 'Layout wrapper' },
      { id: 'grid', name: 'Grid Layout', icon: Grid3X3, description: 'Responsive grid system' },
      { id: 'stack', name: 'Stack', icon: SquareStack, description: 'Vertical/horizontal stack' },
      { id: 'card', name: 'Card', icon: SquareStack, description: 'Content card container' }
    ],
    input: [
      { id: 'text-field', name: 'Text Field', icon: Type, description: 'Text input field' },
      { id: 'button', name: 'Button', icon: SquareStack, description: 'Action button' },
      { id: 'switch', name: 'Switch', icon: ToggleLeft, description: 'Toggle switch' },
      { id: 'slider', name: 'Slider', icon: ToggleLeft, description: 'Range slider' },
      { id: 'date-picker', name: 'Date Picker', icon: Calendar, description: 'Date selection' }
    ],
    media: [
      { id: 'image', name: 'Image', icon: Image, description: 'Image display' },
      { id: 'video', name: 'Video Player', icon: Video, description: 'Video playback' },
      { id: 'audio', name: 'Audio Player', icon: Music, description: 'Audio controls' },
      { id: 'camera', name: 'Camera View', icon: Camera, description: 'Camera preview' }
    ],
    data: [
      { id: 'list', name: 'List View', icon: List, description: 'Scrollable list' },
      { id: 'chart', name: 'Chart', icon: BarChart3, description: 'Data visualization' },
      { id: 'table', name: 'Data Table', icon: Grid3X3, description: 'Tabular data' },
      { id: 'progress', name: 'Progress Bar', icon: BarChart3, description: 'Progress indicator' }
    ],
    native: [
      { id: 'map', name: 'Map View', icon: MapPin, description: 'Interactive map' },
      { id: 'camera-capture', name: 'Camera Capture', icon: Camera, description: 'Take photos' },
      { id: 'location', name: 'Location Service', icon: MapPin, description: 'GPS location' },
      { id: 'notifications', name: 'Push Notifications', icon: MessageCircle, description: 'System notifications' }
    ]
  };

  const filteredComponents = components?.[selectedCategory]?.filter(component =>
    component?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
    component?.description?.toLowerCase()?.includes(searchTerm?.toLowerCase())
  ) || [];

  const handleDragStart = (e, component) => {
    e?.dataTransfer?.setData('application/json', JSON.stringify(component));
  };

  return (
    <div className="h-full flex flex-col">
      {/* Search */}
      <div className="p-4 border-b border-gray-200">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search components..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e?.target?.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
        </div>
      </div>
      {/* Categories */}
      <div className="border-b border-gray-200">
        <nav className="flex overflow-x-auto">
          {categories?.map((category) => (
            <button
              key={category?.id}
              onClick={() => setSelectedCategory(category?.id)}
              className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                selectedCategory === category?.id
                  ? 'border-purple-600 text-purple-600 bg-purple-50' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <category.icon className="h-4 w-4" />
              <span>{category?.name}</span>
            </button>
          ))}
        </nav>
      </div>
      {/* Component List */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4 space-y-2">
          {filteredComponents?.map((component) => (
            <div
              key={component?.id}
              draggable
              onDragStart={(e) => handleDragStart(e, component)}
              className="flex items-center space-x-3 p-3 rounded-lg border border-gray-200 hover:border-gray-300 hover:bg-gray-50 cursor-move transition-colors"
            >
              <div className="flex-shrink-0">
                <component.icon className="h-8 w-8 text-gray-600 p-1.5 bg-gray-100 rounded-lg" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-medium text-gray-900">{component?.name}</h4>
                <p className="text-xs text-gray-500 truncate">{component?.description}</p>
              </div>
              <div className="flex-shrink-0">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              </div>
            </div>
          ))}
        </div>

        {filteredComponents?.length === 0 && (
          <div className="p-8 text-center">
            <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No components found</p>
            <p className="text-sm text-gray-400 mt-1">Try adjusting your search</p>
          </div>
        )}
      </div>
      {/* Usage Stats */}
      <div className="border-t border-gray-200 p-4 bg-gray-50">
        <div className="text-center">
          <p className="text-xs text-gray-500">
            {filteredComponents?.length} component{filteredComponents?.length !== 1 ? 's' : ''} available
          </p>
          <div className="flex items-center justify-center space-x-4 mt-2 text-xs text-gray-400">
            <span>• Drag to canvas</span>
            <span>• Auto-responsive</span>
            <span>• Native optimized</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MobileComponentLibrary;