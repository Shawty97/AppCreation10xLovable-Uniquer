import React from 'react';
import { Gauge, Zap, Clock, Users, TrendingUp, ArrowUp, ArrowDown, Minus } from 'lucide-react';

const PerformanceScorecard = ({ data = {} }) => {
  const { coreWebVitals = {}, performance = {}, traffic = {}, errors = {} } = data;

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600 bg-green-100';
    if (score >= 70) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getVitalStatus = (value, target, isLower = true) => {
    const isGood = isLower ? value <= target : value >= target;
    return {
      status: isGood ? 'good' : value <= target * 1.2 ? 'needs-improvement' : 'poor',
      color: isGood ? 'text-green-600' : value <= target * 1.2 ? 'text-yellow-600' : 'text-red-600',
      bgColor: isGood ? 'bg-green-100' : value <= target * 1.2 ? 'bg-yellow-100' : 'bg-red-100'
    };
  };

  const formatTime = (ms) => {
    if (ms < 1000) return `${ms}ms`;
    return `${(ms / 1000)?.toFixed(1)}s`;
  };

  const TrendIndicator = ({ trend = 0 }) => {
    if (trend > 0) return <ArrowUp className="w-4 h-4 text-green-600" />;
    if (trend < 0) return <ArrowDown className="w-4 h-4 text-red-600" />;
    return <Minus className="w-4 h-4 text-gray-400" />;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Overall Performance Score */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900 flex items-center">
            <Gauge className="w-5 h-5 mr-2 text-blue-600" />
            Performance Score
          </h3>
          <TrendIndicator trend={5} />
        </div>
        
        <div className="text-center">
          <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full text-2xl font-bold ${getScoreColor(performance?.score)}`}>
            {performance?.score || 0}
          </div>
          <div className="mt-2 text-sm text-gray-600">Out of 100</div>
          <div className="mt-1 text-xs text-green-600 flex items-center justify-center">
            <TrendingUp className="w-3 h-3 mr-1" />
            +5 from last week
          </div>
        </div>
      </div>
      {/* Core Web Vitals */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 col-span-1 lg:col-span-2">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900 flex items-center">
            <Zap className="w-5 h-5 mr-2 text-yellow-600" />
            Core Web Vitals
          </h3>
        </div>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {/* LCP */}
          <div className="text-center">
            <div className="font-medium text-gray-900 mb-1">LCP</div>
            <div className={`text-lg font-bold ${getVitalStatus(coreWebVitals?.lcp?.value, coreWebVitals?.lcp?.target)?.color}`}>
              {coreWebVitals?.lcp?.value}s
            </div>
            <div className="text-xs text-gray-500">Target: ≤{coreWebVitals?.lcp?.target}s</div>
            <div className={`mt-1 px-2 py-1 rounded-full text-xs ${getVitalStatus(coreWebVitals?.lcp?.value, coreWebVitals?.lcp?.target)?.bgColor} ${getVitalStatus(coreWebVitals?.lcp?.value, coreWebVitals?.lcp?.target)?.color}`}>
              Good
            </div>
          </div>
          
          {/* FID */}
          <div className="text-center">
            <div className="font-medium text-gray-900 mb-1">FID</div>
            <div className={`text-lg font-bold ${getVitalStatus(coreWebVitals?.fid?.value, coreWebVitals?.fid?.target)?.color}`}>
              {coreWebVitals?.fid?.value}ms
            </div>
            <div className="text-xs text-gray-500">Target: ≤{coreWebVitals?.fid?.target}ms</div>
            <div className={`mt-1 px-2 py-1 rounded-full text-xs ${getVitalStatus(coreWebVitals?.fid?.value, coreWebVitals?.fid?.target)?.bgColor} ${getVitalStatus(coreWebVitals?.fid?.value, coreWebVitals?.fid?.target)?.color}`}>
              Good
            </div>
          </div>
          
          {/* CLS */}
          <div className="text-center">
            <div className="font-medium text-gray-900 mb-1">CLS</div>
            <div className={`text-lg font-bold ${getVitalStatus(coreWebVitals?.cls?.value, coreWebVitals?.cls?.target)?.color}`}>
              {coreWebVitals?.cls?.value}
            </div>
            <div className="text-xs text-gray-500">Target: ≤{coreWebVitals?.cls?.target}</div>
            <div className={`mt-1 px-2 py-1 rounded-full text-xs ${getVitalStatus(coreWebVitals?.cls?.value, coreWebVitals?.cls?.target)?.bgColor} ${getVitalStatus(coreWebVitals?.cls?.value, coreWebVitals?.cls?.target)?.color}`}>
              Good
            </div>
          </div>
          
          {/* FCP */}
          <div className="text-center">
            <div className="font-medium text-gray-900 mb-1">FCP</div>
            <div className={`text-lg font-bold ${getVitalStatus(coreWebVitals?.fcp?.value, coreWebVitals?.fcp?.target)?.color}`}>
              {coreWebVitals?.fcp?.value}s
            </div>
            <div className="text-xs text-gray-500">Target: ≤{coreWebVitals?.fcp?.target}s</div>
            <div className={`mt-1 px-2 py-1 rounded-full text-xs ${getVitalStatus(coreWebVitals?.fcp?.value, coreWebVitals?.fcp?.target)?.bgColor} ${getVitalStatus(coreWebVitals?.fcp?.value, coreWebVitals?.fcp?.target)?.color}`}>
              Good
            </div>
          </div>
        </div>
      </div>
      {/* Loading Performance */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900 flex items-center">
            <Clock className="w-5 h-5 mr-2 text-purple-600" />
            Load Times
          </h3>
          <TrendIndicator trend={-2} />
        </div>
        
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Total Load</span>
            <span className="font-medium">{formatTime(performance?.loadTime)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">DOM Ready</span>
            <span className="font-medium">{formatTime(performance?.domReady)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">First Byte</span>
            <span className="font-medium">{formatTime(performance?.firstByte)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Interactive</span>
            <span className="font-medium">{formatTime(performance?.interactive)}</span>
          </div>
        </div>
      </div>
      {/* User Metrics */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900 flex items-center">
            <Users className="w-5 h-5 mr-2 text-green-600" />
            User Metrics
          </h3>
          <TrendIndicator trend={8} />
        </div>
        
        <div className="space-y-3">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{traffic?.totalUsers?.toLocaleString()}</div>
            <div className="text-xs text-gray-500">Total Users</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-blue-600">{traffic?.activeUsers?.toLocaleString()}</div>
            <div className="text-xs text-gray-500">Active Now</div>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Bounce Rate</span>
            <span className="font-medium">{traffic?.bounceRate}%</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Avg. Session</span>
            <span className="font-medium">{traffic?.avgSessionDuration}</span>
          </div>
        </div>
      </div>
      {/* Error Metrics */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900">Error Overview</h3>
          <TrendIndicator trend={-1} />
        </div>
        
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Total Errors</span>
            <span className="font-medium">{errors?.total}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-red-600">Critical</span>
            <span className="font-medium text-red-600">{errors?.critical}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-yellow-600">Warnings</span>
            <span className="font-medium text-yellow-600">{errors?.warnings}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-blue-600">Notices</span>
            <span className="font-medium text-blue-600">{errors?.notices}</span>
          </div>
        </div>
      </div>
      {/* Performance Insights */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Quick Insights</h3>
        
        <div className="space-y-3">
          <div className="flex items-start space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
            <div>
              <div className="text-sm font-medium text-gray-900">Excellent Core Web Vitals</div>
              <div className="text-xs text-gray-600">All metrics within targets</div>
            </div>
          </div>
          
          <div className="flex items-start space-x-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
            <div>
              <div className="text-sm font-medium text-gray-900">Fast Loading</div>
              <div className="text-xs text-gray-600">2s faster than average</div>
            </div>
          </div>
          
          <div className="flex items-start space-x-2">
            <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
            <div>
              <div className="text-sm font-medium text-gray-900">Bundle Size Warning</div>
              <div className="text-xs text-gray-600">Consider code splitting</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceScorecard;