import React from 'react';
import { CheckCircle, Zap, TrendingUp } from 'lucide-react';

const OptimizationRecommendations = ({ performanceData, environment }) => {
  const recommendations = [
    {
      title: 'Enable Image Compression',
      impact: 'High',
      effort: 'Low',
      description: 'Compress images to reduce bundle size by ~40%',
      estimatedGain: '800ms faster load time',
      priority: 1
    },
    {
      title: 'Implement Code Splitting',
      impact: 'High',
      effort: 'Medium',
      description: 'Split large chunks to improve initial load performance',
      estimatedGain: '1.2s faster initial load',
      priority: 2
    },
    {
      title: 'Add Service Worker Caching',
      impact: 'Medium',
      effort: 'Medium',
      description: 'Cache static assets for repeat visitors',
      estimatedGain: '60% faster repeat visits',
      priority: 3
    }
  ];

  const getImpactColor = (impact) => {
    switch (impact) {
      case 'High': return 'text-red-600 bg-red-100';
      case 'Medium': return 'text-yellow-600 bg-yellow-100';
      case 'Low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center mb-4">
          <CheckCircle className="w-5 h-5 mr-2 text-green-600" />
          Optimization Recommendations
        </h3>
        
        <div className="text-sm text-gray-600 mb-6">
          Based on your current performance metrics, here are prioritized optimizations:
        </div>

        <div className="space-y-4">
          {recommendations?.map((rec, index) => (
            <div key={index} className="p-6 border border-gray-200 rounded-lg hover:shadow-sm transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <span className="font-medium text-gray-900">{rec?.title}</span>
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getImpactColor(rec?.impact)}`}>
                      {rec?.impact} Impact
                    </span>
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {rec?.effort} Effort
                    </span>
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                      Priority {rec?.priority}
                    </span>
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-3">{rec?.description}</p>
                  
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="flex items-center space-x-1 text-green-600">
                      <TrendingUp className="w-4 h-4" />
                      <span>{rec?.estimatedGain}</span>
                    </div>
                  </div>
                </div>
                
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Apply Fix
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <div className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-blue-600" />
            <span className="font-medium text-blue-900">Estimated Total Improvement</span>
          </div>
          <div className="text-sm text-blue-700 mt-1">
            Implementing all recommendations could improve your performance score by ~15 points and reduce load time by ~2.5 seconds.
          </div>
        </div>
      </div>
    </div>
  );
};

export default OptimizationRecommendations;