import React, { useState } from 'react';
import { Package } from 'lucide-react';

const BundleAnalyzer = ({ environment = 'production' }) => {
  const [view, setView] = useState('treemap');

  const bundleData = {
    totalSize: '2.1 MB',
    gzippedSize: '674 KB',
    chunkCount: 12,
    largestChunk: 'main.js (1.2 MB)',
    recommendations: 5
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center mb-4">
          <Package className="w-5 h-5 mr-2 text-blue-600" />
          Bundle Analyzer
        </h3>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{bundleData?.totalSize}</div>
            <div className="text-sm text-blue-700">Total Size</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{bundleData?.gzippedSize}</div>
            <div className="text-sm text-green-700">Gzipped</div>
          </div>
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600">{bundleData?.chunkCount}</div>
            <div className="text-sm text-yellow-700">Chunks</div>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">{bundleData?.recommendations}</div>
            <div className="text-sm text-purple-700">Optimizations</div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-yellow-50 rounded-lg">
            <div>
              <div className="font-medium text-yellow-900">Large Bundle Detected</div>
              <div className="text-sm text-yellow-700">Consider code splitting to improve load times</div>
            </div>
            <button className="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors">
              Optimize
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BundleAnalyzer;