import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, Zap, Globe, Users, Activity, AlertTriangle, CheckCircle, Settings, Download, RefreshCw } from 'lucide-react';
import Header from 'components/ui/Header';
import Sidebar from 'components/ui/Sidebar';
import PerformanceScorecard from './components/PerformanceScorecard';
import MetricsCharts from './components/MetricsCharts';
import CodeAnalysisPanel from './components/CodeAnalysisPanel';
import BundleAnalyzer from './components/BundleAnalyzer';
import UserJourneyMapping from './components/UserJourneyMapping';
import ABTestingFramework from './components/ABTestingFramework';
import MonitoringAlerts from './components/MonitoringAlerts';
import OptimizationRecommendations from './components/OptimizationRecommendations';



const PerformanceAnalyticsCenter = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [timeRange, setTimeRange] = useState('24h');
  const [selectedEnvironment, setSelectedEnvironment] = useState('production');
  const [performanceData, setPerformanceData] = useState({});
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const handleSidebarToggle = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  useEffect(() => {
    // Mock performance data
    setPerformanceData({
      coreWebVitals: {
        lcp: { value: 2.1, target: 2.5, status: 'good' },
        fid: { value: 85, target: 100, status: 'good' },
        cls: { value: 0.08, target: 0.1, status: 'good' },
        fcp: { value: 1.3, target: 1.8, status: 'good' }
      },
      performance: {
        loadTime: 1850,
        domReady: 980,
        firstByte: 230,
        interactive: 1650,
        score: 92
      },
      traffic: {
        totalUsers: 15420,
        activeUsers: 1823,
        bounceRate: 23.5,
        avgSessionDuration: '2m 45s',
        pageViews: 45230
      },
      errors: {
        total: 12,
        critical: 2,
        warnings: 7,
        notices: 3
      }
    });
  }, [timeRange, selectedEnvironment]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    // Simulate API call
    setTimeout(() => {
      setIsRefreshing(false);
    }, 2000);
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'metrics', label: 'Metrics', icon: TrendingUp },
    { id: 'code-analysis', label: 'Code Analysis', icon: Activity },
    { id: 'bundle', label: 'Bundle Analyzer', icon: Zap },
    { id: 'journey', label: 'User Journey', icon: Users },
    { id: 'testing', label: 'A/B Testing', icon: Globe },
    { id: 'alerts', label: 'Alerts', icon: AlertTriangle },
    { id: 'recommendations', label: 'Optimization', icon: CheckCircle }
  ];

  const timeRanges = [
    { value: '1h', label: '1 Hour' },
    { value: '24h', label: '24 Hours' },
    { value: '7d', label: '7 Days' },
    { value: '30d', label: '30 Days' },
    { value: '90d', label: '90 Days' }
  ];

  const environments = [
    { value: 'production', label: 'Production' },
    { value: 'staging', label: 'Staging' },
    { value: 'development', label: 'Development' }
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar onToggleCollapse={handleSidebarToggle} />
      <div className="flex-1 flex flex-col">
        <Header />
        
        <div className="flex-1 flex flex-col">
          {/* Analytics Header */}
          <div className="bg-white border-b border-gray-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <h1 className="text-2xl font-bold text-gray-900">
                  Performance Analytics Center
                </h1>
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${
                    performanceData?.performance?.score >= 90 ? 'bg-green-500' :
                    performanceData?.performance?.score >= 70 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}></div>
                  <span className="text-sm text-gray-600">
                    Performance Score: {performanceData?.performance?.score || 0}/100
                  </span>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                {/* Environment Selector */}
                <select
                  value={selectedEnvironment}
                  onChange={(e) => setSelectedEnvironment(e?.target?.value)}
                  className="text-sm border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {environments?.map(env => (
                    <option key={env.value} value={env.value}>{env.label}</option>
                  ))}
                </select>
                
                {/* Time Range Selector */}
                <select
                  value={timeRange}
                  onChange={(e) => setTimeRange(e?.target?.value)}
                  className="text-sm border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {timeRanges?.map(range => (
                    <option key={range?.value} value={range?.value}>{range?.label}</option>
                  ))}
                </select>
                
                {/* Action Buttons */}
                <button
                  onClick={handleRefresh}
                  disabled={isRefreshing}
                  className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-50"
                >
                  <RefreshCw className={`w-5 h-5 ${isRefreshing ? 'animate-spin' : ''}`} />
                </button>
                
                <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
                  <Download className="w-5 h-5" />
                </button>
                
                <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
                  <Settings className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="bg-white border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {tabs?.map((tab) => {
                const TabIcon = tab?.icon;
                const isActive = activeTab === tab?.id;
                
                return (
                  <button
                    key={tab?.id}
                    onClick={() => setActiveTab(tab?.id)}
                    className={`relative flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                      isActive
                        ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <TabIcon className="w-4 h-4" />
                    <span>{tab?.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1 p-6 overflow-auto">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <PerformanceScorecard data={performanceData} />
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <MetricsCharts timeRange={timeRange} />
                  <MonitoringAlerts environment={selectedEnvironment} />
                </div>
              </div>
            )}
            
            {activeTab === 'metrics' && (
              <MetricsCharts 
                timeRange={timeRange} 
                environment={selectedEnvironment}
                fullView 
              />
            )}
            
            {activeTab === 'code-analysis' && (
              <CodeAnalysisPanel environment={selectedEnvironment} />
            )}
            
            {activeTab === 'bundle' && (
              <BundleAnalyzer environment={selectedEnvironment} />
            )}
            
            {activeTab === 'journey' && (
              <UserJourneyMapping 
                timeRange={timeRange}
                environment={selectedEnvironment}
              />
            )}
            
            {activeTab === 'testing' && (
              <ABTestingFramework environment={selectedEnvironment} />
            )}
            
            {activeTab === 'alerts' && (
              <MonitoringAlerts 
                environment={selectedEnvironment}
                fullView 
              />
            )}
            
            {activeTab === 'recommendations' && (
              <OptimizationRecommendations 
                performanceData={performanceData}
                environment={selectedEnvironment}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceAnalyticsCenter;