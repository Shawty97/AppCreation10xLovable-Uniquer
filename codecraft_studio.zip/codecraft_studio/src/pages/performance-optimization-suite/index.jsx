import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Activity, Target, AlertTriangle, Clock, Database, ChevronRight, BarChart3, Gauge, Cpu, HardDrive, Eye, Users } from 'lucide-react';
import CoreWebVitalsMonitor from './components/CoreWebVitalsMonitor';
import CodeAnalysisEngine from './components/CodeAnalysisEngine';
import BundleOptimizer from './components/BundleOptimizer';
import DatabaseQueryOptimizer from './components/DatabaseQueryOptimizer';
import UserExperienceMonitor from './components/UserExperienceMonitor';
import ABTestingFramework from './components/ABTestingFramework';
import MonitoringAlerts from './components/MonitoringAlerts';

import MobilePerformanceIndicators from './components/MobilePerformanceIndicators';
import Icon from '../../components/AppIcon';


const PerformanceOptimizationSuite = () => {
  const [activeSection, setActiveSection] = useState('overview');
  const [performanceData, setPerformanceData] = useState(null);
  const [optimizationRecommendations, setOptimizationRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    loadPerformanceData();
  }, []);

  const loadPerformanceData = async () => {
    try {
      // Simulate loading performance data from Supabase
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setPerformanceData({
        coreWebVitals: {
          lcp: 2.5,
          fid: 100,
          cls: 0.1,
          fcp: 1.8,
          ttfb: 200
        },
        lighthouse: {
          performance: 95,
          accessibility: 98,
          bestPractices: 92,
          seo: 96
        },
        bundleSize: {
          total: 245.6,
          javascript: 156.2,
          css: 45.8,
          images: 43.6
        },
        pageLoad: {
          average: 1850,
          p95: 3200,
          p99: 5100
        }
      });

      setOptimizationRecommendations([
        {
          id: 1,
          type: 'critical',
          category: 'Bundle Optimization',
          title: 'Remove unused CSS',
          impact: 'High',
          savings: '23.4 KB',
          effort: 'Low'
        },
        {
          id: 2,
          type: 'warning',
          category: 'Image Optimization',
          title: 'Compress images with WebP',
          impact: 'Medium',
          savings: '156 KB',
          effort: 'Medium'
        },
        {
          id: 3,
          type: 'info',
          category: 'Code Splitting',
          title: 'Implement route-based splitting',
          impact: 'High',
          savings: '89.2 KB',
          effort: 'High'
        }
      ]);
      
      setLoading(false);
    } catch (error) {
      console.error('Error loading performance data:', error);
      setLoading(false);
    }
  };

  const sectionConfigs = {
    overview: {
      title: 'Performance Overview',
      icon: Activity,
      description: 'Comprehensive performance analytics dashboard'
    },
    vitals: {
      title: 'Core Web Vitals',
      icon: Target,
      description: 'Real-time monitoring of Google Core Web Vitals'
    },
    code: {
      title: 'Code Analysis',
      icon: Cpu,
      description: 'Automated code quality and performance analysis'
    },
    bundle: {
      title: 'Bundle Optimization',
      icon: HardDrive,
      description: 'Asset compression and code splitting tools'
    },
    database: {
      title: 'Database Optimization',
      icon: Database,
      description: 'Query analysis and indexing strategies'
    },
    ux: {
      title: 'User Experience',
      icon: Users,
      description: 'Conversion and engagement metrics'
    },
    testing: {
      title: 'A/B Testing',
      icon: BarChart3,
      description: 'Performance optimization experiments'
    },
    alerts: {
      title: 'Monitoring Alerts',
      icon: AlertTriangle,
      description: 'Proactive performance notifications'
    }
  };

  const renderOverviewSection = () => (
    <div className="space-y-8">
      {/* Performance Score Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-6 shadow-lg border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-green-100 rounded-lg">
              <Gauge className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-2xl font-bold text-green-600">
              {performanceData?.lighthouse?.performance || 0}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-1">Performance Score</h3>
          <p className="text-sm text-gray-600">Lighthouse performance rating</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl p-6 shadow-lg border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-100 rounded-lg">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-2xl font-bold text-blue-600">
              {performanceData?.pageLoad?.average || 0}ms
            </span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-1">Load Time</h3>
          <p className="text-sm text-gray-600">Average page load speed</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl p-6 shadow-lg border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-purple-100 rounded-lg">
              <HardDrive className="w-6 h-6 text-purple-600" />
            </div>
            <span className="text-2xl font-bold text-purple-600">
              {performanceData?.bundleSize?.total || 0}KB
            </span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-1">Bundle Size</h3>
          <p className="text-sm text-gray-600">Total application size</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-xl p-6 shadow-lg border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-yellow-100 rounded-lg">
              <Eye className="w-6 h-6 text-yellow-600" />
            </div>
            <span className="text-2xl font-bold text-yellow-600">
              {performanceData?.coreWebVitals?.cls || 0}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-1">Visual Stability</h3>
          <p className="text-sm text-gray-600">Cumulative Layout Shift</p>
        </motion.div>
      </div>

      {/* Quick Recommendations */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900">Optimization Recommendations</h2>
          <button className="text-indigo-600 hover:text-indigo-700 font-medium">
            View All
          </button>
        </div>
        <div className="space-y-4">
          {optimizationRecommendations?.slice(0, 3)?.map((rec) => (
            <motion.div
              key={rec?.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center space-x-4">
                <div className={`w-3 h-3 rounded-full ${
                  rec?.type === 'critical' ? 'bg-red-500' :
                  rec?.type === 'warning'? 'bg-yellow-500' : 'bg-blue-500'
                }`} />
                <div>
                  <h4 className="font-medium text-gray-900">{rec?.title}</h4>
                  <p className="text-sm text-gray-600">{rec?.category} • Savings: {rec?.savings}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-1 text-xs rounded-full ${
                  rec?.impact === 'High' ? 'bg-red-100 text-red-700' :
                  rec?.impact === 'Medium'? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'
                }`}>
                  {rec?.impact} Impact
                </span>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderMobileView = () => (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Header */}
      <div className="bg-white shadow-sm border-b border-gray-200 p-4">
        <h1 className="text-lg font-bold text-gray-900">Performance Suite</h1>
        <p className="text-sm text-gray-600">Optimize your app performance</p>
      </div>

      {/* Mobile Performance Cards */}
      <div className="p-4 space-y-4">
        <div className="bg-white rounded-lg p-4 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-900">Performance Score</h3>
            <span className="text-xl font-bold text-green-600">
              {performanceData?.lighthouse?.performance || 0}
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-green-600 h-2 rounded-full"
              style={{ width: `${performanceData?.lighthouse?.performance || 0}%` }}
            />
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 shadow-sm">
          <h3 className="font-semibold text-gray-900 mb-3">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            <button 
              onClick={() => setActiveSection('vitals')}
              className="p-3 bg-blue-50 rounded-lg text-center"
            >
              <Target className="w-6 h-6 text-blue-600 mx-auto mb-1" />
              <span className="text-sm font-medium text-blue-900">Web Vitals</span>
            </button>
            <button 
              onClick={() => setActiveSection('code')}
              className="p-3 bg-purple-50 rounded-lg text-center"
            >
              <Cpu className="w-6 h-6 text-purple-600 mx-auto mb-1" />
              <span className="text-sm font-medium text-purple-900">Code Analysis</span>
            </button>
          </div>
        </div>

        <MobilePerformanceIndicators performanceData={performanceData} />
      </div>
    </div>
  );

  const renderDesktopContent = () => (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Zap className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Performance Optimization Suite</h1>
              <p className="text-gray-600">Advanced application performance analysis and optimization tools</p>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="mb-8">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8 overflow-x-auto">
              {Object.entries(sectionConfigs)?.map(([key, config]) => {
                const Icon = config?.icon;
                return (
                  <button
                    key={key}
                    onClick={() => setActiveSection(key)}
                    className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                      activeSection === key
                        ? 'border-indigo-500 text-indigo-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{config?.title}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Content Area */}
        <div className="space-y-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {activeSection === 'overview' && renderOverviewSection()}
              {activeSection === 'vitals' && <CoreWebVitalsMonitor performanceData={performanceData} />}
              {activeSection === 'code' && <CodeAnalysisEngine />}
              {activeSection === 'bundle' && <BundleOptimizer performanceData={performanceData} />}
              {activeSection === 'database' && <DatabaseQueryOptimizer />}
              {activeSection === 'ux' && <UserExperienceMonitor />}
              {activeSection === 'testing' && <ABTestingFramework />}
              {activeSection === 'alerts' && <MonitoringAlerts />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600 mx-auto"></div>
          <h2 className="text-xl font-semibold text-gray-900 mt-4">Loading Performance Data...</h2>
          <p className="text-gray-600 mt-2">Analyzing your application performance</p>
        </div>
      </div>
    );
  }

  return isMobile ? renderMobileView() : renderDesktopContent();
};

export default PerformanceOptimizationSuite;