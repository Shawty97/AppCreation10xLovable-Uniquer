import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bell, AlertTriangle, CheckCircle, Info, Clock, Activity, Settings, Plus, X, Mail, Smartphone, Slack } from 'lucide-react';

const MonitoringAlerts = () => {
  const [alerts, setAlerts] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState('all');
  const [showCreateAlert, setShowCreateAlert] = useState(false);

  useEffect(() => {
    loadAlerts();
  }, []);

  const loadAlerts = async () => {
    try {
      // Simulate loading alerts data
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setAlerts({
        active: [
          {
            id: 1,
            title: 'High Page Load Time',
            description: 'Average page load time exceeded 3 seconds',
            severity: 'critical',
            metric: 'Page Load Time',
            threshold: '3s',
            currentValue: '3.8s',
            triggered: '2025-01-14T19:45:00Z',
            frequency: 'immediate',
            channels: ['email', 'slack'],
            affectedUsers: 2340
          },
          {
            id: 2,
            title: 'Bundle Size Increase',
            description: 'JavaScript bundle size increased by 15% in latest deployment',
            severity: 'warning',
            metric: 'Bundle Size',
            threshold: '250KB',
            currentValue: '287KB',
            triggered: '2025-01-14T18:30:00Z',
            frequency: 'daily',
            channels: ['email'],
            affectedUsers: null
          },
          {
            id: 3,
            title: 'Low Lighthouse Score',
            description: 'Performance score dropped below 90',
            severity: 'warning',
            metric: 'Lighthouse Performance',
            threshold: '90',
            currentValue: '87',
            triggered: '2025-01-14T17:15:00Z',
            frequency: 'weekly',
            channels: ['email', 'sms'],
            affectedUsers: null
          }
        ],
        resolved: [
          {
            id: 4,
            title: 'Database Query Timeout',
            description: 'Query execution time returned to normal levels',
            severity: 'critical',
            metric: 'Query Response Time',
            threshold: '500ms',
            resolvedValue: '234ms',
            triggered: '2025-01-14T16:00:00Z',
            resolved: '2025-01-14T16:45:00Z',
            duration: '45 minutes'
          },
          {
            id: 5,
            title: 'High Error Rate',
            description: 'JavaScript error rate decreased below threshold',
            severity: 'warning',
            metric: 'Error Rate',
            threshold: '2%',
            resolvedValue: '0.8%',
            triggered: '2025-01-14T14:20:00Z',
            resolved: '2025-01-14T15:10:00Z',
            duration: '50 minutes'
          }
        ],
        rules: [
          {
            id: 1,
            name: 'Core Web Vitals Monitoring',
            description: 'Monitor LCP, FID, and CLS metrics',
            enabled: true,
            conditions: [
              { metric: 'LCP', operator: '>', threshold: '2.5s' },
              { metric: 'FID', operator: '>', threshold: '100ms' },
              { metric: 'CLS', operator: '>', threshold: '0.1' }
            ],
            channels: ['email', 'slack'],
            frequency: 'immediate'
          },
          {
            id: 2,
            name: 'Bundle Size Watch',
            description: 'Alert when bundle size increases significantly',
            enabled: true,
            conditions: [
              { metric: 'Bundle Size', operator: 'increases_by', threshold: '10%' }
            ],
            channels: ['email'],
            frequency: 'daily'
          },
          {
            id: 3,
            name: 'Performance Score Degradation',
            description: 'Monitor overall performance score drops',
            enabled: false,
            conditions: [
              { metric: 'Lighthouse Score', operator: '<', threshold: '85' }
            ],
            channels: ['email', 'sms'],
            frequency: 'weekly'
          }
        ]
      });
      
      setLoading(false);
    } catch (error) {
      console.error('Error loading alerts:', error);
      setLoading(false);
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'text-red-600 bg-red-100 border-red-200';
      case 'warning': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'info': return 'text-blue-600 bg-blue-100 border-blue-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'critical': return AlertTriangle;
      case 'warning': return Info;
      case 'info': return CheckCircle;
      default: return Bell;
    }
  };

  const getChannelIcon = (channel) => {
    switch (channel) {
      case 'email': return Mail;
      case 'sms': return Smartphone;
      case 'slack': return Slack;
      default: return Bell;
    }
  };

  const formatTimeAgo = (dateString) => {
    const now = new Date();
    const alertTime = new Date(dateString);
    const diffInMinutes = Math.floor((now - alertTime) / (1000 * 60));
    
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  const renderAlertCard = (alert, isResolved = false) => {
    const SeverityIcon = getSeverityIcon(alert?.severity);
    
    return (
      <motion.div
        key={alert?.id}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`bg-white rounded-lg p-6 border-l-4 ${getSeverityColor(alert?.severity)} shadow-sm`}
      >
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-4">
            <div className={`p-2 rounded-lg ${getSeverityColor(alert?.severity)?.replace('border-', 'bg-')?.replace('text-', 'text-')}`}>
              <SeverityIcon className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-2">
                <h3 className="font-semibold text-gray-900">{alert?.title}</h3>
                <span className={`px-2 py-1 text-xs rounded-full ${getSeverityColor(alert?.severity)}`}>
                  {alert?.severity}
                </span>
              </div>
              <p className="text-gray-600 mb-3">{alert?.description}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <div className="text-sm text-gray-600">Metric</div>
                  <div className="font-medium text-gray-900">{alert?.metric}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Threshold</div>
                  <div className="font-medium text-gray-900">{alert?.threshold}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Current Value</div>
                  <div className={`font-medium ${isResolved ? 'text-green-600' : 'text-red-600'}`}>
                    {isResolved ? alert?.resolvedValue : alert?.currentValue}
                  </div>
                </div>
                {alert?.affectedUsers && (
                  <div>
                    <div className="text-sm text-gray-600">Affected Users</div>
                    <div className="font-medium text-gray-900">{alert?.affectedUsers?.toLocaleString()}</div>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <span>Triggered: {formatTimeAgo(alert?.triggered)}</span>
                  {isResolved && alert?.resolved && (
                    <span>Resolved: {formatTimeAgo(alert?.resolved)} ({alert?.duration})</span>
                  )}
                </div>
                {alert?.channels && (
                  <div className="flex items-center space-x-2">
                    {alert?.channels?.map((channel) => {
                      const ChannelIcon = getChannelIcon(channel);
                      return (
                        <div key={channel} className="p-1 bg-gray-100 rounded">
                          <ChannelIcon className="w-3 h-3 text-gray-600" />
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {!isResolved && (
              <button className="text-gray-400 hover:text-green-600">
                <CheckCircle className="w-5 h-5" />
              </button>
            )}
            <button className="text-gray-400 hover:text-gray-600">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      </motion.div>
    );
  };

  const renderAlertRules = () => (
    <div className="space-y-4">
      {alerts?.rules?.map((rule) => (
        <motion.div
          key={rule?.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg p-6 border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-semibold text-gray-900">{rule?.name}</h3>
              <p className="text-sm text-gray-600">{rule?.description}</p>
            </div>
            <div className="flex items-center space-x-3">
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={rule?.enabled}
                  className="sr-only peer"
                  onChange={() => {
                    // Handle toggle
                  }}
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
              </label>
              <button className="text-gray-400 hover:text-gray-600">
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <div className="text-sm font-medium text-gray-700 mb-2">Conditions</div>
              <div className="space-y-1">
                {rule?.conditions?.map((condition, index) => (
                  <div key={index} className="text-sm text-gray-600 bg-gray-50 rounded px-3 py-2">
                    {condition?.metric} {condition?.operator} {condition?.threshold}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <div>
                <span className="text-gray-600">Channels: </span>
                <div className="inline-flex items-center space-x-1">
                  {rule?.channels?.map((channel) => {
                    const ChannelIcon = getChannelIcon(channel);
                    return (
                      <div key={channel} className="p-1 bg-gray-100 rounded">
                        <ChannelIcon className="w-3 h-3 text-gray-600" />
                      </div>
                    );
                  })}
                </div>
              </div>
              <div>
                <span className="text-gray-600">Frequency: </span>
                <span className="font-medium text-gray-900 capitalize">{rule?.frequency}</span>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mb-4"></div>
        <h3 className="text-lg font-medium text-gray-900">Loading Alerts...</h3>
        <p className="text-gray-600 mt-1">Checking monitoring status and notifications</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Monitoring Alerts</h2>
          <p className="text-gray-600 mt-1">Proactive performance monitoring with automated notifications</p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setShowCreateAlert(true)}
            className="flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"
          >
            <Plus className="w-4 h-4" />
            <span>New Alert Rule</span>
          </button>
        </div>
      </div>
      {/* Alert Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <div className="p-2 bg-red-100 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-red-600" />
            </div>
            <span className="text-2xl font-bold text-red-600">
              {alerts?.active?.filter(a => a?.severity === 'critical')?.length || 0}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900">Critical Alerts</h3>
          <p className="text-sm text-gray-600">Require immediate attention</p>
        </div>

        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <div className="p-2 bg-yellow-100 rounded-lg">
              <Info className="w-5 h-5 text-yellow-600" />
            </div>
            <span className="text-2xl font-bold text-yellow-600">
              {alerts?.active?.filter(a => a?.severity === 'warning')?.length || 0}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900">Warnings</h3>
          <p className="text-sm text-gray-600">Performance degradation</p>
        </div>

        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <div className="p-2 bg-green-100 rounded-lg">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <span className="text-2xl font-bold text-green-600">
              {alerts?.resolved?.length || 0}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900">Resolved Today</h3>
          <p className="text-sm text-gray-600">Issues fixed</p>
        </div>

        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Activity className="w-5 h-5 text-blue-600" />
            </div>
            <span className="text-2xl font-bold text-blue-600">
              {alerts?.rules?.filter(r => r?.enabled)?.length || 0}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900">Active Rules</h3>
          <p className="text-sm text-gray-600">Monitoring conditions</p>
        </div>
      </div>
      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {[
            { key: 'active', label: 'Active Alerts', count: alerts?.active?.length },
            { key: 'resolved', label: 'Resolved', count: alerts?.resolved?.length },
            { key: 'rules', label: 'Alert Rules', count: alerts?.rules?.length }
          ]?.map(({ key, label, count }) => (
            <button
              key={key}
              onClick={() => setActiveFilter(key)}
              className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm ${
                activeFilter === key
                  ? 'border-indigo-500 text-indigo-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <span>{label}</span>
              {count > 0 && (
                <span className="bg-gray-200 text-gray-700 px-2 py-0.5 rounded-full text-xs">
                  {count}
                </span>
              )}
            </button>
          ))}
        </nav>
      </div>
      {/* Content */}
      <div className="space-y-4">
        {activeFilter === 'active' && (
          <>
            {alerts?.active?.length > 0 ? (
              alerts?.active?.map(alert => renderAlertCard(alert, false))
            ) : (
              <div className="text-center py-12">
                <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900">All Clear!</h3>
                <p className="text-gray-600 mt-1">No active alerts at the moment</p>
              </div>
            )}
          </>
        )}

        {activeFilter === 'resolved' && (
          <>
            {alerts?.resolved?.length > 0 ? (
              alerts?.resolved?.map(alert => renderAlertCard(alert, true))
            ) : (
              <div className="text-center py-12">
                <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900">No Resolved Alerts</h3>
                <p className="text-gray-600 mt-1">No alerts have been resolved recently</p>
              </div>
            )}
          </>
        )}

        {activeFilter === 'rules' && renderAlertRules()}
      </div>
    </div>
  );
};

export default MonitoringAlerts;