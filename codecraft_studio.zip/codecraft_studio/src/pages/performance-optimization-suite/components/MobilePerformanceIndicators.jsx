import React, { useState, useEffect } from 'react';

import { Smartphone, Wifi, Signal, Clock, Eye, Activity, AlertCircle, CheckCircle } from 'lucide-react';

const MobilePerformanceIndicators = ({ performanceData }) => {
  const [mobileMetrics, setMobileMetrics] = useState(null);
  const [networkCondition, setNetworkCondition] = useState('4g');

  useEffect(() => {
    loadMobileMetrics();
  }, [performanceData]);

  const loadMobileMetrics = () => {
    // Process performance data for mobile-specific metrics
    setMobileMetrics({
      coreVitals: {
        lcp: performanceData?.coreWebVitals?.lcp || 3.2,
        fid: performanceData?.coreWebVitals?.fid || 120,
        cls: performanceData?.coreWebVitals?.cls || 0.12
      },
      mobileSpecific: {
        firstPaint: 1.8,
        timeToInteractive: 3.5,
        totalBlockingTime: 180,
        speedIndex: 2.1
      },
      networkImpact: {
        '3g': { lcp: 4.8, fid: 200, cls: 0.15 },
        '4g': { lcp: 3.2, fid: 120, cls: 0.12 },
        'wifi': { lcp: 2.1, fid: 80, cls: 0.08 }
      },
      deviceTypes: {
        'high-end': { score: 92, lcp: 2.1, fid: 80 },
        'mid-range': { score: 85, lcp: 3.2, fid: 120 },
        'low-end': { score: 71, lcp: 4.8, fid: 200 }
      }
    });
  };

  const getVitalStatus = (metric, value) => {
    const thresholds = {
      lcp: { good: 2.5, poor: 4.0 },
      fid: { good: 100, poor: 300 },
      cls: { good: 0.1, poor: 0.25 }
    };

    const threshold = thresholds?.[metric];
    if (!threshold) return 'good';

    if (value <= threshold?.good) return 'good';
    if (value <= threshold?.poor) return 'needs-improvement';
    return 'poor';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'good': return 'text-green-600 bg-green-100';
      case 'needs-improvement': return 'text-yellow-600 bg-yellow-100';
      case 'poor': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'good': return CheckCircle;
      case 'needs-improvement': return AlertCircle;
      case 'poor': return AlertCircle;
      default: return Activity;
    }
  };

  const getNetworkIcon = (network) => {
    switch (network) {
      case '3g': return Signal;
      case '4g': return Wifi;
      case 'wifi': return Wifi;
      default: return Signal;
    }
  };

  return (
    <div className="space-y-4">
      {/* Mobile Performance Score */}
      <div className="bg-white rounded-lg p-4 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Smartphone className="w-5 h-5 text-indigo-600" />
            <h3 className="font-semibold text-gray-900">Mobile Performance</h3>
          </div>
          <div className="text-right">
            <div className="text-xl font-bold text-indigo-600">
              {mobileMetrics?.deviceTypes?.['mid-range']?.score || 85}
            </div>
            <div className="text-xs text-gray-600">Score</div>
          </div>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-2 mb-3">
          <div 
            className="bg-indigo-600 h-2 rounded-full"
            style={{ width: `${mobileMetrics?.deviceTypes?.['mid-range']?.score || 85}%` }}
          />
        </div>
        
        <div className="text-xs text-gray-600">
          Optimized for mid-range mobile devices
        </div>
      </div>
      {/* Core Web Vitals - Mobile */}
      <div className="bg-white rounded-lg p-4 shadow-sm">
        <h4 className="font-medium text-gray-900 mb-3">Core Web Vitals</h4>
        <div className="space-y-3">
          {/* LCP */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-gray-600" />
              <span className="text-sm text-gray-700">LCP</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium">
                {mobileMetrics?.coreVitals?.lcp?.toFixed(1) || '3.2'}s
              </span>
              <div className={`w-3 h-3 rounded-full ${
                getVitalStatus('lcp', mobileMetrics?.coreVitals?.lcp)?.includes('good') ? 'bg-green-500' :
                getVitalStatus('lcp', mobileMetrics?.coreVitals?.lcp)?.includes('needs') ? 'bg-yellow-500' :
                'bg-red-500'
              }`} />
            </div>
          </div>

          {/* FID */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-gray-600" />
              <span className="text-sm text-gray-700">FID</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium">
                {mobileMetrics?.coreVitals?.fid || 120}ms
              </span>
              <div className={`w-3 h-3 rounded-full ${
                getVitalStatus('fid', mobileMetrics?.coreVitals?.fid)?.includes('good') ? 'bg-green-500' :
                getVitalStatus('fid', mobileMetrics?.coreVitals?.fid)?.includes('needs') ? 'bg-yellow-500' :
                'bg-red-500'
              }`} />
            </div>
          </div>

          {/* CLS */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Eye className="w-4 h-4 text-gray-600" />
              <span className="text-sm text-gray-700">CLS</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium">
                {mobileMetrics?.coreVitals?.cls?.toFixed(3) || '0.120'}
              </span>
              <div className={`w-3 h-3 rounded-full ${
                getVitalStatus('cls', mobileMetrics?.coreVitals?.cls)?.includes('good') ? 'bg-green-500' :
                getVitalStatus('cls', mobileMetrics?.coreVitals?.cls)?.includes('needs') ? 'bg-yellow-500' :
                'bg-red-500'
              }`} />
            </div>
          </div>
        </div>
      </div>
      {/* Network Impact */}
      <div className="bg-white rounded-lg p-4 shadow-sm">
        <h4 className="font-medium text-gray-900 mb-3">Network Impact</h4>
        <div className="space-y-2">
          {Object.entries(mobileMetrics?.networkImpact || {})?.map(([network, metrics]) => {
            const NetworkIcon = getNetworkIcon(network);
            const isSelected = networkCondition === network;
            
            return (
              <button
                key={network}
                onClick={() => setNetworkCondition(network)}
                className={`w-full flex items-center justify-between p-2 rounded-lg transition-colors ${
                  isSelected ? 'bg-indigo-50 border border-indigo-200' : 'hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <NetworkIcon className={`w-4 h-4 ${isSelected ? 'text-indigo-600' : 'text-gray-600'}`} />
                  <span className={`text-sm font-medium ${isSelected ? 'text-indigo-900' : 'text-gray-700'}`}>
                    {network?.toUpperCase()}
                  </span>
                </div>
                <div className="text-xs text-gray-600">
                  {metrics?.lcp?.toFixed(1)}s LCP
                </div>
              </button>
            );
          })}
        </div>
      </div>
      {/* Device Performance */}
      <div className="bg-white rounded-lg p-4 shadow-sm">
        <h4 className="font-medium text-gray-900 mb-3">Device Segments</h4>
        <div className="space-y-3">
          {Object.entries(mobileMetrics?.deviceTypes || {})?.map(([device, metrics]) => (
            <div key={device} className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-gray-900 capitalize">
                  {device?.replace('-', ' ')} Device
                </div>
                <div className="text-xs text-gray-600">
                  LCP: {metrics?.lcp?.toFixed(1)}s • FID: {metrics?.fid}ms
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-bold text-gray-900">{metrics?.score}</div>
                <div className="text-xs text-gray-600">Score</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Mobile Optimization Tips */}
      <div className="bg-blue-50 rounded-lg p-4">
        <h4 className="font-medium text-blue-900 mb-2">Mobile Optimization Tips</h4>
        <div className="space-y-2 text-sm text-blue-800">
          <div className="flex items-start space-x-2">
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2"></div>
            <span>Optimize images for mobile screens and bandwidth</span>
          </div>
          <div className="flex items-start space-x-2">
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2"></div>
            <span>Minimize JavaScript for faster parsing</span>
          </div>
          <div className="flex items-start space-x-2">
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2"></div>
            <span>Use responsive design to avoid layout shifts</span>
          </div>
        </div>
      </div>
      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        <button className="bg-indigo-600 text-white p-3 rounded-lg text-sm font-medium hover:bg-indigo-700">
          Test Mobile Speed
        </button>
        <button className="border border-gray-300 text-gray-700 p-3 rounded-lg text-sm font-medium hover:bg-gray-50">
          View Full Report
        </button>
      </div>
    </div>
  );
};

export default MobilePerformanceIndicators;