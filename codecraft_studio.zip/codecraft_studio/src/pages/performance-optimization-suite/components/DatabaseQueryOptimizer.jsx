import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Database, Clock, CheckCircle, BarChart3, Activity, Zap, Target, RefreshCw, Eye, Code } from 'lucide-react';
import Icon from '../../../components/AppIcon';


const DatabaseQueryOptimizer = () => {
  const [queryAnalysis, setQueryAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedQuery, setSelectedQuery] = useState(null);
  const [optimizationResults, setOptimizationResults] = useState({});

  useEffect(() => {
    loadQueryAnalysis();
  }, []);

  const loadQueryAnalysis = async () => {
    try {
      // Simulate database query analysis
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setQueryAnalysis({
        summary: {
          totalQueries: 1247,
          slowQueries: 23,
          averageResponseTime: 145,
          indexCoverage: 78.5,
          cacheHitRatio: 92.3
        },
        slowQueries: [
          {
            id: 1,
            query: 'SELECT * FROM user_profiles JOIN projects ON user_profiles.id = projects.user_id WHERE projects.status = \'active\' ORDER BY projects.created_at DESC',
            executionTime: 847,
            frequency: 156,
            table: 'user_profiles, projects',
            impact: 'high',
            optimization: 'Add index on projects.status and projects.created_at'
          },
          {
            id: 2,
            query: 'SELECT deployment_metrics.* FROM deployment_metrics WHERE measured_at > NOW() - INTERVAL \'7 days\' AND project_id IN (SELECT id FROM projects WHERE user_id = $1)',
            executionTime: 623,
            frequency: 89,
            table: 'deployment_metrics, projects',
            impact: 'medium',
            optimization: 'Create composite index on (project_id, measured_at)'
          },
          {
            id: 3,
            query: 'SELECT COUNT(*) FROM ai_conversations WHERE user_id = $1 AND conversation_type = \'voice_creation\' AND created_at >= $2',
            executionTime: 412,
            frequency: 234,
            table: 'ai_conversations',
            impact: 'medium',
            optimization: 'Add partial index on active conversations'
          }
        ],
        indexRecommendations: [
          {
            id: 1,
            table: 'projects',
            columns: ['status', 'created_at'],
            type: 'composite',
            impact: 'high',
            estimatedSpeedup: '340%',
            size: '2.4MB'
          },
          {
            id: 2,
            table: 'deployment_metrics',
            columns: ['project_id', 'measured_at'],
            type: 'composite',
            impact: 'medium',
            estimatedSpeedup: '180%',
            size: '1.8MB'
          },
          {
            id: 3,
            table: 'user_profiles',
            columns: ['role'],
            type: 'btree',
            impact: 'low',
            estimatedSpeedup: '45%',
            size: '0.3MB'
          }
        ],
        queryPatterns: [
          { pattern: 'JOIN operations', count: 342, avgTime: 234 },
          { pattern: 'Text search', count: 156, avgTime: 445 },
          { pattern: 'Aggregate functions', count: 89, avgTime: 178 },
          { pattern: 'Date range queries', count: 267, avgTime: 312 }
        ]
      });
      
      setLoading(false);
    } catch (error) {
      console.error('Error loading query analysis:', error);
      setLoading(false);
    }
  };

  const optimizeQuery = async (queryId) => {
    setOptimizationResults(prev => ({
      ...prev,
      [queryId]: { status: 'optimizing' }
    }));

    // Simulate optimization process
    setTimeout(() => {
      setOptimizationResults(prev => ({
        ...prev,
        [queryId]: { 
          status: 'completed',
          improvement: Math.floor(Math.random() * 200) + 50 + '%',
          newExecutionTime: Math.floor(Math.random() * 100) + 50
        }
      }));
    }, 3000);
  };

  const getImpactColor = (impact) => {
    switch (impact) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg p-6 border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-100 rounded-lg">
              <Database className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-2xl font-bold text-blue-600">
              {queryAnalysis?.summary?.totalQueries?.toLocaleString()}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900">Total Queries</h3>
          <p className="text-sm text-gray-600">Last 24 hours</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-lg p-6 border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-red-100 rounded-lg">
              <Clock className="w-6 h-6 text-red-600" />
            </div>
            <span className="text-2xl font-bold text-red-600">
              {queryAnalysis?.summary?.slowQueries}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900">Slow Queries</h3>
          <p className="text-sm text-gray-600">&gt; 500ms execution time</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-lg p-6 border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-yellow-100 rounded-lg">
              <Activity className="w-6 h-6 text-yellow-600" />
            </div>
            <span className="text-2xl font-bold text-yellow-600">
              {queryAnalysis?.summary?.averageResponseTime}ms
            </span>
          </div>
          <h3 className="font-semibold text-gray-900">Avg Response</h3>
          <p className="text-sm text-gray-600">Query execution time</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-lg p-6 border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-green-100 rounded-lg">
              <Target className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-2xl font-bold text-green-600">
              {queryAnalysis?.summary?.indexCoverage}%
            </span>
          </div>
          <h3 className="font-semibold text-gray-900">Index Coverage</h3>
          <p className="text-sm text-gray-600">Queries using indexes</p>
        </motion.div>
      </div>

      {/* Query Patterns */}
      <div className="bg-white rounded-lg p-6 border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Query Patterns</h3>
        <div className="space-y-4">
          {queryAnalysis?.queryPatterns?.map((pattern, index) => (
            <div key={pattern?.pattern} className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-3 h-3 bg-indigo-500 rounded-full"></div>
                <span className="font-medium text-gray-900">{pattern?.pattern}</span>
              </div>
              <div className="flex items-center space-x-6 text-sm">
                <span className="text-gray-600">{pattern?.count} queries</span>
                <span className="text-gray-600">{pattern?.avgTime}ms avg</span>
                <div className="w-24 bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-indigo-600 h-2 rounded-full"
                    style={{ width: `${(pattern?.avgTime / 500) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderSlowQueriesTab = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Slow Query Analysis</h3>
        <button className="flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
          <RefreshCw className="w-4 h-4" />
          <span>Refresh Analysis</span>
        </button>
      </div>

      <div className="space-y-4">
        {queryAnalysis?.slowQueries?.map((query) => {
          const optimization = optimizationResults?.[query?.id];
          
          return (
            <motion.div
              key={query?.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-lg p-6 border border-gray-200"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <span className={`px-2 py-1 text-xs rounded-full ${getImpactColor(query?.impact)}`}>
                      {query?.impact} impact
                    </span>
                    <span className="text-sm text-gray-600">
                      {query?.executionTime}ms execution time
                    </span>
                    <span className="text-sm text-gray-600">
                      {query?.frequency} calls/day
                    </span>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4 mb-4">
                    <code className="text-sm text-gray-800 font-mono">
                      {query?.query}
                    </code>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-gray-600">
                      <strong>Tables:</strong> {query?.table}
                    </p>
                    <p className="text-sm text-green-700">
                      <strong>Optimization:</strong> {query?.optimization}
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  {optimization?.status === 'completed' && (
                    <div className="flex items-center space-x-2 text-green-600">
                      <CheckCircle className="w-4 h-4" />
                      <span className="text-sm">
                        Optimized - {optimization?.improvement} faster
                      </span>
                    </div>
                  )}
                  {optimization?.status === 'optimizing' && (
                    <div className="flex items-center space-x-2 text-blue-600">
                      <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                      <span className="text-sm">Optimizing...</span>
                    </div>
                  )}
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setSelectedQuery(query)}
                    className="flex items-center space-x-1 text-gray-600 hover:text-gray-900"
                  >
                    <Eye className="w-4 h-4" />
                    <span className="text-sm">Analyze</span>
                  </button>
                  <button
                    onClick={() => optimizeQuery(query?.id)}
                    disabled={optimization?.status === 'optimizing' || optimization?.status === 'completed'}
                    className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                  >
                    {optimization?.status === 'completed' ? 'Optimized' :
                     optimization?.status === 'optimizing' ? 'Optimizing...' : 'Optimize'}
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );

  const renderIndexesTab = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Index Recommendations</h3>
        <div className="text-sm text-gray-600">
          Current index coverage: <span className="font-semibold text-green-600">{queryAnalysis?.summary?.indexCoverage}%</span>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {queryAnalysis?.indexRecommendations?.map((index) => (
          <motion.div
            key={index?.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg p-6 border border-gray-200"
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="font-semibold text-gray-900">
                  {index?.table} ({index?.columns?.join(', ')})
                </h4>
                <p className="text-sm text-gray-600 capitalize">{index?.type} index</p>
              </div>
              <div className="flex items-center space-x-3">
                <span className={`px-2 py-1 text-xs rounded-full ${getImpactColor(index?.impact)}`}>
                  {index?.impact} impact
                </span>
                <span className="text-sm text-gray-600">
                  {index?.estimatedSpeedup} faster
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">
                Estimated size: <span className="font-medium">{index?.size}</span>
              </div>
              <div className="flex items-center space-x-2">
                <button className="flex items-center space-x-1 text-gray-600 hover:text-gray-900">
                  <Code className="w-4 h-4" />
                  <span className="text-sm">View SQL</span>
                </button>
                <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 text-sm">
                  Create Index
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mb-4"></div>
        <h3 className="text-lg font-medium text-gray-900">Analyzing Database Performance...</h3>
        <p className="text-gray-600 mt-1">Scanning queries and identifying optimization opportunities</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Database Query Optimizer</h2>
        <p className="text-gray-600 mt-1">Analyze slow queries, suggest indexing strategies, and optimize database performance</p>
      </div>
      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {[
            { key: 'overview', label: 'Overview', icon: BarChart3 },
            { key: 'queries', label: 'Slow Queries', icon: Clock },
            { key: 'indexes', label: 'Index Recommendations', icon: Zap }
          ]?.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === key
                  ? 'border-indigo-500 text-indigo-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{label}</span>
            </button>
          ))}
        </nav>
      </div>
      {/* Tab Content */}
      <div>
        {activeTab === 'overview' && renderOverviewTab()}
        {activeTab === 'queries' && renderSlowQueriesTab()}
        {activeTab === 'indexes' && renderIndexesTab()}
      </div>
    </div>
  );
};

export default DatabaseQueryOptimizer;