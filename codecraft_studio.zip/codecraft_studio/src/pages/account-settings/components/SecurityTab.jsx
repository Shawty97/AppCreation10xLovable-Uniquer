import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';


const SecurityTab = () => {
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [showQRCode, setShowQRCode] = useState(false);

  const [activeSessions] = useState([
    {
      id: 1,
      device: "MacBook Pro",
      browser: "Chrome 118.0",
      location: "New York, NY",
      ipAddress: "192.168.1.100",
      lastActive: "2025-10-01T14:15:00Z",
      current: true
    },
    {
      id: 2,
      device: "iPhone 15 Pro",
      browser: "Safari Mobile",
      location: "New York, NY",
      ipAddress: "192.168.1.101",
      lastActive: "2025-10-01T12:30:00Z",
      current: false
    },
    {
      id: 3,
      device: "Windows PC",
      browser: "Edge 118.0",
      location: "Boston, MA",
      ipAddress: "10.0.0.50",
      lastActive: "2025-09-30T18:45:00Z",
      current: false
    }
  ]);

  const [loginActivity] = useState([
    {
      id: 1,
      timestamp: "2025-10-01T14:15:00Z",
      action: "Login",
      device: "MacBook Pro",
      location: "New York, NY",
      ipAddress: "192.168.1.100",
      status: "success"
    },
    {
      id: 2,
      timestamp: "2025-10-01T12:30:00Z",
      action: "Login",
      device: "iPhone 15 Pro",
      location: "New York, NY",
      ipAddress: "192.168.1.101",
      status: "success"
    },
    {
      id: 3,
      timestamp: "2025-09-30T18:45:00Z",
      action: "Login",
      device: "Windows PC",
      location: "Boston, MA",
      ipAddress: "10.0.0.50",
      status: "success"
    },
    {
      id: 4,
      timestamp: "2025-09-29T09:20:00Z",
      action: "Failed Login",
      device: "Unknown",
      location: "Unknown Location",
      ipAddress: "203.0.113.1",
      status: "failed"
    }
  ]);

  const handlePasswordChange = (field, value) => {
    setPasswordForm(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePasswordSubmit = async () => {
    if (passwordForm?.newPassword !== passwordForm?.confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    
    setIsChangingPassword(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsChangingPassword(false);
    setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    alert('Password changed successfully');
  };

  const handleEnable2FA = () => {
    setShowQRCode(true);
  };

  const handleConfirm2FA = () => {
    setTwoFactorEnabled(true);
    setShowQRCode(false);
    alert('Two-factor authentication enabled successfully');
  };

  const handleDisable2FA = () => {
    setTwoFactorEnabled(false);
    alert('Two-factor authentication disabled');
  };

  const handleTerminateSession = (sessionId) => {
    alert(`Session ${sessionId} terminated`);
  };

  const formatDateTime = (timestamp) => {
    return new Date(timestamp)?.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'success': return 'text-success';
      case 'failed': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const getDeviceIcon = (device) => {
    if (device?.includes('iPhone') || device?.includes('iPad')) return 'Smartphone';
    if (device?.includes('MacBook') || device?.includes('Mac')) return 'Laptop';
    if (device?.includes('Windows') || device?.includes('PC')) return 'Monitor';
    return 'Globe';
  };

  return (
    <div className="space-y-8">
      {/* Password Change */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
          <Icon name="Lock" size={20} className="mr-2" />
          Change Password
        </h3>
        
        <div className="space-y-4 max-w-md">
          <Input
            label="Current Password"
            type="password"
            value={passwordForm?.currentPassword}
            onChange={(e) => handlePasswordChange('currentPassword', e?.target?.value)}
            placeholder="Enter current password"
            required
          />
          
          <Input
            label="New Password"
            type="password"
            value={passwordForm?.newPassword}
            onChange={(e) => handlePasswordChange('newPassword', e?.target?.value)}
            placeholder="Enter new password"
            description="Must be at least 8 characters with uppercase, lowercase, and numbers"
            required
          />
          
          <Input
            label="Confirm New Password"
            type="password"
            value={passwordForm?.confirmPassword}
            onChange={(e) => handlePasswordChange('confirmPassword', e?.target?.value)}
            placeholder="Confirm new password"
            required
          />
          
          <Button
            variant="default"
            onClick={handlePasswordSubmit}
            loading={isChangingPassword}
            disabled={!passwordForm?.currentPassword || !passwordForm?.newPassword || !passwordForm?.confirmPassword}
            iconName="Save"
            iconPosition="left"
            iconSize={16}
          >
            Update Password
          </Button>
        </div>
      </div>
      {/* Two-Factor Authentication */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
          <Icon name="Shield" size={20} className="mr-2" />
          Two-Factor Authentication
        </h3>
        
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-4">
              <div className={`w-3 h-3 rounded-full ${twoFactorEnabled ? 'bg-success' : 'bg-muted'}`}></div>
              <span className="font-medium text-foreground">
                {twoFactorEnabled ? 'Enabled' : 'Disabled'}
              </span>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Add an extra layer of security to your account by requiring a verification code from your mobile device.
            </p>
            
            {!twoFactorEnabled ? (
              <Button
                variant="default"
                onClick={handleEnable2FA}
                iconName="Plus"
                iconPosition="left"
                iconSize={16}
              >
                Enable 2FA
              </Button>
            ) : (
              <Button
                variant="outline"
                onClick={handleDisable2FA}
                iconName="X"
                iconPosition="left"
                iconSize={16}
              >
                Disable 2FA
              </Button>
            )}
          </div>
          
          <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center">
            <Icon name="Smartphone" size={24} className="text-muted-foreground" />
          </div>
        </div>

        {/* QR Code Modal */}
        {showQRCode && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-card rounded-lg border border-border p-6 max-w-md w-full mx-4">
              <h4 className="text-lg font-semibold text-foreground mb-4">Setup Two-Factor Authentication</h4>
              
              <div className="text-center mb-6">
                <div className="w-48 h-48 bg-muted rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <div className="text-center">
                    <Icon name="QrCode" size={48} className="text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">QR Code</p>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  Scan this QR code with your authenticator app
                </p>
              </div>
              
              <div className="space-y-4">
                <Input
                  label="Verification Code"
                  type="text"
                  placeholder="Enter 6-digit code"
                  description="Enter the code from your authenticator app"
                />
                
                <div className="flex space-x-3">
                  <Button
                    variant="outline"
                    onClick={() => setShowQRCode(false)}
                    fullWidth
                  >
                    Cancel
                  </Button>
                  <Button
                    variant="default"
                    onClick={handleConfirm2FA}
                    fullWidth
                  >
                    Verify & Enable
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      {/* Active Sessions */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
          <Icon name="Monitor" size={20} className="mr-2" />
          Active Sessions
        </h3>
        
        <div className="space-y-4">
          {activeSessions?.map((session) => (
            <div key={session?.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                  <Icon name={getDeviceIcon(session?.device)} size={20} className="text-muted-foreground" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h4 className="font-medium text-foreground">{session?.device}</h4>
                    {session?.current && (
                      <span className="bg-success text-success-foreground px-2 py-1 rounded-full text-xs font-medium">
                        Current
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{session?.browser}</p>
                  <p className="text-sm text-muted-foreground">
                    {session?.location} • {session?.ipAddress}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Last active: {formatDateTime(session?.lastActive)}
                  </p>
                </div>
              </div>
              
              {!session?.current && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleTerminateSession(session?.id)}
                  iconName="X"
                  iconSize={14}
                >
                  Terminate
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>
      {/* Login Activity */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
          <Icon name="Activity" size={20} className="mr-2" />
          Recent Login Activity
        </h3>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Date & Time</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Action</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Device</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Location</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Status</th>
              </tr>
            </thead>
            <tbody>
              {loginActivity?.map((activity) => (
                <tr key={activity?.id} className="border-b border-border hover:bg-muted/50">
                  <td className="py-3 px-4 text-sm text-foreground">
                    {formatDateTime(activity?.timestamp)}
                  </td>
                  <td className="py-3 px-4 text-sm text-foreground">
                    {activity?.action}
                  </td>
                  <td className="py-3 px-4 text-sm text-foreground">
                    {activity?.device}
                  </td>
                  <td className="py-3 px-4 text-sm text-muted-foreground">
                    {activity?.location}
                    <br />
                    <span className="text-xs">{activity?.ipAddress}</span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${
                        activity?.status === 'success' ? 'bg-success' : 'bg-error'
                      }`}></div>
                      <span className={`text-sm font-medium capitalize ${getStatusColor(activity?.status)}`}>
                        {activity?.status}
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SecurityTab;