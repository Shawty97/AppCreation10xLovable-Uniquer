import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

const DataExportTab = () => {
  const [exportOptions, setExportOptions] = useState({
    profile: true,
    projects: true,
    templates: false,
    billing: true,
    activity: false,
    integrations: true
  });

  const [exportHistory] = useState([
    {
      id: 1,
      type: 'Full Account Export',
      requestDate: '2025-09-15T10:30:00Z',
      completedDate: '2025-09-15T10:35:00Z',
      status: 'completed',
      fileSize: '2.4 MB',
      downloadUrl: '#',
      expiresAt: '2025-10-15T10:35:00Z'
    },
    {
      id: 2,
      type: 'Projects Only',
      requestDate: '2025-08-20T14:20:00Z',
      completedDate: '2025-08-20T14:22:00Z',
      status: 'completed',
      fileSize: '1.8 MB',
      downloadUrl: '#',
      expiresAt: '2025-09-20T14:22:00Z'
    },
    {
      id: 3,
      type: 'Billing Data',
      requestDate: '2025-07-10T09:15:00Z',
      completedDate: null,
      status: 'expired',
      fileSize: null,
      downloadUrl: null,
      expiresAt: '2025-08-10T09:15:00Z'
    }
  ]);

  const [isExporting, setIsExporting] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeletingAccount, setIsDeletingAccount] = useState(false);
  const [deleteConfirmation, setDeleteConfirmation] = useState('');

  const dataCategories = [
    {
      key: 'profile',
      label: 'Profile Information',
      description: 'Personal details, preferences, and account settings',
      icon: 'User',
      estimatedSize: '< 1 MB'
    },
    {
      key: 'projects',
      label: 'Projects & Applications',
      description: 'All your created projects, components, and configurations',
      icon: 'FolderOpen',
      estimatedSize: '5-50 MB'
    },
    {
      key: 'templates',
      label: 'Custom Templates',
      description: 'Templates you\'ve created or customized',
      icon: 'Layout',
      estimatedSize: '1-10 MB'
    },
    {
      key: 'billing',
      label: 'Billing & Subscription',
      description: 'Payment history, invoices, and subscription details',
      icon: 'CreditCard',
      estimatedSize: '< 1 MB'
    },
    {
      key: 'activity',
      label: 'Activity Logs',
      description: 'Login history, actions, and usage analytics',
      icon: 'Activity',
      estimatedSize: '1-5 MB'
    },
    {
      key: 'integrations',
      label: 'Integration Settings',
      description: 'Connected services and API configurations',
      icon: 'Plug',
      estimatedSize: '< 1 MB'
    }
  ];

  const handleExportOptionChange = (key, checked) => {
    setExportOptions(prev => ({
      ...prev,
      [key]: checked
    }));
  };

  const handleRequestExport = async () => {
    setIsExporting(true);
    // Simulate export process
    await new Promise(resolve => setTimeout(resolve, 3000));
    setIsExporting(false);
    alert('Export request submitted! You\'ll receive an email when your data is ready for download.');
  };

  const handleDeleteAccount = async () => {
    if (deleteConfirmation !== 'DELETE MY ACCOUNT') {
      alert('Please type "DELETE MY ACCOUNT" to confirm');
      return;
    }
    
    setIsDeletingAccount(true);
    // Simulate account deletion process
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsDeletingAccount(false);
    alert('Account deletion request submitted. You will receive a confirmation email.');
    setShowDeleteModal(false);
    setDeleteConfirmation('');
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'text-success';
      case 'processing': return 'text-warning';
      case 'failed': return 'text-error';
      case 'expired': return 'text-muted-foreground';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed': return 'CheckCircle';
      case 'processing': return 'Clock';
      case 'failed': return 'XCircle';
      case 'expired': return 'AlertCircle';
      default: return 'Circle';
    }
  };

  const formatDateTime = (timestamp) => {
    return new Date(timestamp)?.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const isExportDisabled = !Object.values(exportOptions)?.some(Boolean);
  const selectedCount = Object.values(exportOptions)?.filter(Boolean)?.length;

  return (
    <div className="space-y-8">
      {/* Data Export */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
          <Icon name="Download" size={20} className="mr-2" />
          Export Your Data
        </h3>
        
        <div className="mb-6">
          <p className="text-muted-foreground text-sm mb-4">
            Download a copy of your data in JSON format. Select the categories you want to include in your export.
          </p>
          
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 mb-6">
            <div className="flex items-start space-x-3">
              <Icon name="Info" size={16} className="text-primary mt-0.5" />
              <div>
                <p className="text-sm font-medium text-foreground">GDPR Compliance</p>
                <p className="text-xs text-muted-foreground">
                  You have the right to receive a copy of your personal data in a structured, commonly used format.
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="space-y-4 mb-6">
          {dataCategories?.map((category) => (
            <div key={category?.key} className="flex items-start space-x-4 p-4 border border-border rounded-lg">
              <Checkbox
                checked={exportOptions?.[category?.key]}
                onChange={(e) => handleExportOptionChange(category?.key, e?.target?.checked)}
              />
              
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon name={category?.icon} size={16} className="text-primary" />
                  <h4 className="font-medium text-foreground">{category?.label}</h4>
                  <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
                    {category?.estimatedSize}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">{category?.description}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            {selectedCount} of {dataCategories?.length} categories selected
          </div>
          <Button
            variant="default"
            onClick={handleRequestExport}
            loading={isExporting}
            disabled={isExportDisabled}
            iconName="Download"
            iconPosition="left"
            iconSize={16}
          >
            {isExporting ? 'Preparing Export...' : 'Request Export'}
          </Button>
        </div>
      </div>
      {/* Export History */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
          <Icon name="History" size={20} className="mr-2" />
          Export History
        </h3>
        
        <div className="space-y-4">
          {exportHistory?.map((export_item) => (
            <div key={export_item?.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                  <Icon 
                    name={getStatusIcon(export_item?.status)} 
                    size={20} 
                    className={getStatusColor(export_item?.status)} 
                  />
                </div>
                
                <div>
                  <h4 className="font-medium text-foreground">{export_item?.type}</h4>
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <span>Requested: {formatDateTime(export_item?.requestDate)}</span>
                    {export_item?.completedDate && (
                      <>
                        <span>•</span>
                        <span>Completed: {formatDateTime(export_item?.completedDate)}</span>
                      </>
                    )}
                    {export_item?.fileSize && (
                      <>
                        <span>•</span>
                        <span>{export_item?.fileSize}</span>
                      </>
                    )}
                  </div>
                  <div className="flex items-center space-x-2 mt-1">
                    <span className={`text-xs font-medium capitalize ${getStatusColor(export_item?.status)}`}>
                      {export_item?.status}
                    </span>
                    {export_item?.status === 'completed' && (
                      <>
                        <span className="text-xs text-muted-foreground">•</span>
                        <span className="text-xs text-muted-foreground">
                          Expires: {formatDateTime(export_item?.expiresAt)}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                {export_item?.status === 'completed' && export_item?.downloadUrl && (
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Download"
                    iconSize={14}
                  >
                    Download
                  </Button>
                )}
                {export_item?.status === 'expired' && (
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="RotateCcw"
                    iconSize={14}
                  >
                    Re-export
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Account Deletion */}
      <div className="bg-card rounded-lg border border-error p-6">
        <h3 className="text-lg font-semibold text-error mb-6 flex items-center">
          <Icon name="AlertTriangle" size={20} className="mr-2" />
          Delete Account
        </h3>
        
        <div className="space-y-4">
          <div className="bg-error/5 border border-error/20 rounded-lg p-4">
            <h4 className="font-medium text-foreground mb-2">Before you delete your account:</h4>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li className="flex items-center space-x-2">
                <Icon name="AlertCircle" size={14} className="text-error" />
                <span>All your projects and data will be permanently deleted</span>
              </li>
              <li className="flex items-center space-x-2">
                <Icon name="AlertCircle" size={14} className="text-error" />
                <span>Your subscription will be cancelled immediately</span>
              </li>
              <li className="flex items-center space-x-2">
                <Icon name="AlertCircle" size={14} className="text-error" />
                <span>This action cannot be undone</span>
              </li>
              <li className="flex items-center space-x-2">
                <Icon name="AlertCircle" size={14} className="text-error" />
                <span>You may lose access to shared workspaces</span>
              </li>
            </ul>
          </div>
          
          <div className="bg-muted/50 rounded-lg p-4">
            <h4 className="font-medium text-foreground mb-2">Recommended steps:</h4>
            <ol className="space-y-1 text-sm text-muted-foreground list-decimal list-inside">
              <li>Export your data using the tool above</li>
              <li>Download any important files or projects</li>
              <li>Cancel any active subscriptions</li>
              <li>Inform team members if you're part of shared workspaces</li>
            </ol>
          </div>
          
          <div className="pt-4">
            <Button
              variant="destructive"
              onClick={() => setShowDeleteModal(true)}
              iconName="Trash2"
              iconPosition="left"
              iconSize={16}
            >
              Delete My Account
            </Button>
          </div>
        </div>
      </div>
      {/* Delete Account Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card rounded-lg border border-border p-6 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-lg font-semibold text-error">Delete Account</h4>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowDeleteModal(false)}
                iconName="X"
                iconSize={20}
              />
            </div>
            
            <div className="space-y-4">
              <div className="text-center">
                <div className="w-16 h-16 bg-error/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon name="AlertTriangle" size={32} className="text-error" />
                </div>
                <p className="text-foreground font-medium mb-2">
                  Are you absolutely sure?
                </p>
                <p className="text-sm text-muted-foreground">
                  This action cannot be undone. This will permanently delete your account and remove all your data from our servers.
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Type "DELETE MY ACCOUNT" to confirm:
                </label>
                <input
                  type="text"
                  value={deleteConfirmation}
                  onChange={(e) => setDeleteConfirmation(e?.target?.value)}
                  className="w-full px-3 py-2 border border-border rounded-md text-foreground bg-input focus:outline-none focus:ring-2 focus:ring-error"
                  placeholder="DELETE MY ACCOUNT"
                />
              </div>
              
              <div className="flex space-x-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowDeleteModal(false)}
                  fullWidth
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  onClick={handleDeleteAccount}
                  loading={isDeletingAccount}
                  disabled={deleteConfirmation !== 'DELETE MY ACCOUNT'}
                  fullWidth
                >
                  Delete Account
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DataExportTab;