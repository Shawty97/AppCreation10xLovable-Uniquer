import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const BillingTab = () => {
  const [paymentMethods, setPaymentMethods] = useState([
    {
      id: 1,
      type: 'card',
      brand: 'visa',
      last4: '4242',
      expiryMonth: 12,
      expiryYear: 2027,
      isDefault: true,
      holderName: 'John Doe'
    },
    {
      id: 2,
      type: 'card',
      brand: 'mastercard',
      last4: '8888',
      expiryMonth: 8,
      expiryYear: 2026,
      isDefault: false,
      holderName: 'John Doe'
    }
  ]);

  const [billingAddress, setBillingAddress] = useState({
    name: 'John Doe',
    company: 'Tech Solutions Inc.',
    address1: '123 Main Street',
    address2: 'Suite 100',
    city: 'New York',
    state: 'NY',
    zipCode: '10001',
    country: 'US'
  });

  const [invoices] = useState([
    {
      id: 'INV-2025-001',
      date: '2025-10-01',
      amount: 29.00,
      status: 'paid',
      description: 'Professional Plan - October 2025',
      downloadUrl: '#'
    },
    {
      id: 'INV-2025-002',
      date: '2025-09-01',
      amount: 29.00,
      status: 'paid',
      description: 'Professional Plan - September 2025',
      downloadUrl: '#'
    },
    {
      id: 'INV-2025-003',
      date: '2025-08-01',
      amount: 29.00,
      status: 'paid',
      description: 'Professional Plan - August 2025',
      downloadUrl: '#'
    },
    {
      id: 'INV-2025-004',
      date: '2025-07-01',
      amount: 29.00,
      status: 'paid',
      description: 'Professional Plan - July 2025',
      downloadUrl: '#'
    }
  ]);

  const [showAddCardModal, setShowAddCardModal] = useState(false);
  const [showEditAddressModal, setShowEditAddressModal] = useState(false);
  const [autoRenewal, setAutoRenewal] = useState(true);
  const [emailReceipts, setEmailReceipts] = useState(true);
  const [isAddingCard, setIsAddingCard] = useState(false);
  const [isSavingAddress, setIsSavingAddress] = useState(false);

  const [newCard, setNewCard] = useState({
    number: '',
    expiryMonth: '',
    expiryYear: '',
    cvc: '',
    holderName: '',
    makeDefault: false
  });

  const countryOptions = [
    { value: 'US', label: 'United States' },
    { value: 'CA', label: 'Canada' },
    { value: 'GB', label: 'United Kingdom' },
    { value: 'DE', label: 'Germany' },
    { value: 'FR', label: 'France' },
    { value: 'AU', label: 'Australia' },
    { value: 'JP', label: 'Japan' }
  ];

  const monthOptions = Array.from({ length: 12 }, (_, i) => ({
    value: String(i + 1)?.padStart(2, '0'),
    label: String(i + 1)?.padStart(2, '0')
  }));

  const yearOptions = Array.from({ length: 10 }, (_, i) => {
    const year = new Date()?.getFullYear() + i;
    return { value: String(year), label: String(year) };
  });

  const getCardIcon = (brand) => {
    const icons = {
      visa: 'CreditCard',
      mastercard: 'CreditCard',
      amex: 'CreditCard',
      discover: 'CreditCard'
    };
    return icons?.[brand] || 'CreditCard';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'paid': return 'text-success';
      case 'pending': return 'text-warning';
      case 'failed': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const handleAddCard = async () => {
    setIsAddingCard(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const newPaymentMethod = {
      id: Date.now(),
      type: 'card',
      brand: 'visa', // Would be determined by card number
      last4: newCard?.number?.slice(-4),
      expiryMonth: parseInt(newCard?.expiryMonth),
      expiryYear: parseInt(newCard?.expiryYear),
      isDefault: newCard?.makeDefault,
      holderName: newCard?.holderName
    };
    
    setPaymentMethods(prev => {
      const updated = newCard?.makeDefault 
        ? prev?.map(method => ({ ...method, isDefault: false }))
        : prev;
      return [...updated, newPaymentMethod];
    });
    
    setNewCard({
      number: '',
      expiryMonth: '',
      expiryYear: '',
      cvc: '',
      holderName: '',
      makeDefault: false
    });
    setIsAddingCard(false);
    setShowAddCardModal(false);
  };

  const handleRemoveCard = (cardId) => {
    if (confirm('Are you sure you want to remove this payment method?')) {
      setPaymentMethods(prev => prev?.filter(method => method?.id !== cardId));
    }
  };

  const handleSetDefault = (cardId) => {
    setPaymentMethods(prev => 
      prev?.map(method => ({
        ...method,
        isDefault: method?.id === cardId
      }))
    );
  };

  const handleSaveAddress = async () => {
    setIsSavingAddress(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSavingAddress(false);
    setShowEditAddressModal(false);
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-8">
      {/* Payment Methods */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground flex items-center">
            <Icon name="CreditCard" size={20} className="mr-2" />
            Payment Methods
          </h3>
          <Button
            variant="outline"
            onClick={() => setShowAddCardModal(true)}
            iconName="Plus"
            iconPosition="left"
            iconSize={16}
          >
            Add Card
          </Button>
        </div>
        
        <div className="space-y-4">
          {paymentMethods?.map((method) => (
            <div key={method?.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-8 bg-muted rounded flex items-center justify-center">
                  <Icon name={getCardIcon(method?.brand)} size={20} className="text-muted-foreground" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-medium text-foreground capitalize">
                      {method?.brand} •••• {method?.last4}
                    </span>
                    {method?.isDefault && (
                      <span className="bg-primary text-primary-foreground px-2 py-1 rounded-full text-xs font-medium">
                        Default
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {method?.holderName} • Expires {method?.expiryMonth}/{method?.expiryYear}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                {!method?.isDefault && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSetDefault(method?.id)}
                  >
                    Set Default
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleRemoveCard(method?.id)}
                  iconName="Trash2"
                  iconSize={16}
                  className="text-error hover:text-error hover:bg-error/10"
                />
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Billing Address */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground flex items-center">
            <Icon name="MapPin" size={20} className="mr-2" />
            Billing Address
          </h3>
          <Button
            variant="outline"
            onClick={() => setShowEditAddressModal(true)}
            iconName="Edit"
            iconPosition="left"
            iconSize={16}
          >
            Edit Address
          </Button>
        </div>
        
        <div className="bg-muted/50 rounded-lg p-4">
          <div className="space-y-2">
            <p className="font-medium text-foreground">{billingAddress?.name}</p>
            {billingAddress?.company && (
              <p className="text-foreground">{billingAddress?.company}</p>
            )}
            <p className="text-foreground">{billingAddress?.address1}</p>
            {billingAddress?.address2 && (
              <p className="text-foreground">{billingAddress?.address2}</p>
            )}
            <p className="text-foreground">
              {billingAddress?.city}, {billingAddress?.state} {billingAddress?.zipCode}
            </p>
            <p className="text-foreground">{countryOptions?.find(c => c?.value === billingAddress?.country)?.label}</p>
          </div>
        </div>
      </div>
      {/* Billing Settings */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
          <Icon name="Settings" size={20} className="mr-2" />
          Billing Settings
        </h3>
        
        <div className="space-y-4">
          <Checkbox
            label="Auto-renewal"
            description="Automatically renew your subscription each billing cycle"
            checked={autoRenewal}
            onChange={(e) => setAutoRenewal(e?.target?.checked)}
          />
          
          <Checkbox
            label="Email receipts"
            description="Send payment receipts to your email address"
            checked={emailReceipts}
            onChange={(e) => setEmailReceipts(e?.target?.checked)}
          />
        </div>
      </div>
      {/* Invoice History */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground flex items-center">
            <Icon name="Receipt" size={20} className="mr-2" />
            Invoice History
          </h3>
          <Button
            variant="outline"
            iconName="Download"
            iconPosition="left"
            iconSize={16}
          >
            Download All
          </Button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Invoice</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Date</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Description</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Amount</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Status</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {invoices?.map((invoice) => (
                <tr key={invoice?.id} className="border-b border-border hover:bg-muted/50">
                  <td className="py-3 px-4 text-sm font-medium text-foreground">
                    {invoice?.id}
                  </td>
                  <td className="py-3 px-4 text-sm text-foreground">
                    {formatDate(invoice?.date)}
                  </td>
                  <td className="py-3 px-4 text-sm text-foreground">
                    {invoice?.description}
                  </td>
                  <td className="py-3 px-4 text-sm font-medium text-foreground">
                    ${invoice?.amount?.toFixed(2)}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`text-sm font-medium capitalize ${getStatusColor(invoice?.status)}`}>
                      {invoice?.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      iconName="Download"
                      iconSize={14}
                    >
                      Download
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {/* Add Card Modal */}
      {showAddCardModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card rounded-lg border border-border p-6 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-lg font-semibold text-foreground">Add Payment Method</h4>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowAddCardModal(false)}
                iconName="X"
                iconSize={20}
              />
            </div>
            
            <div className="space-y-4">
              <Input
                label="Card Number"
                type="text"
                value={newCard?.number}
                onChange={(e) => setNewCard(prev => ({ ...prev, number: e?.target?.value }))}
                placeholder="1234 5678 9012 3456"
                required
              />
              
              <Input
                label="Cardholder Name"
                type="text"
                value={newCard?.holderName}
                onChange={(e) => setNewCard(prev => ({ ...prev, holderName: e?.target?.value }))}
                placeholder="John Doe"
                required
              />
              
              <div className="grid grid-cols-3 gap-4">
                <Select
                  label="Month"
                  options={monthOptions}
                  value={newCard?.expiryMonth}
                  onChange={(value) => setNewCard(prev => ({ ...prev, expiryMonth: value }))}
                  placeholder="MM"
                />
                
                <Select
                  label="Year"
                  options={yearOptions}
                  value={newCard?.expiryYear}
                  onChange={(value) => setNewCard(prev => ({ ...prev, expiryYear: value }))}
                  placeholder="YYYY"
                />
                
                <Input
                  label="CVC"
                  type="text"
                  value={newCard?.cvc}
                  onChange={(e) => setNewCard(prev => ({ ...prev, cvc: e?.target?.value }))}
                  placeholder="123"
                  required
                />
              </div>
              
              <Checkbox
                label="Set as default payment method"
                checked={newCard?.makeDefault}
                onChange={(e) => setNewCard(prev => ({ ...prev, makeDefault: e?.target?.checked }))}
              />
              
              <div className="flex space-x-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowAddCardModal(false)}
                  fullWidth
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleAddCard}
                  loading={isAddingCard}
                  disabled={!newCard?.number || !newCard?.holderName || !newCard?.expiryMonth || !newCard?.expiryYear || !newCard?.cvc}
                  fullWidth
                >
                  Add Card
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Edit Address Modal */}
      {showEditAddressModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card rounded-lg border border-border p-6 max-w-lg w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-lg font-semibold text-foreground">Edit Billing Address</h4>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowEditAddressModal(false)}
                iconName="X"
                iconSize={20}
              />
            </div>
            
            <div className="space-y-4">
              <Input
                label="Full Name"
                type="text"
                value={billingAddress?.name}
                onChange={(e) => setBillingAddress(prev => ({ ...prev, name: e?.target?.value }))}
                required
              />
              
              <Input
                label="Company (Optional)"
                type="text"
                value={billingAddress?.company}
                onChange={(e) => setBillingAddress(prev => ({ ...prev, company: e?.target?.value }))}
              />
              
              <Input
                label="Address Line 1"
                type="text"
                value={billingAddress?.address1}
                onChange={(e) => setBillingAddress(prev => ({ ...prev, address1: e?.target?.value }))}
                required
              />
              
              <Input
                label="Address Line 2 (Optional)"
                type="text"
                value={billingAddress?.address2}
                onChange={(e) => setBillingAddress(prev => ({ ...prev, address2: e?.target?.value }))}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <Input
                  label="City"
                  type="text"
                  value={billingAddress?.city}
                  onChange={(e) => setBillingAddress(prev => ({ ...prev, city: e?.target?.value }))}
                  required
                />
                
                <Input
                  label="State/Province"
                  type="text"
                  value={billingAddress?.state}
                  onChange={(e) => setBillingAddress(prev => ({ ...prev, state: e?.target?.value }))}
                  required
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <Input
                  label="ZIP/Postal Code"
                  type="text"
                  value={billingAddress?.zipCode}
                  onChange={(e) => setBillingAddress(prev => ({ ...prev, zipCode: e?.target?.value }))}
                  required
                />
                
                <Select
                  label="Country"
                  options={countryOptions}
                  value={billingAddress?.country}
                  onChange={(value) => setBillingAddress(prev => ({ ...prev, country: value }))}
                />
              </div>
              
              <div className="flex space-x-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowEditAddressModal(false)}
                  fullWidth
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleSaveAddress}
                  loading={isSavingAddress}
                  fullWidth
                >
                  Save Address
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BillingTab;