import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SubscriptionTab = () => {
  const [currentPlan] = useState({
    name: "Professional",
    price: 29,
    billing: "monthly",
    features: [
      "Unlimited projects",
      "Advanced components",
      "Team collaboration",
      "Priority support",
      "Custom domains",
      "API integrations"
    ],
    nextBilling: "2025-11-01",
    status: "active"
  });

  const [usage] = useState({
    projects: { used: 12, limit: "unlimited" },
    storage: { used: 2.4, limit: 10, unit: "GB" },
    teamMembers: { used: 3, limit: 10 },
    apiCalls: { used: 8420, limit: 50000 }
  });

  const [billingHistory] = useState([
    {
      id: 1,
      date: "2025-10-01",
      amount: 29.00,
      status: "paid",
      invoice: "INV-2025-001",
      description: "Professional Plan - Monthly"
    },
    {
      id: 2,
      date: "2025-09-01",
      amount: 29.00,
      status: "paid",
      invoice: "INV-2025-002",
      description: "Professional Plan - Monthly"
    },
    {
      id: 3,
      date: "2025-08-01",
      amount: 29.00,
      status: "paid",
      invoice: "INV-2025-003",
      description: "Professional Plan - Monthly"
    }
  ]);

  const plans = [
    {
      name: "Starter",
      price: 0,
      billing: "monthly",
      description: "Perfect for individuals getting started",
      features: [
        "3 projects",
        "Basic components",
        "Community support",
        "CodeCraft subdomain"
      ],
      limitations: ["Limited templates", "Basic analytics"],
      popular: false
    },
    {
      name: "Professional",
      price: 29,
      billing: "monthly",
      description: "Ideal for growing businesses and teams",
      features: [
        "Unlimited projects",
        "Advanced components",
        "Team collaboration",
        "Priority support",
        "Custom domains",
        "API integrations"
      ],
      popular: true
    },
    {
      name: "Enterprise",
      price: 99,
      billing: "monthly",
      description: "For large organizations with advanced needs",
      features: [
        "Everything in Professional",
        "White-label solution",
        "Advanced security",
        "Dedicated support",
        "Custom integrations",
        "SLA guarantee"
      ],
      popular: false
    }
  ];

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getUsagePercentage = (used, limit) => {
    if (limit === "unlimited") return 0;
    return Math.min((used / limit) * 100, 100);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'paid': return 'text-success';
      case 'pending': return 'text-warning';
      case 'failed': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <div className="space-y-8">
      {/* Current Plan */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground flex items-center">
            <Icon name="CreditCard" size={20} className="mr-2" />
            Current Plan
          </h3>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full"></div>
            <span className="text-sm text-success font-medium">Active</span>
          </div>
        </div>

        <div className="bg-primary/5 border border-primary/20 rounded-lg p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h4 className="text-xl font-semibold text-foreground">{currentPlan?.name}</h4>
              <p className="text-muted-foreground">Billed {currentPlan?.billing}</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-foreground">${currentPlan?.price}</div>
              <div className="text-sm text-muted-foreground">per month</div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
            {currentPlan?.features?.map((feature, index) => (
              <div key={index} className="flex items-center space-x-2">
                <Icon name="Check" size={16} className="text-success" />
                <span className="text-sm text-foreground">{feature}</span>
              </div>
            ))}
          </div>
          
          <div className="text-sm text-muted-foreground">
            Next billing date: {formatDate(currentPlan?.nextBilling)}
          </div>
        </div>

        <div className="flex space-x-4">
          <Button variant="outline" iconName="Edit" iconPosition="left" iconSize={16}>
            Change Plan
          </Button>
          <Button variant="outline" iconName="Download" iconPosition="left" iconSize={16}>
            Download Invoice
          </Button>
        </div>
      </div>
      {/* Usage Statistics */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
          <Icon name="BarChart3" size={20} className="mr-2" />
          Usage Statistics
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">Projects</span>
              <span className="text-sm text-muted-foreground">
                {usage?.projects?.used} / {usage?.projects?.limit}
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: usage?.projects?.limit === "unlimited" ? "30%" : `${getUsagePercentage(usage?.projects?.used, usage?.projects?.limit)}%` }}
              ></div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">Storage</span>
              <span className="text-sm text-muted-foreground">
                {usage?.storage?.used} / {usage?.storage?.limit} {usage?.storage?.unit}
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-accent h-2 rounded-full transition-all duration-300"
                style={{ width: `${getUsagePercentage(usage?.storage?.used, usage?.storage?.limit)}%` }}
              ></div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">Team Members</span>
              <span className="text-sm text-muted-foreground">
                {usage?.teamMembers?.used} / {usage?.teamMembers?.limit}
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-success h-2 rounded-full transition-all duration-300"
                style={{ width: `${getUsagePercentage(usage?.teamMembers?.used, usage?.teamMembers?.limit)}%` }}
              ></div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">API Calls</span>
              <span className="text-sm text-muted-foreground">
                {usage?.apiCalls?.used?.toLocaleString()} / {usage?.apiCalls?.limit?.toLocaleString()}
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-warning h-2 rounded-full transition-all duration-300"
                style={{ width: `${getUsagePercentage(usage?.apiCalls?.used, usage?.apiCalls?.limit)}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>
      {/* Available Plans */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
          <Icon name="Package" size={20} className="mr-2" />
          Available Plans
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans?.map((plan, index) => (
            <div 
              key={index} 
              className={`relative border rounded-lg p-6 transition-all duration-300 hover:shadow-elevation-2 ${
                plan?.popular 
                  ? 'border-primary bg-primary/5' :'border-border bg-card hover:border-primary/50'
              }`}
            >
              {plan?.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-xs font-medium">
                    Current Plan
                  </span>
                </div>
              )}
              
              <div className="text-center mb-6">
                <h4 className="text-xl font-semibold text-foreground mb-2">{plan?.name}</h4>
                <div className="text-3xl font-bold text-foreground mb-1">
                  ${plan?.price}
                  <span className="text-sm font-normal text-muted-foreground">/month</span>
                </div>
                <p className="text-sm text-muted-foreground">{plan?.description}</p>
              </div>
              
              <div className="space-y-3 mb-6">
                {plan?.features?.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center space-x-2">
                    <Icon name="Check" size={16} className="text-success" />
                    <span className="text-sm text-foreground">{feature}</span>
                  </div>
                ))}
                {plan?.limitations && plan?.limitations?.map((limitation, limitIndex) => (
                  <div key={limitIndex} className="flex items-center space-x-2">
                    <Icon name="X" size={16} className="text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">{limitation}</span>
                  </div>
                ))}
              </div>
              
              <Button
                variant={plan?.popular ? "default" : "outline"}
                fullWidth
                disabled={plan?.popular}
              >
                {plan?.popular ? "Current Plan" : "Upgrade"}
              </Button>
            </div>
          ))}
        </div>
      </div>
      {/* Billing History */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
          <Icon name="Receipt" size={20} className="mr-2" />
          Billing History
        </h3>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Date</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Description</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Amount</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Status</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Invoice</th>
              </tr>
            </thead>
            <tbody>
              {billingHistory?.map((item) => (
                <tr key={item?.id} className="border-b border-border hover:bg-muted/50">
                  <td className="py-3 px-4 text-sm text-foreground">
                    {formatDate(item?.date)}
                  </td>
                  <td className="py-3 px-4 text-sm text-foreground">
                    {item?.description}
                  </td>
                  <td className="py-3 px-4 text-sm font-medium text-foreground">
                    ${item?.amount?.toFixed(2)}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`text-sm font-medium capitalize ${getStatusColor(item?.status)}`}>
                      {item?.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      iconName="Download"
                      iconSize={14}
                    >
                      {item?.invoice}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionTab;