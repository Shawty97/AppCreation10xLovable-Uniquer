import React, { useState } from 'react';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import Icon from '../../components/AppIcon';
import ProfileTab from './components/ProfileTab';
import SubscriptionTab from './components/SubscriptionTab';
import SecurityTab from './components/SecurityTab';
import TeamTab from './components/TeamTab';
import IntegrationsTab from './components/IntegrationsTab';
import BillingTab from './components/BillingTab';
import DataExportTab from './components/DataExportTab';

const AccountSettings = () => {
  const [activeTab, setActiveTab] = useState('profile');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const tabs = [
    {
      id: 'profile',
      label: 'Profile',
      icon: 'User',
      description: 'Personal information and preferences'
    },
    {
      id: 'subscription',
      label: 'Subscription',
      icon: 'CreditCard',
      description: 'Plan details and usage statistics'
    },
    {
      id: 'security',
      label: 'Security',
      icon: 'Shield',
      description: 'Password and authentication settings'
    },
    {
      id: 'team',
      label: 'Team',
      icon: 'Users',
      description: 'Workspace and collaboration management'
    },
    {
      id: 'integrations',
      label: 'Integrations',
      icon: 'Plug',
      description: 'Connected services and APIs'
    },
    {
      id: 'billing',
      label: 'Billing',
      icon: 'Receipt',
      description: 'Payment methods and invoices'
    },
    {
      id: 'data',
      label: 'Data & Privacy',
      icon: 'Download',
      description: 'Export data and account deletion'
    }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'profile':
        return <ProfileTab />;
      case 'subscription':
        return <SubscriptionTab />;
      case 'security':
        return <SecurityTab />;
      case 'team':
        return <TeamTab />;
      case 'integrations':
        return <IntegrationsTab />;
      case 'billing':
        return <BillingTab />;
      case 'data':
        return <DataExportTab />;
      default:
        return <ProfileTab />;
    }
  };

  const currentTab = tabs?.find(tab => tab?.id === activeTab);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar 
        isCollapsed={sidebarCollapsed} 
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)} 
      />
      <main className={`pt-16 transition-all duration-300 ${
        sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'
      } pb-20 lg:pb-8`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center space-x-3 mb-2">
              <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
                <Icon name="Settings" size={20} color="white" />
              </div>
              <h1 className="text-3xl font-bold text-foreground">Account Settings</h1>
            </div>
            <p className="text-muted-foreground">
              Manage your account preferences, security settings, and platform integrations
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Settings Navigation */}
            <div className="lg:col-span-1">
              <div className="bg-card rounded-lg border border-border p-4 sticky top-24">
                <nav className="space-y-2">
                  {tabs?.map((tab) => (
                    <button
                      key={tab?.id}
                      onClick={() => setActiveTab(tab?.id)}
                      className={`w-full flex items-start space-x-3 px-3 py-3 rounded-md text-left transition-quick hover-lift ${
                        activeTab === tab?.id
                          ? 'bg-primary text-primary-foreground shadow-elevation-1'
                          : 'text-foreground hover:bg-muted hover:text-foreground'
                      }`}
                    >
                      <Icon name={tab?.icon} size={18} className="mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <div className="font-medium">{tab?.label}</div>
                        <div className={`text-xs mt-1 ${
                          activeTab === tab?.id 
                            ? 'text-primary-foreground/80' 
                            : 'text-muted-foreground'
                        }`}>
                          {tab?.description}
                        </div>
                      </div>
                    </button>
                  ))}
                </nav>
              </div>
            </div>

            {/* Settings Content */}
            <div className="lg:col-span-3">
              <div className="bg-card rounded-lg border border-border">
                {/* Tab Header */}
                <div className="border-b border-border px-6 py-4">
                  <div className="flex items-center space-x-3">
                    <Icon name={currentTab?.icon} size={20} className="text-primary" />
                    <div>
                      <h2 className="text-xl font-semibold text-foreground">
                        {currentTab?.label}
                      </h2>
                      <p className="text-sm text-muted-foreground">
                        {currentTab?.description}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Tab Content */}
                <div className="p-6">
                  {renderTabContent()}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AccountSettings;