import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Sidebar = ({ isCollapsed = false, onToggleCollapse }) => {
  const location = useLocation();
  const [isResourcesExpanded, setIsResourcesExpanded] = useState(false);
  const [isSettingsExpanded, setIsSettingsExpanded] = useState(false);
  const [collaborators] = useState([
    { id: 1, name: 'Sarah Chen', avatar: 'SC', active: true, section: 'visual-builder' },
    { id: 2, name: 'Mike Johnson', avatar: 'MJ', active: true, section: 'visual-builder' },
  ]);

  const primaryNavItems = [
    { 
      path: '/dashboard', 
      label: 'Dashboard', 
      icon: 'LayoutDashboard',
      tooltip: 'Project management hub and overview'
    },
    { 
      path: '/visual-builder', 
      label: 'Builder', 
      icon: 'Wrench',
      tooltip: 'Visual application development workspace',
      hasCollaborators: true
    },
  ];

  const resourceItems = [
    { 
      path: '/template-gallery', 
      label: 'Templates', 
      icon: 'Layout',
      tooltip: 'Browse and use pre-built templates'
    },
    { 
      path: '/component-marketplace', 
      label: 'Components', 
      icon: 'Package',
      tooltip: 'Discover reusable components'
    },
  ];

  const settingsItems = [
    { 
      path: '/app-settings', 
      label: 'App Settings', 
      icon: 'Settings',
      tooltip: 'Configure current application'
    },
    { 
      path: '/account-settings', 
      label: 'Account', 
      icon: 'User',
      tooltip: 'Manage your account preferences'
    },
  ];

  const isActivePath = (path) => location?.pathname === path;

  const getActiveCollaborators = (section) => {
    return collaborators?.filter(c => c?.active && c?.section === section);
  };

  const NavItem = ({ item, isNested = false }) => {
    const activeCollabs = item?.hasCollaborators ? getActiveCollaborators(item?.path?.replace('/', '')) : [];
    
    return (
      <div className="relative group">
        <Link
          to={item?.path}
          className={`flex items-center space-x-3 px-4 py-3 rounded-md text-sm font-medium transition-quick hover-lift relative ${
            isActivePath(item?.path)
              ? 'bg-primary text-primary-foreground shadow-elevation-1'
              : 'text-foreground hover:bg-muted hover:text-foreground'
          } ${isNested ? 'ml-4 py-2' : ''}`}
        >
          <div className="flex items-center space-x-3 flex-1">
            <Icon name={item?.icon} size={18} />
            {!isCollapsed && <span>{item?.label}</span>}
          </div>
          
          {/* Collaboration Indicators */}
          {!isCollapsed && activeCollabs?.length > 0 && (
            <div className="flex -space-x-1">
              {activeCollabs?.slice(0, 3)?.map((collab) => (
                <div
                  key={collab?.id}
                  className="w-5 h-5 bg-success text-success-foreground rounded-full flex items-center justify-center text-xs font-medium border-2 border-card"
                  title={`${collab?.name} is active`}
                >
                  {collab?.avatar?.charAt(0)}
                </div>
              ))}
              {activeCollabs?.length > 3 && (
                <div className="w-5 h-5 bg-muted text-muted-foreground rounded-full flex items-center justify-center text-xs font-medium border-2 border-card">
                  +{activeCollabs?.length - 3}
                </div>
              )}
            </div>
          )}
        </Link>
        {/* Tooltip for collapsed state */}
        {isCollapsed && (
          <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 bg-popover text-popover-foreground px-2 py-1 rounded-md text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-quick pointer-events-none z-50 shadow-elevation-2">
            {item?.tooltip}
          </div>
        )}
      </div>
    );
  };

  const ExpandableSection = ({ title, icon, items, isExpanded, onToggle, children }) => (
    <div className="space-y-1">
      <Button
        variant="ghost"
        onClick={onToggle}
        className={`w-full justify-start px-4 py-3 text-sm font-medium text-foreground hover:bg-muted transition-quick ${
          isCollapsed ? 'px-3' : ''
        }`}
      >
        <div className="flex items-center space-x-3 flex-1">
          <Icon name={icon} size={18} />
          {!isCollapsed && <span>{title}</span>}
        </div>
        {!isCollapsed && (
          <Icon 
            name={isExpanded ? 'ChevronDown' : 'ChevronRight'} 
            size={16} 
            className="transition-transform duration-200"
          />
        )}
      </Button>
      
      {!isCollapsed && isExpanded && (
        <div className="space-y-1 animate-accordion-down">
          {children || items?.map((item) => (
            <NavItem key={item?.path} item={item} isNested />
          ))}
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className={`fixed left-0 top-16 bottom-0 z-40 bg-card border-r border-border shadow-elevation-1 transition-all duration-300 ${
        isCollapsed ? 'w-16' : 'w-60'
      } hidden lg:block`}>
        <div className="flex flex-col h-full">
          {/* Toggle Button */}
          <div className="flex justify-end p-4 border-b border-border">
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggleCollapse}
              iconName={isCollapsed ? 'ChevronRight' : 'ChevronLeft'}
              iconSize={16}
              className="hover-lift"
            />
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            {/* Primary Navigation */}
            <div className="space-y-1">
              {primaryNavItems?.map((item) => (
                <NavItem key={item?.path} item={item} />
              ))}
            </div>

            {/* Resources Section */}
            <div className="pt-4">
              <ExpandableSection
                title="Resources"
                icon="FolderOpen"
                items={resourceItems}
                isExpanded={isResourcesExpanded}
                onToggle={() => setIsResourcesExpanded(!isResourcesExpanded)}
              />
            </div>

            {/* Settings Section */}
            <div className="pt-4 mt-auto">
              <ExpandableSection
                title="Settings"
                icon="Cog"
                items={settingsItems}
                isExpanded={isSettingsExpanded}
                onToggle={() => setIsSettingsExpanded(!isSettingsExpanded)}
              />
            </div>
          </nav>

          {/* User Profile */}
          {!isCollapsed && (
            <div className="p-4 border-t border-border">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <Icon name="User" size={16} color="white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">John Doe</p>
                  <p className="text-xs text-muted-foreground truncate">john@example.com</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </aside>
      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-card border-t border-border shadow-elevation-3 lg:hidden">
        <div className="flex items-center justify-around py-2">
          {primaryNavItems?.map((item) => (
            <Link
              key={item?.path}
              to={item?.path}
              className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-md transition-quick ${
                isActivePath(item?.path)
                  ? 'text-primary' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon name={item?.icon} size={20} />
              <span className="text-xs font-medium">{item?.label}</span>
            </Link>
          ))}
          
          {/* Resources Trigger */}
          <button
            onClick={() => setIsResourcesExpanded(true)}
            className="flex flex-col items-center space-y-1 px-3 py-2 rounded-md text-muted-foreground hover:text-foreground transition-quick"
          >
            <Icon name="FolderOpen" size={20} />
            <span className="text-xs font-medium">Resources</span>
          </button>
        </div>
      </nav>
      {/* Mobile Resources Panel */}
      {isResourcesExpanded && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div 
            className="absolute inset-0 bg-black/50"
            onClick={() => setIsResourcesExpanded(false)}
          />
          <div className="absolute bottom-0 left-0 right-0 bg-card rounded-t-lg shadow-elevation-3 animate-slide-in">
            <div className="p-4 border-b border-border">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-foreground">Resources</h3>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsResourcesExpanded(false)}
                  iconName="X"
                  iconSize={20}
                />
              </div>
            </div>
            <div className="p-4 space-y-2 max-h-80 overflow-y-auto">
              {[...resourceItems, ...settingsItems]?.map((item) => (
                <Link
                  key={item?.path}
                  to={item?.path}
                  onClick={() => setIsResourcesExpanded(false)}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-md text-sm font-medium transition-quick ${
                    isActivePath(item?.path)
                      ? 'bg-primary text-primary-foreground'
                      : 'text-foreground hover:bg-muted'
                  }`}
                >
                  <Icon name={item?.icon} size={18} />
                  <span>{item?.label}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Sidebar;