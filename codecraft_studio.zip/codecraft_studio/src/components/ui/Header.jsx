import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = () => {
  const location = useLocation();
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);

  const primaryNavItems = [
    { path: '/dashboard', label: 'Dashboard', icon: 'LayoutDashboard' },
    { path: '/visual-builder', label: 'Builder', icon: 'Wrench' },
    { path: '/template-gallery', label: 'Templates', icon: 'Layout' },
    { path: '/component-marketplace', label: 'Components', icon: 'Package' },
  ];

  const secondaryNavItems = [
    { path: '/app-settings', label: 'App Settings', icon: 'Settings' },
    { path: '/account-settings', label: 'Account', icon: 'User' },
  ];

  const isActivePath = (path) => location?.pathname === path;

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-card border-b border-border shadow-elevation-1">
      <div className="flex items-center justify-between h-16 px-6">
        {/* Logo */}
        <Link to="/dashboard" className="flex items-center space-x-3 hover:opacity-80 transition-quick">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
            <Icon name="Code" size={20} color="white" />
          </div>
          <span className="text-xl font-semibold text-foreground">CodeCraft Studio</span>
        </Link>

        {/* Primary Navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          {primaryNavItems?.map((item) => (
            <Link
              key={item?.path}
              to={item?.path}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-quick hover-lift ${
                isActivePath(item?.path)
                  ? 'bg-primary text-primary-foreground shadow-elevation-1'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              <Icon name={item?.icon} size={16} />
              <span>{item?.label}</span>
            </Link>
          ))}

          {/* More Menu */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMoreMenuOpen(!isMoreMenuOpen)}
              iconName="MoreHorizontal"
              iconSize={16}
              className="text-muted-foreground hover:text-foreground"
            >
              More
            </Button>

            {isMoreMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-10"
                  onClick={() => setIsMoreMenuOpen(false)}
                />
                <div className="absolute right-0 top-full mt-2 w-48 bg-popover border border-border rounded-md shadow-elevation-3 z-20 animate-scale-in">
                  <div className="py-2">
                    {secondaryNavItems?.map((item) => (
                      <Link
                        key={item?.path}
                        to={item?.path}
                        onClick={() => setIsMoreMenuOpen(false)}
                        className={`flex items-center space-x-3 px-4 py-2 text-sm transition-quick ${
                          isActivePath(item?.path)
                            ? 'bg-accent text-accent-foreground'
                            : 'text-popover-foreground hover:bg-muted'
                        }`}
                      >
                        <Icon name={item?.icon} size={16} />
                        <span>{item?.label}</span>
                      </Link>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </nav>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          iconName="Menu"
          iconSize={20}
        />

        {/* User Actions */}
        <div className="hidden md:flex items-center space-x-3">
          <Button
            variant="outline"
            size="sm"
            iconName="Plus"
            iconPosition="left"
            iconSize={16}
            className="hover-lift"
          >
            New App
          </Button>
          
          <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center cursor-pointer hover-lift">
            <Icon name="User" size={16} color="var(--color-muted-foreground)" />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;