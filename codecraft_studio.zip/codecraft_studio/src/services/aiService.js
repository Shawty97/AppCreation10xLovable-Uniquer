import OpenAI from 'openai';
import { supabase } from '../lib/supabase';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true, // Required for client-side usage
});

// Voice Services
export const voiceService = {
  // Start a new voice session
  async createVoiceSession(sessionName = null) {
    try {
      const { data: session } = await supabase?.auth?.getSession();
      if (!session?.user) throw new Error('User not authenticated');

      const { data, error } = await supabase?.from('voice_sessions')?.insert({
          user_id: session?.user?.id,
          session_name: sessionName || `Voice Session ${new Date()?.toLocaleString()}`,
          status: 'recording'
        })?.select()?.single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error };
    }
  },

  // Process voice input with OpenAI
  async processVoiceInput(audioBlob, sessionId) {
    try {
      // Check if OpenAI API is available
      if (!import.meta.env?.VITE_OPENAI_API_KEY) {
        throw new Error('OpenAI API key not configured');
      }

      // Convert audio blob to file
      const audioFile = new File([audioBlob], 'voice_input.webm', { type: 'audio/webm' });

      // Update session status
      await supabase?.from('voice_sessions')?.update({ status: 'processing' })?.eq('id', sessionId);

      // Transcribe audio using OpenAI Whisper
      const response = await openai?.audio?.transcriptions?.create({
        model: 'whisper-1',
        file: audioFile,
        language: 'en'
      });

      const transcript = response?.text;

      // Extract requirements using GPT-5
      const requirementsResponse = await openai?.chat?.completions?.create({
        model: 'gpt-5',
        messages: [
          {
            role: 'system',
            content: 'You are an expert at extracting app development requirements from voice descriptions. Parse the user\'s request and identify components, features, styling preferences, and technical requirements. Return a structured JSON with components, features, complexity, and implementation notes.'
          },
          {
            role: 'user',
            content: `Extract development requirements from this voice input: "${transcript}"`
          }
        ],
        response_format: {
          type: 'json_schema',
          json_schema: {
            name: 'requirements_extraction',
            schema: {
              type: 'object',
              properties: {
                components: { 
                  type: 'array', 
                  items: { type: 'string' },
                  description: 'List of UI components needed'
                },
                features: { 
                  type: 'array', 
                  items: { type: 'string' },
                  description: 'List of application features'
                },
                styling: { 
                  type: 'array', 
                  items: { type: 'string' },
                  description: 'Styling requirements and preferences'
                },
                complexity: { 
                  type: 'string', 
                  enum: ['simple', 'medium', 'complex'],
                  description: 'Overall application complexity level'
                },
                framework: { 
                  type: 'string',
                  description: 'Recommended framework or technology'
                },
                implementation_notes: { 
                  type: 'string',
                  description: 'Additional implementation guidance'
                }
              },
              required: ['components', 'features', 'complexity'],
              additionalProperties: false
            }
          }
        },
        reasoning_effort: 'medium',
        verbosity: 'medium'
      });

      const extractedRequirements = JSON.parse(requirementsResponse?.choices?.[0]?.message?.content);

      // Update session with results
      const { data, error } = await supabase?.from('voice_sessions')?.update({
          status: 'completed',
          transcript,
          extracted_requirements: extractedRequirements,
          duration_seconds: Math.floor(audioBlob?.size / 1000) // Approximate duration
        })?.eq('id', sessionId)?.select()?.single();

      if (error) throw error;

      return { 
        data: {
          transcript,
          requirements: extractedRequirements,
          session: data
        }, 
        error: null 
      };
    } catch (error) {
      // Update session status to error
      await supabase?.from('voice_sessions')?.update({ status: 'error' })?.eq('id', sessionId);

      return { data: null, error };
    }
  },

  // Get user's voice sessions
  async getVoiceSessions(limit = 10) {
    try {
      const { data, error } = await supabase?.from('voice_sessions')?.select('*')?.order('created_at', { ascending: false })?.limit(limit);

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error };
    }
  },

  // Get voice commands library
  async getVoiceCommands() {
    try {
      const { data, error } = await supabase?.from('voice_commands')?.select('*')?.order('usage_count', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error };
    }
  },

  // Add custom voice command
  async addVoiceCommand(commandPhrase, category, description, actionData = {}) {
    try {
      const { data: session } = await supabase?.auth?.getSession();
      if (!session?.user) throw new Error('User not authenticated');

      const { data, error } = await supabase?.from('voice_commands')?.insert({
          user_id: session?.user?.id,
          command_phrase: commandPhrase,
          category,
          description,
          action_data: actionData,
          is_custom: true
        })?.select()?.single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error };
    }
  }
};

// AI Assistant Services
export const aiAssistantService = {
  // Create new conversation
  async createConversation(title, type = 'general_help', projectId = null, contextData = {}) {
    try {
      // Wait for session to be fully loaded
      const { data: session, error: sessionError } = await supabase?.auth?.getSession();
      
      if (sessionError) {
        console.error('Session error:', sessionError);
        throw new Error('Authentication session error');
      }
      
      if (!session?.session?.user) {
        throw new Error('User not authenticated');
      }

      // Validate enum value for conversation_type
      const validTypes = ['voice_creation', 'general_help', 'code_review', 'project_guidance'];
      if (!validTypes?.includes(type)) {
        console.warn(`Invalid conversation type: ${type}, defaulting to 'general_help'`);
        type = 'general_help';
      }
      
      const { data, error } = await supabase?.from('ai_conversations')?.insert({
          user_id: session?.session?.user?.id,
          title,
          conversation_type: type,
          project_id: projectId,
          context_data: contextData
        })?.select()?.single();

      if (error) {
        console.error('Database error creating conversation:', error);
        throw error;
      }
      
      return { data, error: null };
    } catch (error) {
      console.error('Failed to create AI conversation:', error);
      return { data: null, error };
    }
  },

  // Send message to AI assistant with context awareness
  async sendMessage(conversationId, message, includeContext = true) {
    try {
      // Check authentication first
      const { data: session, error: sessionError } = await supabase?.auth?.getSession();
      
      if (sessionError) {
        console.error('Session error:', sessionError);
        throw new Error('Authentication session error');
      }
      
      if (!session?.session?.user) {
        throw new Error('User not authenticated');
      }

      // Get conversation and user preferences
      const [conversationResult, preferencesResult] = await Promise.all([
        supabase?.from('ai_conversations')?.select('*, projects(name, description, framework)')?.eq('id', conversationId)?.single(),
        supabase?.from('ai_user_preferences')?.select('*')?.eq('user_id', session?.session?.user?.id)?.single()
      ]);

      const conversation = conversationResult?.data;
      const preferences = preferencesResult?.data;

      if (!conversation) {
        throw new Error('Conversation not found');
      }

      // Verify user owns this conversation
      if (conversation?.user_id !== session?.session?.user?.id) {
        throw new Error('Unauthorized access to conversation');
      }

      // Build context-aware system prompt
      let systemPrompt = 'You are CodeCraft Studio\'s AI assistant, helping users build applications with no-code/low-code tools.';
      
      if (preferences && includeContext) {
        systemPrompt += ` User preferences:
- Preferred frameworks: ${preferences?.preferred_frameworks?.join(', ') || 'None specified'}
- Coding style: ${JSON.stringify(preferences?.coding_style_preferences || {})}
- Assistance level: ${preferences?.assistance_level || 'balanced'}`;
      }

      if (conversation?.projects && includeContext) {
        systemPrompt += `\nCurrent project context: ${conversation?.projects?.name} (${conversation?.projects?.framework}) - ${conversation?.projects?.description}`;
      }

      if (conversation?.context_data && includeContext) {
        systemPrompt += `\nConversation context: ${JSON.stringify(conversation?.context_data)}`;
      }

      // Get previous messages
      const previousMessages = conversation?.messages || [];
      const messages = [
        { role: 'system', content: systemPrompt },
        ...previousMessages,
        { role: 'user', content: message }
      ];

      let aiMessage;

      // Use OpenAI if API key is available
      if (import.meta.env?.VITE_OPENAI_API_KEY) {
        try {
          const response = await openai?.chat?.completions?.create({
            model: 'gpt-4', // Use gpt-4 instead of gpt-5 which may not be available
            messages,
            max_tokens: 1000,
            temperature: 0.7
          });

          aiMessage = response?.choices?.[0]?.message?.content;
        } catch (openaiError) {
          console.error('OpenAI API Error:', openaiError);
          // Fallback to mock response if OpenAI fails
          aiMessage = `I understand you're asking about: "${message}". I'm experiencing some technical difficulties with my AI capabilities right now, but I can still help you with basic guidance. Please try again in a moment.`;
        }
      } else {
        // Fallback to mock response
        aiMessage = `I understand you're asking about: "${message}". While I don't have access to the full AI capabilities right now, I can help you with basic guidance. For advanced AI assistance, please configure your OpenAI API key.`;
      }

      // Update conversation with new messages
      const updatedMessages = [
        ...previousMessages,
        { role: 'user', content: message, timestamp: new Date()?.toISOString() },
        { role: 'assistant', content: aiMessage, timestamp: new Date()?.toISOString() }
      ];

      const { data, error } = await supabase?.from('ai_conversations')?.update({
          messages: updatedMessages,
          total_messages: updatedMessages?.length,
          updated_at: new Date()?.toISOString()
        })?.eq('id', conversationId)?.select()?.single();

      if (error) {
        console.error('Error updating conversation:', error);
        throw error;
      }

      return { 
        data: { 
          message: aiMessage,
          conversation: data
        }, 
        error: null 
      };
    } catch (error) {
      console.error('Error sending message:', error);
      return { data: null, error };
    }
  },

  // Get user's conversations
  async getConversations(limit = 20) {
    try {
      const { data: session, error: sessionError } = await supabase?.auth?.getSession();
      
      if (sessionError) {
        console.error('Session error:', sessionError);
        throw new Error('Authentication session error');
      }
      
      if (!session?.session?.user) {
        throw new Error('User not authenticated');
      }

      const { data, error } = await supabase?.from('ai_conversations')?.select('*, projects(name)')?.eq('user_id', session?.session?.user?.id)?.eq('is_active', true)?.order('updated_at', { ascending: false })?.limit(limit);

      if (error) {
        console.error('Error fetching conversations:', error);
        throw error;
      }
      
      return { data, error: null };
    } catch (error) {
      console.error('Error getting conversations:', error);
      return { data: null, error };
    }
  },

  // Get or create user preferences
  async getUserPreferences() {
    try {
      const { data: session } = await supabase?.auth?.getSession();
      if (!session?.user) throw new Error('User not authenticated');

      let { data, error } = await supabase?.from('ai_user_preferences')?.select('*')?.eq('user_id', session?.user?.id)?.single();

      // Create default preferences if none exist
      if (error && error?.code === 'PGRST116') {
        const { data: newPrefs, error: createError } = await supabase?.from('ai_user_preferences')?.insert({
            user_id: session?.user?.id,
            learning_enabled: true,
            preferred_frameworks: ['react'],
            assistance_level: 'balanced'
          })?.select()?.single();

        if (createError) throw createError;
        data = newPrefs;
      } else if (error) {
        throw error;
      }

      return { data, error: null };
    } catch (error) {
      return { data: null, error };
    }
  },

  // Update user preferences
  async updatePreferences(updates) {
    try {
      const { data: session } = await supabase?.auth?.getSession();
      if (!session?.user) throw new Error('User not authenticated');

      const { data, error } = await supabase?.from('ai_user_preferences')?.update(updates)?.eq('user_id', session?.user?.id)?.select()?.single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error };
    }
  },

  // Analyze user patterns and suggest improvements
  async analyzeUserPatterns() {
    try {
      const { data: conversations, error } = await supabase?.from('ai_conversations')?.select('*')?.order('created_at', { ascending: false })?.limit(50);

      if (error) throw error;

      if (!conversations || conversations?.length === 0) {
        return { data: { suggestions: [], patterns: {} }, error: null };
      }

      // Use AI to analyze patterns if available
      if (import.meta.env?.VITE_OPENAI_API_KEY) {
        const analysisPrompt = `Analyze these AI conversation patterns and suggest improvements for a developer:

Conversation Data:
${JSON.stringify(conversations?.map(c => ({
  type: c?.conversation_type,
  messageCount: c?.total_messages,
  createdAt: c?.created_at,
  context: c?.context_data
})))}

Provide actionable insights and recommendations for improving development workflow and productivity.`;

        const response = await openai?.chat?.completions?.create({
          model: 'gpt-5-mini', // Use mini for analysis to save costs
          messages: [
            {
              role: 'system',
              content: 'You are an AI assistant analyzing user interaction patterns to provide helpful suggestions for improving their development workflow. Be specific and actionable in your recommendations.'
            },
            {
              role: 'user',
              content: analysisPrompt
            }
          ],
          reasoning_effort: 'low',
          verbosity: 'medium'
        });

        return { 
          data: { 
            analysis: response?.choices?.[0]?.message?.content,
            conversationCount: conversations?.length
          }, 
          error: null 
        };
      }

      // Fallback analysis without AI
      return { 
        data: { 
          analysis: `Based on your ${conversations?.length} conversations, you're actively using the AI assistant. Consider exploring more advanced features like voice-to-app creation and real-time collaboration.`,
          conversationCount: conversations?.length
        }, 
        error: null 
      };
    } catch (error) {
      return { data: null, error };
    }
  }
};

// Code Generation Services
export const codeGenerationService = {
  // Generate application structure
  async generateApplication(prompt, framework = 'react') {
    try {
      if (!import.meta.env?.VITE_OPENAI_API_KEY) {
        throw new Error('OpenAI API key not configured');
      }

      const response = await openai?.chat?.completions?.create({
        model: 'gpt-5',
        messages: [
          {
            role: 'system',
            content: `You are an expert ${framework} developer. Generate a complete application structure based on user requirements. Focus on modern best practices, accessibility, and production-ready code.`
          },
          {
            role: 'user',
            content: `Generate a ${framework} application: ${prompt}`
          }
        ],
        response_format: {
          type: 'json_schema',
          json_schema: {
            name: 'application_structure',
            schema: {
              type: 'object',
              properties: {
                name: { type: 'string', description: 'Application name' },
                description: { type: 'string', description: 'Application description' },
                framework: { type: 'string', description: 'Target framework' },
                components: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      name: { type: 'string' },
                      type: { type: 'string' },
                      description: { type: 'string' },
                      props: { type: 'array', items: { type: 'string' } }
                    },
                    required: ['name', 'type', 'description']
                  }
                },
                pages: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      name: { type: 'string' },
                      path: { type: 'string' },
                      description: { type: 'string' },
                      components: { type: 'array', items: { type: 'string' } }
                    },
                    required: ['name', 'path', 'description']
                  }
                },
                features: {
                  type: 'array',
                  items: { type: 'string' },
                  description: 'List of application features'
                },
                dependencies: {
                  type: 'array',
                  items: { type: 'string' },
                  description: 'Required dependencies'
                }
              },
              required: ['name', 'description', 'framework', 'components', 'pages', 'features'],
              additionalProperties: false
            }
          }
        },
        reasoning_effort: 'high',
        verbosity: 'high'
      });

      const applicationData = JSON.parse(response?.choices?.[0]?.message?.content);
      return { data: applicationData, error: null };
    } catch (error) {
      return { data: null, error };
    }
  },

  // Generate specific component code
  async generateComponent(componentName, requirements, framework = 'react') {
    try {
      if (!import.meta.env?.VITE_OPENAI_API_KEY) {
        throw new Error('OpenAI API key not configured');
      }

      const response = await openai?.chat?.completions?.create({
        model: 'gpt-5',
        messages: [
          {
            role: 'system',
            content: `You are an expert ${framework} developer. Generate clean, modern, and accessible component code with proper styling using Tailwind CSS. Include TypeScript types if applicable.`
          },
          {
            role: 'user',
            content: `Generate a ${framework} component named "${componentName}" with these requirements: ${requirements}`
          }
        ],
        reasoning_effort: 'medium',
        verbosity: 'high',
        max_completion_tokens: 2000
      });

      return { 
        data: {
          componentName,
          code: response?.choices?.[0]?.message?.content,
          framework
        }, 
        error: null 
      };
    } catch (error) {
      return { data: null, error };
    }
  }
};