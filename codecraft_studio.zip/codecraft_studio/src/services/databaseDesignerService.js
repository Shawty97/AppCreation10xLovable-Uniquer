import { supabase } from '../lib/supabase.js';

class DatabaseDesignerService {
  // Schema Management
  async createDatabaseSchema(schemaData) {
    try {
      const { data, error } = await supabase?.from('database_schemas')?.insert([{
          project_id: schemaData?.project_id,
          name: schemaData?.name,
          description: schemaData?.description,
          canvas_data: schemaData?.canvas_data || {},
          settings: schemaData?.settings || {}
        }])?.select()?.single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async getDatabaseSchemas(projectId = null) {
    try {
      let query = supabase?.from('database_schemas')?.select(`
          *,
          projects:project_id(name, description)
        `)?.order('updated_at', { ascending: false });

      if (projectId) {
        query = query?.eq('project_id', projectId);
      }

      const { data, error } = await query;
      if (error) throw error;

      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async updateDatabaseSchema(schemaId, updates) {
    try {
      const { data, error } = await supabase?.from('database_schemas')?.update(updates)?.eq('id', schemaId)?.select()?.single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async deleteDatabaseSchema(schemaId) {
    try {
      const { error } = await supabase?.from('database_schemas')?.delete()?.eq('id', schemaId);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  // Table Management
  async createDatabaseTable(tableData) {
    try {
      const { data, error } = await supabase?.from('database_tables')?.insert([tableData])?.select()?.single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async getDatabaseTables(schemaId) {
    try {
      const { data, error } = await supabase?.from('database_tables')?.select(`
          *,
          table_fields(*),
          source_relationships:table_relationships!source_table_id(*,
            target_table:database_tables!target_table_id(name, display_name)
          ),
          target_relationships:table_relationships!target_table_id(*,
            source_table:database_tables!source_table_id(name, display_name)
          )
        `)?.eq('schema_id', schemaId)?.order('created_at', { ascending: true });

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async updateDatabaseTable(tableId, updates) {
    try {
      const { data, error } = await supabase?.from('database_tables')?.update(updates)?.eq('id', tableId)?.select()?.single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async deleteDatabaseTable(tableId) {
    try {
      const { error } = await supabase?.from('database_tables')?.delete()?.eq('id', tableId);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  // Field Management
  async createTableField(fieldData) {
    try {
      const { data, error } = await supabase?.from('table_fields')?.insert([fieldData])?.select()?.single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async updateTableField(fieldId, updates) {
    try {
      const { data, error } = await supabase?.from('table_fields')?.update(updates)?.eq('id', fieldId)?.select()?.single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async deleteTableField(fieldId) {
    try {
      const { error } = await supabase?.from('table_fields')?.delete()?.eq('id', fieldId);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async reorderTableFields(tableId, fieldOrders) {
    try {
      const updates = fieldOrders?.map((order, index) => ({
        id: order?.fieldId,
        sort_order: index + 1
      }));

      for (const update of updates) {
        await supabase?.from('table_fields')?.update({ sort_order: update?.sort_order })?.eq('id', update?.id);
      }

      return { success: true };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  // Relationship Management
  async createTableRelationship(relationshipData) {
    try {
      const { data, error } = await supabase?.from('table_relationships')?.insert([relationshipData])?.select(`
          *,
          source_table:database_tables!source_table_id(name, display_name),
          target_table:database_tables!target_table_id(name, display_name),
          source_field:table_fields!source_field_id(name, display_name),
          target_field:table_fields!target_field_id(name, display_name)
        `)?.single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async getTableRelationships(schemaId) {
    try {
      const { data, error } = await supabase?.from('table_relationships')?.select(`
          *,
          source_table:database_tables!source_table_id(*),
          target_table:database_tables!target_table_id(*),
          source_field:table_fields!source_field_id(*),
          target_field:table_fields!target_field_id(*)
        `)?.eq('schema_id', schemaId);

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async deleteTableRelationship(relationshipId) {
    try {
      const { error } = await supabase?.from('table_relationships')?.delete()?.eq('id', relationshipId);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  // Sample Data Management
  async createSampleDataTemplate(templateData) {
    try {
      const { data, error } = await supabase?.from('sample_data_templates')?.insert([templateData])?.select()?.single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async getSampleDataTemplates(tableId) {
    try {
      const { data, error } = await supabase?.from('sample_data_templates')?.select('*')?.eq('table_id', tableId)?.order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async getPublicSampleDataTemplates() {
    try {
      const { data, error } = await supabase?.from('sample_data_templates')?.select(`
          *,
          table:database_tables!table_id(name, display_name, schema:database_schemas!schema_id(name))
        `)?.eq('is_public', true)?.order('download_count', { ascending: false })?.limit(20);

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  // Query Management
  async createQueryTemplate(queryData) {
    try {
      const { data, error } = await supabase?.from('query_templates')?.insert([queryData])?.select()?.single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async getQueryTemplates(schemaId) {
    try {
      const { data, error } = await supabase?.from('query_templates')?.select('*')?.eq('schema_id', schemaId)?.order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  async getPublicQueryTemplates() {
    try {
      const { data, error } = await supabase?.from('query_templates')?.select(`
          *,
          schema:database_schemas!schema_id(name, description)
        `)?.eq('is_public', true)?.order('performance_score', { ascending: false })?.limit(20);

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  // Utility Methods
  async generateSQL(schemaId) {
    try {
      // This would be enhanced with actual SQL generation logic
      const tablesResult = await this.getDatabaseTables(schemaId);
      if (!tablesResult?.success) throw new Error(tablesResult.error);

      const relationshipsResult = await this.getTableRelationships(schemaId);
      if (!relationshipsResult?.success) throw new Error(relationshipsResult.error);

      // Basic SQL generation logic would go here
      const sqlStatements = [];
      
      // Generate CREATE TABLE statements
      tablesResult?.data?.forEach(table => {
        let sql = `CREATE TABLE ${table?.name} (\n`;
        
        table?.table_fields?.forEach((field, index) => {
          const isLast = index === table?.table_fields?.length - 1;
          sql += `  ${field?.name} ${this.mapDataTypeToSQL(field?.data_type)}`;
          
          if (field?.constraints?.includes('primary_key')) {
            sql += ' PRIMARY KEY';
          }
          if (field?.constraints?.includes('required') && !field?.constraints?.includes('primary_key')) {
            sql += ' NOT NULL';
          }
          if (field?.constraints?.includes('unique')) {
            sql += ' UNIQUE';
          }
          
          sql += isLast ? '\n' : ',\n';
        });
        
        sql += ');';
        sqlStatements?.push(sql);
      });

      return { success: true, sql: sqlStatements?.join('\n\n') };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }

  mapDataTypeToSQL(dataType) {
    const mapping = {
      'text': 'TEXT',
      'number': 'INTEGER',
      'decimal': 'DECIMAL(10,2)',
      'boolean': 'BOOLEAN',
      'date': 'DATE',
      'datetime': 'TIMESTAMP',
      'email': 'TEXT',
      'url': 'TEXT',
      'phone': 'TEXT',
      'uuid': 'UUID',
      'json': 'JSONB',
      'textarea': 'TEXT',
      'image': 'TEXT',
      'file': 'TEXT'
    };
    return mapping?.[dataType] || 'TEXT';
  }

  // Canvas and Visual Operations
  async saveCanvasState(schemaId, canvasData) {
    return this.updateDatabaseSchema(schemaId, { canvas_data: canvasData });
  }

  async duplicateSchema(schemaId, newName) {
    try {
      // Get original schema
      const { data: originalSchema } = await supabase?.from('database_schemas')?.select('*')?.eq('id', schemaId)?.single();

      if (!originalSchema) throw new Error('Schema not found');

      // Create new schema
      const newSchema = {
        ...originalSchema,
        name: newName,
        version: 1,
        status: 'draft'
      };
      delete newSchema?.id;
      delete newSchema?.created_at;
      delete newSchema?.updated_at;

      const { data: createdSchema, error: schemaError } = await supabase?.from('database_schemas')?.insert([newSchema])?.select()?.single();

      if (schemaError) throw schemaError;

      // TODO: Duplicate tables, fields, and relationships
      // This would require additional logic to copy all related data
      
      return { success: true, data: createdSchema };
    } catch (error) {
      return { success: false, error: error?.message };
    }
  }
}

export default new DatabaseDesignerService();