import { supabase } from '../lib/supabase';

export const componentService = {
  // Get all components with product details
  getAll: async (limit = 50) => {
    try {
      const { data, error } = await supabase?.from('component_listings')?.select(`
          *,
          products:product_id (
            name,
            price,
            category,
            description,
            currency
          ),
          user_profiles:seller_id (
            full_name,
            avatar_url,
            email
          )
        `)?.order('created_at', { ascending: false })?.limit(limit)
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get featured components
  getFeatured: async (limit = 10) => {
    try {
      const { data, error } = await supabase?.from('component_listings')?.select(`
          *,
          products:product_id (
            name,
            price,
            category,
            description,
            currency
          ),
          user_profiles:seller_id (
            full_name,
            avatar_url
          )
        `)?.eq('is_featured', true)?.order('rating', { ascending: false })?.limit(limit)
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get components by category via products
  getByCategory: async (category, limit = 20) => {
    try {
      const { data, error } = await supabase?.from('component_listings')?.select(`
          *,
          products:product_id!inner (
            name,
            price,
            category,
            description,
            currency
          ),
          user_profiles:seller_id (
            full_name,
            avatar_url
          )
        `)?.eq('products.category', category)?.order('rating', { ascending: false })?.limit(limit)
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Search components
  search: async (query, filters = {}) => {
    try {
      let queryBuilder = supabase?.from('component_listings')?.select(`
          *,
          products:product_id (
            name,
            price,
            category,
            description,
            currency
          ),
          user_profiles:seller_id (
            full_name,
            avatar_url
          )
        `)

      if (query) {
        queryBuilder = queryBuilder?.or(`component_name.ilike.%${query}%,component_description.ilike.%${query}%,tags.cs.{${query}}`)
      }

      if (filters?.category && filters?.category !== 'all') {
        queryBuilder = queryBuilder?.eq('products.category', filters?.category)
      }

      if (filters?.license && filters?.license !== 'all') {
        queryBuilder = queryBuilder?.eq('license_type', filters?.license)
      }

      if (filters?.priceRange && filters?.priceRange !== 'all') {
        const [min, max] = filters?.priceRange?.split('-')?.map(Number)
        if (max) {
          queryBuilder = queryBuilder?.gte('products.price', min)?.lte('products.price', max)
        } else {
          queryBuilder = queryBuilder?.gte('products.price', min)
        }
      }

      let orderBy = 'created_at'
      let ascending = false

      switch (filters?.sort) {
        case 'price-low':
          orderBy = 'products.price'
          ascending = true
          break
        case 'price-high':
          orderBy = 'products.price'
          ascending = false
          break
        case 'rating':
          orderBy = 'rating'
          ascending = false
          break
        case 'downloads':
          orderBy = 'downloads_count'
          ascending = false
          break
        default:
          orderBy = 'downloads_count'
          ascending = false
      }

      const { data, error } = await queryBuilder?.order(orderBy, { ascending })?.limit(50)

      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get single component by ID
  getById: async (id) => {
    try {
      const { data, error } = await supabase?.from('component_listings')?.select(`
          *,
          products:product_id (
            name,
            price,
            category,
            description,
            currency,
            metadata
          ),
          user_profiles:seller_id (
            full_name,
            avatar_url,
            email
          )
        `)?.eq('id', id)?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get user's components (for sellers)
  getUserComponents: async (userId) => {
    try {
      const { data, error } = await supabase?.from('component_listings')?.select(`
          *,
          products:product_id (
            name,
            price,
            category,
            description,
            currency
          )
        `)?.eq('seller_id', userId)?.order('created_at', { ascending: false })
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Create new component listing
  create: async (componentData, productData, userId) => {
    try {
      // First create the product
      const { data: product, error: productError } = await supabase?.from('products')?.insert([productData])?.select()?.single()

      if (productError) {
        return { data: null, error: productError }
      }

      // Then create the component listing
      const { data, error } = await supabase?.from('component_listings')?.insert([{ 
          ...componentData, 
          product_id: product?.id,
          seller_id: userId
        }])?.select()?.single()

      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Update component
  update: async (id, updates, userId) => {
    try {
      const { data, error } = await supabase?.from('component_listings')?.update(updates)?.eq('id', id)?.eq('seller_id', userId)?.select()?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Delete component
  delete: async (id, userId) => {
    try {
      const { error } = await supabase?.from('component_listings')?.delete()?.eq('id', id)?.eq('seller_id', userId)
      return { error }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  },

  // Increment download count (handled by database trigger)
  incrementDownload: async (id) => {
    try {
      const { data, error } = await supabase?.from('component_listings')?.update({ 
          downloads_count: supabase?.raw('downloads_count + 1')
        })?.eq('id', id)?.select()?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  }
}