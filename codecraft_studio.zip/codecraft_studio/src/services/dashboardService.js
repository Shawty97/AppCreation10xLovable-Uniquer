import { supabase } from '../lib/supabase';

export const dashboardService = {
  // Get comprehensive dashboard statistics
  getStats: async (userId) => {
    try {
      // Get projects count
      const { data: projects, error: projectsError } = await supabase
        ?.from('projects')
        ?.select('id, status, updated_at, deployment_url')
        ?.eq('user_id', userId)

      // Get deployments count  
      const { data: deployments, error: deploymentsError } = await supabase
        ?.from('deployments')
        ?.select('id, status, created_at, deployment_url')
        ?.eq('user_id', userId)

      // Get AI conversations count
      const { data: conversations, error: conversationsError } = await supabase
        ?.from('ai_conversations')
        ?.select('id, created_at, total_messages')
        ?.eq('user_id', userId)

      // Get component purchases count
      const { data: orders, error: ordersError } = await supabase
        ?.from('orders')
        ?.select('id, status, total_amount, created_at')
        ?.eq('user_id', userId)

      // Get user's templates count
      const { data: templates, error: templatesError } = await supabase
        ?.from('templates')
        ?.select('id, download_count, rating')
        ?.eq('creator_id', userId)

      if (projectsError || deploymentsError || conversationsError || ordersError || templatesError) {
        return { 
          data: null, 
          error: projectsError || deploymentsError || conversationsError || ordersError || templatesError 
        }
      }

      // Calculate statistics
      const stats = {
        projects: {
          total: projects?.length || 0,
          published: projects?.filter(p => p?.status === 'published')?.length || 0,
          draft: projects?.filter(p => p?.status === 'draft')?.length || 0,
          deployed: projects?.filter(p => p?.deployment_url)?.length || 0
        },
        deployments: {
          total: deployments?.length || 0,
          successful: deployments?.filter(d => d?.status === 'success')?.length || 0,
          failed: deployments?.filter(d => d?.status === 'failed')?.length || 0,
          pending: deployments?.filter(d => d?.status === 'pending' || d?.status === 'building')?.length || 0
        },
        aiConversations: {
          total: conversations?.length || 0,
          totalMessages: conversations?.reduce((sum, conv) => sum + (conv?.total_messages || 0), 0) || 0,
          thisWeek: conversations?.filter(c => {
            const weekAgo = new Date()
            weekAgo?.setDate(weekAgo?.getDate() - 7)
            return new Date(c.created_at) > weekAgo
          })?.length || 0
        },
        marketplace: {
          totalSpent: orders?.reduce((sum, order) => sum + (parseFloat(order?.total_amount) || 0), 0) || 0,
          totalOrders: orders?.length || 0,
          completedOrders: orders?.filter(o => o?.status === 'delivered')?.length || 0
        },
        templates: {
          total: templates?.length || 0,
          totalDownloads: templates?.reduce((sum, template) => sum + (template?.download_count || 0), 0) || 0,
          averageRating: templates?.length > 0 ? 
            templates?.reduce((sum, template) => sum + (template?.rating || 0), 0) / templates?.length : 0
        }
      }

      return { data: stats, error: null }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get recent activity across all user data
  getRecentActivity: async (userId, limit = 20) => {
    try {
      // Get recent projects
      const { data: projects, error: projectsError } = await supabase
        ?.from('projects')
        ?.select('id, name, updated_at, status, created_at')
        ?.eq('user_id', userId)
        ?.order('updated_at', { ascending: false })
        ?.limit(10)

      // Get recent deployments
      const { data: deployments, error: deploymentsError } = await supabase
        ?.from('deployments')
        ?.select(`
          id, status, created_at, completed_at,
          projects:project_id (name)
        `)
        ?.eq('user_id', userId)
        ?.order('created_at', { ascending: false })
        ?.limit(10)

      // Get recent AI conversations
      const { data: conversations, error: conversationsError } = await supabase
        ?.from('ai_conversations')
        ?.select('id, title, created_at, conversation_type')
        ?.eq('user_id', userId)
        ?.order('created_at', { ascending: false })
        ?.limit(10)

      // Get recent orders
      const { data: orders, error: ordersError } = await supabase
        ?.from('orders')
        ?.select('id, status, created_at, total_amount')
        ?.eq('user_id', userId)
        ?.order('created_at', { ascending: false })
        ?.limit(5)

      if (projectsError || deploymentsError || conversationsError || ordersError) {
        return { 
          data: [], 
          error: projectsError || deploymentsError || conversationsError || ordersError 
        }
      }

      const activities = []

      // Add project activities
      projects?.forEach(project => {
        const isNewProject = new Date(project.created_at)?.getTime() === new Date(project.updated_at)?.getTime()
        activities?.push({
          id: `project-${project?.id}`,
          type: isNewProject ? 'project-created' : 'project-updated',
          title: isNewProject ? 'Created new project' : 'Updated project',
          description: project?.name,
          timestamp: project?.updated_at,
          status: project?.status,
          icon: 'FolderPlus'
        })
      })

      // Add deployment activities
      deployments?.forEach(deployment => {
        activities?.push({
          id: `deployment-${deployment?.id}`,
          type: 'deployment',
          title: `Deployment ${deployment?.status}`,
          description: deployment?.projects?.name || 'Unknown Project',
          timestamp: deployment?.completed_at || deployment?.created_at,
          status: deployment?.status,
          icon: deployment?.status === 'success' ? 'CheckCircle' : 
                deployment?.status === 'failed' ? 'XCircle' : 'Clock'
        })
      })

      // Add AI conversation activities
      conversations?.forEach(conversation => {
        activities?.push({
          id: `conversation-${conversation?.id}`,
          type: 'ai-conversation',
          title: 'AI conversation started',
          description: conversation?.title || 'Untitled conversation',
          timestamp: conversation?.created_at,
          status: conversation?.conversation_type,
          icon: 'MessageSquare'
        })
      })

      // Add order activities
      orders?.forEach(order => {
        activities?.push({
          id: `order-${order?.id}`,
          type: 'purchase',
          title: 'Component purchase',
          description: `Order for $${order?.total_amount}`,
          timestamp: order?.created_at,
          status: order?.status,
          icon: 'ShoppingCart'
        })
      })

      // Sort by timestamp and limit
      const sortedActivities = activities
        ?.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
        ?.slice(0, limit)

      return { data: sortedActivities, error: null }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get featured content for dashboard
  getFeaturedContent: async (limit = 6) => {
    try {
      // Get featured templates
      const { data: templates, error: templatesError } = await supabase
        ?.from('templates')
        ?.select(`
          id, name, description, thumbnail_url, framework, 
          category, rating, download_count, is_premium,
          user_profiles:creator_id (full_name, avatar_url)
        `)
        ?.eq('is_featured', true)
        ?.order('rating', { ascending: false })
        ?.limit(limit)

      // Get featured components
      const { data: components, error: componentsError } = await supabase
        ?.from('component_listings')
        ?.select(`
          *, 
          products:product_id (name, price, category),
          user_profiles:seller_id (full_name, avatar_url)
        `)
        ?.eq('is_featured', true)
        ?.order('rating', { ascending: false })
        ?.limit(limit)

      if (templatesError || componentsError) {
        return { 
          data: { templates: [], components: [] }, 
          error: templatesError || componentsError 
        }
      }

      return { 
        data: { 
          templates: templates || [], 
          components: components || [] 
        }, 
        error: null 
      }
    } catch (error) {
      return { 
        data: { templates: [], components: [] }, 
        error: { message: 'Network error. Please try again.' } 
      }
    }
  },

  // Get user's recent projects for quick access
  getRecentProjects: async (userId, limit = 6) => {
    try {
      const { data, error } = await supabase
        ?.from('projects')
        ?.select('id, name, description, thumbnail_url, framework, status, last_opened_at, updated_at, deployment_url')
        ?.eq('user_id', userId)
        ?.order('last_opened_at', { ascending: false })
        ?.limit(limit)

      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Update project last opened timestamp
  updateProjectLastOpened: async (projectId, userId) => {
    try {
      const { data, error } = await supabase
        ?.from('projects')
        ?.update({ 
          last_opened_at: new Date()?.toISOString() 
        })
        ?.eq('id', projectId)
        ?.eq('user_id', userId)
        ?.select()
        ?.single()

      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get user performance metrics
  getPerformanceMetrics: async (userId, timeRange = '7d') => {
    try {
      const dateThreshold = new Date()
      switch (timeRange) {
        case '24h':
          dateThreshold?.setDate(dateThreshold?.getDate() - 1)
          break
        case '7d':
          dateThreshold?.setDate(dateThreshold?.getDate() - 7)
          break
        case '30d':
          dateThreshold?.setDate(dateThreshold?.getDate() - 30)
          break
        default:
          dateThreshold?.setDate(dateThreshold?.getDate() - 7)
      }

      // Get deployments in time range
      const { data: deployments, error: deploymentsError } = await supabase
        ?.from('deployments')
        ?.select('id, status, created_at, build_duration, deploy_duration')
        ?.eq('user_id', userId)
        ?.gte('created_at', dateThreshold?.toISOString())

      // Get AI conversations in time range
      const { data: conversations, error: conversationsError } = await supabase
        ?.from('ai_conversations')
        ?.select('id, created_at, total_messages')
        ?.eq('user_id', userId)
        ?.gte('created_at', dateThreshold?.toISOString())

      if (deploymentsError || conversationsError) {
        return { 
          data: null, 
          error: deploymentsError || conversationsError 
        }
      }

      const metrics = {
        deployments: {
          total: deployments?.length || 0,
          successRate: deployments?.length > 0 ? 
            (deployments?.filter(d => d?.status === 'success')?.length / deployments?.length) * 100 : 0,
          averageBuildTime: deployments?.length > 0 ?
            deployments?.reduce((sum, d) => sum + (d?.build_duration || 0), 0) / deployments?.length : 0,
          averageDeployTime: deployments?.length > 0 ?
            deployments?.reduce((sum, d) => sum + (d?.deploy_duration || 0), 0) / deployments?.length : 0
        },
        aiUsage: {
          totalConversations: conversations?.length || 0,
          totalMessages: conversations?.reduce((sum, conv) => sum + (conv?.total_messages || 0), 0) || 0,
          averageMessagesPerConversation: conversations?.length > 0 ?
            conversations?.reduce((sum, conv) => sum + (conv?.total_messages || 0), 0) / conversations?.length : 0
        },
        timeRange
      }

      return { data: metrics, error: null }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get system health/status
  getSystemHealth: async () => {
    try {
      // Test database connectivity
      const { data, error } = await supabase
        ?.from('user_profiles')
        ?.select('id')
        ?.limit(1)
      
      if (error) {
        return { 
          data: { 
            status: 'degraded', 
            database: 'error', 
            message: 'Database connectivity issues',
            timestamp: new Date()?.toISOString()
          }, 
          error 
        };
      }

      return { 
        data: { 
          status: 'healthy', 
          database: 'operational', 
          message: 'All systems operational',
          timestamp: new Date()?.toISOString()
        }, 
        error: null 
      };
    } catch (error) {
      return { 
        data: { 
          status: 'down', 
          database: 'error', 
          message: 'Service unavailable',
          timestamp: new Date()?.toISOString()
        }, 
        error: { message: 'Network error. Please try again.' } 
      };
    }
  },

  // Get user's usage analytics
  getUsageAnalytics: async (userId, period = 'month') => {
    try {
      const dateThreshold = new Date()
      switch (period) {
        case 'week':
          dateThreshold?.setDate(dateThreshold?.getDate() - 7)
          break
        case 'month':
          dateThreshold?.setMonth(dateThreshold?.getMonth() - 1)
          break
        case 'year':
          dateThreshold?.setFullYear(dateThreshold?.getFullYear() - 1)
          break
      }

      // Get comprehensive usage data
      const [projectsRes, deploymentsRes, conversationsRes, templatesRes] = await Promise.all([
        supabase?.from('projects')?.select('created_at, status')?.eq('user_id', userId)?.gte('created_at', dateThreshold?.toISOString()),
        supabase?.from('deployments')?.select('created_at, status')?.eq('user_id', userId)?.gte('created_at', dateThreshold?.toISOString()),
        supabase?.from('ai_conversations')?.select('created_at, total_messages')?.eq('user_id', userId)?.gte('created_at', dateThreshold?.toISOString()),
        supabase?.from('templates')?.select('created_at, download_count')?.eq('creator_id', userId)?.gte('created_at', dateThreshold?.toISOString())
      ])

      const analytics = {
        projects: {
          created: projectsRes?.data?.length || 0,
          published: projectsRes?.data?.filter(p => p?.status === 'published')?.length || 0
        },
        deployments: {
          total: deploymentsRes?.data?.length || 0,
          successful: deploymentsRes?.data?.filter(d => d?.status === 'success')?.length || 0
        },
        ai: {
          conversations: conversationsRes?.data?.length || 0,
          messages: conversationsRes?.data?.reduce((sum, conv) => sum + (conv?.total_messages || 0), 0) || 0
        },
        templates: {
          created: templatesRes?.data?.length || 0,
          downloads: templatesRes?.data?.reduce((sum, template) => sum + (template?.download_count || 0), 0) || 0
        },
        period
      }

      return { data: analytics, error: null }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  }
}