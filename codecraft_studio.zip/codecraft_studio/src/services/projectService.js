import { supabase } from '../lib/supabase';

export const projectService = {
  // Get all projects for current user
  getAll: async (userId) => {
    try {
      const { data, error } = await supabase
        ?.from('projects')
        ?.select('*')
        ?.eq('user_id', userId)
        ?.order('updated_at', { ascending: false })
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get public projects (for marketplace/showcase)
  getPublic: async (limit = 20) => {
    try {
      const { data, error } = await supabase
        ?.from('projects')
        ?.select(`
          *,
          user_profiles:user_id (
            full_name,
            avatar_url
          )
        `)
        ?.eq('is_public', true)
        ?.eq('status', 'published')
        ?.order('updated_at', { ascending: false })
        ?.limit(limit)
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get single project by ID
  getById: async (id, userId) => {
    try {
      const { data, error } = await supabase
        ?.from('projects')
        ?.select('*')
        ?.eq('id', id)
        ?.eq('user_id', userId)
        ?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Create new project
  create: async (projectData, userId) => {
    try {
      const { data, error } = await supabase
        ?.from('projects')
        ?.insert([{ 
          ...projectData, 
          user_id: userId,
          status: 'draft',
          settings: projectData?.settings || {}
        }])
        ?.select()
        ?.single()

      // Update user's project count
      if (!error && data) {
        await supabase
          ?.from('user_profiles')
          ?.update({ 
            total_projects: supabase.rpc('increment_projects'),
            updated_at: new Date()?.toISOString()
          })
          ?.eq('id', userId)
      }

      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Update existing project
  update: async (id, updates, userId) => {
    try {
      const { data, error } = await supabase
        ?.from('projects')
        ?.update({
          ...updates,
          last_opened_at: new Date()?.toISOString()
        })
        ?.eq('id', id)
        ?.eq('user_id', userId)
        ?.select()
        ?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Delete project
  delete: async (id, userId) => {
    try {
      const { error } = await supabase
        ?.from('projects')
        ?.delete()
        ?.eq('id', id)
        ?.eq('user_id', userId)

      // Update user's project count
      if (!error) {
        await supabase
          ?.from('user_profiles')
          ?.update({ 
            total_projects: supabase.rpc('decrement_projects'),
            updated_at: new Date()?.toISOString()
          })
          ?.eq('id', userId)
      }

      return { error }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  },

  // Publish/unpublish project
  togglePublic: async (id, isPublic, userId) => {
    try {
      const { data, error } = await supabase
        ?.from('projects')
        ?.update({ 
          is_public: isPublic,
          status: isPublic ? 'published' : 'draft'
        })
        ?.eq('id', id)
        ?.eq('user_id', userId)
        ?.select()
        ?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Search projects
  search: async (query, userId = null) => {
    try {
      let queryBuilder = supabase
        ?.from('projects')
        ?.select(`
          *,
          user_profiles:user_id (
            full_name,
            avatar_url
          )
        `)
        ?.or(`name.ilike.%${query}%,description.ilike.%${query}%`)

      if (userId) {
        queryBuilder = queryBuilder?.eq('user_id', userId)
      } else {
        queryBuilder = queryBuilder
          ?.eq('is_public', true)
          ?.eq('status', 'published')
      }

      const { data, error } = await queryBuilder?.order('updated_at', { ascending: false })
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  }
}