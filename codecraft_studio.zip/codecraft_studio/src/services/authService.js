import { supabase } from '../lib/supabase';

export const authService = {
  // Sign in user
  signIn: async (email, password) => {
    try {
      const { data, error } = await supabase?.auth?.signInWithPassword({
        email,
        password
      })
      return { data, error }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  },

  // Sign up user
  signUp: async (email, password, userData = {}) => {
    try {
      const { data, error } = await supabase?.auth?.signUp({
        email,
        password,
        options: { 
          data: {
            full_name: userData?.full_name || userData?.fullName || 'New User',
            role: userData?.role || 'free'
          }
        }
      })
      return { data, error }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  },

  // Sign out user
  signOut: async () => {
    try {
      const { error } = await supabase?.auth?.signOut()
      return { error }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get current session
  getSession: async () => {
    try {
      const { data: { session }, error } = await supabase?.auth?.getSession()
      return { session, error }
    } catch (error) {
      return { session: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get user profile
  getUserProfile: async (userId) => {
    try {
      const { data, error } = await supabase
        ?.from('user_profiles')
        ?.select('*')
        ?.eq('id', userId)
        ?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Update user profile
  updateProfile: async (userId, updates) => {
    try {
      const { data, error } = await supabase
        ?.from('user_profiles')
        ?.update(updates)
        ?.eq('id', userId)
        ?.select()
        ?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Check subscription status
  hasValidSubscription: async (userId) => {
    try {
      const { data, error } = await supabase
        ?.from('user_profiles')
        ?.select('role, subscription_status, subscription_expires_at')
        ?.eq('id', userId)
        ?.single()

      if (error) return { isValid: false, error }

      const now = new Date()
      const expiresAt = data?.subscription_expires_at ? new Date(data.subscription_expires_at) : null
      
      const isValid = data?.role === 'admin' || 
                     (data?.subscription_status === 'active' && (!expiresAt || expiresAt > now))

      return { isValid, data, error: null }
    } catch (error) {
      return { isValid: false, error: { message: 'Network error. Please try again.' } }
    }
  }
}