import { supabase } from '../lib/supabase';

export const announcementService = {
  // Get system announcements (can be stored in a simple table or managed via admin)
  getAnnouncements: async (limit = 5) => {
    try {
      // For now, we'll return some dynamic announcements based on user data
      // In production, you'd want a dedicated announcements table
      
      // Check for recent templates
      const { data: recentTemplates } = await supabase?.from('templates')?.select('name, created_at, is_featured')?.eq('is_featured', true)?.order('created_at', { ascending: false })?.limit(1)

      // Check for recent components
      const { data: recentComponents } = await supabase?.from('component_listings')?.select('component_name, created_at, rating')?.eq('is_featured', true)?.order('created_at', { ascending: false })?.limit(1)

      const announcements = []

      // Add new template announcement
      if (recentTemplates?.length > 0) {
        const template = recentTemplates?.[0]
        const daysAgo = Math.floor((new Date() - new Date(template.created_at)) / (1000 * 60 * 60 * 24))
        
        if (daysAgo <= 7) {
          announcements?.push({
            id: `template-${template?.name?.replace(/\s+/g, '-')?.toLowerCase()}`,
            type: 'feature',
            title: '🚀 New Featured Template',
            message: `Check out our latest featured template: "${template?.name}". Perfect for your next project!`,
            date: template?.created_at,
            actionLabel: 'View Template',
            actionUrl: '/template-gallery'
          })
        }
      }

      // Add new component announcement
      if (recentComponents?.length > 0) {
        const component = recentComponents?.[0]
        const daysAgo = Math.floor((new Date() - new Date(component.created_at)) / (1000 * 60 * 60 * 24))
        
        if (daysAgo <= 7) {
          announcements?.push({
            id: `component-${component?.component_name?.replace(/\s+/g, '-')?.toLowerCase()}`,
            type: 'update',
            title: '✨ New Component Available',
            message: `New component "${component?.component_name}" is now available in the marketplace with ${component?.rating}/5 rating!`,
            date: component?.created_at,
            actionLabel: 'Browse Components',
            actionUrl: '/component-marketplace'
          })
        }
      }

      // Add general announcements
      announcements?.push(
        {
          id: 'welcome-2025',
          type: 'promotion',
          title: '🎉 Welcome to 2025!',
          message: 'New year, new features! Explore our enhanced AI-powered development tools and real-time collaboration features.',
          date: '2025-01-01T00:00:00Z',
          actionLabel: 'Explore Features',
          actionUrl: '/dashboard'
        },
        {
          id: 'performance-update',
          type: 'update',
          title: '⚡ Performance Improvements',
          message: 'We\'ve optimized our platform for 50% faster load times and smoother user experience.',
          date: '2025-01-10T10:00:00Z',
          actionLabel: 'Learn More',
          actionUrl: '/performance-analytics-center'
        }
      )

      return { data: announcements?.slice(0, limit), error: null };
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Mark announcement as dismissed (could store in user preferences)
  dismissAnnouncement: async (announcementId, userId) => {
    try {
      // Get current user preferences
      const { data: profile, error: fetchError } = await supabase?.from('user_profiles')?.select('preferences')?.eq('id', userId)?.single()

      if (fetchError) {
        return { error: fetchError }
      }

      const preferences = profile?.preferences || {}
      const dismissedAnnouncements = preferences?.dismissedAnnouncements || []

      if (!dismissedAnnouncements?.includes(announcementId)) {
        dismissedAnnouncements?.push(announcementId)
      }

      const { error } = await supabase?.from('user_profiles')?.update({
          preferences: {
            ...preferences,
            dismissedAnnouncements
          }
        })?.eq('id', userId)

      return { error }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get user's dismissed announcements
  getDismissedAnnouncements: async (userId) => {
    try {
      const { data, error } = await supabase?.from('user_profiles')?.select('preferences')?.eq('id', userId)?.single()

      if (error) {
        return { data: [], error }
      }

      const dismissedAnnouncements = data?.preferences?.dismissedAnnouncements || []
      return { data: dismissedAnnouncements, error: null }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  }
}