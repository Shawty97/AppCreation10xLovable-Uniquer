import { supabase } from '../lib/supabase';

export const telemetryService = {
  // Track user events (no PII - only usage patterns)
  trackEvent: async (eventName, properties = {}, userId = null) => {
    try {
      // Only track essential events, no PII
      const allowedEvents = [
        'first_data_query',
        'first_mutation', 
        'first_deployment',
        'template_used',
        'component_purchased',
        'project_created',
        'deployment_triggered',
        'ai_conversation_started',
        'error_encountered',
        'page_view'
      ]

      if (!allowedEvents?.includes(eventName)) {
        return { error: { message: 'Event not allowed for tracking' } }
      }

      // Sanitize properties to remove any PII
      const sanitizedProperties = {
        timestamp: new Date()?.toISOString(),
        event: eventName,
        // Only include non-PII technical metadata
        framework: properties?.framework,
        template_category: properties?.template_category,
        component_type: properties?.component_type,
        error_type: properties?.error_type,
        page_path: properties?.page_path?.replace(/\/[a-f0-9-]{36}/g, '/[id]'), // Remove UUIDs
        duration: properties?.duration,
        status: properties?.status,
        // Session info (anonymized)
        session_id: properties?.session_id,
        user_agent_category: this.categorizeUserAgent(properties?.user_agent),
        // Do NOT include: emails, names, IP addresses, specific content
      }

      // Store in user preferences for lightweight analytics
      if (userId) {
        const { data: profile } = await supabase
          ?.from('user_profiles')
          ?.select('preferences')
          ?.eq('id', userId)
          ?.single()

        const preferences = profile?.preferences || {}
        const telemetryEvents = preferences?.telemetryEvents || []
        
        telemetryEvents?.push(sanitizedProperties)
        
        // Keep only last 100 events per user
        const recentEvents = telemetryEvents?.slice(-100)

        await supabase
          ?.from('user_profiles')
          ?.update({
            preferences: {
              ...preferences,
              telemetryEvents: recentEvents,
              lastEventAt: new Date()?.toISOString()
            }
          })
          ?.eq('id', userId)
      }

      return { data: sanitizedProperties, error: null }
    } catch (error) {
      // Fail silently for telemetry to not disrupt user experience
      return { error: { message: 'Telemetry failed' } }
    }
  },

  // Track error hotspots (no sensitive data)
  trackError: async (errorType, errorContext = {}, userId = null) => {
    try {
      const errorEvent = {
        event: 'error_encountered',
        error_type: errorType,
        error_category: this.categorizeError(errorType),
        component: errorContext?.component,
        action: errorContext?.action,
        timestamp: new Date()?.toISOString(),
        // No sensitive data in error context
        http_status: errorContext?.http_status,
        network_error: errorContext?.network_error,
        browser_category: this.categorizeUserAgent(navigator?.userAgent)
      }

      return await this.trackEvent('error_encountered', errorEvent, userId)
    } catch (error) {
      return { error: { message: 'Error tracking failed' } }
    }
  },

  // Get error analytics (for admins/debugging)
  getErrorAnalytics: async (timeRange = '7d') => {
    try {
      const dateThreshold = new Date()
      switch (timeRange) {
        case '24h':
          dateThreshold?.setDate(dateThreshold?.getDate() - 1)
          break
        case '7d':
          dateThreshold?.setDate(dateThreshold?.getDate() - 7)
          break
        case '30d':
          dateThreshold?.setDate(dateThreshold?.getDate() - 30)
          break
      }

      // Get aggregated error data from user preferences
      const { data: profiles } = await supabase
        ?.from('user_profiles')
        ?.select('preferences')
        ?.gte('updated_at', dateThreshold?.toISOString())

      const errorAnalytics = {
        totalErrors: 0,
        errorTypes: {},
        errorCategories: {},
        components: {},
        timeSpread: {}
      }

      profiles?.forEach(profile => {
        const events = profile?.preferences?.telemetryEvents || []
        const errorEvents = events?.filter(e => e?.event === 'error_encountered')

        errorEvents?.forEach(error => {
          if (new Date(error.timestamp) > dateThreshold) {
            errorAnalytics.totalErrors++
            
            // Count error types
            const errorType = error?.error_type || 'unknown'
            errorAnalytics.errorTypes[errorType] = (errorAnalytics?.errorTypes?.[errorType] || 0) + 1
            
            // Count error categories
            const errorCategory = error?.error_category || 'unknown'
            errorAnalytics.errorCategories[errorCategory] = (errorAnalytics?.errorCategories?.[errorCategory] || 0) + 1
            
            // Count component errors
            const component = error?.component || 'unknown'
            errorAnalytics.components[component] = (errorAnalytics?.components?.[component] || 0) + 1
          }
        })
      })

      return { data: errorAnalytics, error: null }
    } catch (error) {
      return { data: null, error: { message: 'Failed to get error analytics' } }
    }
  },

  // Get usage analytics (aggregated, no PII)
  getUsageAnalytics: async (timeRange = '7d') => {
    try {
      const dateThreshold = new Date()
      switch (timeRange) {
        case '24h':
          dateThreshold?.setDate(dateThreshold?.getDate() - 1)
          break
        case '7d':
          dateThreshold?.setDate(dateThreshold?.getDate() - 7)
          break
        case '30d':
          dateThreshold?.setDate(dateThreshold?.getDate() - 30)
          break
      }

      // Get usage data from database
      const [projectsRes, deploymentsRes, templatesRes, componentsRes] = await Promise.all([
        supabase?.from('projects')?.select('created_at, framework, status')?.gte('created_at', dateThreshold?.toISOString()),
        supabase?.from('deployments')?.select('created_at, status')?.gte('created_at', dateThreshold?.toISOString()),
        supabase?.from('templates')?.select('created_at, framework, category, download_count')?.gte('created_at', dateThreshold?.toISOString()),
        supabase?.from('component_listings')?.select('created_at, downloads_count')?.gte('created_at', dateThreshold?.toISOString())
      ])

      const analytics = {
        projects: {
          total: projectsRes?.data?.length || 0,
          byFramework: {},
          published: projectsRes?.data?.filter(p => p?.status === 'published')?.length || 0
        },
        deployments: {
          total: deploymentsRes?.data?.length || 0,
          successful: deploymentsRes?.data?.filter(d => d?.status === 'success')?.length || 0,
          failed: deploymentsRes?.data?.filter(d => d?.status === 'failed')?.length || 0
        },
        templates: {
          total: templatesRes?.data?.length || 0,
          totalDownloads: templatesRes?.data?.reduce((sum, t) => sum + (t?.download_count || 0), 0) || 0,
          byCategory: {}
        },
        components: {
          total: componentsRes?.data?.length || 0,
          totalDownloads: componentsRes?.data?.reduce((sum, c) => sum + (c?.downloads_count || 0), 0) || 0
        }
      }

      // Aggregate framework usage
      projectsRes?.data?.forEach(project => {
        const framework = project?.framework || 'unknown'
        analytics.projects.byFramework[framework] = (analytics?.projects?.byFramework?.[framework] || 0) + 1
      })

      // Aggregate template categories
      templatesRes?.data?.forEach(template => {
        const category = template?.category || 'unknown'
        analytics.templates.byCategory[category] = (analytics?.templates?.byCategory?.[category] || 0) + 1
      })

      return { data: analytics, error: null }
    } catch (error) {
      return { data: null, error: { message: 'Failed to get usage analytics' } }
    }
  },

  // Helper: Categorize user agent (no PII)
  categorizeUserAgent: (userAgent) => {
    if (!userAgent) return 'unknown'
    
    if (userAgent?.includes('Chrome')) return 'chrome'
    if (userAgent?.includes('Firefox')) return 'firefox'
    if (userAgent?.includes('Safari') && !userAgent?.includes('Chrome')) return 'safari'
    if (userAgent?.includes('Edge')) return 'edge'
    return 'other'
  },

  // Helper: Categorize errors
  categorizeError: (errorType) => {
    if (!errorType) return 'unknown'
    
    if (errorType?.includes('network') || errorType?.includes('fetch')) return 'network'
    if (errorType?.includes('auth')) return 'authentication'
    if (errorType?.includes('permission') || errorType?.includes('rls')) return 'authorization'
    if (errorType?.includes('validation')) return 'validation'
    if (errorType?.includes('database') || errorType?.includes('supabase')) return 'database'
    return 'application'
  },

  // Track milestone events
  trackMilestone: async (milestone, userId) => {
    const milestoneEvents = {
      first_project: 'first_project_created',
      first_deployment: 'first_deployment',
      first_template_use: 'first_template_used',
      first_component_purchase: 'first_component_purchased',
      first_ai_conversation: 'first_ai_conversation'
    }

    const eventName = milestoneEvents?.[milestone]
    if (eventName) {
      return await this.trackEvent(eventName, { milestone }, userId)
    }

    return { error: { message: 'Unknown milestone' } }
  }
}