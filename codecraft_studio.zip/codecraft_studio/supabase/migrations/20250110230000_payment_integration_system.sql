-- Payment Integration System Migration
-- Schema Analysis: Existing CodeCraft Studio schema with user_profiles table exists
-- Integration Type: Addition - creating new payment functionality
-- Dependencies: user_profiles (existing table)

-- 1. Payment-related Types
CREATE TYPE public.payment_status AS ENUM ('pending', 'succeeded', 'failed', 'cancelled', 'refunded');
CREATE TYPE public.order_status AS ENUM ('pending', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded');
CREATE TYPE public.subscription_tier AS ENUM ('free', 'basic', 'premium', 'enterprise');
CREATE TYPE public.component_license AS ENUM ('single_use', 'unlimited', 'team', 'enterprise');

-- 2. Core Payment Tables
CREATE TABLE public.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    category TEXT,
    price DECIMAL(10,2) NOT NULL,
    currency TEXT DEFAULT 'USD',
    is_active BOOLEAN DEFAULT true,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.component_listings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
    seller_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    component_name TEXT NOT NULL,
    component_description TEXT,
    license_type public.component_license DEFAULT 'single_use',
    preview_url TEXT,
    download_url TEXT,
    tech_stack TEXT[],
    tags TEXT[],
    rating DECIMAL(3,2) DEFAULT 0.0,
    downloads_count INTEGER DEFAULT 0,
    is_featured BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.shopping_cart (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
    quantity INTEGER NOT NULL DEFAULT 1,
    license_type public.component_license DEFAULT 'single_use',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, product_id, license_type)
);

CREATE TABLE public.orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    order_number TEXT UNIQUE NOT NULL,
    status public.order_status DEFAULT 'pending',
    payment_status public.payment_status DEFAULT 'pending',
    subtotal DECIMAL(10,2) NOT NULL,
    tax_amount DECIMAL(10,2) DEFAULT 0,
    discount_amount DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    currency TEXT DEFAULT 'USD',
    stripe_payment_intent_id TEXT UNIQUE,
    billing_address JSONB,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
    product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
    component_listing_id UUID REFERENCES public.component_listings(id) ON DELETE SET NULL,
    product_name TEXT NOT NULL,
    license_type public.component_license,
    price DECIMAL(10,2) NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    total DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.payment_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    stripe_payment_intent_id TEXT,
    stripe_charge_id TEXT,
    amount DECIMAL(10,2) NOT NULL,
    currency TEXT DEFAULT 'USD',
    status public.payment_status NOT NULL,
    payment_method_type TEXT,
    transaction_type TEXT DEFAULT 'payment' CHECK (transaction_type IN ('payment', 'refund', 'dispute')),
    gateway TEXT DEFAULT 'stripe',
    gateway_response JSONB,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    tier public.subscription_tier DEFAULT 'free',
    stripe_subscription_id TEXT UNIQUE,
    stripe_customer_id TEXT,
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'cancelled', 'past_due', 'trialing')),
    current_period_start TIMESTAMPTZ,
    current_period_end TIMESTAMPTZ,
    trial_end TIMESTAMPTZ,
    price DECIMAL(10,2),
    currency TEXT DEFAULT 'USD',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.payment_methods (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    stripe_payment_method_id TEXT UNIQUE NOT NULL,
    type TEXT NOT NULL,
    card_brand TEXT,
    card_last_four TEXT,
    card_exp_month INTEGER,
    card_exp_year INTEGER,
    is_default BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.revenue_shares (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    component_listing_id UUID REFERENCES public.component_listings(id) ON DELETE CASCADE,
    seller_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    order_item_id UUID REFERENCES public.order_items(id) ON DELETE CASCADE,
    gross_amount DECIMAL(10,2) NOT NULL,
    platform_fee_rate DECIMAL(5,4) DEFAULT 0.1000,
    platform_fee DECIMAL(10,2) NOT NULL,
    seller_amount DECIMAL(10,2) NOT NULL,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'held')),
    payout_date TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Essential Indexes
CREATE INDEX idx_products_category ON public.products(category);
CREATE INDEX idx_products_price ON public.products(price);
CREATE INDEX idx_component_listings_seller ON public.component_listings(seller_id);
CREATE INDEX idx_component_listings_category ON public.component_listings(product_id);
CREATE INDEX idx_shopping_cart_user ON public.shopping_cart(user_id);
CREATE INDEX idx_orders_user ON public.orders(user_id);
CREATE INDEX idx_orders_status ON public.orders(status);
CREATE INDEX idx_order_items_order ON public.order_items(order_id);
CREATE INDEX idx_payment_transactions_user ON public.payment_transactions(user_id);
CREATE INDEX idx_subscriptions_user ON public.subscriptions(user_id);
CREATE INDEX idx_payment_methods_user ON public.payment_methods(user_id);
CREATE INDEX idx_revenue_shares_seller ON public.revenue_shares(seller_id);

-- 4. Functions (Must be before RLS policies)
CREATE OR REPLACE FUNCTION public.calculate_revenue_share()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    platform_fee_rate DECIMAL(5,4) := 0.1000; -- 10% platform fee
    platform_fee_amount DECIMAL(10,2);
    seller_amount DECIMAL(10,2);
BEGIN
    platform_fee_amount := NEW.total * platform_fee_rate;
    seller_amount := NEW.total - platform_fee_amount;
    
    -- Only create revenue share for component sales
    IF NEW.component_listing_id IS NOT NULL THEN
        INSERT INTO public.revenue_shares (
            component_listing_id,
            seller_id,
            order_item_id,
            gross_amount,
            platform_fee_rate,
            platform_fee,
            seller_amount
        )
        SELECT 
            NEW.component_listing_id,
            cl.seller_id,
            NEW.id,
            NEW.total,
            platform_fee_rate,
            platform_fee_amount,
            seller_amount
        FROM public.component_listings cl
        WHERE cl.id = NEW.component_listing_id;
    END IF;
    
    RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_component_downloads()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Update download count when order status changes to completed
    IF NEW.status = 'delivered' AND OLD.status != 'delivered' THEN
        UPDATE public.component_listings 
        SET downloads_count = downloads_count + oi.quantity
        FROM public.order_items oi
        WHERE oi.order_id = NEW.id 
        AND oi.component_listing_id = component_listings.id;
    END IF;
    
    RETURN NEW;
END;
$$;

-- 5. Enable RLS
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.component_listings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shopping_cart ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_methods ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.revenue_shares ENABLE ROW LEVEL SECURITY;

-- 6. RLS Policies
-- Pattern 4: Public read, private write for products
CREATE POLICY "public_can_read_products"
ON public.products
FOR SELECT
TO public
USING (is_active = true);

CREATE POLICY "authenticated_users_manage_products"
ON public.products
FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

-- Pattern 4: Public read, private write for component listings
CREATE POLICY "public_can_read_component_listings"
ON public.component_listings
FOR SELECT
TO public
USING (true);

CREATE POLICY "sellers_manage_own_component_listings"
ON public.component_listings
FOR ALL
TO authenticated
USING (seller_id = auth.uid())
WITH CHECK (seller_id = auth.uid());

-- Pattern 2: Simple user ownership for shopping cart
CREATE POLICY "users_manage_own_shopping_cart"
ON public.shopping_cart
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Pattern 2: Simple user ownership for orders
CREATE POLICY "users_manage_own_orders"
ON public.orders
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Pattern 3: Operation-specific for order items (users can view, platform can manage)
CREATE POLICY "users_can_view_own_order_items"
ON public.order_items
FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.orders o 
        WHERE o.id = order_items.order_id 
        AND o.user_id = auth.uid()
    )
);

-- Fixed: Separate policies for each operation type
CREATE POLICY "platform_manages_order_items_insert"
ON public.order_items
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "platform_manages_order_items_update"
ON public.order_items
FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "platform_manages_order_items_delete"
ON public.order_items
FOR DELETE
TO authenticated
USING (true);

-- Pattern 2: Simple user ownership for payment transactions
CREATE POLICY "users_manage_own_payment_transactions"
ON public.payment_transactions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Pattern 2: Simple user ownership for subscriptions
CREATE POLICY "users_manage_own_subscriptions"
ON public.subscriptions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Pattern 2: Simple user ownership for payment methods
CREATE POLICY "users_manage_own_payment_methods"
ON public.payment_methods
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Pattern 2: Simple user ownership for revenue shares
CREATE POLICY "sellers_manage_own_revenue_shares"
ON public.revenue_shares
FOR ALL
TO authenticated
USING (seller_id = auth.uid())
WITH CHECK (seller_id = auth.uid());

-- 7. Triggers
CREATE TRIGGER on_order_item_revenue_share
    AFTER INSERT ON public.order_items
    FOR EACH ROW EXECUTE FUNCTION public.calculate_revenue_share();

CREATE TRIGGER on_order_status_update_downloads
    AFTER UPDATE ON public.orders
    FOR EACH ROW EXECUTE FUNCTION public.update_component_downloads();

-- 8. Mock Data for Payment System
DO $$
DECLARE
    existing_user_id UUID;
    product1_id UUID := gen_random_uuid();
    product2_id UUID := gen_random_uuid();
    component1_id UUID := gen_random_uuid();
    component2_id UUID := gen_random_uuid();
    order1_id UUID := gen_random_uuid();
BEGIN
    -- Get existing user ID from user_profiles
    SELECT id INTO existing_user_id FROM public.user_profiles LIMIT 1;
    
    IF existing_user_id IS NOT NULL THEN
        -- Create sample products
        INSERT INTO public.products (id, name, description, category, price, currency) VALUES
            (product1_id, 'React Dashboard Template', 'Professional dashboard template with charts and analytics', 'templates', 49.99, 'USD'),
            (product2_id, 'Vue.js E-commerce Components', 'Complete set of e-commerce components for Vue.js', 'components', 29.99, 'USD');

        -- Create component listings
        INSERT INTO public.component_listings (
            id, product_id, seller_id, component_name, component_description, 
            license_type, tech_stack, tags, rating
        ) VALUES
            (component1_id, product1_id, existing_user_id, 'Analytics Dashboard', 
             'Modern analytics dashboard with real-time charts', 'unlimited'::public.component_license, 
             ARRAY['React', 'TypeScript', 'Chart.js'], ARRAY['dashboard', 'analytics', 'charts'], 4.8),
            (component2_id, product2_id, existing_user_id, 'Shopping Cart Widget', 
             'Responsive shopping cart with payment integration', 'team'::public.component_license,
             ARRAY['Vue.js', 'JavaScript', 'CSS3'], ARRAY['ecommerce', 'cart', 'responsive'], 4.5);

        -- Create sample shopping cart items
        INSERT INTO public.shopping_cart (user_id, product_id, quantity, license_type) VALUES
            (existing_user_id, product1_id, 1, 'unlimited'::public.component_license),
            (existing_user_id, product2_id, 2, 'team'::public.component_license);

        -- Create sample order
        INSERT INTO public.orders (
            id, user_id, order_number, status, payment_status, 
            subtotal, tax_amount, total_amount, currency
        ) VALUES
            (order1_id, existing_user_id, 'ORD-2025-001', 'delivered'::public.order_status, 
             'succeeded'::public.payment_status, 79.98, 8.00, 87.98, 'USD');

        -- Create order items
        INSERT INTO public.order_items (
            order_id, product_id, component_listing_id, product_name, 
            license_type, price, quantity, total
        ) VALUES
            (order1_id, product1_id, component1_id, 'React Dashboard Template', 
             'unlimited'::public.component_license, 49.99, 1, 49.99),
            (order1_id, product2_id, component2_id, 'Vue.js E-commerce Components', 
             'team'::public.component_license, 29.99, 1, 29.99);

        -- Create subscription
        INSERT INTO public.subscriptions (
            user_id, tier, status, current_period_start, current_period_end, price, currency
        ) VALUES
            (existing_user_id, 'premium'::public.subscription_tier, 'active', 
             CURRENT_TIMESTAMP, CURRENT_TIMESTAMP + INTERVAL '1 month', 19.99, 'USD');

        RAISE NOTICE 'Payment system mock data created successfully for user: %', existing_user_id;
    ELSE
        RAISE NOTICE 'No existing users found. Please create user profiles first.';
    END IF;

EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key error during mock data creation: %', SQLERRM;
    WHEN unique_violation THEN
        RAISE NOTICE 'Unique constraint error during mock data creation: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Unexpected error during mock data creation: %', SQLERRM;
END $$;