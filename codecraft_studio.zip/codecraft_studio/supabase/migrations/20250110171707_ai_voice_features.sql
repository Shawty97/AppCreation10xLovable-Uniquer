-- Location: supabase/migrations/20250110171707_ai_voice_features.sql
-- Schema Analysis: Existing schema with user_profiles, projects, templates tables
-- Integration Type: Addition - Adding AI voice and assistant features 
-- Dependencies: References existing user_profiles table

-- Create enums for AI features
CREATE TYPE public.voice_session_status AS ENUM ('recording', 'processing', 'completed', 'error');
CREATE TYPE public.ai_conversation_type AS ENUM ('voice_creation', 'general_help', 'code_review', 'project_guidance');
CREATE TYPE public.voice_command_category AS ENUM ('navigation', 'component_creation', 'styling', 'project_management');

-- Voice sessions table for voice-to-app creator
CREATE TABLE public.voice_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    session_name TEXT,
    status public.voice_session_status DEFAULT 'recording'::public.voice_session_status,
    audio_url TEXT,
    transcript TEXT,
    extracted_requirements JSONB DEFAULT '{}'::jsonb,
    generated_components JSONB DEFAULT '{}'::jsonb,
    voice_settings JSONB DEFAULT '{}'::jsonb,
    duration_seconds INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Voice commands library
CREATE TABLE public.voice_commands (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    command_phrase TEXT NOT NULL,
    category public.voice_command_category NOT NULL,
    description TEXT,
    action_data JSONB DEFAULT '{}'::jsonb,
    usage_count INTEGER DEFAULT 0,
    is_custom BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- AI assistant conversations
CREATE TABLE public.ai_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    conversation_type public.ai_conversation_type DEFAULT 'general_help'::public.ai_conversation_type,
    title TEXT,
    context_data JSONB DEFAULT '{}'::jsonb,
    messages JSONB DEFAULT '[]'::jsonb,
    project_id UUID REFERENCES public.projects(id) ON DELETE SET NULL,
    is_active BOOLEAN DEFAULT true,
    total_messages INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- User AI preferences for context-aware assistant
CREATE TABLE public.ai_user_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    learning_enabled BOOLEAN DEFAULT true,
    preferred_frameworks JSONB DEFAULT '[]'::jsonb,
    coding_style_preferences JSONB DEFAULT '{}'::jsonb,
    assistance_level TEXT DEFAULT 'balanced',
    voice_settings JSONB DEFAULT '{}'::jsonb,
    interaction_patterns JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Voice training data for personalization
CREATE TABLE public.voice_training_data (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    audio_sample_url TEXT,
    expected_text TEXT,
    recognized_text TEXT,
    accuracy_score DECIMAL(3,2),
    language_code TEXT DEFAULT 'en-US',
    accent_profile JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for better performance
CREATE INDEX idx_voice_sessions_user_id ON public.voice_sessions(user_id);
CREATE INDEX idx_voice_sessions_status ON public.voice_sessions(status);
CREATE INDEX idx_voice_sessions_created_at ON public.voice_sessions(created_at);

CREATE INDEX idx_voice_commands_user_id ON public.voice_commands(user_id);
CREATE INDEX idx_voice_commands_category ON public.voice_commands(category);
CREATE INDEX idx_voice_commands_usage_count ON public.voice_commands(usage_count DESC);

CREATE INDEX idx_ai_conversations_user_id ON public.ai_conversations(user_id);
CREATE INDEX idx_ai_conversations_type ON public.ai_conversations(conversation_type);
CREATE INDEX idx_ai_conversations_project_id ON public.ai_conversations(project_id);
CREATE INDEX idx_ai_conversations_active ON public.ai_conversations(is_active);

CREATE INDEX idx_ai_user_preferences_user_id ON public.ai_user_preferences(user_id);
CREATE INDEX idx_voice_training_user_id ON public.voice_training_data(user_id);

-- Functions for automatic timestamp updates
CREATE OR REPLACE FUNCTION public.handle_ai_updated_at()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- Enable Row Level Security
ALTER TABLE public.voice_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.voice_commands ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_user_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.voice_training_data ENABLE ROW LEVEL SECURITY;

-- RLS Policies using Pattern 2 (Simple User Ownership)
CREATE POLICY "users_manage_own_voice_sessions"
ON public.voice_sessions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_voice_commands"
ON public.voice_commands
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_ai_conversations"
ON public.ai_conversations
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_ai_preferences"
ON public.ai_user_preferences
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_voice_training"
ON public.voice_training_data
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Add triggers for updated_at
CREATE TRIGGER handle_updated_at_voice_sessions
    BEFORE UPDATE ON public.voice_sessions
    FOR EACH ROW EXECUTE FUNCTION public.handle_ai_updated_at();

CREATE TRIGGER handle_updated_at_voice_commands
    BEFORE UPDATE ON public.voice_commands
    FOR EACH ROW EXECUTE FUNCTION public.handle_ai_updated_at();

CREATE TRIGGER handle_updated_at_ai_conversations
    BEFORE UPDATE ON public.ai_conversations
    FOR EACH ROW EXECUTE FUNCTION public.handle_ai_updated_at();

CREATE TRIGGER handle_updated_at_ai_preferences
    BEFORE UPDATE ON public.ai_user_preferences
    FOR EACH ROW EXECUTE FUNCTION public.handle_ai_updated_at();

-- Mock data for testing
DO $$
DECLARE
    existing_user_id UUID;
    sample_session_id UUID := gen_random_uuid();
    sample_conversation_id UUID := gen_random_uuid();
    sample_preferences_id UUID := gen_random_uuid();
BEGIN
    -- Get existing user ID from user_profiles
    SELECT id INTO existing_user_id FROM public.user_profiles LIMIT 1;
    
    IF existing_user_id IS NOT NULL THEN
        -- Sample voice session
        INSERT INTO public.voice_sessions (id, user_id, session_name, status, transcript, extracted_requirements)
        VALUES (
            sample_session_id,
            existing_user_id,
            'Create Dashboard Component',
            'completed'::public.voice_session_status,
            'Create a dashboard component with charts and user statistics. Make it responsive and include dark mode support.',
            '{"components": ["Dashboard", "Chart", "UserStats"], "features": ["responsive", "dark_mode"], "complexity": "medium"}'::jsonb
        );

        -- Sample voice commands
        INSERT INTO public.voice_commands (user_id, command_phrase, category, description, usage_count)
        VALUES
            (existing_user_id, 'create new component', 'component_creation'::public.voice_command_category, 'Creates a new React component', 15),
            (existing_user_id, 'navigate to dashboard', 'navigation'::public.voice_command_category, 'Navigate to dashboard page', 8),
            (existing_user_id, 'apply primary styling', 'styling'::public.voice_command_category, 'Apply primary color scheme', 12);

        -- Sample AI conversation
        INSERT INTO public.ai_conversations (id, user_id, conversation_type, title, messages, total_messages)
        VALUES (
            sample_conversation_id,
            existing_user_id,
            'project_guidance'::public.ai_conversation_type,
            'Dashboard Implementation Help',
            '[{"role": "user", "content": "How do I create a responsive dashboard?"}, {"role": "assistant", "content": "I can help you create a responsive dashboard! Let me guide you through the process..."}]'::jsonb,
            2
        );

        -- Sample AI preferences
        INSERT INTO public.ai_user_preferences (id, user_id, preferred_frameworks, coding_style_preferences, assistance_level)
        VALUES (
            sample_preferences_id,
            existing_user_id,
            '["react", "tailwindcss", "typescript"]'::jsonb,
            '{"indentation": "2_spaces", "quotes": "single", "semicolons": true, "component_style": "functional"}'::jsonb,
            'detailed'
        );
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error creating mock data: %', SQLERRM;
END $$;