-- Location: supabase/migrations/20250108160000_zero_code_database_designer.sql
-- Schema Analysis: Existing auth system with projects, templates, user_profiles
-- Integration Type: NEW_MODULE - Database Designer functionality
-- Dependencies: user_profiles (existing), projects (existing)

-- 1. Types for Database Designer
CREATE TYPE public.data_type AS ENUM (
    'text', 'number', 'boolean', 'date', 'datetime', 'email', 'url', 'phone',
    'image', 'file', 'json', 'uuid', 'decimal', 'integer', 'textarea'
);

CREATE TYPE public.field_constraint AS ENUM (
    'required', 'unique', 'indexed', 'foreign_key', 'primary_key', 'auto_increment'
);

CREATE TYPE public.relationship_type AS ENUM (
    'one_to_one', 'one_to_many', 'many_to_many'
);

CREATE TYPE public.schema_status AS ENUM (
    'draft', 'published', 'archived'
);

-- 2. Core Tables - Database Schemas
CREATE TABLE public.database_schemas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    version INTEGER DEFAULT 1,
    status public.schema_status DEFAULT 'draft'::public.schema_status,
    canvas_data JSONB DEFAULT '{}'::jsonb,
    settings JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Database Tables within Schemas  
CREATE TABLE public.database_tables (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schema_id UUID REFERENCES public.database_schemas(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    display_name TEXT,
    description TEXT,
    position_x INTEGER DEFAULT 0,
    position_y INTEGER DEFAULT 0,
    color TEXT DEFAULT '#3B82F6',
    is_junction_table BOOLEAN DEFAULT false,
    settings JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(schema_id, name)
);

-- 4. Table Fields/Columns
CREATE TABLE public.table_fields (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_id UUID REFERENCES public.database_tables(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    display_name TEXT,
    data_type public.data_type NOT NULL,
    constraints public.field_constraint[] DEFAULT ARRAY[]::public.field_constraint[],
    default_value TEXT,
    is_nullable BOOLEAN DEFAULT true,
    max_length INTEGER,
    precision_scale TEXT, -- For decimal types like DECIMAL(10,2)
    description TEXT,
    sort_order INTEGER DEFAULT 0,
    validation_rules JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(table_id, name)
);

-- 5. Table Relationships
CREATE TABLE public.table_relationships (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schema_id UUID REFERENCES public.database_schemas(id) ON DELETE CASCADE,
    source_table_id UUID REFERENCES public.database_tables(id) ON DELETE CASCADE,
    source_field_id UUID REFERENCES public.table_fields(id) ON DELETE CASCADE,
    target_table_id UUID REFERENCES public.database_tables(id) ON DELETE CASCADE,
    target_field_id UUID REFERENCES public.table_fields(id) ON DELETE CASCADE,
    relationship_type public.relationship_type NOT NULL,
    constraint_name TEXT,
    on_delete_action TEXT DEFAULT 'CASCADE',
    on_update_action TEXT DEFAULT 'CASCADE',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 6. Sample Data Templates
CREATE TABLE public.sample_data_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    table_id UUID REFERENCES public.database_tables(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    sample_records JSONB NOT NULL,
    is_public BOOLEAN DEFAULT false,
    download_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 7. Query Templates (Visual Query Builder)
CREATE TABLE public.query_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    schema_id UUID REFERENCES public.database_schemas(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    query_type TEXT NOT NULL, -- 'select', 'insert', 'update', 'delete'
    sql_query TEXT NOT NULL,
    visual_config JSONB DEFAULT '{}'::jsonb,
    performance_score INTEGER,
    is_public BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 8. Indexes
CREATE INDEX idx_database_schemas_user_id ON public.database_schemas(user_id);
CREATE INDEX idx_database_schemas_project_id ON public.database_schemas(project_id);
CREATE INDEX idx_database_schemas_status ON public.database_schemas(status);
CREATE INDEX idx_database_tables_schema_id ON public.database_tables(schema_id);
CREATE INDEX idx_table_fields_table_id ON public.table_fields(table_id);
CREATE INDEX idx_table_fields_sort_order ON public.table_fields(table_id, sort_order);
CREATE INDEX idx_table_relationships_schema_id ON public.table_relationships(schema_id);
CREATE INDEX idx_table_relationships_source_table ON public.table_relationships(source_table_id);
CREATE INDEX idx_table_relationships_target_table ON public.table_relationships(target_table_id);
CREATE INDEX idx_sample_data_templates_table_id ON public.sample_data_templates(table_id);
CREATE INDEX idx_sample_data_templates_public ON public.sample_data_templates(is_public) WHERE is_public = true;
CREATE INDEX idx_query_templates_schema_id ON public.query_templates(schema_id);
CREATE INDEX idx_query_templates_user_id ON public.query_templates(user_id);

-- 9. Functions for Schema Management
CREATE OR REPLACE FUNCTION public.handle_updated_at_database_designer()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- 10. Enable RLS on all tables
ALTER TABLE public.database_schemas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.database_tables ENABLE ROW LEVEL SECURITY;  
ALTER TABLE public.table_fields ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.table_relationships ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sample_data_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.query_templates ENABLE ROW LEVEL SECURITY;

-- 11. RLS Policies using Pattern 2 (Simple User Ownership)
CREATE POLICY "users_manage_own_database_schemas"
ON public.database_schemas
FOR ALL
TO authenticated  
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_database_tables"
ON public.database_tables
FOR ALL
TO authenticated
USING (
    schema_id IN (
        SELECT id FROM public.database_schemas WHERE user_id = auth.uid()
    )
);

CREATE POLICY "users_manage_own_table_fields"
ON public.table_fields  
FOR ALL
TO authenticated
USING (
    table_id IN (
        SELECT dt.id FROM public.database_tables dt
        JOIN public.database_schemas ds ON dt.schema_id = ds.id
        WHERE ds.user_id = auth.uid()
    )
);

CREATE POLICY "users_manage_own_table_relationships"
ON public.table_relationships
FOR ALL
TO authenticated
USING (
    schema_id IN (
        SELECT id FROM public.database_schemas WHERE user_id = auth.uid()
    )
);

CREATE POLICY "users_manage_own_sample_data_templates"
ON public.sample_data_templates
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Public read for shared templates
CREATE POLICY "public_can_read_sample_data_templates"
ON public.sample_data_templates
FOR SELECT
TO public
USING (is_public = true);

CREATE POLICY "users_manage_own_query_templates"
ON public.query_templates
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Public read for shared queries
CREATE POLICY "public_can_read_query_templates"
ON public.query_templates
FOR SELECT
TO public  
USING (is_public = true);

-- 12. Triggers for updated_at
CREATE TRIGGER handle_updated_at_database_schemas
    BEFORE UPDATE ON public.database_schemas
    FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at_database_designer();

CREATE TRIGGER handle_updated_at_database_tables
    BEFORE UPDATE ON public.database_tables
    FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at_database_designer();

CREATE TRIGGER handle_updated_at_table_fields
    BEFORE UPDATE ON public.table_fields
    FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at_database_designer();

CREATE TRIGGER handle_updated_at_table_relationships
    BEFORE UPDATE ON public.table_relationships
    FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at_database_designer();

CREATE TRIGGER handle_updated_at_sample_data_templates
    BEFORE UPDATE ON public.sample_data_templates
    FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at_database_designer();

CREATE TRIGGER handle_updated_at_query_templates
    BEFORE UPDATE ON public.query_templates
    FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at_database_designer();

-- 13. Mock Data for Database Designer
DO $$
DECLARE
    existing_user_id UUID;
    existing_project_id UUID;
    schema_id UUID := gen_random_uuid();
    users_table_id UUID := gen_random_uuid();
    posts_table_id UUID := gen_random_uuid();
    comments_table_id UUID := gen_random_uuid();
    user_id_field UUID := gen_random_uuid();
    post_id_field UUID := gen_random_uuid();
    comment_user_field UUID := gen_random_uuid();
    comment_post_field UUID := gen_random_uuid();
BEGIN
    -- Get existing user and project
    SELECT id INTO existing_user_id FROM public.user_profiles LIMIT 1;
    SELECT id INTO existing_project_id FROM public.projects WHERE user_id = existing_user_id LIMIT 1;
    
    -- Create sample database schema
    INSERT INTO public.database_schemas (id, user_id, project_id, name, description, status, canvas_data)
    VALUES (
        schema_id, 
        existing_user_id, 
        existing_project_id,
        'Blog Application Database',
        'Complete database schema for a modern blog application with user management and commenting system',
        'draft'::public.schema_status,
        '{"zoom": 1, "panX": 0, "panY": 0}'::jsonb
    );

    -- Create sample tables
    INSERT INTO public.database_tables (id, schema_id, name, display_name, description, position_x, position_y, color) VALUES
        (users_table_id, schema_id, 'users', 'Users', 'Application users and authentication', 100, 100, '#10B981'),
        (posts_table_id, schema_id, 'posts', 'Blog Posts', 'User-generated blog posts and articles', 400, 100, '#3B82F6'),  
        (comments_table_id, schema_id, 'comments', 'Comments', 'Comments on blog posts', 700, 300, '#F59E0B');

    -- Create sample fields for users table
    INSERT INTO public.table_fields (table_id, name, display_name, data_type, constraints, is_nullable, sort_order, description) VALUES
        (users_table_id, 'id', 'User ID', 'uuid'::public.data_type, ARRAY['primary_key']::public.field_constraint[], false, 1, 'Unique identifier for users'),
        (users_table_id, 'email', 'Email Address', 'email'::public.data_type, ARRAY['required', 'unique']::public.field_constraint[], false, 2, 'User email for authentication'),
        (users_table_id, 'full_name', 'Full Name', 'text'::public.data_type, ARRAY['required']::public.field_constraint[], false, 3, 'User display name'),
        (users_table_id, 'bio', 'Biography', 'textarea'::public.data_type, ARRAY[]::public.field_constraint[], true, 4, 'User profile bio'),
        (users_table_id, 'avatar_url', 'Avatar Image', 'image'::public.data_type, ARRAY[]::public.field_constraint[], true, 5, 'Profile picture URL'),
        (users_table_id, 'created_at', 'Created Date', 'datetime'::public.data_type, ARRAY['required']::public.field_constraint[], false, 6, 'Account creation timestamp');

    -- Create sample fields for posts table
    INSERT INTO public.table_fields (id, table_id, name, display_name, data_type, constraints, is_nullable, sort_order, description) VALUES
        (post_id_field, posts_table_id, 'id', 'Post ID', 'uuid'::public.data_type, ARRAY['primary_key']::public.field_constraint[], false, 1, 'Unique identifier for posts'),
        (user_id_field, posts_table_id, 'user_id', 'Author', 'uuid'::public.data_type, ARRAY['required', 'foreign_key']::public.field_constraint[], false, 2, 'Reference to post author'),
        (posts_table_id, 'title', 'Post Title', 'text'::public.data_type, ARRAY['required']::public.field_constraint[], false, 3, 'Blog post title'),
        (posts_table_id, 'slug', 'URL Slug', 'text'::public.data_type, ARRAY['required', 'unique']::public.field_constraint[], false, 4, 'SEO-friendly URL'),
        (posts_table_id, 'content', 'Post Content', 'textarea'::public.data_type, ARRAY['required']::public.field_constraint[], false, 5, 'Main blog post content'),
        (posts_table_id, 'featured_image', 'Featured Image', 'image'::public.data_type, ARRAY[]::public.field_constraint[], true, 6, 'Post thumbnail image'),
        (posts_table_id, 'is_published', 'Published Status', 'boolean'::public.data_type, ARRAY[]::public.field_constraint[], false, 7, 'Whether post is live'),
        (posts_table_id, 'published_at', 'Publish Date', 'datetime'::public.data_type, ARRAY[]::public.field_constraint[], true, 8, 'When post was published'),
        (posts_table_id, 'created_at', 'Created Date', 'datetime'::public.data_type, ARRAY['required']::public.field_constraint[], false, 9, 'Post creation timestamp');

    -- Create sample fields for comments table  
    INSERT INTO public.table_fields (id, table_id, name, display_name, data_type, constraints, is_nullable, sort_order, description) VALUES
        (comments_table_id, 'id', 'Comment ID', 'uuid'::public.data_type, ARRAY['primary_key']::public.field_constraint[], false, 1, 'Unique identifier for comments'),
        (comment_post_field, comments_table_id, 'post_id', 'Blog Post', 'uuid'::public.data_type, ARRAY['required', 'foreign_key']::public.field_constraint[], false, 2, 'Reference to parent post'),
        (comment_user_field, comments_table_id, 'user_id', 'Commenter', 'uuid'::public.data_type, ARRAY['required', 'foreign_key']::public.field_constraint[], false, 3, 'Reference to comment author'),
        (comments_table_id, 'content', 'Comment Content', 'textarea'::public.data_type, ARRAY['required']::public.field_constraint[], false, 4, 'Comment text content'),
        (comments_table_id, 'is_approved', 'Approved Status', 'boolean'::public.data_type, ARRAY[]::public.field_constraint[], false, 5, 'Comment moderation status'),
        (comments_table_id, 'created_at', 'Created Date', 'datetime'::public.data_type, ARRAY['required']::public.field_constraint[], false, 6, 'Comment creation timestamp');

    -- Create relationships
    INSERT INTO public.table_relationships (schema_id, source_table_id, source_field_id, target_table_id, target_field_id, relationship_type, constraint_name) VALUES
        (schema_id, posts_table_id, user_id_field, users_table_id, (SELECT id FROM public.table_fields WHERE table_id = users_table_id AND name = 'id'), 'many_to_one'::public.relationship_type, 'fk_posts_user_id'),
        (schema_id, comments_table_id, comment_post_field, posts_table_id, post_id_field, 'many_to_one'::public.relationship_type, 'fk_comments_post_id'),
        (schema_id, comments_table_id, comment_user_field, users_table_id, (SELECT id FROM public.table_fields WHERE table_id = users_table_id AND name = 'id'), 'many_to_one'::public.relationship_type, 'fk_comments_user_id');

    -- Create sample data templates
    INSERT INTO public.sample_data_templates (user_id, table_id, name, description, sample_records, is_public) VALUES
        (existing_user_id, users_table_id, 'Sample Users', 'Demo user accounts for testing', 
         '[{"email": "john@example.com", "full_name": "John Doe", "bio": "Software developer passionate about web technologies"}, {"email": "jane@example.com", "full_name": "Jane Smith", "bio": "Content creator and blogger"}]'::jsonb, true),
        (existing_user_id, posts_table_id, 'Sample Blog Posts', 'Demo blog content for testing',
         '[{"title": "Getting Started with Database Design", "slug": "getting-started-database-design", "content": "Learn the fundamentals of designing efficient database schemas...", "is_published": true}, {"title": "Advanced SQL Techniques", "slug": "advanced-sql-techniques", "content": "Explore complex queries and optimization strategies...", "is_published": false}]'::jsonb, true);

    -- Create sample query templates
    INSERT INTO public.query_templates (user_id, schema_id, name, description, query_type, sql_query, visual_config, performance_score, is_public) VALUES
        (existing_user_id, schema_id, 'Get Published Posts with Authors', 'Retrieve all published blog posts with author information', 'select', 
         'SELECT p.title, p.content, p.published_at, u.full_name, u.email FROM posts p JOIN users u ON p.user_id = u.id WHERE p.is_published = true ORDER BY p.published_at DESC',
         '{"tables": ["posts", "users"], "joins": [{"type": "INNER", "on": "posts.user_id = users.id"}], "filters": [{"field": "is_published", "operator": "=", "value": true}]}'::jsonb, 85, true),
        (existing_user_id, schema_id, 'Comment Statistics by Post', 'Count comments for each blog post', 'select',
         'SELECT p.title, COUNT(c.id) as comment_count FROM posts p LEFT JOIN comments c ON p.id = c.post_id WHERE c.is_approved = true GROUP BY p.id, p.title ORDER BY comment_count DESC',
         '{"tables": ["posts", "comments"], "joins": [{"type": "LEFT", "on": "posts.id = comments.post_id"}], "groupBy": ["posts.id", "posts.title"], "having": [], "aggregates": [{"function": "COUNT", "field": "comments.id", "alias": "comment_count"}]}'::jsonb, 92, true);

EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error creating sample data: %', SQLERRM;
END $$;