-- Location: supabase/migrations/20250108153018_codecraft_studio_authentication.sql
-- Schema Analysis: Fresh project with no existing schema
-- Integration Type: Complete authentication system for CodeCraft Studio
-- Module: Authentication (signin, signup, user management, profiles)

-- 1. Custom Types and Enums
CREATE TYPE public.user_role AS ENUM ('admin', 'premium', 'free');
CREATE TYPE public.subscription_status AS ENUM ('active', 'cancelled', 'past_due', 'trialing');
CREATE TYPE public.account_status AS ENUM ('active', 'suspended', 'pending_verification');

-- 2. Core User Profiles Table (CRITICAL for PostgREST compatibility)
CREATE TABLE public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    avatar_url TEXT,
    role public.user_role DEFAULT 'free'::public.user_role,
    account_status public.account_status DEFAULT 'active'::public.account_status,
    subscription_status public.subscription_status DEFAULT 'trialing'::public.subscription_status,
    subscription_expires_at TIMESTAMPTZ,
    total_projects INTEGER DEFAULT 0,
    api_usage_count INTEGER DEFAULT 0,
    last_active_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    onboarding_completed BOOLEAN DEFAULT false,
    preferences JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Projects Table (Main application data)
CREATE TABLE public.projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    framework TEXT DEFAULT 'react',
    template_id UUID,
    status TEXT DEFAULT 'draft',
    is_public BOOLEAN DEFAULT false,
    deployment_url TEXT,
    repository_url TEXT,
    settings JSONB DEFAULT '{}',
    thumbnail_url TEXT,
    last_opened_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. Templates Table
CREATE TABLE public.templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    creator_id UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    description TEXT,
    category TEXT NOT NULL,
    framework TEXT NOT NULL,
    is_premium BOOLEAN DEFAULT false,
    is_featured BOOLEAN DEFAULT false,
    preview_url TEXT,
    thumbnail_url TEXT,
    download_count INTEGER DEFAULT 0,
    rating DECIMAL(3,2) DEFAULT 0.0,
    tags TEXT[] DEFAULT ARRAY[]::TEXT[],
    code_structure JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 5. Essential Indexes
CREATE INDEX idx_user_profiles_email ON public.user_profiles(email);
CREATE INDEX idx_user_profiles_role ON public.user_profiles(role);
CREATE INDEX idx_projects_user_id ON public.projects(user_id);
CREATE INDEX idx_projects_status ON public.projects(status);
CREATE INDEX idx_projects_framework ON public.projects(framework);
CREATE INDEX idx_templates_category ON public.templates(category);
CREATE INDEX idx_templates_framework ON public.templates(framework);
CREATE INDEX idx_templates_featured ON public.templates(is_featured);

-- 6. Functions (MUST be created before RLS policies)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO public.user_profiles (id, email, full_name, role)
  VALUES (
    NEW.id, 
    NEW.email, 
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'role', 'free')::public.user_role
  );
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;

-- 7. Enable RLS on all tables
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.templates ENABLE ROW LEVEL SECURITY;

-- 8. RLS Policies (Pattern 1 for user_profiles, Pattern 2 for others)

-- Pattern 1: Core User Tables - Simple direct comparison only
CREATE POLICY "users_manage_own_user_profiles"
ON public.user_profiles
FOR ALL
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Pattern 2: Simple User Ownership for projects
CREATE POLICY "users_manage_own_projects"
ON public.projects
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Pattern 4: Public Read, Private Write for templates
CREATE POLICY "public_can_read_templates"
ON public.templates
FOR SELECT
TO public
USING (true);

CREATE POLICY "users_manage_own_templates"
ON public.templates
FOR ALL
TO authenticated
USING (creator_id = auth.uid())
WITH CHECK (creator_id = auth.uid());

-- 9. Triggers
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TRIGGER handle_updated_at_user_profiles
  BEFORE UPDATE ON public.user_profiles
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER handle_updated_at_projects
  BEFORE UPDATE ON public.projects
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER handle_updated_at_templates
  BEFORE UPDATE ON public.templates
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- 10. Storage buckets for file uploads
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
    'user-files',
    'user-files',
    false,
    10485760, -- 10MB limit
    ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'application/pdf', 'text/plain', 'application/zip']
);

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
    'project-assets',
    'project-assets',
    true,
    5242880, -- 5MB limit
    ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif']
);

-- Storage RLS policies for private user files
CREATE POLICY "users_view_own_files"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'user-files' AND owner = auth.uid());

CREATE POLICY "users_upload_own_files"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
    bucket_id = 'user-files' 
    AND owner = auth.uid()
    AND (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "users_update_own_files"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'user-files' AND owner = auth.uid())
WITH CHECK (bucket_id = 'user-files' AND owner = auth.uid());

CREATE POLICY "users_delete_own_files"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'user-files' AND owner = auth.uid());

-- Storage RLS policies for public project assets
CREATE POLICY "public_can_view_project_assets"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'project-assets');

CREATE POLICY "authenticated_users_upload_project_assets"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'project-assets');

CREATE POLICY "owners_manage_project_assets"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'project-assets' AND owner = auth.uid());

-- 11. Mock Data for Development and Testing
DO $$
DECLARE
    admin_uuid UUID := gen_random_uuid();
    premium_uuid UUID := gen_random_uuid();
    free_uuid UUID := gen_random_uuid();
    project1_uuid UUID := gen_random_uuid();
    project2_uuid UUID := gen_random_uuid();
    project3_uuid UUID := gen_random_uuid();
    template1_uuid UUID := gen_random_uuid();
    template2_uuid UUID := gen_random_uuid();
    template3_uuid UUID := gen_random_uuid();
BEGIN
    -- Create complete auth users with all required fields
    INSERT INTO auth.users (
        id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
        created_at, updated_at, raw_user_meta_data, raw_app_meta_data,
        is_sso_user, is_anonymous, confirmation_token, confirmation_sent_at,
        recovery_token, recovery_sent_at, email_change_token_new, email_change,
        email_change_sent_at, email_change_token_current, email_change_confirm_status,
        reauthentication_token, reauthentication_sent_at, phone, phone_change,
        phone_change_token, phone_change_sent_at
    ) VALUES
        (admin_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'admin@codecraft.com', crypt('password123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Admin User", "role": "admin"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (premium_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'premium@codecraft.com', crypt('password123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Premium User", "role": "premium"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (free_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'user@codecraft.com', crypt('password123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Free User", "role": "free"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null);

    -- Create sample projects
    INSERT INTO public.projects (id, user_id, name, description, framework, status, is_public) VALUES
        (project1_uuid, admin_uuid, 'E-commerce Website', 'Modern online store with payment integration', 'react', 'published', true),
        (project2_uuid, premium_uuid, 'Portfolio Site', 'Personal portfolio with blog functionality', 'next', 'draft', false),
        (project3_uuid, free_uuid, 'Task Manager App', 'Simple todo app with drag and drop', 'react', 'in_review', true);

    -- Create sample templates
    INSERT INTO public.templates (id, creator_id, name, description, category, framework, is_premium, is_featured, rating) VALUES
        (template1_uuid, admin_uuid, 'E-commerce Starter', 'Complete e-commerce solution with Stripe integration', 'E-commerce', 'react', true, true, 4.8),
        (template2_uuid, admin_uuid, 'Blog Template', 'Clean and minimal blog template', 'Blog', 'next', false, true, 4.5),
        (template3_uuid, premium_uuid, 'Dashboard Admin', 'Professional admin dashboard template', 'Dashboard', 'react', true, false, 4.2);

EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key error during mock data insertion: %', SQLERRM;
    WHEN unique_violation THEN
        RAISE NOTICE 'Unique constraint error during mock data insertion: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Unexpected error during mock data insertion: %', SQLERRM;
END $$;