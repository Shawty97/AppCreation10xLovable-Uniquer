-- Schema Analysis: Existing projects and user_profiles tables found
-- Integration Type: Addition - deployment automation for existing projects  
-- Dependencies: projects(id), user_profiles(id)

-- 1. Types for deployment automation
CREATE TYPE public.deployment_status AS ENUM ('pending', 'building', 'success', 'failed', 'cancelled');
CREATE TYPE public.deployment_provider AS ENUM ('vercel', 'netlify', 'custom');
CREATE TYPE public.build_status AS ENUM ('queued', 'building', 'success', 'failed', 'cancelled');

-- 2. Deployment targets table
CREATE TABLE public.deployment_targets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    provider public.deployment_provider NOT NULL,
    provider_config JSONB NOT NULL DEFAULT '{}',
    custom_domain TEXT,
    ssl_enabled BOOLEAN DEFAULT false,
    environment_vars JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT true,
    last_deployed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Deployments table
CREATE TABLE public.deployments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    target_id UUID REFERENCES public.deployment_targets(id) ON DELETE CASCADE,
    project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    commit_hash TEXT,
    branch TEXT DEFAULT 'main',
    status public.deployment_status DEFAULT 'pending',
    build_logs TEXT,
    deployment_url TEXT,
    preview_url TEXT,
    provider_deployment_id TEXT,
    build_duration INTEGER,
    deploy_duration INTEGER,
    error_message TEXT,
    metadata JSONB DEFAULT '{}',
    started_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. Build queue table
CREATE TABLE public.build_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deployment_id UUID REFERENCES public.deployments(id) ON DELETE CASCADE,
    project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    priority INTEGER DEFAULT 5,
    status public.build_status DEFAULT 'queued',
    build_config JSONB NOT NULL DEFAULT '{}',
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    estimated_duration INTEGER,
    worker_id TEXT,
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 5. Domain configurations table
CREATE TABLE public.domain_configurations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deployment_target_id UUID REFERENCES public.deployment_targets(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    domain TEXT NOT NULL,
    subdomain TEXT,
    is_apex BOOLEAN DEFAULT false,
    ssl_certificate_id TEXT,
    ssl_status TEXT DEFAULT 'pending',
    dns_configured BOOLEAN DEFAULT false,
    verification_status TEXT DEFAULT 'pending',
    verification_token TEXT,
    provider_domain_id TEXT,
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 6. Performance metrics table
CREATE TABLE public.deployment_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deployment_id UUID REFERENCES public.deployments(id) ON DELETE CASCADE,
    project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE,
    metrics_data JSONB NOT NULL DEFAULT '{}',
    lighthouse_score JSONB,
    bundle_size_mb DECIMAL(10,3),
    load_time_ms INTEGER,
    first_paint_ms INTEGER,
    time_to_interactive_ms INTEGER,
    cumulative_layout_shift DECIMAL(4,3),
    measured_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 7. API integrations for external services
CREATE TABLE public.api_integrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    provider TEXT NOT NULL,
    encrypted_credentials JSONB NOT NULL,
    scopes TEXT[],
    is_active BOOLEAN DEFAULT true,
    last_used_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 8. Essential Indexes
CREATE INDEX idx_deployment_targets_project_id ON public.deployment_targets(project_id);
CREATE INDEX idx_deployment_targets_user_id ON public.deployment_targets(user_id);
CREATE INDEX idx_deployments_target_id ON public.deployments(target_id);
CREATE INDEX idx_deployments_project_id ON public.deployments(project_id);
CREATE INDEX idx_deployments_status ON public.deployments(status);
CREATE INDEX idx_deployments_created_at ON public.deployments(created_at DESC);
CREATE INDEX idx_build_queue_status ON public.build_queue(status);
CREATE INDEX idx_build_queue_priority ON public.build_queue(priority DESC);
CREATE INDEX idx_domain_configurations_domain ON public.domain_configurations(domain);
CREATE INDEX idx_deployment_metrics_deployment_id ON public.deployment_metrics(deployment_id);
CREATE INDEX idx_api_integrations_user_id ON public.api_integrations(user_id);

-- 9. Utility Functions
CREATE OR REPLACE FUNCTION public.handle_deployment_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- 10. Enable RLS
ALTER TABLE public.deployment_targets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deployments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.build_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.domain_configurations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deployment_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.api_integrations ENABLE ROW LEVEL SECURITY;

-- 11. RLS Policies - Pattern 2: Simple User Ownership
CREATE POLICY "users_manage_own_deployment_targets"
ON public.deployment_targets
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_deployments"
ON public.deployments
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_build_queue"
ON public.build_queue
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_domain_configurations"
ON public.domain_configurations
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_deployment_metrics"
ON public.deployment_metrics
FOR ALL
TO authenticated
USING (EXISTS (
    SELECT 1 FROM public.deployments d 
    WHERE d.id = deployment_id AND d.user_id = auth.uid()
));

CREATE POLICY "users_manage_own_api_integrations"
ON public.api_integrations
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 12. Triggers for updated_at
CREATE TRIGGER handle_deployment_targets_updated_at
    BEFORE UPDATE ON public.deployment_targets
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_deployment_updated_at();

CREATE TRIGGER handle_domain_configurations_updated_at
    BEFORE UPDATE ON public.domain_configurations
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_deployment_updated_at();

CREATE TRIGGER handle_api_integrations_updated_at
    BEFORE UPDATE ON public.api_integrations
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_deployment_updated_at();

-- 13. Mock Data for existing projects
DO $$
DECLARE
    existing_project_id UUID;
    existing_user_id UUID;
    target_id UUID := gen_random_uuid();
    deployment_id UUID := gen_random_uuid();
BEGIN
    -- Get existing project and user IDs (don't create new ones)
    SELECT id INTO existing_project_id FROM public.projects LIMIT 1;
    SELECT id INTO existing_user_id FROM public.user_profiles LIMIT 1;

    IF existing_project_id IS NOT NULL AND existing_user_id IS NOT NULL THEN
        -- Add deployment target
        INSERT INTO public.deployment_targets (id, project_id, user_id, name, provider, provider_config, custom_domain, ssl_enabled)
        VALUES (
            target_id,
            existing_project_id,
            existing_user_id,
            'Production Deploy',
            'vercel',
            '{"team_id": null, "org_slug": null}',
            'myapp.example.com',
            true
        );

        -- Add sample deployment
        INSERT INTO public.deployments (id, target_id, project_id, user_id, commit_hash, status, deployment_url, build_duration, deploy_duration)
        VALUES (
            deployment_id,
            target_id,
            existing_project_id,
            existing_user_id,
            'abc123def456',
            'success',
            'https://myapp-xyz123.vercel.app',
            120,
            45
        );

        -- Add build queue entry
        INSERT INTO public.build_queue (deployment_id, project_id, user_id, status, build_config)
        VALUES (
            deployment_id,
            existing_project_id,
            existing_user_id,
            'success',
            '{"node_version": "18", "build_command": "npm run build", "install_command": "npm install"}'
        );

        -- Add performance metrics
        INSERT INTO public.deployment_metrics (deployment_id, project_id, metrics_data, lighthouse_score, bundle_size_mb, load_time_ms)
        VALUES (
            deployment_id,
            existing_project_id,
            '{"pages": 5, "components": 12, "assets": 8}',
            '{"performance": 95, "accessibility": 98, "best_practices": 92, "seo": 96}',
            2.4,
            850
        );
    ELSE
        RAISE NOTICE 'No existing projects found. Create a project first to see deployment data.';
    END IF;
EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key error: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Deployment mock data creation error: %', SQLERRM;
END $$;