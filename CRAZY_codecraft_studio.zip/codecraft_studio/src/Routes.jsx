import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ErrorBoundary from './components/ErrorBoundary';
import ScrollToTop from './components/ScrollToTop';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import NotFound from "pages/NotFound";

// Public pages
import LandingPage from './pages/landing';
import AuthenticationPortal from './pages/authentication-portal';

// Protected pages  
import VisualBuilder from './pages/visual-builder';
import AppSettings from './pages/app-settings';
import AccountSettings from './pages/account-settings';
import TemplateGallery from './pages/template-gallery';
import Dashboard from './pages/dashboard';
import ComponentMarketplace from './pages/component-marketplace';
import AICodeGenerator from './pages/ai-code-generator';
import LivePreviewHub from './pages/live-preview-hub';
import DeploymentCenter from './pages/deployment-center';
import BuildPipeline from './pages/build-pipeline';
import ProjectManager from './pages/project-manager';
import RealTimeCollaborationHub from './pages/real-time-collaboration-hub';
import PerformanceAnalyticsCenter from './pages/performance-analytics-center';
import MobileAppBuilder from './pages/mobile-app-builder';
import ZeroCodeDatabaseDesigner from './pages/zero-code-database-designer';
import ContextAwareAiAssistant from './pages/context-aware-ai-assistant';
import VoiceToAppCreator from './pages/voice-to-app-creator';
import PerformanceOptimizationSuite from './pages/performance-optimization-suite';
import PaymentIntegrationHub from './pages/payment-integration-hub';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Public Routes */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/authentication-portal" element={<AuthenticationPortal />} />
        
        {/* Protected Routes with Layout */}
        <Route path="/" element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/visual-builder" element={<VisualBuilder />} />
          <Route path="/app-settings" element={<AppSettings />} />
          <Route path="/account-settings" element={<AccountSettings />} />
          <Route path="/template-gallery" element={<TemplateGallery />} />
          <Route path="/component-marketplace" element={<ComponentMarketplace />} />
          <Route path="/ai-code-generator" element={<AICodeGenerator />} />
          <Route path="/live-preview-hub" element={<LivePreviewHub />} />
          <Route path="/deployment-center" element={<DeploymentCenter />} />
          <Route path="/build-pipeline" element={<BuildPipeline />} />
          <Route path="/project-manager" element={<ProjectManager />} />
          <Route path="/real-time-collaboration-hub" element={<RealTimeCollaborationHub />} />
          <Route path="/performance-analytics-center" element={<PerformanceAnalyticsCenter />} />
          <Route path="/mobile-app-builder" element={<MobileAppBuilder />} />
          <Route path="/zero-code-database-designer" element={<ZeroCodeDatabaseDesigner />} />
          <Route path="/context-aware-ai-assistant" element={<ContextAwareAiAssistant />} />
          <Route path="/voice-to-app-creator" element={<VoiceToAppCreator />} />
          <Route path="/performance-optimization-suite" element={<PerformanceOptimizationSuite />} />
          <Route path="/payment-integration-hub" element={<PaymentIntegrationHub />} />
          <Route path="/projects/:projectId/deployment" element={<DeploymentCenter />} />
        </Route>

        {/* 404 Route */}
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;