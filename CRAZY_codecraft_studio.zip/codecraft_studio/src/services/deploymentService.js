import { supabase } from '../lib/supabase';

export const deploymentService = {
  // Get all deployment targets for user
  getTargets: async (userId) => {
    try {
      const { data, error } = await supabase?.from('deployment_targets')?.select(`
          *,
          projects:project_id (
            name,
            description
          )
        `)?.eq('user_id', userId)?.order('created_at', { ascending: false })
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get deployments for a user
  getDeployments: async (userId, limit = 50) => {
    try {
      const { data, error } = await supabase?.from('deployments')?.select(`
          *,
          projects:project_id (
            name,
            description
          ),
          deployment_targets:target_id (
            name,
            provider,
            custom_domain
          )
        `)?.eq('user_id', userId)?.order('created_at', { ascending: false })?.limit(limit)
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get deployments for a specific project
  getProjectDeployments: async (projectId, userId) => {
    try {
      const { data, error } = await supabase?.from('deployments')?.select(`
          *,
          deployment_targets:target_id (
            name,
            provider,
            custom_domain
          )
        `)?.eq('project_id', projectId)?.eq('user_id', userId)?.order('created_at', { ascending: false })
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Create deployment target
  createTarget: async (targetData, userId) => {
    try {
      const { data, error } = await supabase?.from('deployment_targets')?.insert([{ 
          ...targetData, 
          user_id: userId
        }])?.select()?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Update deployment target
  updateTarget: async (id, updates, userId) => {
    try {
      const { data, error } = await supabase?.from('deployment_targets')?.update(updates)?.eq('id', id)?.eq('user_id', userId)?.select()?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Create new deployment
  deploy: async (deploymentData, userId) => {
    try {
      const { data, error } = await supabase?.from('deployments')?.insert([{ 
          ...deploymentData, 
          user_id: userId,
          status: 'pending',
          started_at: new Date()?.toISOString()
        }])?.select()?.single()

      // In a real implementation, this would trigger the actual deployment process
      // For now, we'll simulate a deployment
      setTimeout(async () => {
        await supabase?.from('deployments')?.update({ 
            status: 'success',
            completed_at: new Date()?.toISOString(),
            deployment_url: `https://${deploymentData?.project_id}.example.com`,
            build_duration: 120,
            deploy_duration: 45
          })?.eq('id', data?.id)
      }, 2000)

      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get deployment logs
  getLogs: async (deploymentId, userId) => {
    try {
      const { data, error } = await supabase?.from('deployments')?.select('build_logs')?.eq('id', deploymentId)?.eq('user_id', userId)?.single()
      
      // Return formatted logs
      const logs = data?.build_logs || 'No logs available yet...'
      return { data: { logs }, error }
    } catch (error) {
      return { data: { logs: 'Error fetching logs' }, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get deployment status
  getStatus: async (deploymentId, userId) => {
    try {
      const { data, error } = await supabase?.from('deployments')?.select('status, started_at, completed_at, error_message, deployment_url')?.eq('id', deploymentId)?.eq('user_id', userId)?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Cancel deployment
  cancel: async (deploymentId, userId) => {
    try {
      const { data, error } = await supabase?.from('deployments')?.update({ 
          status: 'cancelled',
          completed_at: new Date()?.toISOString()
        })?.eq('id', deploymentId)?.eq('user_id', userId)?.select()?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Deployment Targets
  async getDeploymentTargets(projectId) {
    const { data, error } = await supabase?.from('deployment_targets')?.select(`*,project:projects(id, name)`)?.eq('project_id', projectId)?.order('created_at', { ascending: false });
    
    if (error) throw error;
    return data;
  },

  async createDeploymentTarget(targetData) {
    const { data: session } = await supabase?.auth?.getSession();
    if (!session?.user) throw new Error('User not authenticated');

    const { data, error } = await supabase?.from('deployment_targets')?.insert({
        ...targetData,
        user_id: session?.user?.id
      })?.select()?.single();
    
    if (error) throw error;
    return data;
  },

  async updateDeploymentTarget(targetId, updates) {
    const { data, error } = await supabase?.from('deployment_targets')?.update(updates)?.eq('id', targetId)?.select()?.single();
    
    if (error) throw error;
    return data;
  },

  async deleteDeploymentTarget(targetId) {
    const { error } = await supabase?.from('deployment_targets')?.delete()?.eq('id', targetId);
    
    if (error) throw error;
    return true;
  },

  // Deployments
  async getDeployments(projectId, limit = 20) {
    const { data, error } = await supabase?.from('deployments')?.select(`*,target:deployment_targets(name, provider),project:projects(name)`)?.eq('project_id', projectId)?.order('created_at', { ascending: false })?.limit(limit);
    
    if (error) throw error;
    return data;
  },

  async createDeployment(deploymentData) {
    const { data: session } = await supabase?.auth?.getSession();
    if (!session?.user) throw new Error('User not authenticated');

    const { data, error } = await supabase?.from('deployments')?.insert({
        ...deploymentData,
        user_id: session?.user?.id,
        status: 'pending'
      })?.select()?.single();
    
    if (error) throw error;
    return data;
  },

  async updateDeploymentStatus(deploymentId, statusData) {
    const { data, error } = await supabase?.from('deployments')?.update({
        ...statusData,
        ...(statusData?.status === 'success' || statusData?.status === 'failed' ? 
          { completed_at: new Date()?.toISOString() } : {})
      })?.eq('id', deploymentId)?.select()?.single();
    
    if (error) throw error;
    return data;
  },

  // Build Queue
  async getBuildQueue(status = null) {
    let query = supabase?.from('build_queue')?.select(`*,deployment:deployments(id, status, deployment_url),project:projects(name)`)?.order('priority', { ascending: false })?.order('created_at', { ascending: true });
    
    if (status) {
      query = query?.eq('status', status);
    }
    
    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  async addToBuildQueue(queueData) {
    const { data: session } = await supabase?.auth?.getSession();
    if (!session?.user) throw new Error('User not authenticated');

    const { data, error } = await supabase?.from('build_queue')?.insert({
        ...queueData,
        user_id: session?.user?.id,
        status: 'queued'
      })?.select()?.single();
    
    if (error) throw error;
    return data;
  },

  async updateBuildQueueStatus(queueId, statusData) {
    const { data, error } = await supabase?.from('build_queue')?.update({
        ...statusData,
        ...(statusData?.status === 'building' ? 
          { started_at: new Date()?.toISOString() } : {}),
        ...(statusData?.status === 'success' || statusData?.status === 'failed' ? 
          { completed_at: new Date()?.toISOString() } : {})
      })?.eq('id', queueId)?.select()?.single();
    
    if (error) throw error;
    return data;
  },

  // Domain Management
  async getDomainConfigurations(targetId) {
    const { data, error } = await supabase?.from('domain_configurations')?.select('*')?.eq('deployment_target_id', targetId)?.order('created_at', { ascending: false });
    
    if (error) throw error;
    return data;
  },

  async createDomainConfiguration(domainData) {
    const { data: session } = await supabase?.auth?.getSession();
    if (!session?.user) throw new Error('User not authenticated');

    const { data, error } = await supabase?.from('domain_configurations')?.insert({
        ...domainData,
        user_id: session?.user?.id,
        verification_token: crypto?.getRandomValues ? 
          Array.from(crypto.getRandomValues(new Uint8Array(16)))?.map(b => b?.toString(16)?.padStart(2, '0'))?.join('') : 
          Math.random()?.toString(36)?.substring(2, 18)
      })?.select()?.single();
    
    if (error) throw error;
    return data;
  },

  async updateDomainStatus(domainId, updates) {
    const { data, error } = await supabase?.from('domain_configurations')?.update(updates)?.eq('id', domainId)?.select()?.single();
    
    if (error) throw error;
    return data;
  },

  // Performance Metrics
  async getDeploymentMetrics(deploymentId) {
    const { data, error } = await supabase?.from('deployment_metrics')?.select('*')?.eq('deployment_id', deploymentId)?.order('measured_at', { ascending: false })?.limit(10);
    
    if (error) throw error;
    return data;
  },

  async addDeploymentMetrics(metricsData) {
    const { data, error } = await supabase?.from('deployment_metrics')?.insert(metricsData)?.select()?.single();
    
    if (error) throw error;
    return data;
  },

  // API Integrations
  async getApiIntegrations() {
    const { data, error } = await supabase?.from('api_integrations')?.select('id, provider, scopes, is_active, last_used_at, expires_at, created_at')?.eq('is_active', true)?.order('created_at', { ascending: false });
    
    if (error) throw error;
    return data;
  },

  async createApiIntegration(integrationData) {
    const { data: session } = await supabase?.auth?.getSession();
    if (!session?.user) throw new Error('User not authenticated');

    const { data, error } = await supabase?.from('api_integrations')?.insert({
        ...integrationData,
        user_id: session?.user?.id
      })?.select('id, provider, scopes, is_active, created_at')?.single();
    
    if (error) throw error;
    return data;
  },

  // Deployment Actions (would integrate with actual APIs)
  async triggerDeployment(targetId, options = {}) {
    try {
      // Get deployment target
      const { data: target, error: targetError } = await supabase?.from('deployment_targets')?.select('*, project:projects(*)')?.eq('id', targetId)?.single();
      
      if (targetError) throw targetError;

      // Create deployment record
      const deployment = await this.createDeployment({
        target_id: targetId,
        project_id: target?.project_id,
        branch: options?.branch || 'main',commit_hash: options?.commitHash || 'latest'
      });

      // Add to build queue
      await this.addToBuildQueue({
        deployment_id: deployment?.id,
        project_id: target?.project_id,
        priority: options?.priority || 5,
        build_config: {
          node_version: '18',build_command: 'npm run build',install_command: 'npm install',output_directory: 'dist',
          ...options?.buildConfig
        }
      });

      // TODO: Integrate with actual deployment providers (Vercel/Netlify)
      // For now, simulate deployment process
      setTimeout(() => {
        this.updateDeploymentStatus(deployment?.id, {
          status: 'building',
          started_at: new Date()?.toISOString()
        });
      }, 1000);

      return deployment;
    } catch (error) {
      throw error;
    }
  },

  // Real-time subscriptions
  subscribeToDeployments(projectId, callback) {
    return supabase?.channel(`deployments_${projectId}`)?.on(
        'postgres_changes',
        {
          event: '*',schema: 'public',table: 'deployments',
          filter: `project_id=eq.${projectId}`
        },
        callback
      )?.subscribe();
  },

  subscribeToBuildQueue(callback) {
    return supabase?.channel('build_queue')?.on('postgres_changes',
        {
          event: '*',schema: 'public',table: 'build_queue'
        },
        callback
      )?.subscribe();
  },

  // Utility functions
  formatDeploymentDuration(seconds) {
    if (!seconds) return 'N/A';
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return minutes > 0 ? `${minutes}m ${secs}s` : `${secs}s`;
  },

  getStatusColor(status) {
    const colors = {
      pending: 'text-yellow-600 bg-yellow-100',building: 'text-blue-600 bg-blue-100',success: 'text-green-600 bg-green-100',failed: 'text-red-600 bg-red-100',cancelled: 'text-gray-600 bg-gray-100',queued: 'text-purple-600 bg-purple-100'
    };
    return colors?.[status] || colors?.pending;
  },

  getProviderIcon(provider) {
    const icons = {
      vercel: '▲',
      netlify: '◆',
      custom: '🔧'
    };
    return icons?.[provider] || icons?.custom;
  },

  async cancelDeployment(deploymentId) {
    const { data, error } = await supabase?.from('deployments')?.update({
        status: 'cancelled',
        completed_at: new Date()?.toISOString()
      })?.eq('id', deploymentId)?.select()?.single();
    
    if (error) throw error;

    // Also cancel build queue entry
    await supabase?.from('build_queue')?.update({ status: 'cancelled' })?.eq('deployment_id', deploymentId);

    return data;
  }
};