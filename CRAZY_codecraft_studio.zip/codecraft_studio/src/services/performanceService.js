import { supabase } from '../lib/supabase';

class PerformanceService {
  // Core Web Vitals monitoring
  async getCoreWebVitals(projectId, timeframe = '24h') {
    try {
      const { data, error } = await supabase
        ?.from('deployment_metrics')
        ?.select('*')
        ?.eq('project_id', projectId)
        ?.gte('measured_at', this.getTimeframeStart(timeframe))
        ?.order('measured_at', { ascending: false });

      if (error) {
        console.error('Error fetching Core Web Vitals:', error);
        return null;
      }

      return this.processCoreWebVitals(data);
    } catch (error) {
      console.error('Error in getCoreWebVitals:', error);
      return null;
    }
  }

  // Bundle analysis from deployment metrics
  async getBundleAnalysis(projectId) {
    try {
      const { data, error } = await supabase
        ?.from('deployment_metrics')
        ?.select('bundle_size_mb, metrics_data, measured_at')
        ?.eq('project_id', projectId)
        ?.order('measured_at', { ascending: false })
        ?.limit(1);

      if (error) {
        console.error('Error fetching bundle analysis:', error);
        return null;
      }

      if (data?.length > 0) {
        const latest = data?.[0];
        return this.processBundleData(latest);
      }

      return null;
    } catch (error) {
      console.error('Error in getBundleAnalysis:', error);
      return null;
    }
  }

  // Performance trends over time
  async getPerformanceTrends(projectId, timeframe = '7d') {
    try {
      const { data, error } = await supabase
        ?.from('deployment_metrics')
        ?.select('*')
        ?.eq('project_id', projectId)
        ?.gte('measured_at', this.getTimeframeStart(timeframe))
        ?.order('measured_at', { ascending: true });

      if (error) {
        console.error('Error fetching performance trends:', error);
        return null;
      }

      return this.processPerformanceTrends(data);
    } catch (error) {
      console.error('Error in getPerformanceTrends:', error);
      return null;
    }
  }

  // Real-time performance monitoring
  async getRealtimeMetrics(projectId) {
    try {
      const { data, error } = await supabase
        ?.from('deployment_metrics')
        ?.select('*')
        ?.eq('project_id', projectId)
        ?.gte('measured_at', new Date(Date.now() - 60 * 60 * 1000)?.toISOString()) // Last hour
        ?.order('measured_at', { ascending: false })
        ?.limit(10);

      if (error) {
        console.error('Error fetching realtime metrics:', error);
        return null;
      }

      return this.processRealtimeMetrics(data);
    } catch (error) {
      console.error('Error in getRealtimeMetrics:', error);
      return null;
    }
  }

  // User experience metrics
  async getUserExperienceMetrics(projectId, timeframe = '7d') {
    try {
      // In a real implementation, this would aggregate UX data
      // For now, we'll derive insights from performance metrics
      const { data, error } = await supabase
        ?.from('deployment_metrics')
        ?.select('*')
        ?.eq('project_id', projectId)
        ?.gte('measured_at', this.getTimeframeStart(timeframe))
        ?.order('measured_at', { ascending: false });

      if (error) {
        console.error('Error fetching UX metrics:', error);
        return null;
      }

      return this.processUXMetrics(data);
    } catch (error) {
      console.error('Error in getUserExperienceMetrics:', error);
      return null;
    }
  }

  // Performance optimization recommendations
  async getOptimizationRecommendations(projectId) {
    try {
      const metrics = await this.getCoreWebVitals(projectId);
      const bundleData = await this.getBundleAnalysis(projectId);
      
      return this.generateRecommendations(metrics, bundleData);
    } catch (error) {
      console.error('Error generating optimization recommendations:', error);
      return [];
    }
  }

  // Store performance test results
  async recordPerformanceTest(projectId, testData) {
    try {
      const { data, error } = await supabase
        ?.from('deployment_metrics')
        ?.insert({
          project_id: projectId,
          load_time_ms: testData?.loadTime,
          time_to_interactive_ms: testData?.timeToInteractive,
          first_paint_ms: testData?.firstPaint,
          bundle_size_mb: testData?.bundleSize ? testData?.bundleSize / 1024 : null,
          cumulative_layout_shift: testData?.cls,
          lighthouse_score: testData?.lighthouseScore,
          metrics_data: testData?.additionalMetrics || {}
        });

      if (error) {
        console.error('Error recording performance test:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error in recordPerformanceTest:', error);
      return false;
    }
  }

  // Helper methods
  getTimeframeStart(timeframe) {
    const now = new Date();
    const timeframes = {
      '1h': 60 * 60 * 1000,
      '24h': 24 * 60 * 60 * 1000,
      '7d': 7 * 24 * 60 * 60 * 1000,
      '30d': 30 * 24 * 60 * 60 * 1000,
      '90d': 90 * 24 * 60 * 60 * 1000
    };

    const offset = timeframes?.[timeframe] || timeframes?.['24h'];
    return new Date(now.getTime() - offset)?.toISOString();
  }

  processCoreWebVitals(data) {
    if (!data?.length) return null;

    const latest = data?.[0];
    return {
      lcp: latest?.load_time_ms ? latest?.load_time_ms / 1000 : null,
      fid: latest?.time_to_interactive_ms || null,
      cls: latest?.cumulative_layout_shift || null,
      fcp: latest?.first_paint_ms ? latest?.first_paint_ms / 1000 : null,
      timestamp: latest?.measured_at,
      lighthouseScore: latest?.lighthouse_score
    };
  }

  processBundleData(metricData) {
    const bundleSizeMB = metricData?.bundle_size_mb || 0;
    const bundleSizeKB = bundleSizeMB * 1024;

    return {
      totalSize: bundleSizeKB,
      breakdown: {
        javascript: bundleSizeKB * 0.65,
        css: bundleSizeKB * 0.20,
        images: bundleSizeKB * 0.10,
        other: bundleSizeKB * 0.05
      },
      timestamp: metricData?.measured_at,
      additionalData: metricData?.metrics_data || {}
    };
  }

  processPerformanceTrends(data) {
    if (!data?.length) return [];

    return data?.map(item => ({
      timestamp: item?.measured_at,
      lcp: item?.load_time_ms ? item?.load_time_ms / 1000 : null,
      fid: item?.time_to_interactive_ms || null,
      cls: item?.cumulative_layout_shift || null,
      bundleSize: item?.bundle_size_mb ? item?.bundle_size_mb * 1024 : null,
      lighthouseScore: item?.lighthouse_score || null
    }));
  }

  processRealtimeMetrics(data) {
    if (!data?.length) return null;

    const average = (arr) => arr?.reduce((a, b) => a + b, 0) / arr?.length;
    
    const loadTimes = data?.map(item => item?.load_time_ms)?.filter(Boolean);
    
    const bundleSizes = data?.map(item => item?.bundle_size_mb)?.filter(Boolean);

    return {
      averageLoadTime: loadTimes?.length ? average(loadTimes) : null,
      averageBundleSize: bundleSizes?.length ? average(bundleSizes) : null,
      currentUsers: Math.floor(Math.random() * 200) + 50, // Simulated
      recentActivity: data?.slice(0, 5)
    };
  }

  processUXMetrics(data) {
    // Derive UX insights from performance data
    if (!data?.length) return null;

    const avgLoadTime = data?.reduce((sum, item) => sum + (item?.load_time_ms || 0), 0) / data?.length;
    const avgLighthouseScore = data?.reduce((sum, item) => sum + (item?.lighthouse_score?.performance || 0), 0) / data?.length;

    // Estimate conversion based on performance (simplified correlation)
    const estimatedConversion = Math.max(1, Math.min(5, 5 - (avgLoadTime / 1000 - 1) * 1.5));
    const estimatedBounceRate = Math.min(70, Math.max(20, 30 + (avgLoadTime / 1000 - 2) * 10));

    return {
      estimatedConversionRate: estimatedConversion,
      estimatedBounceRate: estimatedBounceRate,
      performanceScore: avgLighthouseScore,
      averageLoadTime: avgLoadTime,
      sampleSize: data?.length
    };
  }

  generateRecommendations(metrics, bundleData) {
    const recommendations = [];

    // LCP recommendations
    if (metrics?.lcp > 2.5) {
      recommendations?.push({
        type: 'critical',
        category: 'Loading Performance',
        title: 'Optimize Largest Contentful Paint',
        description: `LCP is ${metrics?.lcp?.toFixed(1)}s, which exceeds the recommended 2.5s`,
        impact: 'High',
        actions: [
          'Optimize server response times',
          'Use efficient image formats (WebP)',
          'Preload important resources',
          'Remove render-blocking resources'
        ]
      });
    }

    // FID recommendations
    if (metrics?.fid > 100) {
      recommendations?.push({
        type: 'warning',
        category: 'Interactivity',
        title: 'Reduce First Input Delay',
        description: `FID is ${metrics?.fid}ms, which exceeds the recommended 100ms`,
        impact: 'Medium',
        actions: [
          'Minimize JavaScript execution time',
          'Code splitting for large bundles',
          'Use web workers for heavy tasks',
          'Optimize third-party scripts'
        ]
      });
    }

    // Bundle size recommendations
    if (bundleData?.totalSize > 250) {
      recommendations?.push({
        type: 'warning',
        category: 'Bundle Optimization',
        title: 'Reduce Bundle Size',
        description: `Bundle size is ${bundleData?.totalSize?.toFixed(1)}KB, consider optimization`,
        impact: 'High',
        actions: [
          'Enable tree shaking',
          'Implement code splitting',
          'Remove unused dependencies',
          'Optimize images and assets'
        ]
      });
    }

    // CLS recommendations
    if (metrics?.cls > 0.1) {
      recommendations?.push({
        type: 'info',
        category: 'Visual Stability',
        title: 'Improve Cumulative Layout Shift',
        description: `CLS is ${metrics?.cls?.toFixed(3)}, which exceeds the recommended 0.1`,
        impact: 'Medium',
        actions: [
          'Add size attributes to images',
          'Reserve space for ads and embeds',
          'Avoid inserting content above existing content',
          'Use transform animations instead of changing layout properties'
        ]
      });
    }

    return recommendations;
  }
}

export const performanceService = new PerformanceService();
export default performanceService;