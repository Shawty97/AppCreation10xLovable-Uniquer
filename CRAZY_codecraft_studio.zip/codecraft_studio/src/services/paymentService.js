import { supabase } from '../lib/supabase';

export const paymentService = {
  // Create payment intent with Stripe
  async createPaymentIntent(orderData, customerInfo) {
    try {
      const { data, error } = await supabase?.functions?.invoke('create-payment-intent', {
        body: {
          orderData,
          customerInfo
        }
      });

      if (error) {
        throw new Error(error.message || 'Failed to create payment intent');
      }

      return data;
    } catch (error) {
      throw new Error(`Payment intent creation failed: ${error.message}`);
    }
  },

  // Confirm payment with Stripe
  async confirmPayment(paymentIntentId) {
    try {
      const { data, error } = await supabase?.functions?.invoke('confirm-payment', {
        body: { paymentIntentId }
      });

      if (error) {
        throw new Error(error.message || 'Failed to confirm payment');
      }

      return data;
    } catch (error) {
      throw new Error(`Payment confirmation failed: ${error.message}`);
    }
  },

  // Format amount for display
  formatAmount(amount, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
    })?.format(amount / 100);
  },

  // Get user's payment methods
  async getPaymentMethods(userId) {
    try {
      const { data, error } = await supabase?.from('payment_methods')?.select('*')?.eq('user_id', userId)?.order('created_at', { ascending: false });

      if (error) {
        throw new Error(error.message);
      }

      return data || [];
    } catch (error) {
      throw new Error(`Failed to fetch payment methods: ${error.message}`);
    }
  },

  // Save payment method
  async savePaymentMethod(userId, stripePaymentMethodId, paymentMethodData) {
    try {
      const { data, error } = await supabase?.from('payment_methods')?.insert({
          user_id: userId,
          stripe_payment_method_id: stripePaymentMethodId,
          type: paymentMethodData?.type,
          card_brand: paymentMethodData?.card?.brand,
          card_last_four: paymentMethodData?.card?.last4,
          card_exp_month: paymentMethodData?.card?.exp_month,
          card_exp_year: paymentMethodData?.card?.exp_year,
          is_default: false
        })?.select()?.single();

      if (error) {
        throw new Error(error.message);
      }

      return data;
    } catch (error) {
      throw new Error(`Failed to save payment method: ${error.message}`);
    }
  },

  // Set default payment method
  async setDefaultPaymentMethod(userId, paymentMethodId) {
    try {
      // First, remove default from all other payment methods
      await supabase?.from('payment_methods')?.update({ is_default: false })?.eq('user_id', userId);

      // Then set the new default
      const { data, error } = await supabase?.from('payment_methods')?.update({ is_default: true })?.eq('id', paymentMethodId)?.eq('user_id', userId)?.select()?.single();

      if (error) {
        throw new Error(error.message);
      }

      return data;
    } catch (error) {
      throw new Error(`Failed to set default payment method: ${error.message}`);
    }
  },

  // Delete payment method
  async deletePaymentMethod(userId, paymentMethodId) {
    try {
      const { error } = await supabase?.from('payment_methods')?.delete()?.eq('id', paymentMethodId)?.eq('user_id', userId);

      if (error) {
        throw new Error(error.message);
      }

      return true;
    } catch (error) {
      throw new Error(`Failed to delete payment method: ${error.message}`);
    }
  },

  // Get user's orders
  async getUserOrders(userId, limit = 20) {
    try {
      const { data, error } = await supabase?.from('orders')?.select(`
          *,
          order_items (
            *,
            component_listings (
              component_name,
              seller_id
            )
          )
        `)?.eq('user_id', userId)?.order('created_at', { ascending: false })?.limit(limit);

      if (error) {
        throw new Error(error.message);
      }

      return data || [];
    } catch (error) {
      throw new Error(`Failed to fetch orders: ${error.message}`);
    }
  },

  // Get order by ID
  async getOrderById(orderId, userId) {
    try {
      const { data, error } = await supabase?.from('orders')?.select(`
          *,
          order_items (
            *,
            component_listings (
              component_name,
              seller_id,
              download_url
            )
          ),
          payment_transactions (*)
        `)?.eq('id', orderId)?.eq('user_id', userId)?.single();

      if (error) {
        throw new Error(error.message);
      }

      return data;
    } catch (error) {
      throw new Error(`Failed to fetch order: ${error.message}`);
    }
  },

  // Get user's subscription
  async getUserSubscription(userId) {
    try {
      const { data, error } = await supabase?.from('subscriptions')?.select('*')?.eq('user_id', userId)?.eq('status', 'active')?.single();

      if (error && error?.code !== 'PGRST116') { // Not found error
        throw new Error(error.message);
      }

      return data;
    } catch (error) {
      throw new Error(`Failed to fetch subscription: ${error.message}`);
    }
  },

  // Get revenue shares for seller
  async getSellerRevenue(sellerId, limit = 50) {
    try {
      const { data, error } = await supabase?.from('revenue_shares')?.select(`*,component_listings (component_name,product_id),order_items (product_name,quantity)`)?.eq('seller_id', sellerId)?.order('created_at', { ascending: false })?.limit(limit);

      if (error) {
        throw new Error(error.message);
      }

      return data || [];
    } catch (error) {
      throw new Error(`Failed to fetch revenue: ${error.message}`);
    }
  },

  // Calculate total revenue for seller
  async getSellerStats(sellerId) {
    try {
      const { data, error } = await supabase?.from('revenue_shares')?.select('seller_amount, status')?.eq('seller_id', sellerId);

      if (error) {
        throw new Error(error.message);
      }

      const stats = {
        totalRevenue: 0,
        pendingRevenue: 0,
        paidRevenue: 0,
        transactionCount: data?.length || 0
      };

      data?.forEach(share => {
        const amount = parseFloat(share?.seller_amount);
        stats.totalRevenue += amount;
        
        if (share?.status === 'paid') {
          stats.paidRevenue += amount;
        } else if (share?.status === 'pending') {
          stats.pendingRevenue += amount;
        }
      });

      return stats;
    } catch (error) {
      throw new Error(`Failed to fetch seller stats: ${error.message}`);
    }
  }
};