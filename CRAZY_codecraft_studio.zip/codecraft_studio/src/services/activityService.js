import { supabase } from '../lib/supabase';

export const activityService = {
  // Get user's recent activity based on projects and AI conversations
  getUserActivity: async (userId, limit = 20) => {
    try {
      // Get recent projects activity
      const { data: projectsData, error: projectsError } = await supabase?.from('projects')?.select('id, name, updated_at, status, created_at')?.eq('user_id', userId)?.order('updated_at', { ascending: false })?.limit(10)

      // Get recent AI conversations
      const { data: conversationsData, error: conversationsError } = await supabase?.from('ai_conversations')?.select('id, title, updated_at, created_at, conversation_type')?.eq('user_id', userId)?.order('updated_at', { ascending: false })?.limit(10)

      if (projectsError || conversationsError) {
        return { data: [], error: projectsError || conversationsError }
      }

      // Transform data into activity format
      const activities = []

      // Add project activities
      projectsData?.forEach(project => {
        const isNewProject = new Date(project.created_at)?.getTime() === new Date(project.updated_at)?.getTime()
        
        activities?.push({
          id: `project-${project?.id}`,
          type: isNewProject ? 'created' : project?.status === 'published' ? 'published' : 'updated',
          user: 'You',
          action: isNewProject ? 'created project' : project?.status === 'published' ? 'published project' : 'updated project',
          target: project?.name,
          timestamp: project?.updated_at,
          metadata: {
            projectId: project?.id,
            status: project?.status
          }
        })
      })

      // Add AI conversation activities
      conversationsData?.forEach(conversation => {
        activities?.push({
          id: `conversation-${conversation?.id}`,
          type: 'conversation',
          user: 'You',
          action: 'started AI conversation',
          target: conversation?.title || 'Untitled Conversation',
          timestamp: conversation?.created_at,
          metadata: {
            conversationId: conversation?.id,
            type: conversation?.conversation_type
          }
        })
      })

      // Sort by timestamp and limit
      const sortedActivities = activities?.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))?.slice(0, limit)

      return { data: sortedActivities, error: null }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get deployment activity
  getDeploymentActivity: async (userId, limit = 10) => {
    try {
      const { data, error } = await supabase?.from('deployments')?.select(`
          id,
          status,
          created_at,
          completed_at,
          deployment_url,
          projects:project_id (
            name
          )
        `)?.eq('user_id', userId)?.order('created_at', { ascending: false })?.limit(limit)

      if (error) {
        return { data: [], error }
      }

      const activities = data?.map(deployment => ({
        id: `deployment-${deployment?.id}`,
        type: deployment?.status === 'success' ? 'published' : 'deployment',
        user: 'System',
        action: `deployment ${deployment?.status}`,
        target: deployment?.projects?.name || 'Unknown Project',
        timestamp: deployment?.completed_at || deployment?.created_at,
        metadata: {
          deploymentId: deployment?.id,
          status: deployment?.status,
          url: deployment?.deployment_url
        }
      })) || []

      return { data: activities, error: null }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get team activity (for collaborative features)
  getTeamActivity: async (userId, limit = 15) => {
    try {
      // For now, get public projects activity as a proxy for team activity
      const { data, error } = await // Exclude current user
      supabase?.from('projects')?.select(`
          id,
          name,
          updated_at,
          status,
          user_profiles:user_id (
            full_name,
            avatar_url
          )
        `)?.eq('is_public', true)?.neq('user_id', userId)?.order('updated_at', { ascending: false })?.limit(limit)

      if (error) {
        return { data: [], error }
      }

      const activities = data?.map(project => ({
        id: `team-${project?.id}`,
        type: project?.status === 'published' ? 'published' : 'updated',
        user: project?.user_profiles?.full_name || 'Anonymous',
        action: project?.status === 'published' ? 'published project' : 'updated project',
        target: project?.name,
        timestamp: project?.updated_at,
        metadata: {
          projectId: project?.id,
          userId: project?.user_id
        }
      })) || []

      return { data: activities, error: null }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  }
}