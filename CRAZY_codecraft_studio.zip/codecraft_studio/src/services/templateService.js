import { supabase } from '../lib/supabase';

export const templateService = {
  // Get all public templates
  getAll: async (limit = 50) => {
    try {
      const { data, error } = await supabase?.from('templates')?.select(`
          *,
          user_profiles:creator_id (
            full_name,
            avatar_url
          )
        `)?.order('created_at', { ascending: false })?.limit(limit)
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get featured templates
  getFeatured: async (limit = 10) => {
    try {
      const { data, error } = await supabase?.from('templates')?.select(`
          *,
          user_profiles:creator_id (
            full_name,
            avatar_url
          )
        `)?.eq('is_featured', true)?.order('rating', { ascending: false })?.limit(limit)
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get templates by category
  getByCategory: async (category, limit = 20) => {
    try {
      const { data, error } = await supabase?.from('templates')?.select(`
          *,
          user_profiles:creator_id (
            full_name,
            avatar_url
          )
        `)?.eq('category', category)?.order('rating', { ascending: false })?.limit(limit)
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get templates by framework
  getByFramework: async (framework, limit = 20) => {
    try {
      const { data, error } = await supabase?.from('templates')?.select(`
          *,
          user_profiles:creator_id (
            full_name,
            avatar_url
          )
        `)?.eq('framework', framework)?.order('rating', { ascending: false })?.limit(limit)
      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Search templates
  search: async (query, filters = {}) => {
    try {
      let queryBuilder = supabase?.from('templates')?.select(`
          *,
          user_profiles:creator_id (
            full_name,
            avatar_url
          )
        `)

      if (query) {
        queryBuilder = queryBuilder?.or(`name.ilike.%${query}%,description.ilike.%${query}%`)
      }

      if (filters?.category && filters?.category !== 'all') {
        queryBuilder = queryBuilder?.eq('category', filters?.category)
      }

      if (filters?.framework && filters?.framework !== 'all') {
        queryBuilder = queryBuilder?.eq('framework', filters?.framework)
      }

      if (filters?.isPremium !== undefined) {
        queryBuilder = queryBuilder?.eq('is_premium', filters?.isPremium)
      }

      const { data, error } = await queryBuilder?.order('rating', { ascending: false })?.limit(50)

      return { data: data || [], error }
    } catch (error) {
      return { data: [], error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get single template by ID
  getById: async (id) => {
    try {
      const { data, error } = await supabase?.from('templates')?.select(`
          *,
          user_profiles:creator_id (
            full_name,
            avatar_url,
            email
          )
        `)?.eq('id', id)?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Create new template (for creators)
  create: async (templateData, userId) => {
    try {
      const { data, error } = await supabase?.from('templates')?.insert([{ 
          ...templateData, 
          creator_id: userId
        }])?.select()?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Update template (for creators)
  update: async (id, updates, userId) => {
    try {
      const { data, error } = await supabase?.from('templates')?.update(updates)?.eq('id', id)?.eq('creator_id', userId)?.select()?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Delete template (for creators)
  delete: async (id, userId) => {
    try {
      const { error } = await supabase?.from('templates')?.delete()?.eq('id', id)?.eq('creator_id', userId)
      return { error }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  },

  // Increment download count
  incrementDownload: async (id) => {
    try {
      const { data, error } = await supabase?.from('templates')?.update({ 
          download_count: supabase?.raw('download_count + 1')
        })?.eq('id', id)?.select()?.single()
      return { data, error }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  }
}