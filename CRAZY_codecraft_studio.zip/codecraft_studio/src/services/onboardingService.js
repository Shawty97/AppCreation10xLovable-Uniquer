import { supabase } from '../lib/supabase';

export const onboardingService = {
  // Check user onboarding status
  getOnboardingStatus: async (userId) => {
    try {
      const { data: profile, error } = await supabase
        ?.from('user_profiles')
        ?.select('onboarding_completed, preferences, created_at')
        ?.eq('id', userId)
        ?.single()

      if (error) {
        return { data: null, error }
      }

      // Check what steps are completed
      const preferences = profile?.preferences || {}
      const onboardingData = preferences?.onboarding || {}

      const steps = {
        profileSetup: !!profile?.full_name && !!profile?.email,
        dataSourceConnected: !!onboardingData?.dataSourceSetup,
        firstProjectCreated: !!onboardingData?.firstProjectCreated,
        firstDeployment: !!onboardingData?.firstDeployment
      }

      const completedSteps = Object.values(steps)?.filter(Boolean)?.length
      const totalSteps = Object.keys(steps)?.length
      const isComplete = profile?.onboarding_completed || completedSteps === totalSteps

      return {
        data: {
          isComplete,
          completedSteps,
          totalSteps,
          steps,
          createdAt: profile?.created_at
        },
        error: null
      }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Update onboarding step completion
  updateOnboardingStep: async (userId, step, completed = true, data = {}) => {
    try {
      // Get current preferences
      const { data: profile, error: fetchError } = await supabase
        ?.from('user_profiles')
        ?.select('preferences, onboarding_completed')
        ?.eq('id', userId)
        ?.single()

      if (fetchError) {
        return { error: fetchError }
      }

      const preferences = profile?.preferences || {}
      const onboardingData = preferences?.onboarding || {}

      // Update specific step
      onboardingData[step] = completed
      if (data && Object.keys(data)?.length > 0) {
        onboardingData[`${step}Data`] = data
      }

      // Check if all steps are completed
      const requiredSteps = ['dataSourceSetup', 'firstProjectCreated', 'firstDeployment']
      const allStepsCompleted = requiredSteps?.every(stepName => onboardingData?.[stepName])

      const updatedPreferences = {
        ...preferences,
        onboarding: onboardingData
      }

      // Update user profile
      const { data: updatedProfile, error: updateError } = await supabase
        ?.from('user_profiles')
        ?.update({
          preferences: updatedPreferences,
          onboarding_completed: allStepsCompleted || profile?.onboarding_completed,
          updated_at: new Date()?.toISOString()
        })
        ?.eq('id', userId)
        ?.select()
        ?.single()

      return { data: updatedProfile, error: updateError }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  },

  // Complete full onboarding
  completeOnboarding: async (userId) => {
    try {
      const { data, error } = await supabase
        ?.from('user_profiles')
        ?.update({
          onboarding_completed: true,
          updated_at: new Date()?.toISOString()
        })
        ?.eq('id', userId)
        ?.select()
        ?.single()

      return { data, error }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  },

  // Get onboarding recommendations
  getRecommendations: async (userId) => {
    try {
      // Get user's current data to make recommendations
      const { data: projects } = await supabase
        ?.from('projects')
        ?.select('id, framework, status')
        ?.eq('user_id', userId)
        ?.limit(5)

      const { data: deployments } = await supabase
        ?.from('deployments')
        ?.select('id, status')
        ?.eq('user_id', userId)
        ?.limit(5)

      const { data: templates } = await supabase
        ?.from('templates')
        ?.select('id, framework, category, is_featured')
        ?.eq('is_featured', true)
        ?.limit(3)

      const { data: components } = await supabase
        ?.from('component_listings')
        ?.select('id, component_name, rating')
        ?.eq('is_featured', true)
        ?.order('rating', { ascending: false })
        ?.limit(3)

      // Generate personalized recommendations
      const recommendations = {
        nextSteps: [],
        suggestedTemplates: templates || [],
        suggestedComponents: components || [],
        tutorials: []
      }

      // Add contextual next steps
      if (!projects || projects?.length === 0) {
        recommendations?.nextSteps?.push({
          title: 'Create Your First Project',
          description: 'Start with a template or build from scratch',
          action: 'create-project',
          priority: 'high'
        })
      } else if (projects?.filter(p => p?.status === 'published')?.length === 0) {
        recommendations?.nextSteps?.push({
          title: 'Publish Your Project',
          description: 'Make your project public and share it with the world',
          action: 'publish-project',
          priority: 'medium'
        })
      }

      if (!deployments || deployments?.length === 0) {
        recommendations?.nextSteps?.push({
          title: 'Deploy Your First App',
          description: 'Go live with automatic deployment to Vercel or Netlify',
          action: 'deploy-project',
          priority: 'high'
        })
      }

      // Add helpful tutorials
      recommendations.tutorials = [
        {
          title: 'Getting Started with Templates',
          description: 'Learn how to customize and use our premium templates',
          duration: '5 min',
          url: '/tutorials/templates'
        },
        {
          title: 'Deployment Best Practices',
          description: 'Deploy your apps with confidence using our deployment center',
          duration: '8 min',
          url: '/tutorials/deployment'
        },
        {
          title: 'AI-Powered Code Generation',
          description: 'Boost productivity with our AI assistant',
          duration: '6 min',
          url: '/tutorials/ai-assistant'
        }
      ]

      return { data: recommendations, error: null }
    } catch (error) {
      return { data: null, error: { message: 'Network error. Please try again.' } }
    }
  },

  // Track onboarding analytics
  trackOnboardingEvent: async (userId, event, metadata = {}) => {
    try {
      // Store onboarding events for analytics
      const { data: profile, error: fetchError } = await supabase
        ?.from('user_profiles')
        ?.select('preferences')
        ?.eq('id', userId)
        ?.single()

      if (fetchError) {
        return { error: fetchError }
      }

      const preferences = profile?.preferences || {}
      const onboardingEvents = preferences?.onboardingEvents || []

      onboardingEvents?.push({
        event,
        timestamp: new Date()?.toISOString(),
        metadata
      })

      // Keep only last 50 events
      const recentEvents = onboardingEvents?.slice(-50)

      const { error } = await supabase
        ?.from('user_profiles')
        ?.update({
          preferences: {
            ...preferences,
            onboardingEvents: recentEvents
          }
        })
        ?.eq('id', userId)

      return { error }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  }
}