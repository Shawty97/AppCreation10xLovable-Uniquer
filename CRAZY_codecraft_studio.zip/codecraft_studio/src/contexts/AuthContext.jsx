import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

const AuthContext = createContext({})

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [userProfile, setUserProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [profileLoading, setProfileLoading] = useState(false)
  const [error, setError] = useState(null)

  // Isolated async operations - never called from auth callbacks
  const profileOperations = {
    async load(userId) {
      if (!userId) return
      setProfileLoading(true)
      try {
        const { data, error } = await supabase?.from('user_profiles')?.select('*')?.eq('id', userId)?.single()
        if (!error) setUserProfile(data)
      } catch (error) {
        console.error('Profile load error:', error)
      } finally {
        setProfileLoading(false)
      }
    },

    clear() {
      setUserProfile(null)
      setProfileLoading(false)
    }
  }

  // Auth state handlers - PROTECTED from async modification
  const authStateHandlers = {
    // This handler MUST remain synchronous - Supabase requirement
    onChange: (event, session) => {
      setUser(session?.user ?? null)
      setLoading(false)
      
      if (session?.user) {
        profileOperations?.load(session?.user?.id) // Fire-and-forget
      } else {
        profileOperations?.clear()
      }
    }
  }

  useEffect(() => {
    // Get initial session
    getInitialSession();
    
    // Listen for auth changes
    const { data: { subscription } } = supabase?.auth?.onAuthStateChange(async (event, session) => {
      setUser(session?.user ?? null);
      
      if (event === 'SIGNED_IN' && session?.user) {
        await loadUserProfile(session?.user?.id);
      } else if (event === 'SIGNED_OUT') {
        setUserProfile(null);
      }
      
      setLoading(false);
    });

    return () => subscription?.unsubscribe();
  }, []);

  const getInitialSession = async () => {
    try {
      const { data: { session } } = await supabase?.auth?.getSession();
      authStateHandlers?.onChange(null, session);
    } catch (error) {
      console.error('Error getting initial session:', error);
    }
  };

  const loadUserProfile = async (userId) => {
    try {
      const { data, error } = await supabase?.from('user_profiles')?.select('*')?.eq('id', userId)?.single();
      if (!error) setUserProfile(data);
    } catch (error) {
      console.error('Error loading user profile:', error);
    }
  };

  const signUp = async (email, password, userData = {}) => {
    try {
      setLoading(true);
      setError('');

      const { data, error: signUpError } = await supabase?.auth?.signUp({
        email,
        password,
        options: {
          data: {
            full_name: userData?.fullName || '',
          }
        }
      });

      if (signUpError) {
        if (signUpError?.message?.includes('User already registered')) {
          setError('An account with this email already exists. Please sign in instead.');
        } else if (signUpError?.message?.includes('Password should be')) {
          setError('Password must be at least 6 characters long.');
        } else {
          setError(signUpError?.message);
        }
        return { data: null, error: signUpError };
      }

      // User profile will be created by database trigger
      return { data, error: null };
    } catch (error) {
      if (error?.message?.includes('Failed to fetch') || 
          error?.message?.includes('AuthRetryableFetchError')) {
        setError('Cannot connect to authentication service. Your Supabase project may be paused or inactive. Please check your Supabase dashboard and resume your project if needed.');
        return { data: null, error };
      }
      
      setError('An unexpected error occurred during sign up.');
      return { data: null, error };
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email, password) => {
    try {
      setLoading(true);
      setError('');

      const { data, error: signInError } = await supabase?.auth?.signInWithPassword({
        email,
        password
      });

      if (signInError) {
        if (signInError?.message?.includes('Invalid login credentials')) {
          setError('Invalid email or password. Please check your credentials.');
        } else if (signInError?.message?.includes('Email not confirmed')) {
          setError('Please check your email and click the confirmation link before signing in.');
        } else {
          setError(signInError?.message);
        }
        return { data: null, error: signInError };
      }

      return { data, error: null };
    } catch (error) {
      if (error?.message?.includes('Failed to fetch') || 
          error?.message?.includes('AuthRetryableFetchError')) {
        setError('Cannot connect to authentication service. Your Supabase project may be paused or inactive. Please check your Supabase dashboard and resume your project if needed.');
        return { data: null, error };
      }
      
      setError('An unexpected error occurred during sign in.');
      return { data: null, error };
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    try {
      setLoading(true);
      const { error } = await supabase?.auth?.signOut();
      
      if (error) {
        setError(error?.message);
        return { error };
      }

      setUser(null);
      setUserProfile(null);
      return { error: null };
    } catch (error) {
      setError('An unexpected error occurred during sign out.');
      return { error };
    } finally {
      setLoading(false);
    }
  };

  const updateProfile = async (updates) => {
    try {
      if (!user?.id) {
        throw new Error('No user logged in');
      }

      setLoading(true);
      setError('');

      const { data, error: updateError } = await supabase?.from('user_profiles')?.update({
          ...updates,
          updated_at: new Date()?.toISOString()
        })?.eq('id', user?.id)?.select()?.single();

      if (updateError) {
        setError(updateError?.message);
        return { data: null, error: updateError };
      }

      setUserProfile(data);
      return { data, error: null };
    } catch (error) {
      setError('Failed to update profile.');
      return { data: null, error };
    } finally {
      setLoading(false);
    }
  };

  const resetPassword = async (email) => {
    try {
      setLoading(true);
      setError('');

      const { error: resetError } = await supabase?.auth?.resetPasswordForEmail(email, {
        redirectTo: `${window.location?.origin}/reset-password`
      });

      if (resetError) {
        setError(resetError?.message);
        return { error: resetError };
      }

      return { error: null };
    } catch (error) {
      setError('Failed to send password reset email.');
      return { error };
    } finally {
      setLoading(false);
    }
  };

  const changePassword = async (newPassword) => {
    try {
      setLoading(true);
      setError('');

      const { error: updateError } = await supabase?.auth?.updateUser({
        password: newPassword
      });

      if (updateError) {
        setError(updateError?.message);
        return { error: updateError };
      }

      return { error: null };
    } catch (error) {
      setError('Failed to change password.');
      return { error };
    } finally {
      setLoading(false);
    }
  };

  // Check if user has required permissions
  const hasPermission = (permission) => {
    if (!userProfile) return false;
    
    const role = userProfile?.role;
    
    // Admin has all permissions
    if (role === 'admin') return true;
    
    // Premium users have most permissions
    if (role === 'premium') {
      const premiumPermissions = [
        'create_projects',
        'deploy_projects', 
        'use_templates',
        'purchase_components',
        'use_ai_features',
        'access_analytics'
      ];
      return premiumPermissions?.includes(permission);
    }
    
    // Free users have basic permissions
    const freePermissions = [
      'create_projects',
      'use_free_templates',
      'basic_ai_features'
    ];
    return freePermissions?.includes(permission);
  };

  // Check subscription status
  const isSubscriptionActive = () => {
    if (!userProfile) return false;
    
    const status = userProfile?.subscription_status;
    const expiresAt = userProfile?.subscription_expires_at;
    
    if (status === 'active') return true;
    if (status === 'trialing') return true;
    
    if (expiresAt) {
      return new Date(expiresAt) > new Date();
    }
    
    return false;
  };

  const value = {
    user,
    userProfile,
    loading,
    profileLoading,
    signIn,
    signOut,
    updateProfile,
    resetPassword,
    changePassword,
    hasPermission,
    isSubscriptionActive,
    isAuthenticated: !!user
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}