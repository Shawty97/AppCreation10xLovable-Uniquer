import React, { useState, useEffect } from 'react';
import { CheckCircle, ArrowRight, ArrowLeft, Sparkles, Rocket, Database } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { onboardingService } from '../services/onboardingService';
import { projectService } from '../services/projectService';
import { deploymentService } from '../services/deploymentService';
import { telemetryService } from '../services/telemetryService';

export default function OnboardingFlow({ onComplete }) {
  const { user, userProfile, updateProfile } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const [onboardingStatus, setOnboardingStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [stepData, setStepData] = useState({
    dataSource: '',
    projectName: '',
    projectTemplate: '',
    deploymentProvider: 'vercel'
  });

  const steps = [
    {
      id: 'welcome',
      title: 'Welcome to CodeCraft Studio!',
      description: 'Let\'s get you set up in just 3 simple steps',
      icon: Sparkles,
      component: WelcomeStep
    },
    {
      id: 'dataSource',
      title: 'Connect Your Data Source',
      description: 'Choose how you want to manage your data',
      icon: Database,
      component: DataSourceStep
    },
    {
      id: 'firstProject',
      title: 'Create Your First Project',
      description: 'Start building with a template or from scratch',
      icon: Rocket,
      component: ProjectStep
    },
    {
      id: 'deployment',
      title: 'Deploy Your App',
      description: 'Go live with one-click deployment',
      icon: CheckCircle,
      component: DeploymentStep
    }
  ];

  // Load onboarding status
  useEffect(() => {
    if (user?.id) {
      loadOnboardingStatus();
    }
  }, [user?.id]);

  const loadOnboardingStatus = async () => {
    try {
      const { data, error } = await onboardingService?.getOnboardingStatus(user?.id);
      
      if (!error && data) {
        setOnboardingStatus(data);
        
        // Skip to appropriate step based on completion
        if (data?.steps?.firstProjectCreated && !data?.steps?.firstDeployment) {
          setCurrentStep(3);
        } else if (data?.steps?.dataSourceConnected && !data?.steps?.firstProjectCreated) {
          setCurrentStep(2);
        } else if (!data?.steps?.dataSourceConnected) {
          setCurrentStep(1);
        }
      }
    } catch (err) {
      console.error('Failed to load onboarding status:', err);
    }
  };

  const handleNext = async () => {
    setError('');
    
    try {
      setLoading(true);
      
      // Process current step
      await processCurrentStep();
      
      if (currentStep < steps?.length - 1) {
        setCurrentStep(currentStep + 1);
      } else {
        // Complete onboarding
        await completeOnboarding();
      }
    } catch (err) {
      setError(err?.message || 'An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const processCurrentStep = async () => {
    const step = steps?.[currentStep];
    
    switch (step?.id) {
      case 'welcome':
        // Track onboarding start
        await telemetryService?.trackEvent('onboarding_started', {}, user?.id);
        await onboardingService?.trackOnboardingEvent(user?.id, 'onboarding_started');
        break;
        
      case 'dataSource':
        if (!stepData?.dataSource) {
          throw new Error('Please select a data source option');
        }
        
        await onboardingService?.updateOnboardingStep(user?.id, 'dataSourceSetup', true, {
          dataSource: stepData?.dataSource
        });
        
        await telemetryService?.trackEvent('onboarding_data_source_selected', {
          data_source: stepData?.dataSource
        }, user?.id);
        break;
        
      case 'firstProject':
        if (!stepData?.projectName) {
          throw new Error('Please enter a project name');
        }
        
        // Create the project
        const projectData = {
          name: stepData?.projectName,
          description: 'My first CodeCraft project',
          template_id: stepData?.projectTemplate || null,
          framework: 'react',
          status: 'draft'
        };
        
        const { data: project, error: projectError } = await projectService?.create(projectData, user?.id);
        
        if (projectError) {
          throw new Error('Failed to create project');
        }
        
        await onboardingService?.updateOnboardingStep(user?.id, 'firstProjectCreated', true, {
          projectId: project?.id,
          projectName: stepData?.projectName
        });
        
        await telemetryService?.trackMilestone('first_project', user?.id);
        break;
        
      case 'deployment': // Get user's first project for deployment
        const { data: projects } = await projectService?.getAll(user?.id);
        
        if (projects && projects?.length > 0) {
          const firstProject = projects?.[0];
          
          // Create a deployment (simulated)
          const deploymentData = {
            project_id: firstProject?.id,
            provider: stepData?.deploymentProvider,
            branch: 'main'
          };
          
          await deploymentService?.deploy(deploymentData, user?.id);
          
          await onboardingService?.updateOnboardingStep(user?.id, 'firstDeployment', true, {
            projectId: firstProject?.id,
            provider: stepData?.deploymentProvider
          });
          
          await telemetryService?.trackMilestone('first_deployment', user?.id);
        }
        break;
    }
  };

  const completeOnboarding = async () => {
    try {
      await onboardingService?.completeOnboarding(user?.id);
      await telemetryService?.trackEvent('onboarding_completed', {}, user?.id);
      
      if (onComplete) {
        onComplete();
      }
    } catch (err) {
      throw new Error('Failed to complete onboarding');
    }
  };

  const handleSkip = async () => {
    try {
      await onboardingService?.completeOnboarding(user?.id);
      await telemetryService?.trackEvent('onboarding_skipped', {}, user?.id);
      
      if (onComplete) {
        onComplete();
      }
    } catch (err) {
      console.error('Failed to skip onboarding:', err);
    }
  };

  if (!user) {
    return null;
  }

  const CurrentStepComponent = steps?.[currentStep]?.component;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-gray-900">Getting Started</h2>
            <button
              onClick={handleSkip}
              className="text-gray-400 hover:text-gray-600 text-sm"
            >
              Skip for now
            </button>
          </div>
          
          {/* Progress Bar */}
          <div className="flex items-center space-x-2">
            {steps?.map((step, index) => {
              const StepIcon = step?.icon;
              const isCompleted = index < currentStep;
              const isCurrent = index === currentStep;
              
              return (
                <div key={step?.id} className="flex items-center">
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 ${
                    isCompleted 
                      ? 'bg-green-500 border-green-500 text-white' 
                      : isCurrent 
                        ? 'border-blue-500 text-blue-500 bg-blue-50' :'border-gray-300 text-gray-400'
                  }`}>
                    {isCompleted ? (
                      <CheckCircle className="w-4 h-4" />
                    ) : (
                      <StepIcon className="w-4 h-4" />
                    )}
                  </div>
                  {index < steps?.length - 1 && (
                    <div className={`w-8 h-0.5 mx-2 ${
                      isCompleted ? 'bg-green-500' : 'bg-gray-300'
                    }`} />
                  )}
                </div>
              );
            })}
          </div>
          
          <div className="mt-3">
            <p className="text-sm text-gray-600">
              Step {currentStep + 1} of {steps?.length}
            </p>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {error && (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}
          
          <CurrentStepComponent
            stepData={stepData}
            setStepData={setStepData}
            onNext={handleNext}
            loading={loading}
          />
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
          <button
            onClick={handlePrevious}
            disabled={currentStep === 0}
            className="flex items-center px-4 py-2 text-gray-600 hover:text-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Previous
          </button>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={handleNext}
              disabled={loading}
              className="flex items-center px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              ) : currentStep === steps?.length - 1 ? (
                'Complete Setup'
              ) : (
                <>
                  Next
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Step Components
function WelcomeStep({ onNext }) {
  return (
    <div className="text-center">
      <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
        <Sparkles className="w-8 h-8 text-blue-600" />
      </div>
      
      <h3 className="text-xl font-semibold text-gray-900 mb-4">
        Welcome to CodeCraft Studio!
      </h3>
      
      <p className="text-gray-600 mb-8">
        You're about to experience the future of web development. Let's get you set up with everything you need to build amazing applications in minutes, not hours.
      </p>
      
      <div className="space-y-4 text-left">
        <div className="flex items-center space-x-3">
          <CheckCircle className="w-5 h-5 text-green-500" />
          <span className="text-gray-700">Connect your data source</span>
        </div>
        <div className="flex items-center space-x-3">
          <CheckCircle className="w-5 h-5 text-green-500" />
          <span className="text-gray-700">Create your first project</span>
        </div>
        <div className="flex items-center space-x-3">
          <CheckCircle className="w-5 h-5 text-green-500" />
          <span className="text-gray-700">Deploy to the web</span>
        </div>
      </div>
    </div>
  );
}

function DataSourceStep({ stepData, setStepData }) {
  const dataSourceOptions = [
    {
      id: 'supabase',
      name: 'Supabase',
      description: 'PostgreSQL database with real-time features',
      recommended: true
    },
    {
      id: 'firebase',
      name: 'Firebase',
      description: 'Google\'s NoSQL database platform'
    },
    {
      id: 'mongodb',
      name: 'MongoDB',
      description: 'Flexible document database'
    },
    {
      id: 'custom',
      name: 'Custom API',
      description: 'Connect to your existing API'
    }
  ];

  return (
    <div>
      <div className="text-center mb-6">
        <Database className="w-12 h-12 text-blue-600 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          Connect Your Data Source
        </h3>
        <p className="text-gray-600">
          Choose how you want to store and manage your application data
        </p>
      </div>
      <div className="space-y-3">
        {dataSourceOptions?.map((option) => (
          <label
            key={option?.id}
            className={`block p-4 border-2 rounded-lg cursor-pointer transition-colors ${
              stepData?.dataSource === option?.id
                ? 'border-blue-500 bg-blue-50' :'border-gray-200 hover:border-gray-300'
            }`}
          >
            <input
              type="radio"
              name="dataSource"
              value={option?.id}
              checked={stepData?.dataSource === option?.id}
              onChange={(e) => setStepData(prev => ({ ...prev, dataSource: e?.target?.value }))}
              className="sr-only"
            />
            
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center">
                  <h4 className="font-medium text-gray-900">{option?.name}</h4>
                  {option?.recommended && (
                    <span className="ml-2 px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">
                      Recommended
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-600 mt-1">{option?.description}</p>
              </div>
              
              <div className={`w-4 h-4 border-2 rounded-full ${
                stepData?.dataSource === option?.id
                  ? 'border-blue-500 bg-blue-500' :'border-gray-300'
              }`}>
                {stepData?.dataSource === option?.id && (
                  <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5"></div>
                )}
              </div>
            </div>
          </label>
        ))}
      </div>
    </div>
  );
}

function ProjectStep({ stepData, setStepData }) {
  return (
    <div>
      <div className="text-center mb-6">
        <Rocket className="w-12 h-12 text-blue-600 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          Create Your First Project
        </h3>
        <p className="text-gray-600">
          Give your project a name and we'll set everything up for you
        </p>
      </div>
      <div className="space-y-4">
        <div>
          <label htmlFor="projectName" className="block text-sm font-medium text-gray-700 mb-2">
            Project Name
          </label>
          <input
            type="text"
            id="projectName"
            value={stepData?.projectName}
            onChange={(e) => setStepData(prev => ({ ...prev, projectName: e?.target?.value }))}
            placeholder="My Awesome App"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Start with a template (optional)
          </label>
          <select
            value={stepData?.projectTemplate}
            onChange={(e) => setStepData(prev => ({ ...prev, projectTemplate: e?.target?.value }))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Start from scratch</option>
            <option value="blog">Blog Template</option>
            <option value="ecommerce">E-commerce Template</option>
            <option value="portfolio">Portfolio Template</option>
            <option value="dashboard">Dashboard Template</option>
          </select>
        </div>
      </div>
    </div>
  );
}

function DeploymentStep({ stepData, setStepData }) {
  const deploymentOptions = [
    {
      id: 'vercel',
      name: 'Vercel',
      description: 'Fast, reliable hosting with automatic deployments',
      recommended: true
    },
    {
      id: 'netlify',
      name: 'Netlify',
      description: 'Modern hosting with continuous deployment'
    }
  ];

  return (
    <div>
      <div className="text-center mb-6">
        <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          Deploy Your App
        </h3>
        <p className="text-gray-600">
          Choose where to deploy your application and go live in seconds
        </p>
      </div>
      <div className="space-y-3">
        {deploymentOptions?.map((option) => (
          <label
            key={option?.id}
            className={`block p-4 border-2 rounded-lg cursor-pointer transition-colors ${
              stepData?.deploymentProvider === option?.id
                ? 'border-green-500 bg-green-50' :'border-gray-200 hover:border-gray-300'
            }`}
          >
            <input
              type="radio"
              name="deploymentProvider"
              value={option?.id}
              checked={stepData?.deploymentProvider === option?.id}
              onChange={(e) => setStepData(prev => ({ ...prev, deploymentProvider: e?.target?.value }))}
              className="sr-only"
            />
            
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center">
                  <h4 className="font-medium text-gray-900">{option?.name}</h4>
                  {option?.recommended && (
                    <span className="ml-2 px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">
                      Recommended
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-600 mt-1">{option?.description}</p>
              </div>
              
              <div className={`w-4 h-4 border-2 rounded-full ${
                stepData?.deploymentProvider === option?.id
                  ? 'border-green-500 bg-green-500' :'border-gray-300'
              }`}>
                {stepData?.deploymentProvider === option?.id && (
                  <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5"></div>
                )}
              </div>
            </div>
          </label>
        ))}
      </div>
    </div>
  );
}