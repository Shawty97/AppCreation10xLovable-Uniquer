import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';


const IntegrationsTab = () => {
  const [integrations, setIntegrations] = useState([
    {
      id: 'google-drive',
      name: 'Google Drive',
      description: 'Store and sync your project files with Google Drive',
      icon: 'https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?w=64&h=64&fit=crop',
      category: 'Storage',
      connected: true,
      connectedDate: '2025-09-15',
      permissions: ['Read files', 'Write files', 'Create folders'],
      status: 'active'
    },
    {
      id: 'slack',
      name: 'Slack',
      description: 'Get notifications and updates in your Slack workspace',
      icon: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=64&h=64&fit=crop',
      category: 'Communication',
      connected: true,
      connectedDate: '2025-08-20',
      permissions: ['Send messages', 'Read channels', 'Post to channels'],
      status: 'active'
    },
    {
      id: 'github',
      name: 'GitHub',
      description: 'Export your projects as clean React code repositories',
      icon: 'https://images.unsplash.com/photo-1618401471353-b98afee0b2eb?w=64&h=64&fit=crop',
      category: 'Development',
      connected: false,
      permissions: ['Create repositories', 'Push code', 'Manage webhooks'],
      status: 'available'
    },
    {
      id: 'google-analytics',
      name: 'Google Analytics',
      description: 'Track and analyze your application performance',
      icon: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=64&h=64&fit=crop',
      category: 'Analytics',
      connected: false,
      permissions: ['Read analytics data', 'Create tracking codes'],
      status: 'available'
    },
    {
      id: 'stripe',
      name: 'Stripe',
      description: 'Accept payments in your applications',
      icon: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=64&h=64&fit=crop',
      category: 'Payments',
      connected: true,
      connectedDate: '2025-09-01',
      permissions: ['Process payments', 'Access customer data', 'Create products'],
      status: 'active'
    },
    {
      id: 'mailchimp',
      name: 'Mailchimp',
      description: 'Manage email campaigns and subscriber lists',
      icon: 'https://images.unsplash.com/photo-1596526131083-e8c633c948d2?w=64&h=64&fit=crop',
      category: 'Marketing',
      connected: false,
      permissions: ['Manage lists', 'Send campaigns', 'Access reports'],
      status: 'available'
    },
    {
      id: 'zapier',
      name: 'Zapier',
      description: 'Automate workflows between your apps',
      icon: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=64&h=64&fit=crop',
      category: 'Automation',
      connected: false,
      permissions: ['Create zaps', 'Trigger actions', 'Access data'],
      status: 'available'
    },
    {
      id: 'figma',
      name: 'Figma',
      description: 'Import designs and assets from Figma',
      icon: 'https://images.unsplash.com/photo-1609921212029-bb5a28e60960?w=64&h=64&fit=crop',
      category: 'Design',
      connected: false,
      permissions: ['Read files', 'Export assets', 'Access teams'],
      status: 'available'
    }
  ]);

  const [selectedCategory, setSelectedCategory] = useState('All');
  const [showConnectionModal, setShowConnectionModal] = useState(false);
  const [selectedIntegration, setSelectedIntegration] = useState(null);
  const [isConnecting, setIsConnecting] = useState(false);

  const categories = ['All', 'Storage', 'Communication', 'Development', 'Analytics', 'Payments', 'Marketing', 'Automation', 'Design'];

  const filteredIntegrations = selectedCategory === 'All' 
    ? integrations 
    : integrations?.filter(integration => integration?.category === selectedCategory);

  const connectedCount = integrations?.filter(integration => integration?.connected)?.length;

  const handleConnect = (integration) => {
    setSelectedIntegration(integration);
    setShowConnectionModal(true);
  };

  const handleDisconnect = (integrationId) => {
    if (confirm('Are you sure you want to disconnect this integration?')) {
      setIntegrations(prev => 
        prev?.map(integration => 
          integration?.id === integrationId 
            ? { ...integration, connected: false, connectedDate: null, status: 'available' }
            : integration
        )
      );
    }
  };

  const handleConfirmConnection = async () => {
    setIsConnecting(true);
    // Simulate OAuth flow
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIntegrations(prev => 
      prev?.map(integration => 
        integration?.id === selectedIntegration?.id 
          ? { 
              ...integration, 
              connected: true, 
              connectedDate: new Date()?.toISOString()?.split('T')?.[0],
              status: 'active'
            }
          : integration
      )
    );
    
    setIsConnecting(false);
    setShowConnectionModal(false);
    setSelectedIntegration(null);
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getCategoryIcon = (category) => {
    const icons = {
      'Storage': 'HardDrive',
      'Communication': 'MessageCircle',
      'Development': 'Code',
      'Analytics': 'BarChart3',
      'Payments': 'CreditCard',
      'Marketing': 'Mail',
      'Automation': 'Zap',
      'Design': 'Palette'
    };
    return icons?.[category] || 'Package';
  };

  return (
    <div className="space-y-8">
      {/* Integration Overview */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground flex items-center">
            <Icon name="Plug" size={20} className="mr-2" />
            Connected Integrations
          </h3>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full"></div>
            <span className="text-sm text-muted-foreground">{connectedCount} active</span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <div className="text-2xl font-bold text-foreground">{connectedCount}</div>
            <div className="text-sm text-muted-foreground">Connected</div>
          </div>
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <div className="text-2xl font-bold text-foreground">{integrations?.length - connectedCount}</div>
            <div className="text-sm text-muted-foreground">Available</div>
          </div>
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <div className="text-2xl font-bold text-foreground">{categories?.length - 1}</div>
            <div className="text-sm text-muted-foreground">Categories</div>
          </div>
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <div className="text-2xl font-bold text-foreground">24/7</div>
            <div className="text-sm text-muted-foreground">Monitoring</div>
          </div>
        </div>
      </div>
      {/* Category Filter */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h4 className="font-medium text-foreground mb-4">Filter by Category</h4>
        <div className="flex flex-wrap gap-2">
          {categories?.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-quick ${
                selectedCategory === category
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80 hover:text-foreground'
              }`}
            >
              {category !== 'All' && <Icon name={getCategoryIcon(category)} size={16} />}
              <span>{category}</span>
            </button>
          ))}
        </div>
      </div>
      {/* Integrations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredIntegrations?.map((integration) => (
          <div key={integration?.id} className="bg-card rounded-lg border border-border p-6 hover:shadow-elevation-2 transition-all duration-300">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-lg overflow-hidden border border-border">
                  <Image
                    src={integration?.icon}
                    alt={integration?.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">{integration?.name}</h4>
                  <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
                    {integration?.category}
                  </span>
                </div>
              </div>
              
              <div className="flex items-center space-x-1">
                <div className={`w-2 h-2 rounded-full ${
                  integration?.connected ? 'bg-success' : 'bg-muted'
                }`}></div>
                <span className={`text-xs font-medium ${
                  integration?.connected ? 'text-success' : 'text-muted-foreground'
                }`}>
                  {integration?.connected ? 'Connected' : 'Available'}
                </span>
              </div>
            </div>
            
            <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
              {integration?.description}
            </p>
            
            {integration?.connected && integration?.connectedDate && (
              <p className="text-xs text-muted-foreground mb-4">
                Connected on {formatDate(integration?.connectedDate)}
              </p>
            )}
            
            <div className="space-y-3">
              <div>
                <h5 className="text-xs font-medium text-foreground mb-2">Permissions:</h5>
                <div className="space-y-1">
                  {integration?.permissions?.slice(0, 2)?.map((permission, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Icon name="Check" size={12} className="text-success" />
                      <span className="text-xs text-muted-foreground">{permission}</span>
                    </div>
                  ))}
                  {integration?.permissions?.length > 2 && (
                    <span className="text-xs text-muted-foreground">
                      +{integration?.permissions?.length - 2} more
                    </span>
                  )}
                </div>
              </div>
              
              <div className="pt-2">
                {integration?.connected ? (
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      fullWidth
                      iconName="Settings"
                      iconSize={14}
                    >
                      Configure
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDisconnect(integration?.id)}
                      iconName="Unplug"
                      iconSize={14}
                      className="text-error hover:text-error hover:border-error"
                    >
                      Disconnect
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="default"
                    size="sm"
                    fullWidth
                    onClick={() => handleConnect(integration)}
                    iconName="Plus"
                    iconPosition="left"
                    iconSize={14}
                  >
                    Connect
                  </Button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Connection Modal */}
      {showConnectionModal && selectedIntegration && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card rounded-lg border border-border p-6 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-lg font-semibold text-foreground">
                Connect {selectedIntegration?.name}
              </h4>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowConnectionModal(false)}
                iconName="X"
                iconSize={20}
              />
            </div>
            
            <div className="text-center mb-6">
              <div className="w-16 h-16 rounded-lg overflow-hidden border border-border mx-auto mb-4">
                <Image
                  src={selectedIntegration?.icon}
                  alt={selectedIntegration?.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="text-sm text-muted-foreground">
                {selectedIntegration?.description}
              </p>
            </div>
            
            <div className="space-y-4 mb-6">
              <div>
                <h5 className="text-sm font-medium text-foreground mb-3">
                  This integration will be able to:
                </h5>
                <div className="space-y-2">
                  {selectedIntegration?.permissions?.map((permission, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Icon name="Check" size={16} className="text-success" />
                      <span className="text-sm text-foreground">{permission}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="bg-muted/50 rounded-lg p-3">
                <div className="flex items-start space-x-2">
                  <Icon name="Info" size={16} className="text-primary mt-0.5" />
                  <div>
                    <p className="text-sm text-foreground font-medium">Secure Connection</p>
                    <p className="text-xs text-muted-foreground">
                      Your data is encrypted and we never store your credentials.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowConnectionModal(false)}
                fullWidth
              >
                Cancel
              </Button>
              <Button
                variant="default"
                onClick={handleConfirmConnection}
                loading={isConnecting}
                fullWidth
              >
                {isConnecting ? 'Connecting...' : 'Connect'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default IntegrationsTab;