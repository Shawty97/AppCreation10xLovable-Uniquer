import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const TeamTab = () => {
  const [teamMembers, setTeamMembers] = useState([
    {
      id: 1,
      name: "Sarah Chen",
      email: "sarah.chen@example.com",
      role: "admin",
      status: "active",
      joinedDate: "2025-08-15",
      lastActive: "2025-10-01T14:00:00Z",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      projects: 8
    },
    {
      id: 2,
      name: "Mike Johnson",
      email: "mike.johnson@example.com",
      role: "editor",
      status: "active",
      joinedDate: "2025-09-01",
      lastActive: "2025-10-01T13:30:00Z",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      projects: 5
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      email: "emily.rodriguez@example.com",
      role: "viewer",
      status: "pending",
      joinedDate: "2025-09-28",
      lastActive: null,
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      projects: 0
    }
  ]);

  const [workspaces] = useState([
    {
      id: 1,
      name: "Main Workspace",
      description: "Primary development workspace for all projects",
      members: 3,
      projects: 12,
      created: "2025-07-01",
      isDefault: true
    },
    {
      id: 2,
      name: "Client Projects",
      description: "Dedicated workspace for client work and collaborations",
      members: 2,
      projects: 6,
      created: "2025-08-15",
      isDefault: false
    }
  ]);

  const [inviteForm, setInviteForm] = useState({
    email: '',
    role: 'viewer',
    message: ''
  });

  const [showInviteModal, setShowInviteModal] = useState(false);
  const [isInviting, setIsInviting] = useState(false);

  const roleOptions = [
    { value: 'admin', label: 'Admin', description: 'Full access to all features and settings' },
    { value: 'editor', label: 'Editor', description: 'Can create and edit projects' },
    { value: 'viewer', label: 'Viewer', description: 'Can view projects but not edit' }
  ];

  const getRoleColor = (role) => {
    switch (role) {
      case 'admin': return 'bg-error text-error-foreground';
      case 'editor': return 'bg-warning text-warning-foreground';
      case 'viewer': return 'bg-muted text-muted-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'text-success';
      case 'pending': return 'text-warning';
      case 'inactive': return 'text-muted-foreground';
      default: return 'text-muted-foreground';
    }
  };

  const handleInviteSubmit = async () => {
    setIsInviting(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Add new member to the list
    const newMember = {
      id: Date.now(),
      name: inviteForm?.email?.split('@')?.[0],
      email: inviteForm?.email,
      role: inviteForm?.role,
      status: 'pending',
      joinedDate: new Date()?.toISOString()?.split('T')?.[0],
      lastActive: null,
      avatar: `https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face`,
      projects: 0
    };
    
    setTeamMembers(prev => [...prev, newMember]);
    setInviteForm({ email: '', role: 'viewer', message: '' });
    setShowInviteModal(false);
    setIsInviting(false);
  };

  const handleRoleChange = (memberId, newRole) => {
    setTeamMembers(prev => 
      prev?.map(member => 
        member?.id === memberId ? { ...member, role: newRole } : member
      )
    );
  };

  const handleRemoveMember = (memberId) => {
    if (confirm('Are you sure you want to remove this team member?')) {
      setTeamMembers(prev => prev?.filter(member => member?.id !== memberId));
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatLastActive = (timestamp) => {
    if (!timestamp) return 'Never';
    const now = new Date();
    const lastActive = new Date(timestamp);
    const diffInHours = Math.floor((now - lastActive) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    return formatDate(timestamp);
  };

  return (
    <div className="space-y-8">
      {/* Workspace Overview */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground flex items-center">
            <Icon name="Building" size={20} className="mr-2" />
            Workspaces
          </h3>
          <Button
            variant="outline"
            iconName="Plus"
            iconPosition="left"
            iconSize={16}
          >
            New Workspace
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {workspaces?.map((workspace) => (
            <div key={workspace?.id} className="border border-border rounded-lg p-4 hover:shadow-elevation-1 transition-all duration-300">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center space-x-2">
                    <h4 className="font-semibold text-foreground">{workspace?.name}</h4>
                    {workspace?.isDefault && (
                      <span className="bg-primary text-primary-foreground px-2 py-1 rounded-full text-xs font-medium">
                        Default
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{workspace?.description}</p>
                </div>
                <Button variant="ghost" size="icon" iconName="MoreHorizontal" iconSize={16} />
              </div>
              
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-lg font-semibold text-foreground">{workspace?.members}</div>
                  <div className="text-xs text-muted-foreground">Members</div>
                </div>
                <div>
                  <div className="text-lg font-semibold text-foreground">{workspace?.projects}</div>
                  <div className="text-xs text-muted-foreground">Projects</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-foreground">{formatDate(workspace?.created)}</div>
                  <div className="text-xs text-muted-foreground">Created</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Team Members */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground flex items-center">
            <Icon name="Users" size={20} className="mr-2" />
            Team Members ({teamMembers?.length})
          </h3>
          <Button
            variant="default"
            onClick={() => setShowInviteModal(true)}
            iconName="UserPlus"
            iconPosition="left"
            iconSize={16}
          >
            Invite Member
          </Button>
        </div>
        
        <div className="space-y-4">
          {teamMembers?.map((member) => (
            <div key={member?.id} className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-quick">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-border">
                  <Image
                    src={member?.avatar}
                    alt={member?.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <div>
                  <div className="flex items-center space-x-2">
                    <h4 className="font-medium text-foreground">{member?.name}</h4>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRoleColor(member?.role)}`}>
                      {member?.role}
                    </span>
                    <div className="flex items-center space-x-1">
                      <div className={`w-2 h-2 rounded-full ${member?.status === 'active' ? 'bg-success' : 'bg-warning'}`}></div>
                      <span className={`text-xs font-medium ${getStatusColor(member?.status)}`}>
                        {member?.status}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">{member?.email}</p>
                  <div className="flex items-center space-x-4 text-xs text-muted-foreground mt-1">
                    <span>Joined {formatDate(member?.joinedDate)}</span>
                    <span>•</span>
                    <span>Last active {formatLastActive(member?.lastActive)}</span>
                    <span>•</span>
                    <span>{member?.projects} projects</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Select
                  options={roleOptions}
                  value={member?.role}
                  onChange={(value) => handleRoleChange(member?.id, value)}
                  className="w-32"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleRemoveMember(member?.id)}
                  iconName="Trash2"
                  iconSize={16}
                  className="text-error hover:text-error hover:bg-error/10"
                />
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Permissions & Access Control */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center">
          <Icon name="Shield" size={20} className="mr-2" />
          Permissions & Access Control
        </h3>
        
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <h4 className="font-medium text-foreground flex items-center">
                <Icon name="Crown" size={16} className="mr-2 text-error" />
                Admin
              </h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center space-x-2">
                  <Icon name="Check" size={14} className="text-success" />
                  <span>Full workspace access</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Icon name="Check" size={14} className="text-success" />
                  <span>Manage team members</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Icon name="Check" size={14} className="text-success" />
                  <span>Billing & subscription</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Icon name="Check" size={14} className="text-success" />
                  <span>Security settings</span>
                </li>
              </ul>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-medium text-foreground flex items-center">
                <Icon name="Edit" size={16} className="mr-2 text-warning" />
                Editor
              </h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center space-x-2">
                  <Icon name="Check" size={14} className="text-success" />
                  <span>Create & edit projects</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Icon name="Check" size={14} className="text-success" />
                  <span>Access templates</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Icon name="Check" size={14} className="text-success" />
                  <span>Deploy applications</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Icon name="X" size={14} className="text-muted-foreground" />
                  <span>Team management</span>
                </li>
              </ul>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-medium text-foreground flex items-center">
                <Icon name="Eye" size={16} className="mr-2 text-muted-foreground" />
                Viewer
              </h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center space-x-2">
                  <Icon name="Check" size={14} className="text-success" />
                  <span>View projects</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Icon name="Check" size={14} className="text-success" />
                  <span>Comment on projects</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Icon name="X" size={14} className="text-muted-foreground" />
                  <span>Edit projects</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Icon name="X" size={14} className="text-muted-foreground" />
                  <span>Deploy applications</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      {/* Invite Member Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card rounded-lg border border-border p-6 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-lg font-semibold text-foreground">Invite Team Member</h4>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowInviteModal(false)}
                iconName="X"
                iconSize={20}
              />
            </div>
            
            <div className="space-y-4">
              <Input
                label="Email Address"
                type="email"
                value={inviteForm?.email}
                onChange={(e) => setInviteForm(prev => ({ ...prev, email: e?.target?.value }))}
                placeholder="colleague@example.com"
                required
              />
              
              <Select
                label="Role"
                options={roleOptions}
                value={inviteForm?.role}
                onChange={(value) => setInviteForm(prev => ({ ...prev, role: value }))}
                description="Choose the appropriate access level"
              />
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Personal Message (Optional)
                </label>
                <textarea
                  value={inviteForm?.message}
                  onChange={(e) => setInviteForm(prev => ({ ...prev, message: e?.target?.value }))}
                  rows={3}
                  className="w-full px-3 py-2 border border-border rounded-md text-foreground bg-input resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Add a personal message to the invitation..."
                />
              </div>
              
              <div className="flex space-x-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowInviteModal(false)}
                  fullWidth
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleInviteSubmit}
                  loading={isInviting}
                  disabled={!inviteForm?.email}
                  fullWidth
                >
                  Send Invitation
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeamTab;