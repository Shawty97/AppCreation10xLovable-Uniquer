import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const PropertiesPanel = ({ selectedComponent, onComponentUpdate, isCollapsed, onToggleCollapse }) => {
  const [activeTab, setActiveTab] = useState('style');

  const tabs = [
    { id: 'style', name: 'Style', icon: 'Palette' },
    { id: 'content', name: 'Content', icon: 'Type' },
    { id: 'layout', name: 'Layout', icon: 'Move' },
    { id: 'events', name: 'Events', icon: 'Zap' }
  ];

  const colorPresets = [
    { name: 'Primary', value: '#2563eb' },
    { name: 'Success', value: '#059669' },
    { name: 'Warning', value: '#d97706' },
    { name: 'Error', value: '#dc2626' },
    { name: 'Gray', value: '#6b7280' },
    { name: 'White', value: '#ffffff' },
    { name: 'Black', value: '#000000' }
  ];

  const fontFamilyOptions = [
    { value: 'Inter', label: 'Inter' },
    { value: 'Arial', label: 'Arial' },
    { value: 'Helvetica', label: 'Helvetica' },
    { value: 'Georgia', label: 'Georgia' },
    { value: 'Times New Roman', label: 'Times New Roman' }
  ];

  const fontSizeOptions = [
    { value: '12px', label: '12px' },
    { value: '14px', label: '14px' },
    { value: '16px', label: '16px' },
    { value: '18px', label: '18px' },
    { value: '20px', label: '20px' },
    { value: '24px', label: '24px' },
    { value: '32px', label: '32px' }
  ];

  const handleStyleChange = (property, value) => {
    if (selectedComponent && onComponentUpdate) {
      const updatedComponent = {
        ...selectedComponent,
        styles: {
          ...selectedComponent?.styles,
          [property]: value
        }
      };
      onComponentUpdate(updatedComponent);
    }
  };

  const handleContentChange = (property, value) => {
    if (selectedComponent && onComponentUpdate) {
      const updatedComponent = {
        ...selectedComponent,
        [property]: value
      };
      onComponentUpdate(updatedComponent);
    }
  };

  if (isCollapsed) {
    return (
      <div className="w-12 bg-card border-l border-border flex flex-col items-center py-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleCollapse}
          iconName="PanelRightOpen"
          iconSize={16}
          className="hover-lift"
        />
      </div>
    );
  }

  if (!selectedComponent) {
    return (
      <div className="w-80 bg-card border-l border-border flex flex-col">
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-foreground">Properties</h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggleCollapse}
              iconName="PanelRightClose"
              iconSize={16}
              className="hover-lift"
            />
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="text-center">
            <Icon name="MousePointer" size={32} className="mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">Select a component to edit properties</p>
          </div>
        </div>
      </div>
    );
  }

  const renderStyleTab = () => (
    <div className="space-y-4">
      {/* Background Color */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Background Color</label>
        <div className="flex items-center space-x-2 mb-2">
          <input
            type="color"
            value={selectedComponent?.styles?.backgroundColor || '#ffffff'}
            onChange={(e) => handleStyleChange('backgroundColor', e?.target?.value)}
            className="w-8 h-8 rounded border border-border cursor-pointer"
          />
          <Input
            type="text"
            value={selectedComponent?.styles?.backgroundColor || '#ffffff'}
            onChange={(e) => handleStyleChange('backgroundColor', e?.target?.value)}
            className="flex-1"
          />
        </div>
        <div className="flex flex-wrap gap-1">
          {colorPresets?.map((color) => (
            <button
              key={color?.name}
              onClick={() => handleStyleChange('backgroundColor', color?.value)}
              className="w-6 h-6 rounded border border-border hover:scale-110 transition-transform"
              style={{ backgroundColor: color?.value }}
              title={color?.name}
            />
          ))}
        </div>
      </div>

      {/* Text Color */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Text Color</label>
        <div className="flex items-center space-x-2">
          <input
            type="color"
            value={selectedComponent?.styles?.color || '#000000'}
            onChange={(e) => handleStyleChange('color', e?.target?.value)}
            className="w-8 h-8 rounded border border-border cursor-pointer"
          />
          <Input
            type="text"
            value={selectedComponent?.styles?.color || '#000000'}
            onChange={(e) => handleStyleChange('color', e?.target?.value)}
            className="flex-1"
          />
        </div>
      </div>

      {/* Font Family */}
      <Select
        label="Font Family"
        options={fontFamilyOptions}
        value={selectedComponent?.styles?.fontFamily || 'Inter'}
        onChange={(value) => handleStyleChange('fontFamily', value)}
      />

      {/* Font Size */}
      <Select
        label="Font Size"
        options={fontSizeOptions}
        value={selectedComponent?.styles?.fontSize || '16px'}
        onChange={(value) => handleStyleChange('fontSize', value)}
      />

      {/* Border */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Border</label>
        <Input
          type="text"
          placeholder="1px solid #e2e8f0"
          value={selectedComponent?.styles?.border || ''}
          onChange={(e) => handleStyleChange('border', e?.target?.value)}
        />
      </div>

      {/* Border Radius */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Border Radius</label>
        <Input
          type="text"
          placeholder="8px"
          value={selectedComponent?.styles?.borderRadius || ''}
          onChange={(e) => handleStyleChange('borderRadius', e?.target?.value)}
        />
      </div>

      {/* Box Shadow */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Box Shadow</label>
        <Input
          type="text"
          placeholder="0 1px 3px rgba(0,0,0,0.1)"
          value={selectedComponent?.styles?.boxShadow || ''}
          onChange={(e) => handleStyleChange('boxShadow', e?.target?.value)}
        />
      </div>
    </div>
  );

  const renderContentTab = () => (
    <div className="space-y-4">
      {/* Component Name */}
      <Input
        label="Component Name"
        type="text"
        value={selectedComponent?.name || ''}
        onChange={(e) => handleContentChange('name', e?.target?.value)}
      />

      {/* Content (for text-based components) */}
      {['button', 'card']?.includes(selectedComponent?.type) && (
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Content</label>
          <textarea
            value={selectedComponent?.content || ''}
            onChange={(e) => handleContentChange('content', e?.target?.value)}
            className="w-full px-3 py-2 text-sm bg-background border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none"
            rows={3}
            placeholder="Enter content..."
          />
        </div>
      )}

      {/* Placeholder (for input components) */}
      {['input', 'textarea']?.includes(selectedComponent?.type) && (
        <Input
          label="Placeholder"
          type="text"
          value={selectedComponent?.placeholder || ''}
          onChange={(e) => handleContentChange('placeholder', e?.target?.value)}
        />
      )}

      {/* Alt Text (for image components) */}
      {selectedComponent?.type === 'image' && (
        <Input
          label="Alt Text"
          type="text"
          value={selectedComponent?.alt || ''}
          onChange={(e) => handleContentChange('alt', e?.target?.value)}
        />
      )}
    </div>
  );

  const renderLayoutTab = () => (
    <div className="space-y-4">
      {/* Position */}
      <div className="grid grid-cols-2 gap-2">
        <Input
          label="X Position"
          type="number"
          value={selectedComponent?.x || 0}
          onChange={(e) => handleContentChange('x', parseInt(e?.target?.value) || 0)}
        />
        <Input
          label="Y Position"
          type="number"
          value={selectedComponent?.y || 0}
          onChange={(e) => handleContentChange('y', parseInt(e?.target?.value) || 0)}
        />
      </div>

      {/* Size */}
      <div className="grid grid-cols-2 gap-2">
        <Input
          label="Width"
          type="number"
          value={selectedComponent?.width || 0}
          onChange={(e) => handleContentChange('width', parseInt(e?.target?.value) || 0)}
        />
        <Input
          label="Height"
          type="number"
          value={selectedComponent?.height || 0}
          onChange={(e) => handleContentChange('height', parseInt(e?.target?.value) || 0)}
        />
      </div>

      {/* Padding */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Padding</label>
        <Input
          type="text"
          placeholder="16px"
          value={selectedComponent?.styles?.padding || ''}
          onChange={(e) => handleStyleChange('padding', e?.target?.value)}
        />
      </div>

      {/* Margin */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Margin</label>
        <Input
          type="text"
          placeholder="8px"
          value={selectedComponent?.styles?.margin || ''}
          onChange={(e) => handleStyleChange('margin', e?.target?.value)}
        />
      </div>
    </div>
  );

  const renderEventsTab = () => (
    <div className="space-y-4">
      <div className="text-center py-8">
        <Icon name="Zap" size={32} className="mx-auto text-muted-foreground mb-2" />
        <p className="text-sm text-muted-foreground">Event handling coming soon</p>
        <p className="text-xs text-muted-foreground mt-1">Configure click, hover, and form events</p>
      </div>
    </div>
  );

  return (
    <div className="w-80 bg-card border-l border-border flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">Properties</h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleCollapse}
            iconName="PanelRightClose"
            iconSize={16}
            className="hover-lift"
          />
        </div>

        {/* Component Info */}
        <div className="flex items-center space-x-2 p-2 bg-muted rounded-md">
          <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
            <Icon name="Square" size={12} color="white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">
              {selectedComponent?.name}
            </p>
            <p className="text-xs text-muted-foreground capitalize">
              {selectedComponent?.type}
            </p>
          </div>
        </div>
      </div>
      {/* Tabs */}
      <div className="border-b border-border">
        <div className="flex">
          {tabs?.map((tab) => (
            <button
              key={tab?.id}
              onClick={() => setActiveTab(tab?.id)}
              className={`flex-1 flex items-center justify-center space-x-1 px-3 py-2 text-sm font-medium transition-quick ${
                activeTab === tab?.id
                  ? 'text-primary border-b-2 border-primary bg-primary/5' :'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              <Icon name={tab?.icon} size={14} />
              <span className="hidden sm:inline">{tab?.name}</span>
            </button>
          ))}
        </div>
      </div>
      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'style' && renderStyleTab()}
        {activeTab === 'content' && renderContentTab()}
        {activeTab === 'layout' && renderLayoutTab()}
        {activeTab === 'events' && renderEventsTab()}
      </div>
    </div>
  );
};

export default PropertiesPanel;