import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ComponentLibrary = ({ isCollapsed, onToggleCollapse, onDragStart }) => {
  const [activeCategory, setActiveCategory] = useState('layout');
  const [searchTerm, setSearchTerm] = useState('');

  const componentCategories = [
    {
      id: 'layout',
      name: 'Layout',
      icon: 'Layout',
      components: [
        { id: 'container', name: 'Container', icon: 'Square', description: 'Basic container element' },
        { id: 'grid', name: 'Grid', icon: 'Grid3X3', description: 'Responsive grid layout' },
        { id: 'flexbox', name: 'Flexbox', icon: 'AlignJustify', description: 'Flexible box layout' },
        { id: 'section', name: 'Section', icon: 'Rectangle', description: 'Content section wrapper' },
        { id: 'header', name: 'Header', icon: 'AlignTop', description: 'Page header component' },
        { id: 'footer', name: 'Footer', icon: 'AlignBottom', description: 'Page footer component' }
      ]
    },
    {
      id: 'forms',
      name: 'Forms',
      icon: 'FileText',
      components: [
        { id: 'input', name: 'Text Input', icon: 'Type', description: 'Single line text input' },
        { id: 'textarea', name: 'Textarea', icon: 'AlignLeft', description: 'Multi-line text input' },
        { id: 'select', name: 'Select', icon: 'ChevronDown', description: 'Dropdown selection' },
        { id: 'checkbox', name: 'Checkbox', icon: 'CheckSquare', description: 'Boolean selection' },
        { id: 'radio', name: 'Radio Group', icon: 'Circle', description: 'Single choice selection' },
        { id: 'button', name: 'Button', icon: 'MousePointer', description: 'Action trigger button' }
      ]
    },
    {
      id: 'data',
      name: 'Data Display',
      icon: 'Database',
      components: [
        { id: 'table', name: 'Data Table', icon: 'Table', description: 'Structured data display' },
        { id: 'list', name: 'List', icon: 'List', description: 'Vertical item list' },
        { id: 'card', name: 'Card', icon: 'CreditCard', description: 'Content card container' },
        { id: 'chart', name: 'Chart', icon: 'BarChart3', description: 'Data visualization' },
        { id: 'stats', name: 'Stats', icon: 'TrendingUp', description: 'Key metrics display' },
        { id: 'badge', name: 'Badge', icon: 'Tag', description: 'Status indicator' }
      ]
    },
    {
      id: 'media',
      name: 'Media',
      icon: 'Image',
      components: [
        { id: 'image', name: 'Image', icon: 'Image', description: 'Static image display' },
        { id: 'video', name: 'Video', icon: 'Video', description: 'Video player component' },
        { id: 'gallery', name: 'Gallery', icon: 'Images', description: 'Image gallery grid' },
        { id: 'carousel', name: 'Carousel', icon: 'ArrowLeftRight', description: 'Sliding content display' },
        { id: 'avatar', name: 'Avatar', icon: 'User', description: 'Profile image display' }
      ]
    },
    {
      id: 'navigation',
      name: 'Navigation',
      icon: 'Navigation',
      components: [
        { id: 'navbar', name: 'Navigation Bar', icon: 'Menu', description: 'Top navigation menu' },
        { id: 'sidebar', name: 'Sidebar', icon: 'PanelLeft', description: 'Side navigation panel' },
        { id: 'breadcrumb', name: 'Breadcrumb', icon: 'ChevronRight', description: 'Navigation trail' },
        { id: 'tabs', name: 'Tabs', icon: 'Tabs', description: 'Tabbed content switcher' },
        { id: 'pagination', name: 'Pagination', icon: 'MoreHorizontal', description: 'Page navigation' }
      ]
    }
  ];

  const filteredComponents = componentCategories?.find(cat => cat?.id === activeCategory)?.components?.filter(comp =>
    comp?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
    comp?.description?.toLowerCase()?.includes(searchTerm?.toLowerCase())
  ) || [];

  const handleDragStart = (e, component) => {
    e?.dataTransfer?.setData('application/json', JSON.stringify({
      type: 'component',
      componentType: component?.id,
      name: component?.name
    }));
    onDragStart && onDragStart(component);
  };

  if (isCollapsed) {
    return (
      <div className="w-12 bg-card border-r border-border flex flex-col items-center py-4 space-y-2">
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleCollapse}
          iconName="PanelLeftOpen"
          iconSize={16}
          className="hover-lift"
        />
        {componentCategories?.map((category) => (
          <button
            key={category?.id}
            onClick={() => {
              setActiveCategory(category?.id);
              onToggleCollapse();
            }}
            className={`p-2 rounded-md transition-quick hover-lift ${
              activeCategory === category?.id
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
            title={category?.name}
          >
            <Icon name={category?.icon} size={16} />
          </button>
        ))}
      </div>
    );
  }

  return (
    <div className="w-80 bg-card border-r border-border flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">Components</h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleCollapse}
            iconName="PanelLeftClose"
            iconSize={16}
            className="hover-lift"
          />
        </div>
        
        {/* Search */}
        <div className="relative">
          <Icon 
            name="Search" 
            size={16} 
            className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" 
          />
          <input
            type="text"
            placeholder="Search components..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e?.target?.value)}
            className="w-full pl-10 pr-4 py-2 text-sm bg-background border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
          />
        </div>
      </div>
      {/* Categories */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-border">
          <div className="flex flex-wrap gap-1">
            {componentCategories?.map((category) => (
              <button
                key={category?.id}
                onClick={() => setActiveCategory(category?.id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-quick hover-lift ${
                  activeCategory === category?.id
                    ? 'bg-primary text-primary-foreground shadow-elevation-1'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
              >
                <Icon name={category?.icon} size={14} />
                <span>{category?.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Components List */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="space-y-2">
            {filteredComponents?.map((component) => (
              <div
                key={component?.id}
                draggable
                onDragStart={(e) => handleDragStart(e, component)}
                className="group p-3 bg-background border border-border rounded-md cursor-grab active:cursor-grabbing hover:border-primary hover:shadow-elevation-1 transition-quick hover-lift"
              >
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-muted rounded-md flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-quick">
                    <Icon name={component?.icon} size={16} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-medium text-foreground group-hover:text-primary transition-quick">
                      {component?.name}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {component?.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredComponents?.length === 0 && (
            <div className="text-center py-8">
              <Icon name="Search" size={32} className="mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">No components found</p>
              <p className="text-xs text-muted-foreground mt-1">Try adjusting your search terms</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ComponentLibrary;