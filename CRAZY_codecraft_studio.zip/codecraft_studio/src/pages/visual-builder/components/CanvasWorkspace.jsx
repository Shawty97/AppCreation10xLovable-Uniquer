import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CanvasWorkspace = ({ selectedComponent, onComponentSelect, onComponentUpdate }) => {
  const [canvasComponents, setCanvasComponents] = useState([
    {
      id: 'comp-1',
      type: 'container',
      name: 'Main Container',
      x: 50,
      y: 50,
      width: 600,
      height: 400,
      styles: { backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px' },
      children: [
        {
          id: 'comp-2',
          type: 'button',
          name: 'Primary Button',
          x: 20,
          y: 20,
          width: 120,
          height: 40,
          styles: { backgroundColor: '#2563eb', color: '#ffffff', borderRadius: '6px' },
          content: 'Click Me'
        }
      ]
    }
  ]);
  
  const [draggedComponent, setDraggedComponent] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(100);
  const [showGrid, setShowGrid] = useState(true);
  const canvasRef = useRef(null);

  const handleDrop = (e) => {
    e?.preventDefault();
    const rect = canvasRef?.current?.getBoundingClientRect();
    const x = (e?.clientX - rect?.left) * (100 / zoom);
    const y = (e?.clientY - rect?.top) * (100 / zoom);

    try {
      const data = JSON.parse(e?.dataTransfer?.getData('application/json'));
      if (data?.type === 'component') {
        const newComponent = {
          id: `comp-${Date.now()}`,
          type: data?.componentType,
          name: data?.name,
          x: Math.max(0, x - 50),
          y: Math.max(0, y - 25),
          width: getDefaultWidth(data?.componentType),
          height: getDefaultHeight(data?.componentType),
          styles: getDefaultStyles(data?.componentType),
          content: getDefaultContent(data?.componentType)
        };

        setCanvasComponents(prev => [...prev, newComponent]);
      }
    } catch (error) {
      console.error('Error parsing dropped data:', error);
    }
  };

  const getDefaultWidth = (type) => {
    const widths = {
      container: 400,
      button: 120,
      input: 200,
      textarea: 300,
      image: 200,
      card: 300
    };
    return widths?.[type] || 150;
  };

  const getDefaultHeight = (type) => {
    const heights = {
      container: 300,
      button: 40,
      input: 40,
      textarea: 100,
      image: 150,
      card: 200
    };
    return heights?.[type] || 50;
  };

  const getDefaultStyles = (type) => {
    const styles = {
      container: { backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px' },
      button: { backgroundColor: '#2563eb', color: '#ffffff', borderRadius: '6px' },
      input: { backgroundColor: '#ffffff', border: '1px solid #d1d5db', borderRadius: '4px' },
      textarea: { backgroundColor: '#ffffff', border: '1px solid #d1d5db', borderRadius: '4px' },
      image: { backgroundColor: '#f3f4f6', border: '1px solid #e5e7eb', borderRadius: '4px' },
      card: { backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }
    };
    return styles?.[type] || { backgroundColor: '#ffffff', border: '1px solid #e2e8f0' };
  };

  const getDefaultContent = (type) => {
    const content = {
      button: 'Button',
      input: '',
      textarea: 'Enter text here...',
      card: 'Card Content'
    };
    return content?.[type] || '';
  };

  const handleComponentMouseDown = (e, component) => {
    e?.stopPropagation();
    setDraggedComponent(component);
    setIsDragging(true);
    setDragOffset({
      x: e?.clientX - component?.x * (zoom / 100),
      y: e?.clientY - component?.y * (zoom / 100)
    });
    onComponentSelect(component);
  };

  const handleMouseMove = (e) => {
    if (isDragging && draggedComponent) {
      const rect = canvasRef?.current?.getBoundingClientRect();
      const newX = (e?.clientX - rect?.left - dragOffset?.x) * (100 / zoom);
      const newY = (e?.clientY - rect?.top - dragOffset?.y) * (100 / zoom);

      setCanvasComponents(prev => prev?.map(comp =>
        comp?.id === draggedComponent?.id
          ? { ...comp, x: Math.max(0, newX), y: Math.max(0, newY) }
          : comp
      ));
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setDraggedComponent(null);
  };

  const renderComponent = (component) => {
    const isSelected = selectedComponent?.id === component?.id;
    
    return (
      <div
        key={component?.id}
        className={`absolute cursor-move select-none ${isSelected ? 'ring-2 ring-primary' : ''}`}
        style={{
          left: `${component?.x}px`,
          top: `${component?.y}px`,
          width: `${component?.width}px`,
          height: `${component?.height}px`,
          ...component?.styles,
          zIndex: isSelected ? 10 : 1
        }}
        onMouseDown={(e) => handleComponentMouseDown(e, component)}
        onClick={(e) => {
          e?.stopPropagation();
          onComponentSelect(component);
        }}
      >
        {/* Component Content */}
        <div className="w-full h-full flex items-center justify-center text-sm">
          {component?.type === 'button' && (
            <span className="font-medium">{component?.content || 'Button'}</span>
          )}
          {component?.type === 'input' && (
            <div className="w-full h-full bg-white border rounded px-2 flex items-center text-gray-500">
              Placeholder text
            </div>
          )}
          {component?.type === 'container' && (
            <div className="w-full h-full flex items-center justify-center text-gray-400">
              Container
            </div>
          )}
          {component?.type === 'image' && (
            <div className="w-full h-full flex items-center justify-center text-gray-400">
              <Icon name="Image" size={24} />
            </div>
          )}
          {component?.type === 'card' && (
            <div className="w-full h-full p-4">
              <div className="text-sm font-medium mb-2">Card Title</div>
              <div className="text-xs text-gray-500">Card content goes here...</div>
            </div>
          )}
        </div>
        {/* Selection Handles */}
        {isSelected && (
          <>
            <div className="absolute -top-1 -left-1 w-2 h-2 bg-primary rounded-full"></div>
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-primary rounded-full"></div>
            <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-primary rounded-full"></div>
            <div className="absolute -bottom-1 -right-1 w-2 h-2 bg-primary rounded-full"></div>
          </>
        )}
        {/* Render Children */}
        {component?.children?.map(child => renderComponent(child))}
      </div>
    );
  };

  return (
    <div className="flex-1 flex flex-col bg-muted/30">
      {/* Canvas Toolbar */}
      <div className="h-12 bg-card border-b border-border flex items-center justify-between px-4">
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            iconName="Grid3X3"
            iconSize={16}
            onClick={() => setShowGrid(!showGrid)}
            className={showGrid ? 'bg-muted' : ''}
          >
            Grid
          </Button>
          <div className="w-px h-6 bg-border"></div>
          <Button
            variant="ghost"
            size="sm"
            iconName="Smartphone"
            iconSize={16}
          >
            Mobile
          </Button>
          <Button
            variant="ghost"
            size="sm"
            iconName="Tablet"
            iconSize={16}
          >
            Tablet
          </Button>
          <Button
            variant="ghost"
            size="sm"
            iconName="Monitor"
            iconSize={16}
            className="bg-muted"
          >
            Desktop
          </Button>
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            iconName="ZoomOut"
            iconSize={16}
            onClick={() => setZoom(Math.max(25, zoom - 25))}
            disabled={zoom <= 25}
          />
          <span className="text-sm text-muted-foreground min-w-[60px] text-center">
            {zoom}%
          </span>
          <Button
            variant="ghost"
            size="sm"
            iconName="ZoomIn"
            iconSize={16}
            onClick={() => setZoom(Math.min(200, zoom + 25))}
            disabled={zoom >= 200}
          />
          <div className="w-px h-6 bg-border"></div>
          <Button
            variant="ghost"
            size="sm"
            iconName="Undo"
            iconSize={16}
          />
          <Button
            variant="ghost"
            size="sm"
            iconName="Redo"
            iconSize={16}
          />
        </div>
      </div>
      {/* Canvas Area */}
      <div className="flex-1 overflow-auto p-8">
        <div
          ref={canvasRef}
          className="relative bg-white rounded-lg shadow-elevation-1 mx-auto"
          style={{
            width: `${800 * (zoom / 100)}px`,
            height: `${600 * (zoom / 100)}px`,
            transform: `scale(${zoom / 100})`,
            transformOrigin: 'top left',
            backgroundImage: showGrid ? 
              'radial-gradient(circle, #e2e8f0 1px, transparent 1px)' : 'none',
            backgroundSize: showGrid ? '20px 20px' : 'auto'
          }}
          onDrop={handleDrop}
          onDragOver={(e) => e?.preventDefault()}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onClick={() => onComponentSelect(null)}
        >
          {/* Drop Zone Indicator */}
          <div className="absolute inset-0 border-2 border-dashed border-transparent hover:border-primary/30 transition-colors rounded-lg pointer-events-none">
            {canvasComponents?.length === 0 && (
              <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <Icon name="MousePointer" size={32} className="mx-auto mb-2" />
                  <p className="text-sm">Drag components here to start building</p>
                </div>
              </div>
            )}
          </div>

          {/* Render Components */}
          {canvasComponents?.map(component => renderComponent(component))}
        </div>
      </div>
    </div>
  );
};

export default CanvasWorkspace;