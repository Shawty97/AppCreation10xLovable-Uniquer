import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Code, Lightbulb, FileText, Copy, ThumbsUp, ThumbsDown } from 'lucide-react';
import Icon from '../../../components/AppIcon';


const ConversationInterface = ({ 
  conversations = [], 
  currentConversation, 
  onNewConversation, 
  onSendMessage, 
  onSelectConversation,
  preferences
}) => {
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const messagesEndRef = useRef(null);

  // Mock projects for demo - in real app this would come from props
  const mockProjects = [
    { id: 1, name: 'E-commerce Dashboard', framework: 'react' },
    { id: 2, name: 'Portfolio Website', framework: 'next' },
    { id: 3, name: 'Mobile App', framework: 'react' }
  ];

  const conversationTypes = [
    { value: 'general_help', label: 'General Help', icon: Bot },
    { value: 'code_review', label: 'Code Review', icon: Code },
    { value: 'project_guidance', label: 'Project Guidance', icon: Lightbulb },
    { value: 'voice_creation', label: 'Voice Creation', icon: FileText }
  ];

  useEffect(() => {
    scrollToBottom();
  }, [currentConversation?.messages]);

  const scrollToBottom = () => {
    messagesEndRef?.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async (e) => {
    e?.preventDefault();
    if (!message?.trim() || !currentConversation || isLoading) return;

    const userMessage = message;
    setMessage('');
    setIsLoading(true);

    try {
      await onSendMessage?.(userMessage, currentConversation?.id);
    } catch (error) {
      console.error('Failed to send message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewConversation = async (type = 'general_help') => {
    const title = `New ${type?.replace('_', ' ')} conversation`;
    await onNewConversation?.(title, type, selectedProject);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard?.writeText(text);
  };

  const renderMessage = (msg, index) => {
    const isUser = msg?.role === 'user';
    
    return (
      <div key={index} className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
        <div className={`flex max-w-3xl ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
          {/* Avatar */}
          <div className={`flex-shrink-0 ${isUser ? 'ml-3' : 'mr-3'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              isUser ? 'bg-purple-600 text-white' : 'bg-blue-100 text-blue-600'
            }`}>
              {isUser ? <User className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
            </div>
          </div>
          
          {/* Message Content */}
          <div className={`rounded-lg px-4 py-3 ${
            isUser 
              ? 'bg-purple-600 text-white' :'bg-white border border-gray-200 text-gray-900'
          }`}>
            <div className="prose prose-sm max-w-none">
              {msg?.content?.split('\n')?.map((line, i) => (
                <p key={i} className={`${i === 0 ? 'mt-0' : 'mt-2'} ${isUser ? 'text-white' : 'text-gray-900'}`}>
                  {line}
                </p>
              ))}
            </div>
            
            {/* Message Actions */}
            {!isUser && (
              <div className="flex items-center space-x-2 mt-2 pt-2 border-t border-gray-100">
                <button
                  onClick={() => copyToClipboard(msg?.content)}
                  className="text-gray-500 hover:text-gray-700 p-1 rounded"
                  title="Copy message"
                >
                  <Copy className="h-4 w-4" />
                </button>
                <button
                  className="text-gray-500 hover:text-green-600 p-1 rounded"
                  title="Good response"
                >
                  <ThumbsUp className="h-4 w-4" />
                </button>
                <button
                  className="text-gray-500 hover:text-red-600 p-1 rounded"
                  title="Poor response"
                >
                  <ThumbsDown className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="grid lg:grid-cols-4 gap-6 h-[calc(100vh-200px)]">
      {/* Sidebar - Conversations List */}
      <div className="lg:col-span-1 bg-white rounded-lg shadow-lg p-4 overflow-y-auto">
        <div className="space-y-4">
          {/* New Conversation Buttons */}
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-900 mb-2">Start New Chat</h3>
            {conversationTypes?.map((type) => {
              const Icon = type?.icon;
              return (
                <button
                  key={type?.value}
                  onClick={() => handleNewConversation(type?.value)}
                  className="w-full flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Icon className="h-4 w-4" />
                  <span>{type?.label}</span>
                </button>
              );
            })}
          </div>

          {/* Project Selection */}
          <div className="pt-4 border-t border-gray-200">
            <h3 className="text-sm font-medium text-gray-900 mb-2">Current Project</h3>
            <select
              value={selectedProject || ''}
              onChange={(e) => setSelectedProject(e?.target?.value ? parseInt(e?.target?.value) : null)}
              className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">No project selected</option>
              {mockProjects?.map((project) => (
                <option key={project?.id} value={project?.id}>
                  {project?.name} ({project?.framework})
                </option>
              ))}
            </select>
          </div>

          {/* Recent Conversations */}
          <div className="pt-4 border-t border-gray-200">
            <h3 className="text-sm font-medium text-gray-900 mb-3">Recent Chats</h3>
            <div className="space-y-2">
              {conversations?.slice(0, 5)?.map((conv) => (
                <button
                  key={conv?.id}
                  onClick={() => onSelectConversation?.(conv)}
                  className={`w-full text-left p-3 rounded-lg text-sm transition-colors ${
                    currentConversation?.id === conv?.id
                      ? 'bg-blue-50 border border-blue-200 text-blue-900' :'hover:bg-gray-50 border border-transparent'
                  }`}
                >
                  <div className="font-medium truncate">
                    {conv?.title || 'Untitled Chat'}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    {conv?.total_messages} messages • {new Date(conv.updated_at)?.toLocaleDateString()}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
      {/* Main Chat Interface */}
      <div className="lg:col-span-3 bg-white rounded-lg shadow-lg flex flex-col">
        {currentConversation ? (
          <>
            {/* Chat Header */}
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">
                    {currentConversation?.title || 'AI Assistant Chat'}
                  </h2>
                  <p className="text-sm text-gray-600">
                    {currentConversation?.conversation_type?.replace('_', ' ')} • 
                    {currentConversation?.total_messages} messages
                  </p>
                </div>
                
                {preferences && (
                  <div className="text-xs text-gray-500">
                    <div>Mode: {preferences?.assistance_level || 'balanced'}</div>
                    <div>Learning: {preferences?.learning_enabled ? 'On' : 'Off'}</div>
                  </div>
                )}
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              {currentConversation?.messages?.length > 0 ? (
                currentConversation?.messages?.map((msg, index) => renderMessage(msg, index))
              ) : (
                <div className="text-center py-12">
                  <Bot className="h-12 w-12 text-blue-500 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Hi! I'm your AI assistant
                  </h3>
                  <p className="text-gray-600 mb-4">
                    I'm here to help with your development questions. I learn from your preferences and projects to provide better assistance.
                  </p>
                  
                  {/* Suggested Questions */}
                  <div className="max-w-md mx-auto space-y-2">
                    <p className="text-sm font-medium text-gray-900 mb-3">Try asking me:</p>
                    {[
                      'How can I improve my React component performance?',
                      'What\'s the best way to structure my project?',
                      'Help me debug this error',
                      'Suggest improvements for my code'
                    ]?.map((suggestion, index) => (
                      <button
                        key={index}
                        onClick={() => setMessage(suggestion)}
                        className="block w-full text-left px-3 py-2 text-sm text-gray-700 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                      >
                        "{suggestion}"
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              {isLoading && (
                <div className="flex justify-start mb-4">
                  <div className="flex">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                      <Bot className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="bg-white border border-gray-200 rounded-lg px-4 py-3">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <div className="px-6 py-4 border-t border-gray-200">
              <form onSubmit={handleSendMessage} className="flex space-x-3">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e?.target?.value)}
                  placeholder="Ask me anything about your development work..."
                  disabled={isLoading}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                />
                <button
                  type="submit"
                  disabled={!message?.trim() || isLoading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
              
              <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                <span>
                  Context-aware responses • Learning from your patterns
                </span>
                <span>
                  Press Enter to send
                </span>
              </div>
            </div>
          </>
        ) : (
          /* No Conversation Selected */
          (<div className="flex items-center justify-center h-full">
            <div className="text-center">
              <Bot className="h-16 w-16 text-blue-500 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-900 mb-2">
                Welcome to your AI Assistant
              </h3>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">
                Start a new conversation or select an existing one from the sidebar to begin getting personalized development assistance.
              </p>
              
              <div className="space-y-2">
                {conversationTypes?.slice(0, 2)?.map((type) => {
                  const Icon = type?.icon;
                  return (
                    <button
                      key={type?.value}
                      onClick={() => handleNewConversation(type?.value)}
                      className="inline-flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors mr-2"
                    >
                      <Icon className="h-4 w-4" />
                      <span>{type?.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>)
        )}
      </div>
    </div>
  );
};

export default ConversationInterface;