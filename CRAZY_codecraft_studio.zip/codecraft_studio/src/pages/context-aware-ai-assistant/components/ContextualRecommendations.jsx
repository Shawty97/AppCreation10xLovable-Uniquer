import React, { useState } from 'react';
import { Lightbulb, Shield, Zap, Palette, Code, RefreshCw, CheckCircle, XCircle, ArrowRight, ExternalLink } from 'lucide-react';
import Icon from '../../../components/AppIcon';


const ContextualRecommendations = ({ recommendations = [], preferences, onRefreshRecommendations }) => {
  const [filter, setFilter] = useState('all');
  const [dismissedItems, setDismissedItems] = useState(new Set());

  const categories = [
    { value: 'all', label: 'All Recommendations', icon: Lightbulb },
    { value: 'performance', label: 'Performance', icon: Zap },
    { value: 'security', label: 'Security', icon: Shield },
    { value: 'ui/ux', label: 'UI/UX', icon: Palette },
    { value: 'code_quality', label: 'Code Quality', icon: Code }
  ];

  // Mock enhanced recommendations with more detail
  const enhancedRecommendations = [
    {
      id: 1,
      type: 'security',
      category: 'security',
      title: 'Add User Authentication',
      description: 'Based on your recent projects, consider adding user authentication to improve security and user management.',
      confidence: 0.92,
      impact: 'high',
      effort: 'medium',
      tags: ['authentication', 'security', 'user-management'],
      reasoning: 'I noticed your dashboard components handle user data but lack authentication. This is critical for production apps.',
      actionItems: [
        'Implement login/signup flow',
        'Add JWT token management',
        'Set up protected routes',
        'Create user profile management'
      ],
      estimatedTime: '2-3 days',
      relatedProjects: ['E-commerce Dashboard', 'Admin Panel']
    },
    {
      id: 2,
      type: 'performance',
      category: 'performance',
      title: 'Optimize Component Re-renders',
      description: 'Your dashboard components could benefit from React.memo and useMemo for better performance.',
      confidence: 0.78,
      impact: 'medium',
      effort: 'low',
      tags: ['react', 'performance', 'optimization'],
      reasoning: 'I analyzed your component patterns and found several components that re-render unnecessarily.',
      actionItems: [
        'Wrap expensive components with React.memo',
        'Use useMemo for calculated values',
        'Implement useCallback for event handlers',
        'Split large components into smaller ones'
      ],
      estimatedTime: '1-2 days',
      relatedProjects: ['Dashboard Components']
    },
    {
      id: 3,
      type: 'ui/ux',
      category: 'ui/ux',
      title: 'Dark Mode Implementation',
      description: 'Popular user request: Add dark mode toggle to improve user experience and reduce eye strain.',
      confidence: 0.89,
      impact: 'medium',
      effort: 'low',
      tags: ['ui', 'theme', 'user-experience'],
      reasoning: 'Dark mode is increasingly expected in modern applications and improves accessibility.',
      actionItems: [
        'Set up CSS custom properties for theming',
        'Create theme context provider',
        'Add toggle component',
        'Update all components for theme support'
      ],
      estimatedTime: '1 day',
      relatedProjects: ['All Projects']
    },
    {
      id: 4,
      type: 'code_quality',
      category: 'code_quality',
      title: 'Add Error Boundaries',
      description: 'Implement error boundaries to gracefully handle component crashes and improve user experience.',
      confidence: 0.71,
      impact: 'high',
      effort: 'low',
      tags: ['error-handling', 'reliability', 'react'],
      reasoning: 'Error boundaries prevent entire app crashes when individual components fail.',
      actionItems: [
        'Create reusable ErrorBoundary component',
        'Wrap route components with error boundaries',
        'Add error reporting integration',
        'Create fallback UI components'
      ],
      estimatedTime: '0.5-1 day',
      relatedProjects: ['All React Projects']
    },
    {
      id: 5,
      type: 'performance',
      category: 'performance',
      title: 'Implement Code Splitting',
      description: 'Use dynamic imports and React.lazy to reduce initial bundle size and improve loading times.',
      confidence: 0.83,
      impact: 'high',
      effort: 'medium',
      tags: ['bundling', 'performance', 'loading'],
      reasoning: 'Your bundle size has grown significantly. Code splitting will improve initial load performance.',
      actionItems: [
        'Identify heavy components and routes',
        'Implement React.lazy for route components',
        'Add loading fallbacks',
        'Configure bundle analyzer'
      ],
      estimatedTime: '2 days',
      relatedProjects: ['Large Applications']
    }
  ];

  // Combine provided recommendations with enhanced ones
  const allRecommendations = [...enhancedRecommendations, ...recommendations];

  const filteredRecommendations = allRecommendations?.filter(rec => {
    if (dismissedItems?.has(rec?.id)) return false;
    if (filter === 'all') return true;
    return rec?.category === filter;
  });

  const handleDismiss = (id) => {
    setDismissedItems(prev => new Set([...prev, id]));
  };

  const getConfidenceColor = (confidence) => {
    if (confidence >= 0.8) return 'text-green-600 bg-green-100';
    if (confidence >= 0.6) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getImpactColor = (impact) => {
    switch (impact) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getEffortColor = (effort) => {
    switch (effort) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'performance': return Zap;
      case 'security': return Shield;
      case 'ui/ux': return Palette;
      case 'code_quality': return Code;
      default: return Lightbulb;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Contextual Recommendations</h2>
          <p className="text-gray-600 mt-1">
            AI-powered suggestions based on your projects and coding patterns
          </p>
        </div>
        
        <button
          onClick={onRefreshRecommendations}
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </button>
      </div>
      {/* Filters */}
      <div className="flex space-x-2 overflow-x-auto">
        {categories?.map((category) => {
          const Icon = category?.icon;
          return (
            <button
              key={category?.value}
              onClick={() => setFilter(category?.value)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                filter === category?.value
                  ? 'bg-blue-100 text-blue-700 border border-blue-200' :'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span className="text-sm font-medium">{category?.label}</span>
            </button>
          );
        })}
      </div>
      {/* Recommendations Grid */}
      <div className="grid gap-6">
        {filteredRecommendations?.map((recommendation) => {
          const Icon = getCategoryIcon(recommendation?.category);
          
          return (
            <div key={recommendation?.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:border-blue-200 hover:shadow-md transition-all">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Icon className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      {recommendation?.title}
                    </h3>
                    <p className="text-gray-600 text-sm">
                      {recommendation?.description}
                    </p>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleDismiss(recommendation?.id)}
                    className="p-1 text-gray-400 hover:text-gray-600"
                    title="Dismiss"
                  >
                    <XCircle className="h-5 w-5" />
                  </button>
                </div>
              </div>
              {/* Metrics */}
              <div className="flex items-center space-x-4 mb-4">
                <div className="flex items-center space-x-1">
                  <span className="text-xs text-gray-500">Confidence:</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getConfidenceColor(recommendation?.confidence)}`}>
                    {Math.round(recommendation?.confidence * 100)}%
                  </span>
                </div>
                
                {recommendation?.impact && (
                  <div className="flex items-center space-x-1">
                    <span className="text-xs text-gray-500">Impact:</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getImpactColor(recommendation?.impact)}`}>
                      {recommendation?.impact}
                    </span>
                  </div>
                )}
                
                {recommendation?.effort && (
                  <div className="flex items-center space-x-1">
                    <span className="text-xs text-gray-500">Effort:</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getEffortColor(recommendation?.effort)}`}>
                      {recommendation?.effort}
                    </span>
                  </div>
                )}
                
                {recommendation?.estimatedTime && (
                  <div className="flex items-center space-x-1">
                    <span className="text-xs text-gray-500">Time:</span>
                    <span className="text-xs font-medium text-gray-700">
                      {recommendation?.estimatedTime}
                    </span>
                  </div>
                )}
              </div>
              {/* Reasoning */}
              {recommendation?.reasoning && (
                <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                  <h4 className="text-sm font-medium text-gray-900 mb-1">Why this matters:</h4>
                  <p className="text-sm text-gray-700">{recommendation?.reasoning}</p>
                </div>
              )}
              {/* Action Items */}
              {recommendation?.actionItems && (
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Action Items:</h4>
                  <ul className="space-y-1">
                    {recommendation?.actionItems?.map((item, index) => (
                      <li key={index} className="flex items-start space-x-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {/* Tags */}
              {recommendation?.tags && (
                <div className="mb-4">
                  <div className="flex flex-wrap gap-2">
                    {recommendation?.tags?.map((tag, index) => (
                      <span key={index} className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {/* Related Projects */}
              {recommendation?.relatedProjects && (
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Affects Projects:</h4>
                  <div className="flex flex-wrap gap-2">
                    {recommendation?.relatedProjects?.map((project, index) => (
                      <span key={index} className="px-3 py-1 bg-blue-50 text-blue-700 rounded-lg text-xs font-medium">
                        {project}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {/* Actions */}
              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <div className="text-xs text-gray-500">
                  AI recommendation • Generated based on your patterns
                </div>
                
                <div className="flex space-x-3">
                  <button className="inline-flex items-center text-sm text-gray-600 hover:text-gray-800">
                    <ExternalLink className="h-4 w-4 mr-1" />
                    Learn More
                  </button>
                  
                  <button className="inline-flex items-center px-3 py-1 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 transition-colors">
                    <span>Start Implementation</span>
                    <ArrowRight className="h-4 w-4 ml-1" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {filteredRecommendations?.length === 0 && (
          <div className="text-center py-12">
            <Lightbulb className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {dismissedItems?.size > 0 ? 'All recommendations dismissed' : 'No recommendations yet'}
            </h3>
            <p className="text-gray-600 mb-4">
              {dismissedItems?.size > 0 
                ? 'Check back later for new suggestions based on your activity.'
                : 'Keep working on your projects, and I\'ll learn your patterns to provide better recommendations.'
              }
            </p>
            <button
              onClick={onRefreshRecommendations}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Check for New Recommendations
            </button>
          </div>
        )}
      </div>
      {/* Learning Status */}
      {preferences && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="font-medium text-blue-800 mb-2">💡 How Recommendations Work</h4>
          <div className="text-sm text-blue-700 space-y-1">
            <p>• I analyze your coding patterns, project structures, and preferences</p>
            <p>• Recommendations improve as I learn more about your development style</p>
            <p>• Learning is currently <strong>{preferences?.learning_enabled ? 'enabled' : 'disabled'}</strong></p>
            <p>• Assistance level: <strong>{preferences?.assistance_level || 'balanced'}</strong></p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ContextualRecommendations;