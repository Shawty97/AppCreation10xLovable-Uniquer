import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import { cn } from '../../../utils/cn';

const StorageAnalytics = ({ projects }) => {
  // Calculate storage statistics
  const totalSize = projects?.reduce((acc, project) => {
    const size = parseFloat(project?.size?.replace('MB', '')) || 0;
    return acc + size;
  }, 0);

  const totalFiles = projects?.reduce((acc, project) => acc + (project?.fileCount || 0), 0);

  const storageLimit = 1000; // MB
  const usedPercentage = (totalSize / storageLimit) * 100;

  const typeBreakdown = projects?.reduce((acc, project) => {
    const size = parseFloat(project?.size?.replace('MB', '')) || 0;
    acc[project?.type] = (acc?.[project?.type] || 0) + size;
    return acc;
  }, {});

  const getTypeColor = (type) => {
    switch (type) {
      case 'web': return 'bg-blue-500';
      case 'mobile': return 'bg-green-500';
      case 'desktop': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'web': return 'Globe';
      case 'mobile': return 'Smartphone';
      case 'desktop': return 'Monitor';
      default: return 'FileText';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Storage Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-card rounded-xl border border-border p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center">
              <Icon name="HardDrive" size={20} className="text-primary" />
            </div>
            <div>
              <h3 className="font-medium text-foreground">Storage Used</h3>
              <p className="text-sm text-muted-foreground">
                {totalSize?.toFixed(1)} MB of {storageLimit} MB
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-lg font-semibold text-foreground">
              {usedPercentage?.toFixed(1)}%
            </div>
            <div className="text-xs text-muted-foreground">Used</div>
          </div>
        </div>

        {/* Storage Bar */}
        <div className="w-full bg-muted rounded-full h-2 mb-3">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${usedPercentage}%` }}
            className={cn(
              "h-2 rounded-full transition-all duration-500",
              usedPercentage > 90 ? 'bg-destructive' :
              usedPercentage > 75 ? 'bg-warning' : 'bg-success'
            )}
          />
        </div>

        <div className="text-xs text-muted-foreground">
          {(storageLimit - totalSize)?.toFixed(1)} MB remaining
        </div>
      </motion.div>
      {/* File Statistics */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-card rounded-xl border border-border p-6"
      >
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-accent/20 rounded-xl flex items-center justify-center">
            <Icon name="Files" size={20} className="text-accent" />
          </div>
          <div>
            <h3 className="font-medium text-foreground">Total Files</h3>
            <p className="text-sm text-muted-foreground">Across all projects</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="text-2xl font-bold text-foreground">
            {totalFiles?.toLocaleString()}
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <div className="text-sm font-medium text-foreground">
                {projects?.length}
              </div>
              <div className="text-xs text-muted-foreground">Projects</div>
            </div>
            <div>
              <div className="text-sm font-medium text-foreground">
                {Math.round(totalFiles / projects?.length) || 0}
              </div>
              <div className="text-xs text-muted-foreground">Avg/Project</div>
            </div>
          </div>
        </div>
      </motion.div>
      {/* Project Type Breakdown */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-card rounded-xl border border-border p-6"
      >
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-success/20 rounded-xl flex items-center justify-center">
            <Icon name="PieChart" size={20} className="text-success" />
          </div>
          <div>
            <h3 className="font-medium text-foreground">By Type</h3>
            <p className="text-sm text-muted-foreground">Storage breakdown</p>
          </div>
        </div>

        <div className="space-y-3">
          {Object?.entries(typeBreakdown)?.map(([type, size]) => {
            const percentage = (size / totalSize) * 100;
            return (
              <div key={type} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className={cn(
                    "w-3 h-3 rounded-full",
                    getTypeColor(type)
                  )} />
                  <div className="flex items-center space-x-1">
                    <Icon name={getTypeIcon(type)} size={14} className="text-muted-foreground" />
                    <span className="text-sm capitalize text-foreground">{type}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-foreground">
                    {size?.toFixed(1)} MB
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {percentage?.toFixed(1)}%
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
};

export default StorageAnalytics;