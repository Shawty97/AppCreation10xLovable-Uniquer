import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';
import { cn } from '../../../utils/cn';

const FileExplorer = ({ projects, activeProject, onProjectSelect }) => {
  const [expandedFolders, setExpandedFolders] = useState(['root']);
  const [searchQuery, setSearchQuery] = useState('');

  // Mock file structure
  const fileStructure = {
    root: {
      id: 'root',
      name: 'Projects',
      type: 'folder',
      children: projects?.map(project => ({
        id: project?.id,
        name: project?.name,
        type: 'project',
        status: project?.status,
        children: [
          {
            id: `${project?.id}-src`,
            name: 'src',
            type: 'folder',
            children: [
              { id: `${project?.id}-components`, name: 'components', type: 'folder', children: [] },
              { id: `${project?.id}-pages`, name: 'pages', type: 'folder', children: [] },
              { id: `${project?.id}-assets`, name: 'assets', type: 'folder', children: [] },
              { id: `${project?.id}-utils`, name: 'utils', type: 'folder', children: [] }
            ]
          },
          {
            id: `${project?.id}-public`,
            name: 'public',
            type: 'folder',
            children: [
              { id: `${project?.id}-images`, name: 'images', type: 'folder', children: [] },
              { id: `${project?.id}-icons`, name: 'icons', type: 'folder', children: [] }
            ]
          },
          { id: `${project?.id}-package`, name: 'package.json', type: 'file' },
          { id: `${project?.id}-readme`, name: 'README.md', type: 'file' },
          { id: `${project?.id}-config`, name: 'vite.config.js', type: 'file' }
        ]
      }))
    }
  };

  const toggleFolder = (folderId) => {
    setExpandedFolders(prev => 
      prev?.includes(folderId)
        ? prev?.filter(id => id !== folderId)
        : [...prev, folderId]
    );
  };

  const getItemIcon = (item) => {
    switch (item?.type) {
      case 'project':
        switch (projects?.find(p => p?.id === item?.id)?.type) {
          case 'web': return 'Globe';
          case 'mobile': return 'Smartphone';
          case 'desktop': return 'Monitor';
          default: return 'FileText';
        }
      case 'folder': return 'Folder';
      case 'file':
        if (item?.name?.endsWith('.js') || item?.name?.endsWith('.jsx')) return 'FileType';
        if (item?.name?.endsWith('.css')) return 'Palette';
        if (item?.name?.endsWith('.json')) return 'Braces';
        if (item?.name?.endsWith('.md')) return 'FileText';
        return 'File';
      default: return 'File';
    }
  };

  const getItemColor = (item) => {
    if (item?.type === 'project') {
      const project = projects?.find(p => p?.id === item?.id);
      switch (project?.status) {
        case 'active': return 'text-success';
        case 'building': return 'text-warning';
        case 'draft': return 'text-muted-foreground';
        case 'archived': return 'text-secondary';
        default: return 'text-primary';
      }
    }
    return item?.type === 'folder' ? 'text-primary' : 'text-muted-foreground';
  };

  const renderTreeItem = (item, level = 0) => {
    const isExpanded = expandedFolders?.includes(item?.id);
    const hasChildren = item?.children && item?.children?.length > 0;
    const isActive = activeProject?.id === item?.id;

    return (
      <div key={item?.id}>
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          className={cn(
            "flex items-center space-x-2 px-3 py-2 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors",
            isActive && "bg-primary/10 text-primary",
            level > 0 && "ml-4"
          )}
          style={{ paddingLeft: `${level * 12 + 12}px` }}
          onClick={() => {
            if (item?.type === 'project') {
              onProjectSelect?.(projects?.find(p => p?.id === item?.id));
            }
            if (hasChildren) {
              toggleFolder(item?.id);
            }
          }}
        >
          {hasChildren && (
            <motion.div
              animate={{ rotate: isExpanded ? 90 : 0 }}
              transition={{ duration: 0.2 }}
            >
              <Icon name="ChevronRight" size={14} className="text-muted-foreground" />
            </motion.div>
          )}
          
          <Icon 
            name={getItemIcon(item)} 
            size={16} 
            className={getItemColor(item)} 
          />
          
          <span className="text-sm text-foreground truncate">{item?.name}</span>

          {item?.type === 'project' && (
            <div className="flex items-center space-x-1 ml-auto">
              {projects?.find(p => p?.id === item?.id)?.collaborators?.length > 0 && (
                <div className="w-1.5 h-1.5 bg-success rounded-full" />
              )}
            </div>
          )}
        </motion.div>
        <AnimatePresence>
          {isExpanded && hasChildren && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
            >
              {item?.children?.map(child => renderTreeItem(child, level + 1))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  const filteredStructure = searchQuery 
    ? {
        ...fileStructure?.root,
        children: fileStructure?.root?.children?.filter(item =>
          item?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase())
        )
      }
    : fileStructure?.root;

  return (
    <div className="bg-card rounded-xl border border-border h-full overflow-hidden flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-medium text-foreground">File Explorer</h3>
          <Button variant="ghost" size="sm">
            <Icon name="MoreHorizontal" size={16} />
          </Button>
        </div>

        {/* Search */}
        <Input
          type="text"
          placeholder="Search files..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e?.target?.value)}
          className="w-full"
        />
      </div>
      {/* Tree View */}
      <div className="flex-1 overflow-y-auto p-2">
        <div className="space-y-1">
          {filteredStructure?.children?.map(item => renderTreeItem(item))}
        </div>
      </div>
      {/* Footer Actions */}
      <div className="p-4 border-t border-border">
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" size="sm" fullWidth>
            <Icon name="FolderPlus" size={14} className="mr-2" />
            New Folder
          </Button>
          <Button variant="outline" size="sm" fullWidth>
            <Icon name="FilePlus" size={14} className="mr-2" />
            New File
          </Button>
        </div>
      </div>
    </div>
  );
};

export default FileExplorer;