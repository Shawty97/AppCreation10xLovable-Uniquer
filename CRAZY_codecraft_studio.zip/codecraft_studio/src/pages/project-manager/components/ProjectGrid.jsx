import React from 'react';
import { motion } from 'framer-motion';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';
import { cn } from '../../../utils/cn';

const ProjectGrid = ({ 
  projects, 
  viewMode, 
  selectedItems, 
  onSelectionChange, 
  onProjectAction, 
  loading 
}) => {
  const handleItemSelect = (projectId, isSelected) => {
    if (isSelected) {
      onSelectionChange?.([...selectedItems, projectId]);
    } else {
      onSelectionChange?.(selectedItems?.filter(id => id !== projectId));
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active': return 'Play';
      case 'building': return 'Settings';
      case 'draft': return 'Edit';
      case 'archived': return 'Archive';
      default: return 'FileText';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'text-success';
      case 'building': return 'text-warning';
      case 'draft': return 'text-muted-foreground';
      case 'archived': return 'text-secondary';
      default: return 'text-muted-foreground';
    }
  };

  const getBuildStatusColor = (buildStatus) => {
    switch (buildStatus) {
      case 'success': return 'bg-success';
      case 'failed': return 'bg-destructive';
      case 'building': return 'bg-warning';
      case 'pending': return 'bg-muted-foreground';
      default: return 'bg-muted-foreground';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'web': return 'Globe';
      case 'mobile': return 'Smartphone';
      case 'desktop': return 'Monitor';
      default: return 'FileText';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return 'Today';
    if (diffDays === 2) return 'Yesterday';
    if (diffDays <= 7) return `${diffDays - 1} days ago`;
    return date?.toLocaleDateString();
  };

  if (projects?.length === 0) {
    return (
      <div className="bg-card rounded-xl border border-border p-12 text-center">
        <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Icon name="FolderOpen" size={32} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium text-foreground mb-2">No Projects Found</h3>
        <p className="text-muted-foreground mb-6">
          Create your first project or adjust your search filters
        </p>
        <Button>
          <Icon name="Plus" size={16} className="mr-2" />
          Create Project
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {projects?.map((project, index) => (
            <motion.div
              key={project?.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={cn(
                "bg-card rounded-xl border border-border p-6 hover-lift cursor-pointer transition-all",
                selectedItems?.includes(project?.id) && "ring-2 ring-primary bg-primary/5"
              )}
              onClick={() => handleItemSelect(
                project?.id, 
                !selectedItems?.includes(project?.id)
              )}
            >
              {/* Project Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center">
                    <Icon 
                      name={getTypeIcon(project?.type)} 
                      size={24} 
                      className="text-primary" 
                    />
                  </div>
                  <div>
                    <h3 className="font-medium text-foreground mb-1">{project?.name}</h3>
                    <div className="flex items-center space-x-2">
                      <Icon 
                        name={getStatusIcon(project?.status)} 
                        size={14} 
                        className={getStatusColor(project?.status)} 
                      />
                      <span className="text-sm text-muted-foreground capitalize">
                        {project?.status}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Build Status */}
                <div className="flex items-center space-x-2">
                  <div className={cn(
                    "w-2 h-2 rounded-full",
                    getBuildStatusColor(project?.buildStatus)
                  )} />
                  <span className="text-xs text-muted-foreground capitalize">
                    {project?.buildStatus}
                  </span>
                </div>
              </div>

              {/* Project Preview */}
              <div className="w-full h-32 bg-muted rounded-lg mb-4 flex items-center justify-center">
                <Icon name="ImageIcon" size={32} className="text-muted-foreground" />
              </div>

              {/* Project Description */}
              <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                {project?.description}
              </p>

              {/* Project Stats */}
              <div className="grid grid-cols-3 gap-4 mb-4 text-center">
                <div>
                  <div className="text-sm font-medium text-foreground">
                    {project?.fileCount}
                  </div>
                  <div className="text-xs text-muted-foreground">Files</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-foreground">
                    {project?.size}
                  </div>
                  <div className="text-xs text-muted-foreground">Size</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-foreground">
                    {project?.collaborators?.length}
                  </div>
                  <div className="text-xs text-muted-foreground">Team</div>
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-4 border-t border-border">
                <span className="text-xs text-muted-foreground">
                  {formatDate(project?.lastModified)}
                </span>
                
                <div className="flex items-center space-x-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e?.stopPropagation();
                      onProjectAction?.('duplicate', [project?.id]);
                    }}
                  >
                    <Icon name="Copy" size={14} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e?.stopPropagation();
                      // Open project actions menu
                    }}
                  >
                    <Icon name="MoreHorizontal" size={14} />
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          {/* List Header */}
          <div className="grid grid-cols-12 gap-4 p-4 border-b border-border bg-muted/30 text-sm font-medium text-muted-foreground">
            <div className="col-span-1">
              <input
                type="checkbox"
                checked={selectedItems?.length === projects?.length}
                onChange={(e) => {
                  if (e?.target?.checked) {
                    onSelectionChange?.(projects?.map(p => p?.id));
                  } else {
                    onSelectionChange?.([]);
                  }
                }}
                className="rounded border-border"
              />
            </div>
            <div className="col-span-4">Name</div>
            <div className="col-span-2">Type</div>
            <div className="col-span-2">Status</div>
            <div className="col-span-2">Modified</div>
            <div className="col-span-1">Actions</div>
          </div>

          {/* List Items */}
          {projects?.map((project, index) => (
            <motion.div
              key={project?.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className={cn(
                "grid grid-cols-12 gap-4 p-4 border-b border-border last:border-b-0 hover:bg-muted/30 transition-colors",
                selectedItems?.includes(project?.id) && "bg-primary/5"
              )}
            >
              <div className="col-span-1 flex items-center">
                <input
                  type="checkbox"
                  checked={selectedItems?.includes(project?.id)}
                  onChange={(e) => handleItemSelect(project?.id, e?.target?.checked)}
                  className="rounded border-border"
                />
              </div>

              <div className="col-span-4 flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center">
                  <Icon 
                    name={getTypeIcon(project?.type)} 
                    size={16} 
                    className="text-primary" 
                  />
                </div>
                <div>
                  <div className="font-medium text-foreground">{project?.name}</div>
                  <div className="text-sm text-muted-foreground">
                    {project?.fileCount} files • {project?.size}
                  </div>
                </div>
              </div>

              <div className="col-span-2 flex items-center">
                <span className="capitalize text-sm text-muted-foreground">
                  {project?.type}
                </span>
              </div>

              <div className="col-span-2 flex items-center space-x-2">
                <Icon 
                  name={getStatusIcon(project?.status)} 
                  size={14} 
                  className={getStatusColor(project?.status)} 
                />
                <span className="text-sm capitalize">{project?.status}</span>
                <div className={cn(
                  "w-2 h-2 rounded-full ml-2",
                  getBuildStatusColor(project?.buildStatus)
                )} />
              </div>

              <div className="col-span-2 flex items-center">
                <span className="text-sm text-muted-foreground">
                  {formatDate(project?.lastModified)}
                </span>
              </div>

              <div className="col-span-1 flex items-center space-x-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onProjectAction?.('duplicate', [project?.id])}
                >
                  <Icon name="Copy" size={14} />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                >
                  <Icon name="MoreHorizontal" size={14} />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ProjectGrid;