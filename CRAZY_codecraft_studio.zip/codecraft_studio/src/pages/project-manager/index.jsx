import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import { cn } from '../../utils/cn';
import Icon from '../../components/AppIcon';
import ProjectGrid from './components/ProjectGrid';
import FileExplorer from './components/FileExplorer';
import StorageAnalytics from './components/StorageAnalytics';
import ProjectActions from './components/ProjectActions';
import CollaborationPanel from './components/CollaborationPanel';
import VersionControl from './components/VersionControl';
import TemplateManager from './components/TemplateManager';

const ProjectManager = () => {
  const [viewMode, setViewMode] = useState('grid'); // grid, list, explorer
  const [activeProject, setActiveProject] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('modified'); // name, modified, size, type
  const [filterType, setFilterType] = useState('all'); // all, web, mobile, desktop
  const [showFileExplorer, setShowFileExplorer] = useState(false);
  const [projects, setProjects] = useState([]);
  const [selectedItems, setSelectedItems] = useState([]);
  const [loading, setLoading] = useState(false);

  // Mock project data
  useEffect(() => {
    const mockProjects = [
      {
        id: '1',
        name: 'E-commerce Dashboard',
        type: 'web',
        status: 'active',
        lastModified: '2025-01-03T10:30:00Z',
        size: '45.2MB',
        fileCount: 127,
        thumbnail: null,
        collaborators: ['user1', 'user2'],
        buildStatus: 'success',
        description: 'Modern dashboard for online store management'
      },
      {
        id: '2',
        name: 'Mobile Banking App',
        type: 'mobile',
        status: 'building',
        lastModified: '2025-01-03T08:15:00Z',
        size: '32.8MB',
        fileCount: 89,
        thumbnail: null,
        collaborators: ['user3'],
        buildStatus: 'building',
        description: 'Secure mobile banking application'
      },
      {
        id: '3',
        name: 'Portfolio Website',
        type: 'web',
        status: 'draft',
        lastModified: '2025-01-02T16:45:00Z',
        size: '12.4MB',
        fileCount: 34,
        thumbnail: null,
        collaborators: [],
        buildStatus: 'pending',
        description: 'Personal portfolio with blog functionality'
      },
      {
        id: '4',
        name: 'Desktop CRM Tool',
        type: 'desktop',
        status: 'archived',
        lastModified: '2025-01-01T14:20:00Z',
        size: '78.9MB',
        fileCount: 203,
        thumbnail: null,
        collaborators: ['user1', 'user2', 'user4'],
        buildStatus: 'failed',
        description: 'Customer relationship management desktop application'
      }
    ];
    setProjects(mockProjects);
  }, []);

  // Filter and sort projects
  const filteredProjects = projects
    ?.filter(project => {
      const matchesSearch = project?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
                          project?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase());
      const matchesFilter = filterType === 'all' || project?.type === filterType;
      return matchesSearch && matchesFilter;
    })
    ?.sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a?.name?.localeCompare(b?.name);
        case 'modified':
          return new Date(b?.lastModified) - new Date(a?.lastModified);
        case 'size':
          const aSize = parseFloat(a?.size?.replace('MB', ''));
          const bSize = parseFloat(b?.size?.replace('MB', ''));
          return bSize - aSize;
        default:
          return 0;
      }
    });

  const handleProjectAction = async (action, projectIds) => {
    setLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      switch (action) {
        case 'delete':
          setProjects(prev => prev?.filter(p => !projectIds?.includes(p?.id)));
          break;
        case 'duplicate':
          const projectsToDuplicate = projects?.filter(p => projectIds?.includes(p?.id));
          const duplicated = projectsToDuplicate?.map(p => ({
            ...p,
            id: Date.now() + Math.random(),
            name: `${p?.name} (Copy)`,
            lastModified: new Date()?.toISOString()
          }));
          setProjects(prev => [...prev, ...duplicated]);
          break;
        case 'archive':
          setProjects(prev => prev?.map(p => 
            projectIds?.includes(p?.id) ? { ...p, status: 'archived' } : p
          ));
          break;
        default:
          break;
      }
      
      setSelectedItems([]);
    } catch (error) {
      console.error('Project action failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBulkAction = (action) => {
    if (selectedItems?.length > 0) {
      handleProjectAction(action, selectedItems);
    }
  };

  const formatFileSize = (size) => {
    if (!size) return '0 MB';
    return size;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return 'Today';
    if (diffDays === 2) return 'Yesterday';
    if (diffDays <= 7) return `${diffDays - 1} days ago`;
    return date?.toLocaleDateString();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Icon name="Folder" size={20} className="text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-semibold text-foreground">Project Manager</h1>
                  <p className="text-sm text-muted-foreground">
                    {filteredProjects?.length} project{filteredProjects?.length !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              {/* Quick Actions */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFileExplorer(!showFileExplorer)}
              >
                <Icon name="FolderTree" size={16} className="mr-2" />
                Explorer
              </Button>

              <Button size="sm">
                <Icon name="Plus" size={16} className="mr-2" />
                New Project
              </Button>
            </div>
          </div>
        </div>
      </div>
      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar - File Explorer */}
          <AnimatePresence>
            {showFileExplorer && (
              <motion.div
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: 320, opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                className="flex-shrink-0 overflow-hidden"
              >
                <FileExplorer
                  projects={projects}
                  activeProject={activeProject}
                  onProjectSelect={setActiveProject}
                />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Main Panel */}
          <div className="flex-1 min-w-0 space-y-6">
            {/* Filters and Controls */}
            <div className="bg-card rounded-xl border border-border p-4">
              <div className="flex flex-col sm:flex-row gap-4">
                {/* Search */}
                <div className="flex-1">
                  <Input
                    type="text"
                    placeholder="Search projects..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e?.target?.value)}
                    className="w-full"
                  />
                </div>

                {/* Filter Controls */}
                <div className="flex items-center space-x-3">
                  {/* Type Filter */}
                  <select
                    value={filterType}
                    onChange={(e) => setFilterType(e?.target?.value)}
                    className="px-3 py-2 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="all">All Types</option>
                    <option value="web">Web Apps</option>
                    <option value="mobile">Mobile Apps</option>
                    <option value="desktop">Desktop Apps</option>
                  </select>

                  {/* Sort By */}
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e?.target?.value)}
                    className="px-3 py-2 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="modified">Last Modified</option>
                    <option value="name">Name</option>
                    <option value="size">Size</option>
                  </select>

                  {/* View Mode */}
                  <div className="flex items-center bg-muted rounded-lg p-1">
                    <button
                      onClick={() => setViewMode('grid')}
                      className={cn(
                        'p-2 rounded-md transition-colors',
                        viewMode === 'grid' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
                      )}
                    >
                      <Icon name="Grid3X3" size={16} />
                    </button>
                    <button
                      onClick={() => setViewMode('list')}
                      className={cn(
                        'p-2 rounded-md transition-colors',
                        viewMode === 'list' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
                      )}
                    >
                      <Icon name="List" size={16} />
                    </button>
                  </div>
                </div>
              </div>

              {/* Bulk Actions */}
              {selectedItems?.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="mt-4 pt-4 border-t border-border"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      {selectedItems?.length} project{selectedItems?.length !== 1 ? 's' : ''} selected
                    </span>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleBulkAction('duplicate')}
                        disabled={loading}
                      >
                        <Icon name="Copy" size={14} className="mr-2" />
                        Duplicate
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleBulkAction('archive')}
                        disabled={loading}
                      >
                        <Icon name="Archive" size={14} className="mr-2" />
                        Archive
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleBulkAction('delete')}
                        disabled={loading}
                      >
                        <Icon name="Trash2" size={14} className="mr-2" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Storage Analytics */}
            <StorageAnalytics projects={projects} />

            {/* Project Grid/List */}
            <ProjectGrid
              projects={filteredProjects}
              viewMode={viewMode}
              selectedItems={selectedItems}
              onSelectionChange={setSelectedItems}
              onProjectAction={handleProjectAction}
              loading={loading}
            />

            {/* Version Control Panel */}
            {activeProject && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
              >
                <VersionControl project={activeProject} />
              </motion.div>
            )}
          </div>

          {/* Right Sidebar - Tools and Templates */}
          <div className="w-80 flex-shrink-0 space-y-6">
            {/* Project Actions */}
            <ProjectActions
              selectedProject={activeProject}
              onAction={handleProjectAction}
            />

            {/* Collaboration Panel */}
            <CollaborationPanel
              project={activeProject}
              projects={projects}
            />

            {/* Template Manager */}
            <TemplateManager />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectManager;