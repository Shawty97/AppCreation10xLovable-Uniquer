import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import PlatformPreview from './components/PlatformPreview';
import NativeFeatures from './components/NativeFeatures';
import MobileTesting from './components/MobileTesting';
import AppStoreDeployment from './components/AppStoreDeployment';
import CrossPlatformSync from './components/CrossPlatformSync';
import Button from '../../components/ui/Button';

const CrossPlatformMobileStudio = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('preview');
  const [selectedPlatform, setSelectedPlatform] = useState('ios');
  const [projectData, setProjectData] = useState({
    name: 'My Mobile App',
    description: 'Cross-platform mobile application',
    platforms: ['ios', 'android'],
    nativeFeatures: [],
    testResults: {},
    deploymentStatus: {}
  });

  const tabs = [
    { id: 'preview', label: 'Platform Preview', icon: 'Smartphone' },
    { id: 'features', label: 'Native Features', icon: 'Cpu' },
    { id: 'testing', label: 'Mobile Testing', icon: 'TestTube' },
    { id: 'sync', label: 'Cross-Platform Sync', icon: 'RefreshCw' },
    { id: 'deployment', label: 'App Store Deployment', icon: 'Store' }
  ];

  const platforms = [
    { id: 'ios', name: 'iOS', icon: '📱', color: 'blue' },
    { id: 'android', name: 'Android', icon: '🤖', color: 'green' }
  ];

  const handleProjectUpdate = (updates) => {
    setProjectData(prev => ({ ...prev, ...updates }));
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center p-8 bg-white rounded-lg shadow-md">
          <div className="text-gray-400 mb-4">
            <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Authentication Required</h3>
          <p className="text-gray-600 mb-4">Please sign in to access the Cross-Platform Mobile Studio</p>
          <Button variant="primary" onClick={() => window.location.href = '/authentication-portal'}>
            Sign In
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Cross-Platform Mobile Studio</h1>
                <p className="mt-2 text-gray-600">
                  Advanced mobile app development with native features and unified deployment
                </p>
              </div>
              
              {/* Platform Selector */}
              <div className="flex items-center space-x-2">
                <span className="text-sm font-medium text-gray-700">Platform:</span>
                {platforms?.map((platform) => (
                  <button
                    key={platform?.id}
                    onClick={() => setSelectedPlatform(platform?.id)}
                    className={`
                      flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors
                      ${selectedPlatform === platform?.id
                        ? `bg-${platform?.color}-100 text-${platform?.color}-700 border-${platform?.color}-300`
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }
                    `}
                  >
                    <span className="text-lg">{platform?.icon}</span>
                    <span>{platform?.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8" aria-label="Tabs">
            {tabs?.map((tab) => (
              <button
                key={tab?.id}
                onClick={() => setActiveTab(tab?.id)}
                className={`
                  whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm flex items-center space-x-2
                  ${activeTab === tab?.id
                    ? 'border-blue-500 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }
                `}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  {tab?.icon === 'Smartphone' && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a1 1 0 001-1V4a1 1 0 00-1-1H8a1 1 0 00-1 1v16a1 1 0 001 1z" />}
                  {tab?.icon === 'Cpu' && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />}
                  {tab?.icon === 'TestTube' && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />}
                  {tab?.icon === 'RefreshCw' && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />}
                  {tab?.icon === 'Store' && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />}
                </svg>
                <span>{tab?.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>
      {/* Tab Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'preview' && (
          <PlatformPreview
            platform={selectedPlatform}
            projectData={projectData}
            onProjectUpdate={handleProjectUpdate}
          />
        )}
        
        {activeTab === 'features' && (
          <NativeFeatures
            platform={selectedPlatform}
            projectData={projectData}
            onProjectUpdate={handleProjectUpdate}
          />
        )}
        
        {activeTab === 'testing' && (
          <MobileTesting
            platform={selectedPlatform}
            projectData={projectData}
            onProjectUpdate={handleProjectUpdate}
          />
        )}
        
        {activeTab === 'sync' && (
          <CrossPlatformSync
            projectData={projectData}
            onProjectUpdate={handleProjectUpdate}
          />
        )}
        
        {activeTab === 'deployment' && (
          <AppStoreDeployment
            platform={selectedPlatform}
            projectData={projectData}
            onProjectUpdate={handleProjectUpdate}
          />
        )}
      </div>
      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6">
        <Button
          variant="primary"
          className="rounded-full w-14 h-14 shadow-lg"
          onClick={() => {
            // In real implementation, this would build the app
            alert('Building cross-platform app... (This is a demo)');
          }}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z" />
          </svg>
        </Button>
      </div>
    </div>
  );
};

export default CrossPlatformMobileStudio;