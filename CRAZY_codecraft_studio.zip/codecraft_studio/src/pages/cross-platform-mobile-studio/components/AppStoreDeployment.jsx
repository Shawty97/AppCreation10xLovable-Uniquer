import React, { useEffect } from 'react';

const AppStoreDeployment = () => {
  React.useEffect(() => {
    // eslint-disable-next-line no-console
    console.warn('Placeholder: AppStoreDeployment is not implemented yet.');
  }, []);
  return (
    <>
  { /*AppStoreDeployment */} 
 </>
  );
};

export default AppStoreDeployment;
