import React, { useState } from 'react';
import Button from '../../../components/ui/Button';


const NativeFeatures = ({ platform, projectData, onProjectUpdate }) => {
  const [selectedCategory, setSelectedCategory] = useState('authentication');
  const [enabledFeatures, setEnabledFeatures] = useState([]);

  const featureCategories = {
    authentication: {
      name: 'Authentication',
      icon: '🔐',
      features: {
        ios: [
          { id: 'face-id', name: 'Face ID', description: 'Biometric authentication using Face ID', code: 'import LocalAuthentication' },
          { id: 'touch-id', name: 'Touch ID', description: 'Fingerprint authentication', code: 'LAContext().evaluatePolicy' },
          { id: 'keychain', name: 'Keychain Services', description: 'Secure credential storage', code: 'SecItemAdd, SecItemCopyMatching' }
        ],
        android: [
          { id: 'biometric', name: 'Biometric Auth', description: 'Fingerprint and face authentication', code: 'BiometricPrompt.authenticate()' },
          { id: 'keystore', name: 'Android Keystore', description: 'Hardware-backed key storage', code: 'KeyStore.getInstance("AndroidKeyStore")' },
          { id: 'smart-lock', name: 'Smart Lock', description: 'Google Smart Lock integration', code: 'CredentialsApi.save()' }
        ]
      }
    },
    notifications: {
      name: 'Push Notifications',
      icon: '🔔',
      features: {
        ios: [
          { id: 'apns', name: 'Apple Push Notifications', description: 'Native iOS push notifications', code: 'UNUserNotificationCenter' },
          { id: 'local-notifications', name: 'Local Notifications', description: 'Schedule local notifications', code: 'UNTimeIntervalNotificationTrigger' },
          { id: 'rich-notifications', name: 'Rich Notifications', description: 'Media and interactive notifications', code: 'UNNotificationServiceExtension' }
        ],
        android: [
          { id: 'fcm', name: 'Firebase Cloud Messaging', description: 'Google FCM integration', code: 'FirebaseMessaging.getInstance()' },
          { id: 'notification-channels', name: 'Notification Channels', description: 'Android O+ notification channels', code: 'NotificationChannel' },
          { id: 'background-sync', name: 'Background Sync', description: 'Sync data in background', code: 'WorkManager.enqueue()' }
        ]
      }
    },
    storage: {
      name: 'Data Storage',
      icon: '💾',
      features: {
        ios: [
          { id: 'core-data', name: 'Core Data', description: 'Apple\'s data persistence framework', code: 'NSManagedObjectContext' },
          { id: 'userdefaults', name: 'UserDefaults', description: 'Simple key-value storage', code: 'UserDefaults.standard' },
          { id: 'cloudkit', name: 'CloudKit', description: 'iCloud data synchronization', code: 'CKContainer.default()' }
        ],
        android: [
          { id: 'room', name: 'Room Database', description: 'SQLite abstraction layer', code: '@Database, @Entity, @Dao' },
          { id: 'shared-prefs', name: 'SharedPreferences', description: 'Key-value pair storage', code: 'getSharedPreferences()' },
          { id: 'datastore', name: 'Jetpack DataStore', description: 'Modern data storage solution', code: 'dataStore.data.collect()' }
        ]
      }
    },
    camera: {
      name: 'Camera & Media',
      icon: '📸',
      features: {
        ios: [
          { id: 'avcapture', name: 'AVCaptureSession', description: 'Professional camera control', code: 'AVCaptureSession()' },
          { id: 'photo-picker', name: 'PHPickerViewController', description: 'Modern photo picker', code: 'PHPickerConfiguration' },
          { id: 'arkit', name: 'ARKit', description: 'Augmented reality features', code: 'ARSCNView, ARWorldTrackingConfiguration' }
        ],
        android: [
          { id: 'camera2', name: 'Camera2 API', description: 'Advanced camera operations', code: 'CameraManager.openCamera()' },
          { id: 'camerax', name: 'CameraX', description: 'Jetpack camera library', code: 'CameraX.bindToLifecycle()' },
          { id: 'ml-kit', name: 'ML Kit', description: 'Machine learning features', code: 'FirebaseVision.getInstance()' }
        ]
      }
    },
    location: {
      name: 'Location Services',
      icon: '📍',
      features: {
        ios: [
          { id: 'core-location', name: 'Core Location', description: 'GPS and location tracking', code: 'CLLocationManager' },
          { id: 'mapkit', name: 'MapKit', description: 'Native map integration', code: 'MKMapView, MKAnnotation' },
          { id: 'beacon', name: 'iBeacon', description: 'Bluetooth beacon detection', code: 'CLBeaconRegion' }
        ],
        android: [
          { id: 'fused-location', name: 'Fused Location', description: 'Google Play Services location', code: 'FusedLocationProviderClient' },
          { id: 'google-maps', name: 'Google Maps', description: 'Google Maps integration', code: 'GoogleMap, Marker' },
          { id: 'geofencing', name: 'Geofencing', description: 'Location-based triggers', code: 'GeofencingClient.addGeofences()' }
        ]
      }
    },
    connectivity: {
      name: 'Connectivity',
      icon: '🌐',
      features: {
        ios: [
          { id: 'network', name: 'Network Framework', description: 'Modern networking APIs', code: 'NWConnection, NWPathMonitor' },
          { id: 'bluetooth', name: 'Core Bluetooth', description: 'Bluetooth LE communication', code: 'CBCentralManager, CBPeripheral' },
          { id: 'nfc', name: 'Near Field Communication', description: 'NFC tag reading', code: 'NFCNDEFReaderSession' }
        ],
        android: [
          { id: 'connectivity-manager', name: 'ConnectivityManager', description: 'Network state monitoring', code: 'ConnectivityManager.getActiveNetwork()' },
          { id: 'bluetooth-le', name: 'Bluetooth LE', description: 'Low energy Bluetooth', code: 'BluetoothAdapter.getBluetoothLeScanner()' },
          { id: 'wifi-aware', name: 'Wi-Fi Aware', description: 'Device-to-device discovery', code: 'WifiAwareManager.attach()' }
        ]
      }
    }
  };

  const currentFeatures = featureCategories?.[selectedCategory]?.features?.[platform] || [];

  const toggleFeature = (featureId) => {
    setEnabledFeatures(prev => {
      const isEnabled = prev?.includes(featureId);
      const newFeatures = isEnabled 
        ? prev?.filter(id => id !== featureId)
        : [...prev, featureId];
      
      onProjectUpdate({
        nativeFeatures: newFeatures
      });
      
      return newFeatures;
    });
  };

  const generateFeatureCode = (feature) => {
    const codeTemplates = {
      ios: {
        'face-id': `
import LocalAuthentication

func authenticateWithFaceID() {
    let context = LAContext()
    let reason = "Use Face ID to authenticate"
    
    context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, 
                          localizedReason: reason) { success, error in
        DispatchQueue.main.async {
            if success {
                // Authentication successful
                print("Face ID authentication successful")
            } else {
                // Authentication failed
                print("Face ID authentication failed: \\(error?.localizedDescription ?? "Unknown error")")
            }
        }
    }
}`,
        'core-data': `
import CoreData

@objc(DataModel)
public class DataModel: NSManagedObject {
    // Core Data implementation
}

func setupCoreDataStack() {
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "DataModel")
        container.loadPersistentStores { _, error in
            if let error = error {
                fatalError("Core Data error: \\(error)")
            }
        }
        return container
    }()
}`
      },
      android: {
        'biometric': `
import androidx.biometric.BiometricPrompt
import androidx.biometric.BiometricManager

private fun authenticateWithBiometric() {
    val biometricPrompt = BiometricPrompt(this, 
        ContextCompat.getMainExecutor(this), 
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                // Authentication successful
            }
            
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                // Authentication error
            }
        })

    val promptInfo = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Biometric Authentication")
        .setSubtitle("Use your fingerprint to authenticate")
        .setNegativeButtonText("Cancel")
        .build()

    biometricPrompt.authenticate(promptInfo)
}`,
        'room': `
@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: Int,
    val name: String,
    val email: String
)

@Dao
interface UserDao {
    @Query("SELECT * FROM users")
    fun getAllUsers(): Flow<List<User>>
    
    @Insert
    suspend fun insertUser(user: User)
}

@Database(entities = [User::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
}`
      }
    };

    return codeTemplates?.[platform]?.[feature?.id] || feature?.code;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Native Features Integration</h3>
        <p className="text-gray-600">
          Access platform-specific APIs and features for {platform === 'ios' ? 'iOS' : 'Android'} development
        </p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Feature Categories */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Categories</h3>
          
          <div className="space-y-2">
            {Object.entries(featureCategories)?.map(([categoryId, category]) => (
              <button
                key={categoryId}
                onClick={() => setSelectedCategory(categoryId)}
                className={`
                  w-full flex items-center space-x-3 p-3 rounded-lg text-left transition-colors
                  ${selectedCategory === categoryId 
                    ? 'bg-blue-50 border border-blue-200 text-blue-700' :'bg-gray-50 hover:bg-gray-100 text-gray-700'
                  }
                `}
              >
                <span className="text-xl">{category?.icon}</span>
                <span className="font-medium">{category?.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Feature List */}
        <div className="lg:col-span-2 bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">
              {featureCategories?.[selectedCategory]?.name} Features
            </h3>
            <span className="text-sm text-gray-500 capitalize">{platform}</span>
          </div>
          
          <div className="space-y-4">
            {currentFeatures?.map((feature) => {
              const isEnabled = enabledFeatures?.includes(feature?.id);
              
              return (
                <div key={feature?.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h4 className="font-semibold text-gray-900">{feature?.name}</h4>
                        <button
                          onClick={() => toggleFeature(feature?.id)}
                          className={`
                            relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                            ${isEnabled ? 'bg-blue-600' : 'bg-gray-200'}
                          `}
                        >
                          <span
                            className={`
                              inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                              ${isEnabled ? 'translate-x-6' : 'translate-x-1'}
                            `}
                          />
                        </button>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{feature?.description}</p>
                      
                      {/* Code Preview */}
                      <div className="bg-gray-50 rounded-lg p-3">
                        <pre className="text-xs text-gray-700 overflow-x-auto">
                          <code>{feature?.code}</code>
                        </pre>
                      </div>
                    </div>
                  </div>
                  {isEnabled && (
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          View Docs
                        </Button>
                        <Button variant="outline" size="sm">
                          Generate Code
                        </Button>
                        <Button variant="primary" size="sm">
                          Configure
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Configuration Panel */}
        <div className="space-y-6">
          {/* Enabled Features Summary */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Enabled Features</h3>
            
            {enabledFeatures?.length === 0 ? (
              <p className="text-sm text-gray-500">No features enabled yet</p>
            ) : (
              <div className="space-y-2">
                {enabledFeatures?.map((featureId) => {
                  // Find the feature across all categories
                  let foundFeature = null;
                  let foundCategory = null;
                  
                  Object.entries(featureCategories)?.forEach(([catId, category]) => {
                    const feature = category?.features?.[platform]?.find(f => f?.id === featureId);
                    if (feature) {
                      foundFeature = feature;
                      foundCategory = category;
                    }
                  });
                  
                  if (!foundFeature) return null;
                  
                  return (
                    <div key={featureId} className="flex items-center justify-between p-2 bg-green-50 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm">{foundCategory?.icon}</span>
                        <span className="text-sm font-medium text-green-800">
                          {foundFeature?.name}
                        </span>
                      </div>
                      <button
                        onClick={() => toggleFeature(featureId)}
                        className="text-green-600 hover:text-green-800"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Platform Requirements */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Platform Requirements</h3>
            
            <div className="space-y-3 text-sm">
              {platform === 'ios' ? (
                <>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Min iOS Version:</span>
                    <span className="font-medium">14.0+</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Xcode Version:</span>
                    <span className="font-medium">14.0+</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Swift Version:</span>
                    <span className="font-medium">5.7+</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Device Support:</span>
                    <span className="font-medium">iPhone, iPad</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Min API Level:</span>
                    <span className="font-medium">21 (Android 5.0)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Target API:</span>
                    <span className="font-medium">34 (Android 14)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Kotlin Version:</span>
                    <span className="font-medium">1.8+</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Device Support:</span>
                    <span className="font-medium">Phone, Tablet</span>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Permissions */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Required Permissions</h3>
            
            <div className="space-y-2 text-sm">
              {enabledFeatures?.length === 0 ? (
                <p className="text-gray-500">Enable features to see required permissions</p>
              ) : (
                <div className="space-y-1">
                  {platform === 'ios' ? (
                    <>
                      {enabledFeatures?.some(f => f?.includes('face-id') || f?.includes('touch-id')) && (
                        <div className="text-orange-600">• NSFaceIDUsageDescription</div>
                      )}
                      {enabledFeatures?.some(f => f?.includes('camera') || f?.includes('avcapture')) && (
                        <div className="text-orange-600">• NSCameraUsageDescription</div>
                      )}
                      {enabledFeatures?.some(f => f?.includes('location') || f?.includes('core-location')) && (
                        <div className="text-orange-600">• NSLocationWhenInUseUsageDescription</div>
                      )}
                    </>
                  ) : (
                    <>
                      {enabledFeatures?.some(f => f?.includes('camera')) && (
                        <div className="text-orange-600">• android.permission.CAMERA</div>
                      )}
                      {enabledFeatures?.some(f => f?.includes('location')) && (
                        <div className="text-orange-600">• android.permission.ACCESS_FINE_LOCATION</div>
                      )}
                      {enabledFeatures?.some(f => f?.includes('bluetooth')) && (
                        <div className="text-orange-600">• android.permission.BLUETOOTH</div>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Actions</h3>
            
            <div className="space-y-2">
              <Button variant="primary" className="w-full">
                Generate Integration Code
              </Button>
              <Button variant="outline" className="w-full">
                Export Configuration
              </Button>
              <Button variant="outline" className="w-full">
                View Documentation
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NativeFeatures;