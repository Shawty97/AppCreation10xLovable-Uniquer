import React, { useEffect } from 'react';

const MobileTesting = () => {
  React.useEffect(() => {
    // eslint-disable-next-line no-console
    console.warn('Placeholder: MobileTesting is not implemented yet.');
  }, []);
  return (
    <>
  { /*MobileTesting */} 
 </>
  );
};

export default MobileTesting;
