import React from 'react';
import { Globe } from 'lucide-react';

const ABTestingFramework = ({ environment }) => {
  const activeTests = [
    {
      name: 'Header CTA Button',
      status: 'running',
      participants: 2451,
      confidence: 95,
      improvement: '+12.5%'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center mb-4">
          <Globe className="w-5 h-5 mr-2 text-blue-600" />
          A/B Testing Framework
        </h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">3</div>
            <div className="text-sm text-blue-700">Active Tests</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">89%</div>
            <div className="text-sm text-green-700">Avg Confidence</div>
          </div>
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600">8.3%</div>
            <div className="text-sm text-yellow-700">Avg Improvement</div>
          </div>
        </div>

        <div className="space-y-4">
          {activeTests?.map((test, index) => (
            <div key={index} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-gray-900">{test?.name}</div>
                  <div className="text-sm text-gray-600">{test?.participants} participants • {test?.confidence}% confidence</div>
                </div>
                <div className="text-green-600 font-bold">{test?.improvement}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ABTestingFramework;