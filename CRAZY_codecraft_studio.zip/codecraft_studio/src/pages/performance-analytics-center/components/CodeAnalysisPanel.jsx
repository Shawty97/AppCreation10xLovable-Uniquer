import React, { useState } from 'react';
import { Activity, AlertTriangle, CheckCircle, Code, FileText, Zap, Package, Layers, Search, Bug, Trash2 } from 'lucide-react';
import Icon from '../../../components/AppIcon';


const CodeAnalysisPanel = ({ environment = 'production' }) => {
  const [activeAnalysis, setActiveAnalysis] = useState('bottlenecks');
  const [selectedFile, setSelectedFile] = useState(null);

  const analysisTypes = [
    { id: 'bottlenecks', label: 'Performance Bottlenecks', icon: Activity },
    { id: 'dependencies', label: 'Unused Dependencies', icon: Package },
    { id: 'duplicates', label: 'Code Duplicates', icon: Layers },
    { id: 'security', label: 'Security Issues', icon: AlertTriangle },
    { id: 'best-practices', label: 'Best Practices', icon: CheckCircle }
  ];

  const bottlenecks = [
    {
      id: 1,
      file: 'src/components/Dashboard.jsx',
      issue: 'Heavy computation in render method',
      severity: 'high',
      impact: 'Blocks main thread for ~250ms',
      line: 47,
      suggestion: 'Move calculation to useMemo hook',
      estimatedImprovement: '40% faster rendering'
    },
    {
      id: 2,
      file: 'src/utils/dataProcessor.js',
      issue: 'Inefficient array operations',
      severity: 'medium',
      impact: 'O(n²) complexity on large datasets',
      line: 23,
      suggestion: 'Use Map for lookups instead of array.find',
      estimatedImprovement: '60% faster processing'
    },
    {
      id: 3,
      file: 'src/pages/Analytics.jsx',
      issue: 'Multiple API calls on mount',
      severity: 'medium',
      impact: 'Waterfall loading pattern',
      line: 15,
      suggestion: 'Combine API calls or use parallel requests',
      estimatedImprovement: '30% faster page load'
    }
  ];

  const unusedDependencies = [
    {
      name: 'lodash',
      size: '528 KB',
      lastUsed: 'Never',
      impact: 'Bundle size increase',
      alternative: 'Native ES6 methods or specific lodash functions',
      confidence: 'High'
    },
    {
      name: 'moment.js',
      size: '232 KB',
      lastUsed: '45 days ago',
      impact: 'Large bundle size',
      alternative: 'date-fns (lighter alternative)',
      confidence: 'Medium'
    },
    {
      name: 'react-router-redux',
      size: '45 KB',
      lastUsed: 'Never',
      impact: 'Deprecated package',
      alternative: 'Remove - no longer needed',
      confidence: 'High'
    }
  ];

  const codeDuplicates = [
    {
      id: 1,
      pattern: 'Form validation logic',
      files: ['LoginForm.jsx', 'SignupForm.jsx', 'ContactForm.jsx'],
      lines: 45,
      similarity: '89%',
      suggestion: 'Extract to custom hook useFormValidation'
    },
    {
      id: 2,
      pattern: 'API error handling',
      files: ['UserService.js', 'ProductService.js', 'OrderService.js'],
      lines: 32,
      similarity: '76%',
      suggestion: 'Create centralized error handling utility'
    },
    {
      id: 3,
      pattern: 'Loading state management',
      files: ['Dashboard.jsx', 'Profile.jsx', 'Settings.jsx'],
      lines: 28,
      similarity: '82%',
      suggestion: 'Use custom hook useAsyncState'
    }
  ];

  const securityIssues = [
    {
      id: 1,
      type: 'XSS Vulnerability',
      file: 'src/components/UserProfile.jsx',
      line: 34,
      severity: 'high',
      description: 'Unsafe innerHTML usage with user data',
      fix: 'Use textContent or sanitize HTML input',
      cwe: 'CWE-79'
    },
    {
      id: 2,
      type: 'Hardcoded Secrets',
      file: 'src/config/api.js',
      line: 8,
      severity: 'critical',
      description: 'API key hardcoded in source code',
      fix: 'Move to environment variables',
      cwe: 'CWE-798'
    },
    {
      id: 3,
      type: 'Insecure Dependencies',
      file: 'package.json',
      line: 15,
      severity: 'medium',
      description: 'Package "old-library" has known vulnerabilities',
      fix: 'Update to version 2.1.4 or higher',
      cwe: 'CWE-1104'
    }
  ];

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'text-red-600 bg-red-100';
      case 'high': return 'text-red-600 bg-red-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'low': return 'text-blue-600 bg-blue-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const renderAnalysisContent = () => {
    switch (activeAnalysis) {
      case 'bottlenecks':
        return (
          <div className="space-y-6">
            {bottlenecks?.map((bottleneck) => (
              <div key={bottleneck?.id} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-sm transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <FileText className="w-5 h-5 text-blue-600" />
                      <span className="font-medium text-gray-900">{bottleneck?.file}</span>
                      <span className="text-sm text-gray-500">Line {bottleneck?.line}</span>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(bottleneck?.severity)}`}>
                        {bottleneck?.severity}
                      </span>
                    </div>
                    
                    <h4 className="font-medium text-gray-900 mb-2">{bottleneck?.issue}</h4>
                    <p className="text-sm text-gray-600 mb-3">{bottleneck?.impact}</p>
                    
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <div className="flex items-start space-x-2">
                        <Zap className="w-4 h-4 text-blue-600 mt-0.5" />
                        <div>
                          <div className="text-sm font-medium text-blue-900">Suggested Fix</div>
                          <div className="text-sm text-blue-700">{bottleneck?.suggestion}</div>
                          <div className="text-xs text-blue-600 mt-1">{bottleneck?.estimatedImprovement}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                    Apply Fix
                  </button>
                </div>
              </div>
            ))}
          </div>
        );

      case 'dependencies':
        return (
          <div className="space-y-4">
            {unusedDependencies?.map((dep, index) => (
              <div key={index} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-sm transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <Package className="w-5 h-5 text-orange-600" />
                      <span className="font-medium text-gray-900">{dep?.name}</span>
                      <span className="text-sm text-gray-500">{dep?.size}</span>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        dep?.confidence === 'High' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {dep?.confidence} confidence
                      </span>
                    </div>
                    
                    <div className="text-sm text-gray-600 space-y-1">
                      <div><span className="font-medium">Last used:</span> {dep?.lastUsed}</div>
                      <div><span className="font-medium">Impact:</span> {dep?.impact}</div>
                      <div><span className="font-medium">Alternative:</span> {dep?.alternative}</div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <button className="px-3 py-1 text-gray-600 border border-gray-300 rounded hover:bg-gray-50 transition-colors text-sm">
                      Keep
                    </button>
                    <button className="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700 transition-colors text-sm flex items-center space-x-1">
                      <Trash2 className="w-3 h-3" />
                      <span>Remove</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        );

      case 'duplicates':
        return (
          <div className="space-y-4">
            {codeDuplicates?.map((duplicate) => (
              <div key={duplicate?.id} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-sm transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <Layers className="w-5 h-5 text-purple-600" />
                      <span className="font-medium text-gray-900">{duplicate?.pattern}</span>
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                        {duplicate?.similarity} similar
                      </span>
                    </div>
                    
                    <div className="text-sm text-gray-600 mb-3">
                      <span className="font-medium">Duplicated in:</span> {duplicate?.files?.join(', ')}
                    </div>
                    <div className="text-sm text-gray-600 mb-3">
                      <span className="font-medium">Lines affected:</span> {duplicate?.lines}
                    </div>
                    
                    <div className="bg-purple-50 p-3 rounded-lg">
                      <div className="flex items-start space-x-2">
                        <CheckCircle className="w-4 h-4 text-purple-600 mt-0.5" />
                        <div className="text-sm text-purple-700">{duplicate?.suggestion}</div>
                      </div>
                    </div>
                  </div>
                  
                  <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm">
                    Refactor
                  </button>
                </div>
              </div>
            ))}
          </div>
        );

      case 'security':
        return (
          <div className="space-y-4">
            {securityIssues?.map((issue) => (
              <div key={issue?.id} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-sm transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <AlertTriangle className="w-5 h-5 text-red-600" />
                      <span className="font-medium text-gray-900">{issue?.type}</span>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(issue?.severity)}`}>
                        {issue?.severity}
                      </span>
                      <span className="text-xs text-gray-500">{issue?.cwe}</span>
                    </div>
                    
                    <div className="text-sm text-gray-600 space-y-1 mb-3">
                      <div><span className="font-medium">File:</span> {issue?.file}:{issue?.line}</div>
                      <div><span className="font-medium">Issue:</span> {issue?.description}</div>
                    </div>
                    
                    <div className="bg-red-50 p-3 rounded-lg">
                      <div className="flex items-start space-x-2">
                        <Bug className="w-4 h-4 text-red-600 mt-0.5" />
                        <div className="text-sm text-red-700">{issue?.fix}</div>
                      </div>
                    </div>
                  </div>
                  
                  <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm">
                    Fix Issue
                  </button>
                </div>
              </div>
            ))}
          </div>
        );

      default:
        return (
          <div className="text-center py-12">
            <Activity className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Select an analysis type to view results</p>
          </div>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Analysis Header */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Code className="w-5 h-5 mr-2 text-blue-600" />
            Code Analysis & Optimization
          </h3>
          
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">
              Environment: <span className="font-medium capitalize">{environment}</span>
            </span>
            <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              <Search className="w-4 h-4" />
              <span>Run Analysis</span>
            </button>
          </div>
        </div>

        {/* Analysis Summary */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <div className="text-2xl font-bold text-red-600">{bottlenecks?.length}</div>
            <div className="text-sm text-red-700">Bottlenecks</div>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <div className="text-2xl font-bold text-orange-600">{unusedDependencies?.length}</div>
            <div className="text-sm text-orange-700">Unused Deps</div>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">{codeDuplicates?.length}</div>
            <div className="text-sm text-purple-700">Duplicates</div>
          </div>
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <div className="text-2xl font-bold text-red-600">{securityIssues?.length}</div>
            <div className="text-sm text-red-700">Security</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">85%</div>
            <div className="text-sm text-green-700">Code Quality</div>
          </div>
        </div>
      </div>
      {/* Analysis Navigation */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
          {analysisTypes?.map(analysis => {
            const Icon = analysis?.icon;
            return (
              <button
                key={analysis?.id}
                onClick={() => setActiveAnalysis(analysis?.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeAnalysis === analysis?.id
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{analysis?.label}</span>
              </button>
            );
          })}
        </div>
      </div>
      {/* Analysis Results */}
      <div>
        {renderAnalysisContent()}
      </div>
    </div>
  );
};

export default CodeAnalysisPanel;