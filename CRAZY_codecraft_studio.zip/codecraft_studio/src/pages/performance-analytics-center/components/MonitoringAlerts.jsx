import React from 'react';
import { AlertTriangle, CheckCircle, Clock } from 'lucide-react';

const MonitoringAlerts = ({ environment, fullView = false }) => {
  const alerts = [
    {
      id: 1,
      type: 'warning',
      title: 'High Memory Usage',
      description: 'Memory usage exceeded 85% threshold',
      timestamp: new Date(Date.now() - 300000),
      resolved: false
    },
    {
      id: 2,
      type: 'error',
      title: 'API Response Time',
      description: 'Average response time > 2 seconds',
      timestamp: new Date(Date.now() - 600000),
      resolved: true
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 flex items-center mb-4">
        <AlertTriangle className="w-5 h-5 mr-2 text-red-600" />
        Monitoring Alerts
      </h3>
      <div className="space-y-4">
        {alerts?.map((alert) => (
          <div key={alert?.id} className={`p-4 rounded-lg border ${
            alert?.resolved ? 'bg-green-50 border-green-200' : 
            alert?.type === 'error' ? 'bg-red-50 border-red-200' : 'bg-yellow-50 border-yellow-200'
          }`}>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  {alert?.resolved ? 
                    <CheckCircle className="w-4 h-4 text-green-600" /> :
                    <AlertTriangle className={`w-4 h-4 ${alert?.type === 'error' ? 'text-red-600' : 'text-yellow-600'}`} />
                  }
                  <span className="font-medium text-gray-900">{alert?.title}</span>
                  {alert?.resolved && <span className="text-xs text-green-600">Resolved</span>}
                </div>
                <div className="text-sm text-gray-600 mt-1">{alert?.description}</div>
                <div className="flex items-center space-x-1 text-xs text-gray-500 mt-2">
                  <Clock className="w-3 h-3" />
                  <span>{Math.floor((Date.now() - alert?.timestamp) / 60000)} minutes ago</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MonitoringAlerts;