import React, { useState, useMemo } from 'react';
import { Users, Zap, Globe, Smartphone, Monitor, Tablet, Filter } from 'lucide-react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import Icon from '../../../components/AppIcon';


const MetricsCharts = ({ timeRange = '24h', environment = 'production', fullView = false }) => {
  const [selectedMetric, setSelectedMetric] = useState('performance');
  const [deviceFilter, setDeviceFilter] = useState('all');

  // Mock data based on time range
  const generateMockData = useMemo(() => {
    const baseData = [];
    const points = timeRange === '1h' ? 12 : timeRange === '24h' ? 24 : timeRange === '7d' ? 7 : 30;
    
    for (let i = 0; i < points; i++) {
      baseData?.push({
        time: timeRange === '1h' ? `${String(i * 5)?.padStart(2, '0')}:00` :
              timeRange === '24h' ? `${String(i)?.padStart(2, '0')}:00` :
              timeRange === '7d' ? `Day ${i + 1}` : `Week ${i + 1}`,
        loadTime: 1500 + Math.random() * 800,
        fcp: 1.2 + Math.random() * 0.6,
        lcp: 2.0 + Math.random() * 1.0,
        cls: 0.05 + Math.random() * 0.1,
        fid: 80 + Math.random() * 40,
        users: 1000 + Math.random() * 500,
        pageViews: 2000 + Math.random() * 1000,
        bounceRate: 20 + Math.random() * 15,
        errorRate: Math.random() * 2
      });
    }
    return baseData;
  }, [timeRange]);

  const deviceData = [
    { device: 'Desktop', value: 45, color: '#3B82F6' },
    { device: 'Mobile', value: 40, color: '#10B981' },
    { device: 'Tablet', value: 15, color: '#F59E0B' }
  ];

  const performanceMetrics = [
    { key: 'performance', label: 'Performance', icon: Zap },
    { key: 'users', label: 'Users', icon: Users },
    { key: 'errors', label: 'Errors', icon: Globe },
    { key: 'devices', label: 'Devices', icon: Monitor }
  ];

  const getChartColor = (metric) => {
    switch (metric) {
      case 'loadTime': return '#3B82F6';
      case 'fcp': return '#10B981';
      case 'lcp': return '#F59E0B';
      case 'cls': return '#EF4444';
      case 'fid': return '#8B5CF6';
      case 'users': return '#06B6D4';
      case 'pageViews': return '#84CC16';
      default: return '#6B7280';
    }
  };

  const formatValue = (value, type) => {
    switch (type) {
      case 'time':
        return value < 1000 ? `${Math.round(value)}ms` : `${(value / 1000)?.toFixed(1)}s`;
      case 'percentage':
        return `${value?.toFixed(1)}%`;
      case 'number':
        return Math.round(value)?.toLocaleString();
      default:
        return value?.toFixed(2);
    }
  };

  const CustomTooltip = ({ active, payload, label, type = 'time' }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{label}</p>
          {payload?.map((entry, index) => (
            <p key={index} style={{ color: entry?.color }} className="text-sm">
              {entry?.name}: {formatValue(entry?.value, type)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const renderChart = () => {
    switch (selectedMetric) {
      case 'performance':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Load Time Trend */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h4 className="font-semibold text-gray-900 mb-4">Load Time Trend</h4>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={generateMockData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip content={<CustomTooltip type="time" />} />
                  <Line 
                    type="monotone" 
                    dataKey="loadTime" 
                    stroke={getChartColor('loadTime')} 
                    strokeWidth={2}
                    dot={{ fill: getChartColor('loadTime'), strokeWidth: 2, r: 4 }}
                    name="Load Time"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Core Web Vitals */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h4 className="font-semibold text-gray-900 mb-4">Core Web Vitals</h4>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={generateMockData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line 
                    type="monotone" 
                    dataKey="fcp" 
                    stroke={getChartColor('fcp')} 
                    strokeWidth={2}
                    name="FCP (s)"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="lcp" 
                    stroke={getChartColor('lcp')} 
                    strokeWidth={2}
                    name="LCP (s)"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="cls" 
                    stroke={getChartColor('cls')} 
                    strokeWidth={2}
                    name="CLS"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        );

      case 'users':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* User Traffic */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h4 className="font-semibold text-gray-900 mb-4">User Traffic</h4>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={generateMockData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip content={<CustomTooltip type="number" />} />
                  <Area 
                    type="monotone" 
                    dataKey="users" 
                    stroke={getChartColor('users')} 
                    fill={getChartColor('users')}
                    fillOpacity={0.6}
                    name="Active Users"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Page Views vs Bounce Rate */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h4 className="font-semibold text-gray-900 mb-4">Engagement Metrics</h4>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={generateMockData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip content={<CustomTooltip type="number" />} />
                  <Bar dataKey="pageViews" fill={getChartColor('pageViews')} name="Page Views" />
                  <Line 
                    type="monotone" 
                    dataKey="bounceRate" 
                    stroke="#EF4444" 
                    strokeWidth={2}
                    name="Bounce Rate (%)"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        );

      case 'errors':
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h4 className="font-semibold text-gray-900 mb-4">Error Rate Trend</h4>
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={generateMockData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip content={<CustomTooltip type="percentage" />} />
                <Line 
                  type="monotone" 
                  dataKey="errorRate" 
                  stroke="#EF4444" 
                  strokeWidth={2}
                  dot={{ fill: '#EF4444', strokeWidth: 2, r: 4 }}
                  name="Error Rate"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        );

      case 'devices':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Device Distribution */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h4 className="font-semibold text-gray-900 mb-4">Device Distribution</h4>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={deviceData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ device, value }) => `${device}: ${value}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {deviceData?.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry?.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            {/* Device Performance */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h4 className="font-semibold text-gray-900 mb-4">Performance by Device</h4>
              <div className="space-y-4">
                {[
                  { device: 'Desktop', icon: Monitor, score: 95, loadTime: 1200 },
                  { device: 'Mobile', icon: Smartphone, score: 78, loadTime: 2100 },
                  { device: 'Tablet', icon: Tablet, score: 85, loadTime: 1800 }
                ]?.map(({ device, icon: Icon, score, loadTime }) => (
                  <div key={device} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Icon className="w-5 h-5 text-gray-600" />
                      <span className="font-medium">{device}</span>
                    </div>
                    <div className="text-right">
                      <div className={`font-bold ${score >= 90 ? 'text-green-600' : score >= 70 ? 'text-yellow-600' : 'text-red-600'}`}>
                        {score}/100
                      </div>
                      <div className="text-sm text-gray-500">{formatValue(loadTime, 'time')}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className={`space-y-6 ${fullView ? '' : ''}`}>
      {/* Metrics Navigation */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
          <h3 className="text-lg font-semibold text-gray-900">Performance Metrics</h3>
          
          <div className="flex items-center space-x-4">
            {/* Metric Selector */}
            <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
              {performanceMetrics?.map(metric => {
                const Icon = metric?.icon;
                return (
                  <button
                    key={metric?.key}
                    onClick={() => setSelectedMetric(metric?.key)}
                    className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      selectedMetric === metric?.key
                        ? 'bg-white text-blue-600 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{metric?.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Device Filter */}
            <select
              value={deviceFilter}
              onChange={(e) => setDeviceFilter(e?.target?.value)}
              className="text-sm border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Devices</option>
              <option value="desktop">Desktop</option>
              <option value="mobile">Mobile</option>
              <option value="tablet">Tablet</option>
            </select>
          </div>
        </div>
      </div>
      {/* Charts */}
      {renderChart()}
      {/* Historical Comparison */}
      {fullView && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h4 className="font-semibold text-gray-900 mb-4">Historical Comparison</h4>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">1.8s</div>
              <div className="text-sm text-blue-700">Avg Load Time</div>
              <div className="text-xs text-green-600 mt-1">↓15% vs last month</div>
            </div>
            
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">92</div>
              <div className="text-sm text-green-700">Performance Score</div>
              <div className="text-xs text-green-600 mt-1">↑8% vs last month</div>
            </div>
            
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600">23.5%</div>
              <div className="text-sm text-yellow-700">Bounce Rate</div>
              <div className="text-xs text-red-600 mt-1">↑3% vs last month</div>
            </div>
            
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">0.8%</div>
              <div className="text-sm text-purple-700">Error Rate</div>
              <div className="text-xs text-green-600 mt-1">↓40% vs last month</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MetricsCharts;