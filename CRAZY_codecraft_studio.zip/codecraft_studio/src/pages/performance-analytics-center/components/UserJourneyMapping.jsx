import React from 'react';
import { MapPin } from 'lucide-react';

const UserJourneyMapping = ({ timeRange, environment }) => {
  const journeyData = {
    totalJourneys: 15420,
    avgDuration: '2m 45s',
    conversionRate: 12.8,
    dropOffRate: 23.5
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center mb-4">
          <MapPin className="w-5 h-5 mr-2 text-blue-600" />
          User Journey Mapping
        </h3>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{journeyData?.totalJourneys?.toLocaleString()}</div>
            <div className="text-sm text-blue-700">Total Journeys</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{journeyData?.avgDuration}</div>
            <div className="text-sm text-green-700">Avg Duration</div>
          </div>
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600">{journeyData?.conversionRate}%</div>
            <div className="text-sm text-yellow-700">Conversion</div>
          </div>
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <div className="text-2xl font-bold text-red-600">{journeyData?.dropOffRate}%</div>
            <div className="text-sm text-red-700">Drop-off Rate</div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-4 bg-blue-50 rounded-lg">
            <div className="font-medium text-blue-900 mb-2">Most Common Journey</div>
            <div className="text-sm text-blue-700">
              Landing Page → Product List → Product Details → Checkout → Success
            </div>
            <div className="text-xs text-blue-600 mt-1">Average completion time: 3m 12s</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserJourneyMapping;