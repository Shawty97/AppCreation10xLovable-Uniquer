import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const IndustryCollections = ({ collections, onViewCollection }) => {
  const [expandedCollection, setExpandedCollection] = useState(null);

  const toggleCollection = (collectionId) => {
    setExpandedCollection(expandedCollection === collectionId ? null : collectionId);
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-foreground">Industry Collections</h2>
        <Button
          variant="outline"
          iconName="Grid3X3"
          iconPosition="left"
          iconSize={16}
        >
          View All Collections
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {collections?.map((collection) => (
          <div
            key={collection?.id}
            className="bg-card border border-border rounded-lg shadow-elevation-1 hover:shadow-elevation-2 transition-all duration-300 overflow-hidden"
          >
            {/* Collection Header */}
            <div className="relative h-32 overflow-hidden">
              <Image
                src={collection?.coverImage}
                alt={`${collection?.name} collection cover`}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <h3 className="text-lg font-semibold text-white mb-1">{collection?.name}</h3>
                <p className="text-sm text-white/80">{collection?.templateCount} templates</p>
              </div>
            </div>

            {/* Collection Content */}
            <div className="p-4">
              <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                {collection?.description}
              </p>

              {/* Template Preview Grid */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                {collection?.previewTemplates?.slice(0, 3)?.map((template, index) => (
                  <div key={index} className="aspect-square rounded-md overflow-hidden">
                    <Image
                      src={template?.previewImage}
                      alt={`${template?.name} preview`}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-200"
                    />
                  </div>
                ))}
              </div>

              {/* Collection Stats */}
              <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
                <div className="flex items-center space-x-1">
                  <Icon name="Star" size={12} />
                  <span>{collection?.averageRating}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Download" size={12} />
                  <span>{collection?.totalDownloads}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Clock" size={12} />
                  <span>Updated {collection?.lastUpdated}</span>
                </div>
              </div>

              {/* Expandable Template List */}
              {expandedCollection === collection?.id && (
                <div className="border-t border-border pt-4 mb-4 animate-accordion-down">
                  <div className="space-y-2">
                    {collection?.templates?.map((template) => (
                      <div
                        key={template?.id}
                        className="flex items-center space-x-3 p-2 rounded-md hover:bg-muted transition-colors"
                      >
                        <div className="w-8 h-8 rounded overflow-hidden flex-shrink-0">
                          <Image
                            src={template?.previewImage}
                            alt={template?.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">
                            {template?.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {template?.difficulty} • {template?.setupTime}
                          </p>
                        </div>
                        <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                          <Icon name="Download" size={12} />
                          <span>{template?.downloads}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => toggleCollection(collection?.id)}
                  iconName={expandedCollection === collection?.id ? 'ChevronUp' : 'ChevronDown'}
                  iconPosition="left"
                  iconSize={14}
                  className="flex-1"
                >
                  {expandedCollection === collection?.id ? 'Show Less' : 'Show Templates'}
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => onViewCollection(collection)}
                  iconName="ArrowRight"
                  iconPosition="right"
                  iconSize={14}
                  className="flex-1"
                >
                  View Collection
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default IndustryCollections;