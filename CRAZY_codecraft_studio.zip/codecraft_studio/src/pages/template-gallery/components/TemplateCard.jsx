import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TemplateCard = ({ template, onPreview, onUseTemplate }) => {
  const [isHovered, setIsHovered] = useState(false);

  const getDifficultyColor = (level) => {
    switch (level) {
      case 'Beginner':
        return 'bg-success text-success-foreground';
      case 'Intermediate':
        return 'bg-warning text-warning-foreground';
      case 'Advanced':
        return 'bg-error text-error-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div
      className="bg-card border border-border rounded-lg shadow-elevation-1 hover:shadow-elevation-3 transition-all duration-300 hover-lift overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Template Preview Image */}
      <div className="relative aspect-video overflow-hidden">
        <Image
          src={template?.previewImage}
          alt={`${template?.name} template preview`}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
        
        {/* Overlay on hover */}
        {isHovered && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center space-x-3 animate-fade-in">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onPreview(template)}
              iconName="Eye"
              iconPosition="left"
              iconSize={16}
              className="bg-white/90 hover:bg-white text-foreground"
            >
              Preview
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={() => onUseTemplate(template)}
              iconName="Download"
              iconPosition="left"
              iconSize={16}
            >
              Use Template
            </Button>
          </div>
        )}

        {/* Premium Badge */}
        {template?.isPremium && (
          <div className="absolute top-3 right-3 bg-accent text-accent-foreground px-2 py-1 rounded-md text-xs font-medium">
            <Icon name="Crown" size={12} className="inline mr-1" />
            Premium
          </div>
        )}

        {/* Featured Badge */}
        {template?.isFeatured && (
          <div className="absolute top-3 left-3 bg-primary text-primary-foreground px-2 py-1 rounded-md text-xs font-medium">
            <Icon name="Star" size={12} className="inline mr-1" />
            Featured
          </div>
        )}
      </div>
      {/* Template Info */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="text-lg font-semibold text-foreground line-clamp-1">{template?.name}</h3>
          <div className="flex items-center space-x-1 text-muted-foreground">
            <Icon name="Heart" size={14} />
            <span className="text-sm">{template?.likes}</span>
          </div>
        </div>

        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{template?.description}</p>

        {/* Category and Difficulty */}
        <div className="flex items-center justify-between mb-3">
          <span className="inline-flex items-center px-2 py-1 rounded-md bg-muted text-muted-foreground text-xs font-medium">
            {template?.category}
          </span>
          <span className={`inline-flex items-center px-2 py-1 rounded-md text-xs font-medium ${getDifficultyColor(template?.difficulty)}`}>
            {template?.difficulty}
          </span>
        </div>

        {/* Template Stats */}
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
          <div className="flex items-center space-x-1">
            <Icon name="Clock" size={12} />
            <span>{template?.setupTime}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Package" size={12} />
            <span>{template?.components} components</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Download" size={12} />
            <span>{template?.downloads}</span>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onPreview(template)}
            iconName="Eye"
            iconPosition="left"
            iconSize={14}
            className="flex-1"
          >
            Preview
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={() => onUseTemplate(template)}
            iconName="Plus"
            iconPosition="left"
            iconSize={14}
            className="flex-1"
          >
            Use Template
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TemplateCard;