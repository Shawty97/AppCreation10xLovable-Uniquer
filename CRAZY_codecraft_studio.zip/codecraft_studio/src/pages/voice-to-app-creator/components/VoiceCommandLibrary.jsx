import React, { useState } from 'react';
import { Search, Plus, BookOpen, Mic, Command, Star, Copy, Edit } from 'lucide-react';
import Icon from '../../../components/AppIcon';


const VoiceCommandLibrary = ({ commands = [], onAddCommand }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newCommand, setNewCommand] = useState({
    phrase: '',
    category: 'component_creation',
    description: '',
    actionData: {}
  });

  const categories = [
    { value: 'all', label: 'All Commands', icon: BookOpen },
    { value: 'navigation', label: 'Navigation', icon: Command },
    { value: 'component_creation', label: 'Components', icon: Plus },
    { value: 'styling', label: 'Styling', icon: Star },
    { value: 'project_management', label: 'Project', icon: Edit }
  ];

  const defaultCommands = [
    { id: 'nav-1', command_phrase: 'navigate to dashboard', category: 'navigation', description: 'Navigate to the main dashboard page', usage_count: 45, is_custom: false },
    { id: 'nav-2', command_phrase: 'go to projects', category: 'navigation', description: 'Open projects list view', usage_count: 32, is_custom: false },
    { id: 'comp-1', command_phrase: 'create new component', category: 'component_creation', description: 'Generate a new React component', usage_count: 78, is_custom: false },
    { id: 'comp-2', command_phrase: 'add button component', category: 'component_creation', description: 'Add a styled button component', usage_count: 56, is_custom: false },
    { id: 'comp-3', command_phrase: 'create form', category: 'component_creation', description: 'Generate a form with validation', usage_count: 41, is_custom: false },
    { id: 'style-1', command_phrase: 'apply primary colors', category: 'styling', description: 'Apply primary color scheme', usage_count: 29, is_custom: false },
    { id: 'style-2', command_phrase: 'make it responsive', category: 'styling', description: 'Add responsive design classes', usage_count: 67, is_custom: false },
    { id: 'style-3', command_phrase: 'add dark mode', category: 'styling', description: 'Implement dark mode toggle', usage_count: 38, is_custom: false },
    { id: 'proj-1', command_phrase: 'save project', category: 'project_management', description: 'Save current project state', usage_count: 89, is_custom: false },
    { id: 'proj-2', command_phrase: 'deploy application', category: 'project_management', description: 'Start deployment process', usage_count: 23, is_custom: false }
  ];

  // Combine default commands with user commands
  const allCommands = [...(commands || []), ...defaultCommands];

  const filteredCommands = allCommands?.filter(command => {
    const matchesSearch = command?.command_phrase?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                         command?.description?.toLowerCase()?.includes(searchTerm?.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || command?.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleAddCommand = async (e) => {
    e?.preventDefault();
    if (!newCommand?.phrase?.trim()) return;

    await onAddCommand?.(newCommand);
    
    setNewCommand({
      phrase: '',
      category: 'component_creation',
      description: '',
      actionData: {}
    });
    setShowAddForm(false);
  };

  const getCategoryIcon = (category) => {
    const cat = categories?.find(c => c?.value === category);
    const Icon = cat?.icon || Command;
    return Icon;
  };

  const getCategoryColor = (category) => {
    const colors = {
      navigation: 'bg-blue-100 text-blue-800',
      component_creation: 'bg-green-100 text-green-800',
      styling: 'bg-purple-100 text-purple-800',
      project_management: 'bg-orange-100 text-orange-800'
    };
    return colors?.[category] || 'bg-gray-100 text-gray-800';
  };

  const copyToClipboard = (text) => {
    navigator.clipboard?.writeText(text);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <BookOpen className="h-6 w-6 text-purple-600" />
          <h2 className="text-xl font-semibold text-gray-900">Voice Command Library</h2>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Command
        </button>
      </div>
      {/* Search and Filters */}
      <div className="mb-6 space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search commands..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e?.target?.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
        </div>

        <div className="flex space-x-2 overflow-x-auto">
          {categories?.map((category) => {
            const Icon = category?.icon;
            return (
              <button
                key={category?.value}
                onClick={() => setSelectedCategory(category?.value)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                  selectedCategory === category?.value
                    ? 'bg-purple-100 text-purple-700 border border-purple-200' :'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span className="text-sm font-medium">{category?.label}</span>
              </button>
            );
          })}
        </div>
      </div>
      {/* Add Command Form */}
      {showAddForm && (
        <div className="mb-6 p-4 border border-gray-200 rounded-lg bg-gray-50">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Add Custom Command</h3>
          <form onSubmit={handleAddCommand} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Voice Command Phrase
                </label>
                <input
                  type="text"
                  value={newCommand?.phrase}
                  onChange={(e) => setNewCommand({ ...newCommand, phrase: e?.target?.value })}
                  placeholder="e.g., create login form"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select
                  value={newCommand?.category}
                  onChange={(e) => setNewCommand({ ...newCommand, category: e?.target?.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="navigation">Navigation</option>
                  <option value="component_creation">Component Creation</option>
                  <option value="styling">Styling</option>
                  <option value="project_management">Project Management</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <input
                type="text"
                value={newCommand?.description}
                onChange={(e) => setNewCommand({ ...newCommand, description: e?.target?.value })}
                placeholder="Describe what this command does"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700"
              >
                Add Command
              </button>
            </div>
          </form>
        </div>
      )}
      {/* Commands Grid */}
      <div className="grid gap-4">
        {filteredCommands?.map((command) => {
          const Icon = getCategoryIcon(command?.category);
          return (
            <div key={command?.id} className="border border-gray-200 rounded-lg p-4 hover:border-purple-200 hover:bg-purple-50/30 transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <div className="p-1.5 bg-gray-100 rounded-lg">
                      <Icon className="h-4 w-4 text-gray-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <Mic className="h-4 w-4 text-purple-600" />
                        <code className="text-purple-700 font-medium bg-purple-50 px-2 py-1 rounded text-sm">
                          "{command?.command_phrase}"
                        </code>
                        {command?.is_custom && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            Custom
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600">
                        {command?.description}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 ml-4">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getCategoryColor(command?.category)}`}>
                    {command?.category?.replace('_', ' ')}
                  </span>
                  
                  <div className="flex items-center text-xs text-gray-500">
                    <span className="font-medium">{command?.usage_count || 0}</span>
                    <span className="ml-1">uses</span>
                  </div>
                  
                  <button
                    onClick={() => copyToClipboard(command?.command_phrase)}
                    className="p-1.5 text-gray-400 hover:text-gray-600 rounded"
                    title="Copy command"
                  >
                    <Copy className="h-4 w-4" />
                  </button>
                </div>
              </div>
              {/* Pronunciation Guide */}
              <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center text-gray-600">
                    <span className="font-medium mr-2">Pronunciation:</span>
                    <span className="italic">{command?.command_phrase}</span>
                  </div>
                  <div className="flex items-center space-x-3 text-gray-500">
                    <span>Accuracy: {Math.round(85 + Math.random() * 10)}%</span>
                    <span>Speed: Fast</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {filteredCommands?.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No commands found</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm || selectedCategory !== 'all' ?'Try adjusting your search or filter criteria' :'Add your first custom voice command to get started'
              }
            </p>
            {!searchTerm && selectedCategory === 'all' && (
              <button
                onClick={() => setShowAddForm(true)}
                className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Your First Command
              </button>
            )}
          </div>
        )}
      </div>
      {/* Quick Tips */}
      <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h4 className="font-medium text-blue-800 mb-2">💡 Voice Command Tips</h4>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• Speak clearly and at a moderate pace</li>
          <li>• Use natural language - avoid robotic commands</li>
          <li>• Commands are case-insensitive and flexible</li>
          <li>• You can combine multiple commands in one sentence</li>
        </ul>
      </div>
    </div>
  );
};

export default VoiceCommandLibrary;