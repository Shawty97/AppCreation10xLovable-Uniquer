import React, { useState } from 'react';
import { CheckCircle, Circle, Copy, Download, Code, Palette, Layers, Zap, ChevronRight, ExternalLink } from 'lucide-react';
import Icon from '../../../components/AppIcon';


const RequirementsDisplay = ({ requirements }) => {
  const [checkedItems, setCheckedItems] = useState({});
  const [activeTab, setActiveTab] = useState('overview');

  if (!requirements) return null;

  const handleToggleItem = (category, index) => {
    const key = `${category}-${index}`;
    setCheckedItems(prev => ({
      ...prev,
      [key]: !prev?.[key]
    }));
  };

  const exportRequirements = () => {
    const exportData = {
      timestamp: new Date()?.toISOString(),
      requirements,
      checkedItems
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `voice-requirements-${Date.now()}.json`;
    a?.click();
    URL.revokeObjectURL(url);
  };

  const copyToClipboard = () => {
    const text = `
Voice-to-App Requirements:

Components: ${requirements?.components?.join(', ') || 'None specified'}
Features: ${requirements?.features?.join(', ') || 'None specified'}
Styling: ${requirements?.styling?.join(', ') || 'None specified'}
Framework: ${requirements?.framework || 'Not specified'}
Complexity: ${requirements?.complexity || 'Unknown'}

Implementation Notes:
${requirements?.implementation_notes || 'No additional notes'}
    `?.trim();
    
    navigator.clipboard?.writeText(text);
  };

  const getComplexityColor = (complexity) => {
    switch (complexity?.toLowerCase()) {
      case 'simple': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'complex': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getComplexityIcon = (complexity) => {
    switch (complexity?.toLowerCase()) {
      case 'simple': return '🟢';
      case 'medium': return '🟡';
      case 'complex': return '🔴';
      default: return '⚪';
    }
  };

  const renderItemList = (items = [], category, icon) => {
    if (!items || items?.length === 0) {
      return (
        <div className="text-center py-8 text-gray-500">
          <p>No {category?.toLowerCase()} specified</p>
        </div>
      );
    }

    return (
      <div className="space-y-3">
        {items?.map((item, index) => {
          const key = `${category}-${index}`;
          const isChecked = checkedItems?.[key] || false;
          
          return (
            <div
              key={index}
              className={`flex items-center space-x-3 p-3 rounded-lg border transition-colors cursor-pointer ${
                isChecked 
                  ? 'bg-green-50 border-green-200' :'bg-white border-gray-200 hover:border-purple-200 hover:bg-purple-50/30'
              }`}
              onClick={() => handleToggleItem(category, index)}
            >
              {isChecked ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <Circle className="h-5 w-5 text-gray-400" />
              )}
              
              <div className="flex items-center space-x-2 flex-1">
                <span className="text-lg">{icon}</span>
                <span className={`font-medium ${isChecked ? 'text-green-800 line-through' : 'text-gray-900'}`}>
                  {item}
                </span>
              </div>
              
              <ChevronRight className={`h-4 w-4 text-gray-400 transition-transform ${isChecked ? 'rotate-90' : ''}`} />
            </div>
          );
        })}
      </div>
    );
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Layers },
    { id: 'components', label: 'Components', icon: Code },
    { id: 'features', label: 'Features', icon: Zap },
    { id: 'styling', label: 'Styling', icon: Palette }
  ];

  const completedCount = Object.values(checkedItems)?.filter(Boolean)?.length;
  const totalCount = (requirements?.components?.length || 0) + 
                     (requirements?.features?.length || 0) + 
                     (requirements?.styling?.length || 0);

  return (
    <div className="bg-white border border-gray-200 rounded-lg">
      {/* Header */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">AI-Extracted Requirements</h3>
            <p className="text-sm text-gray-600 mt-1">
              Based on your voice input, here's what I understood
            </p>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="text-sm text-gray-600">
              {completedCount}/{totalCount} completed
            </div>
            
            <div className="flex space-x-2">
              <button
                onClick={copyToClipboard}
                className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
                title="Copy to clipboard"
              >
                <Copy className="h-4 w-4" />
              </button>
              
              <button
                onClick={exportRequirements}
                className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
                title="Export requirements"
              >
                <Download className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        {totalCount > 0 && (
          <div className="mt-3">
            <div className="flex items-center justify-between text-xs text-gray-600 mb-1">
              <span>Implementation Progress</span>
              <span>{Math.round((completedCount / totalCount) * 100)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${(completedCount / totalCount) * 100}%` }}
              />
            </div>
          </div>
        )}
      </div>
      {/* Tabs */}
      <div className="border-b border-gray-200">
        <div className="flex space-x-0">
          {tabs?.map((tab) => {
            const Icon = tab?.icon;
            return (
              <button
                key={tab?.id}
                onClick={() => setActiveTab(tab?.id)}
                className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab?.id
                    ? 'border-purple-500 text-purple-600 bg-purple-50/30' :'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{tab?.label}</span>
              </button>
            );
          })}
        </div>
      </div>
      {/* Content */}
      <div className="p-6">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Summary Cards */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Code className="h-5 w-5 text-blue-600" />
                  <span className="font-medium text-blue-800">Components</span>
                </div>
                <div className="text-2xl font-bold text-blue-900">
                  {requirements?.components?.length || 0}
                </div>
              </div>
              
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Zap className="h-5 w-5 text-green-600" />
                  <span className="font-medium text-green-800">Features</span>
                </div>
                <div className="text-2xl font-bold text-green-900">
                  {requirements?.features?.length || 0}
                </div>
              </div>
              
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Palette className="h-5 w-5 text-purple-600" />
                  <span className="font-medium text-purple-800">Styling</span>
                </div>
                <div className="text-2xl font-bold text-purple-900">
                  {requirements?.styling?.length || 0}
                </div>
              </div>
              
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-lg">{getComplexityIcon(requirements?.complexity)}</span>
                  <span className="font-medium text-orange-800">Complexity</span>
                </div>
                <div className="text-lg font-bold text-orange-900 capitalize">
                  {requirements?.complexity || 'Unknown'}
                </div>
              </div>
            </div>

            {/* Quick Overview */}
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-3">Project Overview</h4>
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium text-gray-700">Framework:</span>
                  <span className="ml-2 text-gray-600">{requirements?.framework || 'Not specified'}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Complexity:</span>
                  <span className={`ml-2 px-2 py-0.5 rounded-full text-xs font-medium ${getComplexityColor(requirements?.complexity)}`}>
                    {requirements?.complexity || 'Unknown'}
                  </span>
                </div>
              </div>
              
              {requirements?.implementation_notes && (
                <div className="mt-3 pt-3 border-t border-gray-200">
                  <span className="font-medium text-gray-700">Notes:</span>
                  <p className="mt-1 text-gray-600">{requirements?.implementation_notes}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'components' && (
          <div>
            <h4 className="font-medium text-gray-900 mb-4">Components to Create</h4>
            {renderItemList(requirements?.components, 'components', '⚙️')}
          </div>
        )}

        {activeTab === 'features' && (
          <div>
            <h4 className="font-medium text-gray-900 mb-4">Features to Implement</h4>
            {renderItemList(requirements?.features, 'features', '✨')}
          </div>
        )}

        {activeTab === 'styling' && (
          <div>
            <h4 className="font-medium text-gray-900 mb-4">Styling Requirements</h4>
            {renderItemList(requirements?.styling, 'styling', '🎨')}
          </div>
        )}
      </div>
      {/* Action Buttons */}
      <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 rounded-b-lg">
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-600">
            Ready to start building? Use these requirements as your development guide.
          </div>
          
          <div className="flex space-x-3">
            <button className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors">
              <ExternalLink className="h-4 w-4 mr-2" />
              Create Project
            </button>
            
            <button className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-md text-sm font-medium hover:bg-purple-700 transition-colors">
              <Code className="h-4 w-4 mr-2" />
              Generate Code
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequirementsDisplay;