import React, { useState, useRef, useEffect } from 'react';
import { Settings, Mic, Save, Volume2, Languages, Target, Award, TrendingUp } from 'lucide-react';

const VoiceTrainingModule = ({ settings, onUpdateSettings }) => {
  const [isTraining, setIsTraining] = useState(false);
  const [trainingStep, setTrainingStep] = useState(0);
  const [accuracy, setAccuracy] = useState(85);
  const [voiceProfile, setVoiceProfile] = useState({
    accent: 'General American',
    speed: 'Medium',
    clarity: 'Good',
    adaptations: 12
  });

  const trainingPhrases = [
    "Create a new dashboard component",
    "Add responsive navigation menu",
    "Implement user authentication",
    "Style with primary colors",
    "Make the layout mobile-friendly",
    "Add dark mode toggle",
    "Create a contact form",
    "Deploy to production"
  ];

  const [currentPhrase, setCurrentPhrase] = useState(trainingPhrases?.[0]);
  const [recordedText, setRecordedText] = useState('');
  const [trainingProgress, setTrainingProgress] = useState(0);

  const handleTrainingStart = () => {
    setIsTraining(true);
    setTrainingStep(0);
    setTrainingProgress(0);
    setCurrentPhrase(trainingPhrases?.[0]);
  };

  const handleNextPhrase = () => {
    const nextStep = trainingStep + 1;
    if (nextStep < trainingPhrases?.length) {
      setTrainingStep(nextStep);
      setCurrentPhrase(trainingPhrases?.[nextStep]);
      setTrainingProgress(((nextStep + 1) / trainingPhrases?.length) * 100);
    } else {
      setIsTraining(false);
      setTrainingProgress(100);
      // Simulate accuracy improvement
      setAccuracy(prev => Math.min(98, prev + Math.random() * 5));
    }
  };

  const handleSettingChange = (key, value) => {
    const newSettings = { ...settings, [key]: value };
    onUpdateSettings?.(newSettings);
  };

  const languages = [
    { code: 'en-US', name: 'English (US)', flag: '🇺🇸' },
    { code: 'en-GB', name: 'English (UK)', flag: '🇬🇧' },
    { code: 'es-ES', name: 'Spanish', flag: '🇪🇸' },
    { code: 'fr-FR', name: 'French', flag: '🇫🇷' },
    { code: 'de-DE', name: 'German', flag: '🇩🇪' },
    { code: 'it-IT', name: 'Italian', flag: '🇮🇹' },
    { code: 'pt-BR', name: 'Portuguese (Brazil)', flag: '🇧🇷' },
    { code: 'zh-CN', name: 'Chinese (Mandarin)', flag: '🇨🇳' }
  ];

  const getAccuracyColor = (acc) => {
    if (acc >= 95) return 'text-green-600';
    if (acc >= 85) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getAccuracyBg = (acc) => {
    if (acc >= 95) return 'bg-green-100 border-green-200';
    if (acc >= 85) return 'bg-yellow-100 border-yellow-200';
    return 'bg-red-100 border-red-200';
  };

  return (
    <div className="space-y-8">
      {/* Voice Profile Overview */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <Target className="h-6 w-6 text-purple-600" />
          <h2 className="text-xl font-semibold text-gray-900">Voice Training & Calibration</h2>
        </div>

        <div className="grid md:grid-cols-4 gap-4 mb-6">
          <div className={`p-4 rounded-lg border ${getAccuracyBg(accuracy)}`}>
            <div className="flex items-center space-x-2 mb-2">
              <Award className="h-5 w-5 text-purple-600" />
              <span className="font-medium text-gray-900">Accuracy</span>
            </div>
            <div className={`text-2xl font-bold ${getAccuracyColor(accuracy)}`}>
              {Math.round(accuracy)}%
            </div>
          </div>

          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Languages className="h-5 w-5 text-blue-600" />
              <span className="font-medium text-gray-900">Accent</span>
            </div>
            <div className="text-lg font-semibold text-blue-900">
              {voiceProfile?.accent}
            </div>
          </div>

          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Volume2 className="h-5 w-5 text-green-600" />
              <span className="font-medium text-gray-900">Clarity</span>
            </div>
            <div className="text-lg font-semibold text-green-900">
              {voiceProfile?.clarity}
            </div>
          </div>

          <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <TrendingUp className="h-5 w-5 text-orange-600" />
              <span className="font-medium text-gray-900">Adaptations</span>
            </div>
            <div className="text-lg font-semibold text-orange-900">
              {voiceProfile?.adaptations}
            </div>
          </div>
        </div>

        {/* Training Session */}
        <div className="bg-gray-50 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Accuracy Training</h3>
            {!isTraining ? (
              <button
                onClick={handleTrainingStart}
                className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
              >
                <Mic className="h-4 w-4 mr-2" />
                Start Training
              </button>
            ) : (
              <div className="flex items-center space-x-3">
                <div className="text-sm text-gray-600">
                  {trainingStep + 1} of {trainingPhrases?.length}
                </div>
                <button
                  onClick={() => setIsTraining(false)}
                  className="px-3 py-1 text-sm text-gray-600 border border-gray-300 rounded hover:bg-gray-50"
                >
                  Stop
                </button>
              </div>
            )}
          </div>

          {isTraining && (
            <div className="space-y-4">
              {/* Progress Bar */}
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${trainingProgress}%` }}
                />
              </div>

              {/* Training Phrase */}
              <div className="bg-white rounded-lg p-4 border">
                <div className="text-sm text-gray-600 mb-2">Please read this phrase clearly:</div>
                <div className="text-lg font-medium text-gray-900 mb-4">
                  "{currentPhrase}"
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <button className="p-3 bg-red-500 text-white rounded-full hover:bg-red-600">
                      <Mic className="h-5 w-5" />
                    </button>
                    <div className="text-sm text-gray-600">
                      Click to record this phrase
                    </div>
                  </div>
                  
                  <button
                    onClick={handleNextPhrase}
                    className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                  >
                    Next Phrase
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {!isTraining && trainingProgress === 100 && (
            <div className="text-center py-8">
              <Award className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Training Complete!</h3>
              <p className="text-gray-600">Your voice profile has been updated with improved accuracy.</p>
            </div>
          )}
        </div>
      </div>
      {/* Voice Settings */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <Settings className="h-6 w-6 text-purple-600" />
          <h2 className="text-xl font-semibold text-gray-900">Voice Settings</h2>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Language Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Language & Region
            </label>
            <select
              value={settings?.language || 'en-US'}
              onChange={(e) => handleSettingChange('language', e?.target?.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              {languages?.map((lang) => (
                <option key={lang?.code} value={lang?.code}>
                  {lang?.flag} {lang?.name}
                </option>
              ))}
            </select>
          </div>

          {/* Sensitivity */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Voice Sensitivity: {Math.round((settings?.sensitivity || 0.7) * 100)}%
            </label>
            <input
              type="range"
              min="0.1"
              max="1"
              step="0.1"
              value={settings?.sensitivity || 0.7}
              onChange={(e) => handleSettingChange('sensitivity', parseFloat(e?.target?.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>Less Sensitive</span>
              <span>More Sensitive</span>
            </div>
          </div>

          {/* Pause Threshold */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Pause Detection: {settings?.pauseThreshold || 2000}ms
            </label>
            <input
              type="range"
              min="500"
              max="5000"
              step="250"
              value={settings?.pauseThreshold || 2000}
              onChange={(e) => handleSettingChange('pauseThreshold', parseInt(e?.target?.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>Quick (500ms)</span>
              <span>Slow (5s)</span>
            </div>
          </div>

          {/* Real-time Transcription */}
          <div>
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-700">
                Real-time Transcription
              </label>
              <button
                onClick={() => handleSettingChange('enableRealTimeTranscription', !settings?.enableRealTimeTranscription)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  settings?.enableRealTimeTranscription ? 'bg-purple-600' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    settings?.enableRealTimeTranscription ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Show text as you speak in real-time
            </p>
          </div>
        </div>

        {/* Advanced Settings */}
        <div className="mt-8 pt-6 border-t border-gray-200">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Advanced Settings</h3>
          
          <div className="grid md:grid-cols-3 gap-4">
            <div className="p-4 border border-gray-200 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">Noise Reduction</h4>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Auto Filter</span>
                <input type="checkbox" defaultChecked className="rounded text-purple-600" />
              </div>
            </div>
            
            <div className="p-4 border border-gray-200 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">Echo Cancellation</h4>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Enabled</span>
                <input type="checkbox" defaultChecked className="rounded text-purple-600" />
              </div>
            </div>
            
            <div className="p-4 border border-gray-200 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">Auto Gain Control</h4>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Adaptive</span>
                <input type="checkbox" defaultChecked className="rounded text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Save Settings */}
        <div className="flex justify-end mt-6">
          <button className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors">
            <Save className="h-4 w-4 mr-2" />
            Save Settings
          </button>
        </div>
      </div>
      {/* Tips and Best Practices */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="font-medium text-blue-800 mb-4">🎯 Voice Training Tips</h3>
        <div className="grid md:grid-cols-2 gap-4 text-sm text-blue-700">
          <div>
            <h4 className="font-medium mb-2">For Better Accuracy:</h4>
            <ul className="space-y-1">
              <li>• Speak at a consistent pace</li>
              <li>• Use a quiet environment</li>
              <li>• Keep microphone at consistent distance</li>
              <li>• Avoid background noise</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-2">Training Frequency:</h4>
            <ul className="space-y-1">
              <li>• Train weekly for best results</li>
              <li>• Complete full sessions when possible</li>
              <li>• Practice with technical vocabulary</li>
              <li>• Record in different conditions</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VoiceTrainingModule;