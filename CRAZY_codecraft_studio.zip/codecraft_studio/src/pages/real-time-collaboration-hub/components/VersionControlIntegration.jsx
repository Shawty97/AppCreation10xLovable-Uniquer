import React, { useState } from 'react';
import { GitBranch, GitCommit, GitMerge, GitPullRequest, Users, MessageSquare, CheckCircle, Code, Plus, ArrowRight, Eye } from 'lucide-react';

const VersionControlIntegration = () => {
  const [activeBranch, setActiveBranch] = useState('feature/collaboration-hub');
  const [pullRequests, setPullRequests] = useState([
    {
      id: 1,
      title: 'Add real-time collaboration features',
      author: 'Alex Chen',
      branch: 'feature/collaboration-hub',
      target: 'main',
      status: 'open',
      reviewers: ['Sarah Kim', 'Mike Johnson'],
      comments: 5,
      commits: 8,
      changes: { additions: 234, deletions: 45 },
      timestamp: new Date(Date.now() - 3600000)
    },
    {
      id: 2,
      title: 'Fix chat panel styling issues',
      author: 'Sarah Kim',
      branch: 'fix/chat-styling',
      target: 'develop',
      status: 'review',
      reviewers: ['Alex Chen'],
      comments: 2,
      commits: 3,
      changes: { additions: 56, deletions: 12 },
      timestamp: new Date(Date.now() - 7200000)
    }
  ]);
  
  const [branches, setBranches] = useState([
    { name: 'main', active: false, protected: true, lastCommit: '2 hours ago' },
    { name: 'develop', active: false, protected: false, lastCommit: '30 minutes ago' },
    { name: 'feature/collaboration-hub', active: true, protected: false, lastCommit: 'Just now' },
    { name: 'fix/chat-styling', active: false, protected: false, lastCommit: '1 hour ago' }
  ]);

  const [commitHistory, setCommitHistory] = useState([
    {
      hash: 'a1b2c3d',
      message: 'Add collaborative debugging tools',
      author: 'Alex Chen',
      timestamp: new Date(Date.now() - 1800000),
      branch: 'feature/collaboration-hub'
    },
    {
      hash: 'e4f5g6h',
      message: 'Implement screen sharing functionality',
      author: 'Alex Chen',
      timestamp: new Date(Date.now() - 3600000),
      branch: 'feature/collaboration-hub'
    },
    {
      hash: 'i7j8k9l',
      message: 'Fix chat panel responsiveness',
      author: 'Sarah Kim',
      timestamp: new Date(Date.now() - 5400000),
      branch: 'fix/chat-styling'
    }
  ]);

  const getStatusColor = (status) => {
    switch (status) {
      case 'open': return 'text-green-600 bg-green-100';
      case 'review': return 'text-yellow-600 bg-yellow-100';
      case 'merged': return 'text-blue-600 bg-blue-100';
      case 'closed': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = Math.floor((now - timestamp) / 1000);
    
    if (diff < 60) return `${diff}s ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return timestamp?.toLocaleDateString();
  };

  return (
    <div className="space-y-6">
      {/* Version Control Overview */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <GitBranch className="w-5 h-5 mr-2 text-blue-600" />
            Version Control Integration
          </h3>
          
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">
              Repository: <span className="font-medium">codecraft-studio</span>
            </span>
            <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              <Plus className="w-4 h-4" />
              <span>New Branch</span>
            </button>
          </div>
        </div>

        {/* Repository Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{branches?.length}</div>
            <div className="text-sm text-blue-700">Active Branches</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{pullRequests?.filter(pr => pr?.status === 'open')?.length}</div>
            <div className="text-sm text-green-700">Open PRs</div>
          </div>
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600">{pullRequests?.filter(pr => pr?.status === 'review')?.length}</div>
            <div className="text-sm text-yellow-700">In Review</div>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">{commitHistory?.length}</div>
            <div className="text-sm text-purple-700">Recent Commits</div>
          </div>
        </div>

        {/* Current Branch Info */}
        <div className="p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <GitBranch className="w-5 h-5 text-blue-600" />
              <span className="font-medium text-gray-900">Current Branch:</span>
              <span className="font-mono bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                {activeBranch}
              </span>
            </div>
            
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                <Users className="w-4 h-4 inline mr-1" />
                3 collaborators
              </span>
              <button className="text-blue-600 hover:text-blue-700 font-medium text-sm">
                Switch Branch
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pull Requests */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h4 className="font-semibold text-gray-900 flex items-center">
              <GitPullRequest className="w-4 h-4 mr-2" />
              Pull Requests
            </h4>
          </div>

          <div className="divide-y divide-gray-200">
            {pullRequests?.map((pr) => (
              <div key={pr?.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h5 className="font-medium text-gray-900 mb-2">{pr?.title}</h5>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span>#{pr?.id}</span>
                      <span>by {pr?.author}</span>
                      <span>{formatTimeAgo(pr?.timestamp)}</span>
                    </div>
                  </div>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(pr?.status)}`}>
                    {pr?.status}
                  </span>
                </div>

                <div className="flex items-center space-x-4 mb-3">
                  <div className="flex items-center space-x-2 text-sm">
                    <GitBranch className="w-4 h-4 text-gray-400" />
                    <span className="font-mono bg-gray-100 px-2 py-1 rounded text-xs">
                      {pr?.branch}
                    </span>
                    <ArrowRight className="w-3 h-3 text-gray-400" />
                    <span className="font-mono bg-gray-100 px-2 py-1 rounded text-xs">
                      {pr?.target}
                    </span>
                  </div>
                </div>

                <div className="flex items-center space-x-6 text-sm text-gray-600">
                  <span className="flex items-center space-x-1">
                    <GitCommit className="w-4 h-4" />
                    <span>{pr?.commits} commits</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <MessageSquare className="w-4 h-4" />
                    <span>{pr?.comments} comments</span>
                  </span>
                  <span className="text-green-600">+{pr?.changes?.additions}</span>
                  <span className="text-red-600">-{pr?.changes?.deletions}</span>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-600">Reviewers:</span>
                    <div className="flex items-center -space-x-1">
                      {pr?.reviewers?.map((reviewer, index) => (
                        <div
                          key={index}
                          className="w-6 h-6 bg-gray-300 rounded-full border-2 border-white flex items-center justify-center text-xs font-medium text-gray-600"
                        >
                          {reviewer?.charAt(0)}
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <button className="px-3 py-1 text-blue-600 hover:text-blue-700 text-sm font-medium">
                      <Eye className="w-3 h-3 inline mr-1" />
                      Review
                    </button>
                    {pr?.status === 'open' && (
                      <button className="px-3 py-1 bg-green-100 text-green-800 rounded hover:bg-green-200 text-sm font-medium">
                        <GitMerge className="w-3 h-3 inline mr-1" />
                        Merge
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Branches & Commits */}
        <div className="space-y-6">
          {/* Branch List */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h4 className="font-semibold text-gray-900 flex items-center">
                <GitBranch className="w-4 h-4 mr-2" />
                Branches
              </h4>
            </div>

            <div className="divide-y divide-gray-200">
              {branches?.map((branch, index) => (
                <div key={index} className="p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <GitBranch className={`w-4 h-4 ${branch?.active ? 'text-green-600' : 'text-gray-400'}`} />
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className={`font-medium ${branch?.active ? 'text-green-900' : 'text-gray-900'}`}>
                            {branch?.name}
                          </span>
                          {branch?.protected && (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                              Protected
                            </span>
                          )}
                          {branch?.active && (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              Current
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-gray-500">
                          Last commit {branch?.lastCommit}
                        </div>
                      </div>
                    </div>
                    
                    {!branch?.active && (
                      <button
                        onClick={() => setActiveBranch(branch?.name)}
                        className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                      >
                        Switch
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Commits */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h4 className="font-semibold text-gray-900 flex items-center">
                <GitCommit className="w-4 h-4 mr-2" />
                Recent Commits
              </h4>
            </div>

            <div className="divide-y divide-gray-200">
              {commitHistory?.map((commit, index) => (
                <div key={index} className="p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                      <GitCommit className="w-4 h-4 text-gray-600" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-gray-900 mb-1">
                        {commit?.message}
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span>{commit?.author}</span>
                        <span className="font-mono bg-gray-100 px-2 py-0.5 rounded">
                          {commit?.hash}
                        </span>
                        <span>{formatTimeAgo(commit?.timestamp)}</span>
                      </div>
                      <div className="mt-1">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                          {commit?.branch}
                        </span>
                      </div>
                    </div>
                    
                    <button className="text-gray-400 hover:text-gray-600">
                      <Code className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-4 border-t border-gray-200 text-center">
              <button className="text-blue-600 hover:text-blue-700 font-medium text-sm">
                View All Commits
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Branch-specific Collaboration */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h4 className="font-semibold text-gray-900 mb-4">Branch-specific Discussions</h4>
        
        <div className="space-y-4">
          <div className="flex items-start space-x-4 p-4 bg-blue-50 rounded-lg">
            <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
              <MessageSquare className="w-4 h-4 text-blue-600" />
            </div>
            
            <div className="flex-1">
              <div className="font-medium text-blue-900 mb-1">
                Discussion: Real-time collaboration implementation
              </div>
              <div className="text-sm text-blue-700 mb-2">
                "Should we use WebSockets or Server-Sent Events for real-time updates?"
              </div>
              <div className="flex items-center space-x-4 text-sm text-blue-600">
                <span>Alex Chen</span>
                <span>•</span>
                <span>feature/collaboration-hub</span>
                <span>•</span>
                <span>3 replies</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-start space-x-4 p-4 bg-green-50 rounded-lg">
            <div className="flex-shrink-0 w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="w-4 h-4 text-green-600" />
            </div>
            
            <div className="flex-1">
              <div className="font-medium text-green-900 mb-1">
                Code Review: Chat styling fixes
              </div>
              <div className="text-sm text-green-700 mb-2">
                "LGTM! The responsive design improvements look great."
              </div>
              <div className="flex items-center space-x-4 text-sm text-green-600">
                <span>Mike Johnson approved</span>
                <span>•</span>
                <span>fix/chat-styling</span>
                <span>•</span>
                <span>Ready to merge</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VersionControlIntegration;