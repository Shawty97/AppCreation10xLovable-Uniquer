import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Paperclip, 
  Code, 
  AtSign, 
  Hash, 
  Smile, 
  MoreVertical,
  Reply,
  Search,
  Filter
} from 'lucide-react';

const ChatPanel = ({ fullView = false }) => {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [activeThread, setActiveThread] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef(null);

  useEffect(() => {
    // Mock chat messages
    setMessages([
      {
        id: 1,
        user: 'Alex Chen',
        avatar: '/api/placeholder/32/32',
        message: 'Just pushed the header component updates. Can everyone review?',
        timestamp: new Date(Date.now() - 300000),
        type: 'text',
        mentions: [],
        reactions: { '👍': 2, '✅': 1 },
        replies: []
      },
      {
        id: 2,
        user: 'Sarah Kim',
        avatar: '/api/placeholder/32/32',
        message: '@Alex looks great! Quick question about the responsive breakpoints:',
        timestamp: new Date(Date.now() - 240000),
        type: 'text',
        mentions: ['Alex Chen'],
        codeSnippet: {
          language: 'css',
          code: `@media (max-width: 768px) {
  .header { padding: 1rem; }
}`
        },
        replies: []
      },
      {
        id: 3,
        user: 'Mike Johnson',
        avatar: '/api/placeholder/32/32',
        message: 'I can help test this on different devices. Screen sharing in 5?',
        timestamp: new Date(Date.now() - 180000),
        type: 'text',
        mentions: [],
        replies: [
          {
            id: 4,
            user: 'Alex Chen',
            avatar: '/api/placeholder/32/32',
            message: 'Perfect! I\'ll start the screen share session.',
            timestamp: new Date(Date.now() - 120000)
          }
        ]
      }
    ]);
  }, []);

  const scrollToBottom = () => {
    messagesEndRef?.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (e) => {
    e?.preventDefault();
    if (!message?.trim()) return;

    const newMessage = {
      id: Date.now(),
      user: 'You',
      avatar: '/api/placeholder/32/32',
      message: message,
      timestamp: new Date(),
      type: 'text',
      mentions: message?.match(/@\w+/g) || [],
      replies: []
    };

    if (activeThread) {
      setMessages(prev => prev?.map(msg => 
        msg?.id === activeThread 
          ? { ...msg, replies: [...msg?.replies, newMessage] }
          : msg
      ));
    } else {
      setMessages(prev => [...prev, newMessage]);
    }

    setMessage('');
  };

  const handleReaction = (messageId, emoji) => {
    setMessages(prev => prev?.map(msg => {
      if (msg?.id === messageId) {
        const reactions = { ...msg?.reactions };
        reactions[emoji] = (reactions?.[emoji] || 0) + 1;
        return { ...msg, reactions };
      }
      return msg;
    }));
  };

  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return timestamp?.toLocaleDateString();
  };

  const MessageComponent = ({ msg, isReply = false }) => (
    <div className={`flex space-x-3 ${isReply ? 'ml-6 mt-2' : 'mb-4'}`}>
      <img
        src={msg?.avatar}
        alt={msg?.user}
        className="w-8 h-8 rounded-full flex-shrink-0"
      />
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center space-x-2 mb-1">
          <span className="font-medium text-sm text-gray-900">{msg?.user}</span>
          <span className="text-xs text-gray-500">{formatTimestamp(msg?.timestamp)}</span>
        </div>
        
        <div className="text-sm text-gray-800 break-words">
          {msg?.message}
        </div>
        
        {msg?.codeSnippet && (
          <div className="mt-2 bg-gray-900 rounded-lg p-3 overflow-x-auto">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-400 uppercase tracking-wide">
                {msg?.codeSnippet?.language}
              </span>
              <button className="text-gray-400 hover:text-white">
                <Code className="w-4 h-4" />
              </button>
            </div>
            <pre className="text-sm text-gray-100">
              <code>{msg?.codeSnippet?.code}</code>
            </pre>
          </div>
        )}
        
        {msg?.reactions && Object.keys(msg?.reactions)?.length > 0 && (
          <div className="flex items-center space-x-1 mt-2">
            {Object.entries(msg?.reactions)?.map(([emoji, count]) => (
              <button
                key={emoji}
                onClick={() => handleReaction(msg?.id, emoji)}
                className="flex items-center space-x-1 px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded-full text-xs transition-colors"
              >
                <span>{emoji}</span>
                <span>{count}</span>
              </button>
            ))}
            <button 
              onClick={() => handleReaction(msg?.id, '👍')}
              className="p-1 text-gray-400 hover:text-gray-600 rounded transition-colors"
            >
              <Smile className="w-4 h-4" />
            </button>
          </div>
        )}
        
        {!isReply && (
          <div className="flex items-center space-x-3 mt-2">
            <button 
              onClick={() => setActiveThread(activeThread === msg?.id ? null : msg?.id)}
              className="text-xs text-blue-600 hover:text-blue-700 font-medium"
            >
              <Reply className="w-3 h-3 inline mr-1" />
              {msg?.replies?.length > 0 ? `${msg?.replies?.length} replies` : 'Reply'}
            </button>
            <button className="text-xs text-gray-500 hover:text-gray-600">
              <MoreVertical className="w-3 h-3" />
            </button>
          </div>
        )}
        
        {/* Thread Replies */}
        {activeThread === msg?.id && msg?.replies?.length > 0 && (
          <div className="mt-3 pl-4 border-l-2 border-gray-200">
            {msg?.replies?.map(reply => (
              <MessageComponent key={reply?.id} msg={reply} isReply />
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className={`bg-white rounded-lg shadow-sm border border-gray-200 flex flex-col ${fullView ? 'h-full' : 'h-96'}`}>
      {/* Chat Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Hash className="w-5 h-5 text-gray-400" />
            <h3 className="font-semibold text-gray-900">Project Discussion</h3>
            <span className="text-sm text-gray-500">• 3 members</span>
          </div>
          
          {fullView && (
            <div className="flex items-center space-x-2">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search messages..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e?.target?.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <button className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100">
                <Filter className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        {messages?.filter(msg => !searchQuery || msg?.message?.toLowerCase()?.includes(searchQuery?.toLowerCase()) || msg?.user?.toLowerCase()?.includes(searchQuery?.toLowerCase()))?.map(msg => (
            <MessageComponent key={msg?.id} msg={msg} />
          ))}
        <div ref={messagesEndRef} />
      </div>
      {/* Active Thread Indicator */}
      {activeThread && (
        <div className="px-4 py-2 bg-blue-50 border-t border-blue-200 text-sm text-blue-700">
          Replying to thread
          <button 
            onClick={() => setActiveThread(null)}
            className="ml-2 text-blue-600 hover:text-blue-800 font-medium"
          >
            Cancel
          </button>
        </div>
      )}
      {/* Message Input */}
      <div className="p-4 border-t border-gray-200">
        <form onSubmit={handleSendMessage} className="flex space-x-2">
          <div className="flex-1 relative">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e?.target?.value)}
              placeholder={activeThread ? "Reply to thread..." : "Type a message... Use @name to mention"}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            
            <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
              <button
                type="button"
                className="p-1 text-gray-400 hover:text-gray-600 rounded"
              >
                <Code className="w-4 h-4" />
              </button>
              <button
                type="button"
                className="p-1 text-gray-400 hover:text-gray-600 rounded"
              >
                <AtSign className="w-4 h-4" />
              </button>
              <button
                type="button"
                className="p-1 text-gray-400 hover:text-gray-600 rounded"
              >
                <Paperclip className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          <button
            type="submit"
            disabled={!message?.trim()}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
        
        <div className="mt-2 text-xs text-gray-500">
          Press Enter to send, Shift+Enter for new line
        </div>
      </div>
    </div>
  );
};

export default ChatPanel;