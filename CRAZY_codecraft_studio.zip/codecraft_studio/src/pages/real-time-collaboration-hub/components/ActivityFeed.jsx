import React, { useState } from 'react';
import { Activity, User, MessageSquare, GitBranch, Settings, Clock, Filter, Search, Edit3, Plus, Trash2, Eye } from 'lucide-react';

const ActivityFeed = ({ activities = [] }) => {
  const [filter, setFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [timeRange, setTimeRange] = useState('today');

  const getActivityIcon = (type) => {
    switch (type) {
      case 'edit': return Edit3;
      case 'comment': return MessageSquare;
      case 'session': return User;
      case 'version': return GitBranch;
      case 'create': return Plus;
      case 'delete': return Trash2;
      case 'view': return Eye;
      default: return Activity;
    }
  };

  const getActivityColor = (type) => {
    switch (type) {
      case 'edit': return 'text-blue-600 bg-blue-100';
      case 'comment': return 'text-green-600 bg-green-100';
      case 'session': return 'text-purple-600 bg-purple-100';
      case 'version': return 'text-orange-600 bg-orange-100';
      case 'create': return 'text-emerald-600 bg-emerald-100';
      case 'delete': return 'text-red-600 bg-red-100';
      case 'view': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diff = Math.floor((now - timestamp) / 1000);
    
    if (diff < 60) return `${diff} seconds ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)} minutes ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} hours ago`;
    return timestamp?.toLocaleDateString();
  };

  const filteredActivities = activities?.filter(activity => {
    const matchesFilter = filter === 'all' || activity?.type === filter;
    const matchesSearch = !searchQuery || 
      activity?.user?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
      activity?.target?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
      activity?.action?.toLowerCase()?.includes(searchQuery?.toLowerCase());
    
    let matchesTimeRange = true;
    if (timeRange !== 'all') {
      const now = new Date();
      const activityDate = new Date(activity.timestamp);
      const timeDiff = now - activityDate;
      
      switch (timeRange) {
        case 'today':
          matchesTimeRange = timeDiff < 24 * 60 * 60 * 1000;
          break;
        case 'week':
          matchesTimeRange = timeDiff < 7 * 24 * 60 * 60 * 1000;
          break;
        case 'month':
          matchesTimeRange = timeDiff < 30 * 24 * 60 * 60 * 1000;
          break;
      }
    }
    
    return matchesFilter && matchesSearch && matchesTimeRange;
  }) || [];

  const filterOptions = [
    { value: 'all', label: 'All Activities', count: activities?.length || 0 },
    { value: 'edit', label: 'Edits', count: activities?.filter(a => a?.type === 'edit')?.length || 0 },
    { value: 'comment', label: 'Comments', count: activities?.filter(a => a?.type === 'comment')?.length || 0 },
    { value: 'session', label: 'Sessions', count: activities?.filter(a => a?.type === 'session')?.length || 0 },
    { value: 'version', label: 'Version Control', count: activities?.filter(a => a?.type === 'version')?.length || 0 }
  ];

  return (
    <div className="space-y-6">
      {/* Activity Controls */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Activity className="w-5 h-5 mr-2 text-blue-600" />
            Team Activity Feed
          </h3>
          
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search activities..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e?.target?.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            {/* Time Range Filter */}
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e?.target?.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Time</option>
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
            </select>
          </div>
        </div>

        {/* Activity Type Filters */}
        <div className="flex flex-wrap gap-2 mb-6">
          {filterOptions?.map(option => (
            <button
              key={option?.value}
              onClick={() => setFilter(option?.value)}
              className={`inline-flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                filter === option?.value
                  ? 'bg-blue-100 text-blue-700 border border-blue-200' :'bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200'
              }`}
            >
              <span>{option?.label}</span>
              <span className="bg-white bg-opacity-70 px-2 py-0.5 rounded-full text-xs">
                {option?.count}
              </span>
            </button>
          ))}
        </div>

        {/* Activity Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">
              {activities?.filter(a => a?.type === 'edit')?.length || 0}
            </div>
            <div className="text-sm text-blue-700">Edits Today</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">
              {activities?.filter(a => a?.type === 'comment')?.length || 0}
            </div>
            <div className="text-sm text-green-700">Comments</div>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">3</div>
            <div className="text-sm text-purple-700">Active Users</div>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <div className="text-2xl font-bold text-orange-600">
              {activities?.filter(a => a?.type === 'session')?.length || 0}
            </div>
            <div className="text-sm text-orange-700">Sessions</div>
          </div>
        </div>
      </div>
      {/* Activity Timeline */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h4 className="font-semibold text-gray-900">Recent Activities</h4>
            <span className="text-sm text-gray-500">
              Showing {filteredActivities?.length} of {activities?.length || 0} activities
            </span>
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {filteredActivities?.map((activity) => {
            const ActivityIcon = getActivityIcon(activity?.type);
            const iconColor = getActivityColor(activity?.type);
            
            return (
              <div key={activity?.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex space-x-4">
                  <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${iconColor}`}>
                    <ActivityIcon className="w-5 h-5" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="font-medium text-gray-900">{activity?.user}</span>
                      <span className="text-gray-600">{activity?.action}</span>
                      <span className="font-medium text-gray-900">{activity?.target}</span>
                    </div>
                    
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {formatTimestamp(activity?.timestamp)}
                      </span>
                      
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700 capitalize">
                        {activity?.type}
                      </span>
                    </div>
                    
                    {/* Additional Context */}
                    {activity?.type === 'edit' && (
                      <div className="mt-2 text-sm text-gray-600">
                        <span className="text-green-600">+12 lines</span>
                        <span className="text-red-600 ml-2">-5 lines</span>
                      </div>
                    )}
                    
                    {activity?.type === 'comment' && (
                      <div className="mt-2 p-3 bg-gray-50 rounded-lg text-sm text-gray-700">
                        "This looks great! Should we also add error handling here?"
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-shrink-0">
                    <button className="text-gray-400 hover:text-gray-600 p-1 rounded transition-colors">
                      <Settings className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
          
          {filteredActivities?.length === 0 && (
            <div className="p-12 text-center">
              <Activity className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Activities Found</h3>
              <p className="text-gray-600">
                {searchQuery || filter !== 'all' ?'Try adjusting your filters or search query.' :'Team activities will appear here as they happen.'
                }
              </p>
            </div>
          )}
        </div>
        
        {filteredActivities?.length > 0 && (
          <div className="p-6 border-t border-gray-200 text-center">
            <button className="text-blue-600 hover:text-blue-700 font-medium">
              Load More Activities
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ActivityFeed;