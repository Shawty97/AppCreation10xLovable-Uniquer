import React, { useState, useRef } from 'react';
import { Monitor, Users, Mic, MicOff, Video, VideoOff, Settings, Maximize, Minimize, Play, Square, Volume2 } from 'lucide-react';



const ScreenShare = ({ isActive = false, isRecording = false, collaborators = [] }) => {
  const [isPresenting, setIsPresenting] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [videoEnabled, setVideoEnabled] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedScreen, setSelectedScreen] = useState('entire-screen');
  const [recordingTime, setRecordingTime] = useState('00:05:23');
  const videoRef = useRef(null);

  const screenOptions = [
    { id: 'entire-screen', label: 'Entire Screen', icon: Monitor },
    { id: 'application', label: 'Application Window', icon: Square },
    { id: 'browser-tab', label: 'Browser Tab', icon: Play }
  ];

  const handleStartPresenting = () => {
    setIsPresenting(!isPresenting);
  };

  const handleToggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  return (
    <div className="space-y-6">
      {/* Screen Share Controls */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Monitor className="w-5 h-5 mr-2 text-blue-600" />
            Screen Sharing & Remote Pairing
          </h3>
          
          <div className="flex items-center space-x-2">
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
              isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
            }`}>
              {isActive ? 'Sharing Active' : 'Not Sharing'}
            </span>
            
            {isRecording && (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-2"></div>
                Recording {recordingTime}
              </span>
            )}
          </div>
        </div>

        {/* Screen Selection */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {screenOptions?.map((option) => {
            const IconComponent = option?.icon;
            return (
              <button
                key={option?.id}
                onClick={() => setSelectedScreen(option?.id)}
                className={`p-4 border-2 border-dashed rounded-lg text-center transition-colors ${
                  selectedScreen === option?.id
                    ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-300 hover:border-gray-400 text-gray-600'
                }`}
              >
                <IconComponent className="w-8 h-8 mx-auto mb-2" />
                <div className="font-medium">{option?.label}</div>
              </button>
            );
          })}
        </div>

        {/* Control Buttons */}
        <div className="flex flex-wrap items-center justify-center space-x-4 mb-6">
          <button
            onClick={handleStartPresenting}
            className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-colors ${
              isPresenting
                ? 'bg-red-600 text-white hover:bg-red-700' : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            <Monitor className="w-5 h-5" />
            <span>{isPresenting ? 'Stop Sharing' : 'Start Sharing'}</span>
          </button>

          <button
            onClick={() => setAudioEnabled(!audioEnabled)}
            className={`p-3 rounded-lg transition-colors ${
              audioEnabled
                ? 'bg-gray-100 text-gray-700 hover:bg-gray-200' : 'bg-red-100 text-red-700 hover:bg-red-200'
            }`}
          >
            {audioEnabled ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
          </button>

          <button
            onClick={() => setVideoEnabled(!videoEnabled)}
            className={`p-3 rounded-lg transition-colors ${
              videoEnabled
                ? 'bg-gray-100 text-gray-700 hover:bg-gray-200' : 'bg-red-100 text-red-700 hover:bg-red-200'
            }`}
          >
            {videoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
          </button>

          <button
            onClick={handleToggleFullscreen}
            className="p-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
          </button>

          <button className="p-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>
      {/* Screen Preview */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-semibold text-gray-900">Live Preview</h4>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">Viewers: {collaborators?.length || 0}</span>
            <div className="flex items-center -space-x-1">
              {collaborators?.slice(0, 3)?.map((collaborator, index) => (
                <img
                  key={index}
                  src={collaborator?.avatar}
                  alt={collaborator?.name}
                  className="w-6 h-6 rounded-full border-2 border-white"
                />
              ))}
            </div>
          </div>
        </div>

        <div className={`relative bg-gray-900 rounded-lg overflow-hidden ${isFullscreen ? 'h-96' : 'h-64'}`}>
          {isPresenting || isActive ? (
            <>
              {/* Mock screen content */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
                <div className="text-center text-white">
                  <Monitor className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p className="text-lg">Screen sharing active</p>
                  <p className="text-sm opacity-75">Sharing: {screenOptions?.find(o => o?.id === selectedScreen)?.label}</p>
                </div>
              </div>
              
              {/* Presenter cursor indicator */}
              <div className="absolute top-20 left-32 animate-bounce">
                <div className="w-4 h-4 bg-red-500 rounded-full border-2 border-white shadow-lg"></div>
              </div>
            </>
          ) : (
            <div className="absolute inset-0 flex items-center justify-center text-gray-500">
              <div className="text-center">
                <Monitor className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No screen sharing active</p>
              </div>
            </div>
          )}
        </div>
      </div>
      {/* Collaboration Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Voice Chat Participants */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h4 className="font-semibold text-gray-900 mb-4 flex items-center">
            <Users className="w-5 h-5 mr-2 text-green-600" />
            Voice Chat ({collaborators?.length || 0})
          </h4>
          
          <div className="space-y-3">
            {collaborators?.map((collaborator, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <img
                    src={collaborator?.avatar}
                    alt={collaborator?.name}
                    className="w-8 h-8 rounded-full"
                  />
                  <span className="font-medium text-gray-900">{collaborator?.name}</span>
                </div>
                
                <div className="flex items-center space-x-2">
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <Volume2 className="w-4 h-4 text-green-600" />
                  </div>
                  <button className="text-gray-400 hover:text-gray-600">
                    <Settings className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
            
            {collaborators?.length === 0 && (
              <p className="text-gray-500 text-sm">No one in voice chat</p>
            )}
          </div>
        </div>

        {/* Session Recording */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h4 className="font-semibold text-gray-900 mb-4">Session Recording</h4>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Auto-record sessions</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Include audio</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            
            {isRecording && (
              <div className="p-3 bg-red-50 rounded-lg">
                <div className="flex items-center space-x-2 text-red-700">
                  <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                  <span className="font-medium">Recording in progress</span>
                </div>
                <p className="text-sm text-red-600 mt-1">Duration: {recordingTime}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScreenShare;