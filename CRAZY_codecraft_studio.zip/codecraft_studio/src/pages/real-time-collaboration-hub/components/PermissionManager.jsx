import React, { useState } from 'react';
import { Shield, Users, Settings, UserPlus, UserMinus, Crown, Edit, Eye, CheckCircle, XCircle } from 'lucide-react';

const PermissionManager = ({ collaborators = [], permissions = {}, onUpdatePermissions }) => {
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('viewer');
  const [selectedUser, setSelectedUser] = useState(null);

  const roles = [
    {
      id: 'owner',
      name: 'Owner',
      icon: Crown,
      color: 'text-purple-600 bg-purple-100',
      description: 'Full access to all project features and settings',
      permissions: ['read', 'write', 'delete', 'admin', 'invite', 'deploy']
    },
    {
      id: 'admin',
      name: 'Admin',
      icon: Shield,
      color: 'text-red-600 bg-red-100',
      description: 'Can manage users and project settings',
      permissions: ['read', 'write', 'delete', 'admin', 'invite']
    },
    {
      id: 'editor',
      name: 'Editor',
      icon: Edit,
      color: 'text-blue-600 bg-blue-100',
      description: 'Can read and modify project files',
      permissions: ['read', 'write']
    },
    {
      id: 'viewer',
      name: 'Viewer',
      icon: Eye,
      color: 'text-green-600 bg-green-100',
      description: 'Read-only access to project files',
      permissions: ['read']
    }
  ];

  const handleRoleChange = (userId, newRole) => {
    const updatedPermissions = { ...permissions };
    updatedPermissions[userId] = newRole;
    onUpdatePermissions?.(updatedPermissions);
  };

  const handleRemoveUser = (userId) => {
    const updatedPermissions = { ...permissions };
    delete updatedPermissions?.[userId];
    onUpdatePermissions?.(updatedPermissions);
  };

  const handleInviteUser = (e) => {
    e?.preventDefault();
    if (!inviteEmail?.trim()) return;
    
    // Mock invite functionality
    console.log(`Inviting ${inviteEmail} as ${inviteRole}`);
    setInviteEmail('');
    setShowInviteModal(false);
  };

  const getRoleInfo = (roleId) => {
    return roles?.find(role => role?.id === roleId) || roles?.[3]; // Default to viewer
  };

  return (
    <div className="space-y-6">
      {/* Permission Overview */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Shield className="w-5 h-5 mr-2 text-blue-600" />
            Permission Management
          </h3>
          
          <button
            onClick={() => setShowInviteModal(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <UserPlus className="w-4 h-4" />
            <span>Invite User</span>
          </button>
        </div>

        {/* Role Statistics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {roles?.map(role => {
            const count = collaborators?.filter(c => c?.role === role?.id)?.length || 0;
            const RoleIcon = role?.icon;
            
            return (
              <div key={role?.id} className="text-center p-4 bg-gray-50 rounded-lg">
                <div className={`inline-flex items-center justify-center w-10 h-10 rounded-full ${role?.color} mb-2`}>
                  <RoleIcon className="w-5 h-5" />
                </div>
                <div className="text-2xl font-bold text-gray-900">{count}</div>
                <div className="text-sm text-gray-600">{role?.name}s</div>
              </div>
            );
          })}
        </div>
      </div>
      {/* User Management */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h4 className="font-semibold text-gray-900">Team Members & Permissions</h4>
        </div>

        <div className="divide-y divide-gray-200">
          {collaborators?.map((collaborator) => {
            const roleInfo = getRoleInfo(collaborator?.role);
            const RoleIcon = roleInfo?.icon;
            
            return (
              <div key={collaborator?.id} className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <img
                      src={collaborator?.avatar}
                      alt={collaborator?.name}
                      className="w-12 h-12 rounded-full"
                    />
                    
                    <div>
                      <div className="flex items-center space-x-2">
                        <h5 className="font-medium text-gray-900">{collaborator?.name}</h5>
                        <div className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${roleInfo?.color}`}>
                          <RoleIcon className="w-3 h-3" />
                          <span>{roleInfo?.name}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4 mt-1">
                        <span className="text-sm text-gray-600">
                          Status: <span className="text-green-600 capitalize">{collaborator?.status}</span>
                        </span>
                        <span className="text-sm text-gray-600">
                          Last active: Just now
                        </span>
                      </div>
                      
                      <div className="text-xs text-gray-500 mt-1">
                        {roleInfo?.description}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    {collaborator?.role !== 'owner' && (
                      <>
                        <select
                          value={collaborator?.role}
                          onChange={(e) => handleRoleChange(collaborator?.id, e?.target?.value)}
                          className="text-sm border border-gray-300 rounded px-3 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                          {roles?.filter(r => r?.id !== 'owner')?.map(role => (
                            <option key={role?.id} value={role?.id}>
                              {role?.name}
                            </option>
                          ))}
                        </select>
                        
                        <button
                          onClick={() => handleRemoveUser(collaborator?.id)}
                          className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded transition-colors"
                          title="Remove user"
                        >
                          <UserMinus className="w-4 h-4" />
                        </button>
                      </>
                    )}
                    
                    <button
                      onClick={() => setSelectedUser(selectedUser === collaborator?.id ? null : collaborator?.id)}
                      className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded transition-colors"
                    >
                      <Settings className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                {/* Detailed Permissions */}
                {selectedUser === collaborator?.id && (
                  <div className="mt-6 pt-6 border-t border-gray-200">
                    <h6 className="font-medium text-gray-900 mb-3">Permissions & Access</h6>
                    
                    <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                      {[
                        { id: 'read', label: 'View Files', icon: Eye },
                        { id: 'write', label: 'Edit Files', icon: Edit },
                        { id: 'delete', label: 'Delete Files', icon: XCircle },
                        { id: 'admin', label: 'Admin Settings', icon: Settings },
                        { id: 'invite', label: 'Invite Users', icon: UserPlus },
                        { id: 'deploy', label: 'Deploy Project', icon: CheckCircle }
                      ]?.map(permission => {
                        const hasPermission = roleInfo?.permissions?.includes(permission?.id);
                        const PermissionIcon = permission?.icon;
                        
                        return (
                          <div
                            key={permission?.id}
                            className={`flex items-center space-x-3 p-3 rounded-lg border ${
                              hasPermission 
                                ? 'bg-green-50 border-green-200' :'bg-gray-50 border-gray-200'
                            }`}
                          >
                            <div className={`p-2 rounded ${
                              hasPermission 
                                ? 'bg-green-100 text-green-600' :'bg-gray-200 text-gray-400'
                            }`}>
                              <PermissionIcon className="w-4 h-4" />
                            </div>
                            <div>
                              <div className={`font-medium text-sm ${
                                hasPermission ? 'text-green-900' : 'text-gray-600'
                              }`}>
                                {permission?.label}
                              </div>
                              <div className="text-xs text-gray-500">
                                {hasPermission ? 'Allowed' : 'Not allowed'}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          
          {collaborators?.length === 0 && (
            <div className="p-12 text-center">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Team Members</h3>
              <p className="text-gray-600">Invite team members to start collaborating.</p>
            </div>
          )}
        </div>
      </div>
      {/* Project Access Settings */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h4 className="font-semibold text-gray-900 mb-4">Project Access Settings</h4>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium text-gray-900">Public Link Access</div>
              <div className="text-sm text-gray-600">Allow anyone with the link to view the project</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium text-gray-900">Require Approval</div>
              <div className="text-sm text-gray-600">New members need approval to join</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium text-gray-900">Auto-save Changes</div>
              <div className="text-sm text-gray-600">Automatically save all user changes</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>
      </div>
      {/* Invite Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Invite Team Member</h3>
            
            <form onSubmit={handleInviteUser} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e?.target?.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="colleague@company.com"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Role
                </label>
                <select
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e?.target?.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {roles?.filter(r => r?.id !== 'owner')?.map(role => (
                    <option key={role?.id} value={role?.id}>
                      {role?.name} - {role?.description}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="flex space-x-3 mt-6">
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Send Invitation
                </button>
                <button
                  type="button"
                  onClick={() => setShowInviteModal(false)}
                  className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PermissionManager;