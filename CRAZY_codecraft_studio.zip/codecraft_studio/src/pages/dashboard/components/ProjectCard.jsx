import React, { useState } from 'react';
import { Calendar, Globe, Lock, MoreVertical, ExternalLink, Edit, Trash2, Share2 } from 'lucide-react';
import { projectService } from '../../../services/projectService';
import { useAuth } from '../../../contexts/AuthContext';

export function ProjectCard({ project, onUpdate, onDelete }) {
  const [showMenu, setShowMenu] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { user } = useAuth()

  const handleTogglePublic = async () => {
    if (!user?.id) return
    
    setLoading(true)
    setError('')
    
    const { data, error } = await projectService?.togglePublic(
      project?.id, 
      !project?.is_public, 
      user?.id
    )
    
    if (error) {
      setError('Failed to update project visibility')
    } else {
      onUpdate?.(data)
    }
    
    setLoading(false)
    setShowMenu(false)
  }

  const handleDelete = async () => {
    if (!user?.id || !confirm('Are you sure you want to delete this project?')) return
    
    setLoading(true)
    setError('')
    
    const { error } = await projectService?.delete(project?.id, user?.id)
    
    if (error) {
      setError('Failed to delete project')
    } else {
      onDelete?.(project?.id)
    }
    
    setLoading(false)
    setShowMenu(false)
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'Unknown date'
    try {
      return new Date(dateString)?.toLocaleDateString();
    } catch (error) {
      return 'Invalid date'
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'published': return 'bg-green-100 text-green-800'
      case 'draft': return 'bg-gray-100 text-gray-800'
      case 'in_review': return 'bg-yellow-100 text-yellow-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
      {/* Project Thumbnail/Preview */}
      <div className="aspect-video bg-gradient-to-br from-blue-50 to-purple-50 rounded-t-lg flex items-center justify-center relative">
        {project?.thumbnail_url ? (
          <img 
            src={project?.thumbnail_url} 
            alt={project?.name}
            className="w-full h-full object-cover rounded-t-lg"
          />
        ) : (
          <div className="text-center">
            <svg className="w-12 h-12 text-gray-400 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
            </svg>
            <span className="text-sm text-gray-500">{project?.framework || 'React'}</span>
          </div>
        )}
        
        {/* Status Badge */}
        <div className={`absolute top-2 left-2 px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(project?.status)}`}>
          {project?.status || 'draft'}
        </div>

        {/* Visibility Badge */}
        <div className="absolute top-2 right-2 p-1 bg-white bg-opacity-90 rounded-full">
          {project?.is_public ? (
            <Globe className="w-4 h-4 text-green-600" />
          ) : (
            <Lock className="w-4 h-4 text-gray-600" />
          )}
        </div>
      </div>
      {/* Project Info */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-semibold text-gray-900 truncate flex-1">
            {project?.name || 'Untitled Project'}
          </h3>
          
          {/* Actions Menu */}
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              disabled={loading}
              className="p-1 hover:bg-gray-100 rounded-full disabled:opacity-50"
            >
              <MoreVertical className="w-4 h-4 text-gray-500" />
            </button>
            
            {showMenu && (
              <div className="absolute right-0 top-8 bg-white border border-gray-200 rounded-lg shadow-lg py-1 z-10 min-w-[160px]">
                <button 
                  className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center gap-2"
                  onClick={() => setShowMenu(false)}
                >
                  <Edit className="w-4 h-4" />
                  Edit Project
                </button>
                
                <button 
                  onClick={handleTogglePublic}
                  disabled={loading}
                  className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center gap-2 disabled:opacity-50"
                >
                  <Share2 className="w-4 h-4" />
                  Make {project?.is_public ? 'Private' : 'Public'}
                </button>
                
                {project?.deployment_url && (
                  <a 
                    href={project?.deployment_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center gap-2"
                  >
                    <ExternalLink className="w-4 h-4" />
                    View Live
                  </a>
                )}
                
                <hr className="my-1" />
                
                <button 
                  onClick={handleDelete}
                  disabled={loading}
                  className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2 disabled:opacity-50"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete
                </button>
              </div>
            )}
          </div>
        </div>

        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
          {project?.description || 'No description provided'}
        </p>

        <div className="flex items-center justify-between text-xs text-gray-500">
          <div className="flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            <span>
              {project?.last_opened_at ? 
                `Opened ${formatDate(project?.last_opened_at)}` : 
                `Created ${formatDate(project?.created_at)}`
              }
            </span>
          </div>
          
          <span className="px-2 py-1 bg-gray-100 rounded-full text-xs font-medium">
            {project?.framework || 'React'}
          </span>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mt-2 text-xs text-red-600 bg-red-50 px-2 py-1 rounded">
            {error}
          </div>
        )}
      </div>
    </div>
  );
}