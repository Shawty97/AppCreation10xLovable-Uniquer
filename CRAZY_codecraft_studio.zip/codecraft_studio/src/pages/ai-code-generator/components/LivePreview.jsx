import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const LivePreview = ({ app, framework, onExport, onSave, onContinueEdit, isMobile }) => {
  const [previewDevice, setPreviewDevice] = useState('desktop');
  const [previewPage, setPreviewPage] = useState('home');

  const deviceOptions = [
    { value: 'desktop', label: 'Desktop', icon: 'Monitor' },
    { value: 'tablet', label: 'Tablet', icon: 'Tablet' },
    { value: 'mobile', label: 'Mobile', icon: 'Smartphone' }
  ];

  const getDeviceClasses = () => {
    switch (previewDevice) {
      case 'mobile':
        return 'w-[375px] h-[667px]';
      case 'tablet':
        return 'w-[768px] h-[1024px]';
      default:
        return 'w-full h-full';
    }
  };

  const getDeviceFrame = () => {
    if (previewDevice === 'desktop') return '';
    return 'border-[8px] border-gray-800 rounded-[20px] shadow-xl';
  };

  if (!app) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center">
        <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mb-6">
          <Icon name="Sparkles" size={32} className="text-muted-foreground" />
        </div>
        <h3 className="text-xl font-semibold text-foreground mb-2">
          No App Generated Yet
        </h3>
        <p className="text-muted-foreground mb-6 max-w-md">
          Start a conversation with the AI to generate your first application. Describe what you want to build and watch the magic happen!
        </p>
        <div className="space-y-3">
          <p className="text-sm font-medium text-foreground">Quick Examples:</p>
          <div className="text-sm text-muted-foreground space-y-1">
            <p>• "Build a todo app with dark mode"</p>
            <p>• "Create an e-commerce dashboard"</p>
            <p>• "Make a portfolio website"</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Preview Header */}
      <div className="p-4 border-b border-border bg-card">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3">
            <Icon name="Eye" size={20} className="text-foreground" />
            <div>
              <h3 className="font-semibold text-foreground">{app?.name}</h3>
              <p className="text-xs text-muted-foreground">
                {framework?.toUpperCase()} • Generated {app?.generatedAt?.toLocaleTimeString()}
              </p>
            </div>
          </div>
          
          {!isMobile && (
            <div className="flex items-center space-x-2">
              <Select
                options={deviceOptions}
                value={previewDevice}
                onChange={setPreviewDevice}
                className="w-32"
              />
            </div>
          )}
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="bg-muted rounded-lg p-3">
            <div className="text-lg font-semibold text-foreground">{app?.codeStats?.files}</div>
            <div className="text-xs text-muted-foreground">Files</div>
          </div>
          <div className="bg-muted rounded-lg p-3">
            <div className="text-lg font-semibold text-foreground">{app?.codeStats?.lines?.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">Lines</div>
          </div>
          <div className="bg-muted rounded-lg p-3">
            <div className="text-lg font-semibold text-foreground">{app?.codeStats?.components}</div>
            <div className="text-xs text-muted-foreground">Components</div>
          </div>
        </div>
      </div>
      {/* Preview Content */}
      <div className="flex-1 bg-gray-100 p-4 overflow-auto">
        <div className="flex items-center justify-center h-full">
          <div className={`${getDeviceClasses()} ${getDeviceFrame()} bg-white relative overflow-hidden`}>
            {/* Mock App Interface */}
            <div className="w-full h-full bg-gradient-to-br from-blue-50 to-indigo-100 relative">
              {/* Mock Header */}
              <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <Icon name="Zap" size={16} className="text-primary-foreground" />
                  </div>
                  <span className="font-semibold text-gray-900">{app?.name}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="Bell" size={16} className="text-gray-500" />
                  <Icon name="User" size={16} className="text-gray-500" />
                </div>
              </div>

              {/* Mock Content */}
              <div className="p-4 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[1, 2, 3]?.map((i) => (
                    <div key={i} className="bg-white rounded-lg shadow-sm p-4">
                      <div className="h-3 bg-gray-200 rounded mb-2"></div>
                      <div className="h-8 bg-gray-100 rounded mb-2"></div>
                      <div className="h-2 bg-gray-100 rounded w-2/3"></div>
                    </div>
                  ))}
                </div>

                <div className="bg-white rounded-lg shadow-sm p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                    <div className="h-8 bg-primary rounded w-20"></div>
                  </div>
                  <div className="space-y-3">
                    {[1, 2, 3, 4]?.map((i) => (
                      <div key={i} className="flex items-center space-x-3 p-3 bg-gray-50 rounded">
                        <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                        <div className="flex-1">
                          <div className="h-3 bg-gray-200 rounded mb-1"></div>
                          <div className="h-2 bg-gray-100 rounded w-3/4"></div>
                        </div>
                        <div className="w-8 h-6 bg-gray-200 rounded"></div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Generated Badge */}
              <div className="absolute top-4 right-4">
                <div className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-medium flex items-center space-x-1">
                  <Icon name="CheckCircle" size={12} />
                  <span>AI Generated</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Action Buttons */}
      <div className="p-4 border-t border-border bg-card space-y-3">
        <div className="grid grid-cols-1 gap-2">
          <Button
            variant="default"
            iconName="Download"
            iconPosition="left"
            iconSize={16}
            onClick={onExport}
            className="w-full"
          >
            Export Code
          </Button>
          
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              iconName="Save"
              iconPosition="left"
              iconSize={16}
              onClick={onSave}
              className="w-full"
            >
              Save to Library
            </Button>
            
            <Button
              variant="outline"
              iconName="Edit"
              iconPosition="left"
              iconSize={16}
              onClick={onContinueEdit}
              className="w-full"
            >
              Continue Editing
            </Button>
          </div>
        </div>

        <div className="flex items-center justify-center space-x-4 text-xs text-muted-foreground">
          <div className="flex items-center space-x-1">
            <Icon name="Shield" size={12} />
            <span>Production Ready</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Smartphone" size={12} />
            <span>Responsive</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Zap" size={12} />
            <span>Optimized</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LivePreview;