import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const PromptTemplates = ({ appTypes, onClose, onSelect }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const templateCategories = [
    { value: 'all', label: 'All Templates' },
    { value: 'business', label: 'Business' },
    { value: 'creative', label: 'Creative' },
    { value: 'ecommerce', label: 'E-commerce' },
    { value: 'social', label: 'Social' },
    { value: 'utility', label: 'Utility' }
  ];

  const promptTemplates = [
    {
      id: 1,
      title: 'Modern E-commerce Store',
      category: 'ecommerce',
      description: 'Complete online store with shopping cart, payment processing, and admin dashboard',
      prompt: 'Create a modern e-commerce website with product catalog, shopping cart functionality, user authentication, payment integration with Stripe, order management system, and responsive design. Include features like product search, filtering, reviews, wishlist, and admin dashboard for inventory management.',
      features: ['Shopping Cart', 'Payment Processing', 'User Auth', 'Admin Dashboard', 'Product Reviews'],
      difficulty: 'Advanced',
      estimatedTime: '2-3 hours'
    },
    {
      id: 2,
      title: 'Task Management Dashboard',
      category: 'business',
      description: 'Collaborative task management with real-time updates and team features',
      prompt: 'Build a task management application with drag-and-drop kanban boards, real-time collaboration, user assignments, due dates, priority levels, project organization, time tracking, and team chat functionality. Include dashboard with analytics and reporting.',
      features: ['Kanban Boards', 'Real-time Updates', 'Team Collaboration', 'Analytics', 'Time Tracking'],
      difficulty: 'Intermediate',
      estimatedTime: '1-2 hours'
    },
    {
      id: 3,
      title: 'Creative Portfolio Website',
      category: 'creative',
      description: 'Stunning portfolio showcase for artists and designers',
      prompt: 'Create a creative portfolio website with image gallery, project showcases, smooth animations, contact form, blog section, responsive design, and dark/light mode toggle. Include admin panel for content management and SEO optimization.',
      features: ['Image Gallery', 'Animations', 'Blog', 'Dark Mode', 'SEO Optimized'],
      difficulty: 'Beginner',
      estimatedTime: '30-60 min'
    },
    {
      id: 4,
      title: 'Social Media Platform',
      category: 'social',
      description: 'Mini social network with posts, likes, and messaging',
      prompt: 'Build a social media platform with user profiles, post creation and sharing, like and comment system, real-time messaging, friend connections, news feed algorithm, image/video uploads, and notification system.',
      features: ['User Profiles', 'Real-time Chat', 'News Feed', 'Media Upload', 'Notifications'],
      difficulty: 'Advanced',
      estimatedTime: '3-4 hours'
    },
    {
      id: 5,
      title: 'Restaurant Management System',
      category: 'business',
      description: 'Complete restaurant operations with ordering and POS',
      prompt: 'Create a restaurant management system with online menu, table reservation system, online ordering, POS integration, inventory management, staff management, customer database, analytics dashboard, and mobile-responsive design.',
      features: ['Online Menu', 'Reservations', 'POS System', 'Inventory', 'Staff Management'],
      difficulty: 'Advanced',
      estimatedTime: '2-3 hours'
    },
    {
      id: 6,
      title: 'Learning Management System',
      category: 'utility',
      description: 'Educational platform with courses and progress tracking',
      prompt: 'Build a learning management system with course creation, video lessons, quizzes and assessments, student progress tracking, certificates, discussion forums, instructor dashboard, and payment integration for premium courses.',
      features: ['Course Creation', 'Video Lessons', 'Quizzes', 'Progress Tracking', 'Certificates'],
      difficulty: 'Intermediate',
      estimatedTime: '2 hours'
    },
    {
      id: 7,
      title: 'Fitness Tracker App',
      category: 'utility',
      description: 'Personal fitness tracking with workouts and nutrition',
      prompt: 'Create a fitness tracking application with workout logging, exercise database, progress charts, nutrition tracking, goal setting, social sharing, workout plans, and integration with wearable devices.',
      features: ['Workout Logging', 'Progress Charts', 'Nutrition Tracking', 'Goal Setting', 'Social Sharing'],
      difficulty: 'Intermediate',
      estimatedTime: '1-2 hours'
    },
    {
      id: 8,
      title: 'Real Estate Platform',
      category: 'business',
      description: 'Property listings with search and management tools',
      prompt: 'Build a real estate platform with property listings, advanced search and filtering, map integration, virtual tours, agent profiles, lead management, mortgage calculator, and admin dashboard for property management.',
      features: ['Property Listings', 'Map Integration', 'Virtual Tours', 'Lead Management', 'Mortgage Calculator'],
      difficulty: 'Advanced',
      estimatedTime: '3 hours'
    }
  ];

  const filteredTemplates = promptTemplates?.filter(template => {
    const matchesSearch = template?.title?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
                         template?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
                         template?.features?.some(feature => feature?.toLowerCase()?.includes(searchQuery?.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || template?.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Beginner':
        return 'text-green-600 bg-green-50 border-green-200';
      case 'Intermediate':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'Advanced':
        return 'text-red-600 bg-red-50 border-red-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const handleTemplateSelect = (template) => {
    onSelect?.(template);
    onClose?.();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-border rounded-lg shadow-elevation-2 w-full max-w-6xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold text-foreground">Prompt Templates</h2>
              <p className="text-muted-foreground">
                Choose from pre-built templates to get started quickly
              </p>
            </div>
            <Button
              variant="ghost"
              iconName="X"
              iconSize={20}
              onClick={onClose}
              className="h-10 w-10"
            />
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Input
              type="search"
              placeholder="Search templates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e?.target?.value)}
              className="flex-1"
            />
            <div className="flex flex-wrap gap-2">
              {templateCategories?.map((category) => (
                <Button
                  key={category?.value}
                  variant={selectedCategory === category?.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category?.value)}
                  className="text-xs"
                >
                  {category?.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Templates Grid */}
        <div className="flex-1 overflow-y-auto p-6">
          {filteredTemplates?.length === 0 ? (
            <div className="text-center py-12">
              <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">No templates found</h3>
              <p className="text-muted-foreground">
                Try adjusting your search terms or category filter
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTemplates?.map((template) => (
                <div
                  key={template?.id}
                  className="bg-background border border-border rounded-lg p-6 hover:shadow-elevation-1 transition-all cursor-pointer group"
                  onClick={() => handleTemplateSelect(template)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                      {template?.title}
                    </h3>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium border ${getDifficultyColor(template?.difficulty)}`}>
                      {template?.difficulty}
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {template?.description}
                  </p>

                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                      <Icon name="Clock" size={12} />
                      <span>{template?.estimatedTime}</span>
                    </div>
                    <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                      <Icon name="Code" size={12} />
                      <span>{template?.features?.length} features</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-4">
                    {template?.features?.slice(0, 3)?.map((feature, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded"
                      >
                        {feature}
                      </span>
                    ))}
                    {template?.features?.length > 3 && (
                      <span className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded">
                        +{template?.features?.length - 3} more
                      </span>
                    )}
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    iconName="ArrowRight"
                    iconPosition="right"
                    iconSize={14}
                    className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                  >
                    Use Template
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PromptTemplates;