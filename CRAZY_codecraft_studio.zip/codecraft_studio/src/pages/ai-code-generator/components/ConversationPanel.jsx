import React, { useEffect, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ConversationPanel = ({ messages, onSuggestionClick, isGenerating }) => {
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef?.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const formatTimestamp = (timestamp) => {
    return timestamp?.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6">
      {messages?.map((message) => (
        <div
          key={message?.id}
          className={`flex ${message?.type === 'user' ? 'justify-end' : 'justify-start'}`}
        >
          <div className={`flex max-w-[80%] ${message?.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
            {/* Avatar */}
            <div className={`flex-shrink-0 ${message?.type === 'user' ? 'ml-3' : 'mr-3'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                message?.type === 'user' ?'bg-primary text-primary-foreground' 
                  : message?.isError
                    ? 'bg-destructive text-destructive-foreground'
                    : 'bg-secondary text-secondary-foreground'
              }`}>
                <Icon 
                  name={message?.type === 'user' ? 'User' : message?.isError ? 'AlertCircle' : 'Bot'} 
                  size={16} 
                />
              </div>
            </div>

            {/* Message Content */}
            <div className={`flex flex-col ${message?.type === 'user' ? 'items-end' : 'items-start'}`}>
              <div className={`rounded-lg px-4 py-3 ${
                message?.type === 'user' ?'bg-primary text-primary-foreground'
                  : message?.isError
                    ? 'bg-destructive/10 text-destructive border border-destructive/20' :'bg-secondary text-secondary-foreground'
              }`}>
                <p className="text-sm whitespace-pre-wrap">{message?.content}</p>
                
                {/* Code Generation Badge */}
                {message?.codeGenerated && !message?.isError && (
                  <div className="mt-3 pt-3 border-t border-border">
                    <div className="flex items-center space-x-2">
                      <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                        <Icon name="Code" size={12} />
                        <span>Code Generated</span>
                      </div>
                      <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                        <Icon name="Zap" size={12} />
                        <span>Production Ready</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Timestamp */}
              <div className="text-xs text-muted-foreground mt-1">
                {formatTimestamp(message?.timestamp)}
              </div>

              {/* Suggestions */}
              {message?.suggestions && message?.suggestions?.length > 0 && !isGenerating && (
                <div className="mt-3 space-y-2 w-full">
                  <p className="text-xs text-muted-foreground">Suggested improvements:</p>
                  <div className="grid grid-cols-1 gap-2">
                    {message?.suggestions?.map((suggestion, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => onSuggestionClick?.(suggestion)}
                        className="text-xs text-left justify-start h-auto py-2 px-3 whitespace-normal"
                      >
                        <Icon name="Plus" size={12} className="mr-2 flex-shrink-0" />
                        <span className="text-left">{suggestion}</span>
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      ))}

      {/* Typing Indicator */}
      {isGenerating && (
        <div className="flex justify-start">
          <div className="flex">
            <div className="flex-shrink-0 mr-3">
              <div className="w-8 h-8 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center">
                <Icon name="Bot" size={16} />
              </div>
            </div>
            <div className="bg-secondary text-secondary-foreground rounded-lg px-4 py-3">
              <div className="flex items-center space-x-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
                <span className="text-sm">AI is thinking...</span>
              </div>
            </div>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  );
};

export default ConversationPanel;