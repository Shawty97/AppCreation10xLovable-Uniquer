import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, TrendingUp, TrendingDown, Target, Clock, Eye, Heart, Activity, Smartphone, Monitor, Globe, ChevronDown } from 'lucide-react';
import Icon from '../../../components/AppIcon';


const UserExperienceMonitor = () => {
  const [uxMetrics, setUxMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedTimeframe, setSelectedTimeframe] = useState('7d');
  const [selectedMetric, setSelectedMetric] = useState('conversion');

  useEffect(() => {
    loadUXMetrics();
  }, [selectedTimeframe]);

  const loadUXMetrics = async () => {
    try {
      // Simulate loading UX metrics
      await new Promise(resolve => setTimeout(resolve, 1200));
      
      setUxMetrics({
        overview: {
          totalUsers: 12847,
          conversionRate: 3.4,
          bounceRate: 42.1,
          averageSessionDuration: 245,
          pagesPerSession: 2.8,
          returnVisitorRate: 28.5
        },
        conversionFunnel: [
          { stage: 'Landing Page', users: 12847, conversion: 100, dropoff: 0 },
          { stage: 'Product View', users: 8234, conversion: 64.1, dropoff: 35.9 },
          { stage: 'Add to Cart', users: 3421, conversion: 26.6, dropoff: 37.5 },
          { stage: 'Checkout', users: 1876, conversion: 14.6, dropoff: 12.0 },
          { stage: 'Purchase', users: 437, conversion: 3.4, dropoff: 11.2 }
        ],
        deviceSegments: {
          desktop: { users: 7708, conversion: 4.2, avgSession: 312, bounce: 38.5 },
          mobile: { users: 4496, conversion: 2.8, avgSession: 189, bounce: 46.8 },
          tablet: { users: 643, conversion: 3.1, avgSession: 234, bounce: 41.2 }
        },
        performanceCorrelation: {
          pageSpeed: [
            { loadTime: '<1s', conversion: 5.2, engagement: 8.4 },
            { loadTime: '1-2s', conversion: 4.1, engagement: 6.8 },
            { loadTime: '2-3s', conversion: 3.4, engagement: 5.2 },
            { loadTime: '3-4s', conversion: 2.8, engagement: 4.1 },
            { loadTime: '>4s', conversion: 1.9, engagement: 2.6 }
          ]
        },
        userJourney: [
          { page: 'Homepage', visitors: 12847, avgTime: 45, exits: 2847 },
          { page: 'Products', visitors: 8234, avgTime: 89, exits: 1234 },
          { page: 'Product Detail', visitors: 6421, avgTime: 156, exits: 2145 },
          { page: 'Cart', visitors: 3421, avgTime: 67, exits: 891 },
          { page: 'Checkout', visitors: 1876, avgTime: 234, exits: 445 }
        ],
        realTimeActivity: {
          currentUsers: 147,
          topPages: [
            { page: '/dashboard', users: 34 },
            { page: '/products', users: 28 },
            { page: '/profile', users: 19 },
            { page: '/settings', users: 12 }
          ]
        }
      });
      
      setLoading(false);
    } catch (error) {
      console.error('Error loading UX metrics:', error);
      setLoading(false);
    }
  };

  const getMetricTrend = (current, previous) => {
    const change = ((current - previous) / previous) * 100;
    return {
      value: Math.abs(change)?.toFixed(1),
      direction: change >= 0 ? 'up' : 'down',
      isPositive: change >= 0
    };
  };

  const renderOverviewCards = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-lg p-6 border border-gray-200"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-green-100 rounded-lg">
            <Target className="w-6 h-6 text-green-600" />
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-green-600">
              {uxMetrics?.overview?.conversionRate}%
            </div>
            <div className="flex items-center text-sm text-green-600">
              <TrendingUp className="w-4 h-4 mr-1" />
              +0.3%
            </div>
          </div>
        </div>
        <h3 className="font-semibold text-gray-900">Conversion Rate</h3>
        <p className="text-sm text-gray-600">Users completing desired actions</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-lg p-6 border border-gray-200"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-blue-100 rounded-lg">
            <Users className="w-6 h-6 text-blue-600" />
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-blue-600">
              {uxMetrics?.overview?.totalUsers?.toLocaleString()}
            </div>
            <div className="flex items-center text-sm text-blue-600">
              <TrendingUp className="w-4 h-4 mr-1" />
              +12.4%
            </div>
          </div>
        </div>
        <h3 className="font-semibold text-gray-900">Total Users</h3>
        <p className="text-sm text-gray-600">Unique visitors in timeframe</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-lg p-6 border border-gray-200"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-yellow-100 rounded-lg">
            <Activity className="w-6 h-6 text-yellow-600" />
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-yellow-600">
              {uxMetrics?.overview?.bounceRate}%
            </div>
            <div className="flex items-center text-sm text-red-600">
              <TrendingDown className="w-4 h-4 mr-1" />
              -2.1%
            </div>
          </div>
        </div>
        <h3 className="font-semibold text-gray-900">Bounce Rate</h3>
        <p className="text-sm text-gray-600">Single-page session visits</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-lg p-6 border border-gray-200"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-purple-100 rounded-lg">
            <Clock className="w-6 h-6 text-purple-600" />
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-purple-600">
              {Math.floor(uxMetrics?.overview?.averageSessionDuration / 60)}:{(uxMetrics?.overview?.averageSessionDuration % 60)?.toString()?.padStart(2, '0')}
            </div>
            <div className="flex items-center text-sm text-purple-600">
              <TrendingUp className="w-4 h-4 mr-1" />
              +8.2%
            </div>
          </div>
        </div>
        <h3 className="font-semibold text-gray-900">Avg Session</h3>
        <p className="text-sm text-gray-600">Duration per user session</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-white rounded-lg p-6 border border-gray-200"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-indigo-100 rounded-lg">
            <Eye className="w-6 h-6 text-indigo-600" />
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-indigo-600">
              {uxMetrics?.overview?.pagesPerSession}
            </div>
            <div className="flex items-center text-sm text-indigo-600">
              <TrendingUp className="w-4 h-4 mr-1" />
              +5.7%
            </div>
          </div>
        </div>
        <h3 className="font-semibold text-gray-900">Pages/Session</h3>
        <p className="text-sm text-gray-600">Average pages viewed</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-white rounded-lg p-6 border border-gray-200"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-orange-100 rounded-lg">
            <Heart className="w-6 h-6 text-orange-600" />
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-orange-600">
              {uxMetrics?.overview?.returnVisitorRate}%
            </div>
            <div className="flex items-center text-sm text-orange-600">
              <TrendingUp className="w-4 h-4 mr-1" />
              +3.1%
            </div>
          </div>
        </div>
        <h3 className="font-semibold text-gray-900">Return Visitors</h3>
        <p className="text-sm text-gray-600">Repeat user engagement</p>
      </motion.div>
    </div>
  );

  const renderConversionFunnel = () => (
    <div className="bg-white rounded-lg p-6 border border-gray-200">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Conversion Funnel</h3>
      <div className="space-y-4">
        {uxMetrics?.conversionFunnel?.map((stage, index) => (
          <motion.div
            key={stage?.stage}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="relative"
          >
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center text-sm font-semibold">
                  {index + 1}
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">{stage?.stage}</h4>
                  <p className="text-sm text-gray-600">{stage?.users?.toLocaleString()} users</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-lg font-bold text-gray-900">{stage?.conversion}%</div>
                {stage?.dropoff > 0 && (
                  <div className="text-sm text-red-600">-{stage?.dropoff}% dropoff</div>
                )}
              </div>
            </div>
            
            {/* Funnel Visual */}
            <div className="mt-2 mx-4">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${stage?.conversion}%` }}
                />
              </div>
            </div>

            {index < uxMetrics?.conversionFunnel?.length - 1 && (
              <div className="flex justify-center mt-2">
                <ChevronDown className="w-5 h-5 text-gray-400" />
              </div>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );

  const renderDeviceSegments = () => (
    <div className="bg-white rounded-lg p-6 border border-gray-200">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Performance by Device</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {Object.entries(uxMetrics?.deviceSegments || {})?.map(([device, metrics]) => {
          const icons = {
            desktop: Monitor,
            mobile: Smartphone,
            tablet: Globe
          };
          const Icon = icons?.[device];
          
          return (
            <motion.div
              key={device}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gray-50 rounded-lg p-4"
            >
              <div className="flex items-center space-x-3 mb-4">
                <div className="p-2 bg-white rounded-lg shadow-sm">
                  <Icon className="w-5 h-5 text-gray-600" />
                </div>
                <h4 className="font-medium text-gray-900 capitalize">{device}</h4>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Users</span>
                  <span className="text-sm font-medium">{metrics?.users?.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Conversion</span>
                  <span className="text-sm font-medium text-green-600">{metrics?.conversion}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Avg Session</span>
                  <span className="text-sm font-medium">{Math.floor(metrics?.avgSession / 60)}:{(metrics?.avgSession % 60)?.toString()?.padStart(2, '0')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Bounce Rate</span>
                  <span className="text-sm font-medium text-red-600">{metrics?.bounce}%</span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );

  const renderPerformanceCorrelation = () => (
    <div className="bg-white rounded-lg p-6 border border-gray-200">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Performance Impact on UX</h3>
      <div className="space-y-4">
        {uxMetrics?.performanceCorrelation?.pageSpeed?.map((item, index) => (
          <motion.div
            key={item?.loadTime}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
          >
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center shadow-sm">
                <Clock className="w-6 h-6 text-gray-600" />
              </div>
              <div>
                <h4 className="font-medium text-gray-900">Load Time: {item?.loadTime}</h4>
                <p className="text-sm text-gray-600">Page loading performance</p>
              </div>
            </div>
            <div className="text-right space-y-1">
              <div className="text-sm">
                <span className="text-gray-600">Conversion: </span>
                <span className="font-semibold text-green-600">{item?.conversion}%</span>
              </div>
              <div className="text-sm">
                <span className="text-gray-600">Engagement: </span>
                <span className="font-semibold text-blue-600">{item?.engagement}/10</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mb-4"></div>
        <h3 className="text-lg font-medium text-gray-900">Loading UX Metrics...</h3>
        <p className="text-gray-600 mt-1">Analyzing user behavior and engagement patterns</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">User Experience Monitor</h2>
          <p className="text-gray-600 mt-1">Track conversion rates, engagement metrics, and user behavior patterns</p>
        </div>
        <div className="flex items-center space-x-4">
          <select
            value={selectedTimeframe}
            onChange={(e) => setSelectedTimeframe(e?.target?.value)}
            className="rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </select>
        </div>
      </div>
      {/* Overview Cards */}
      {renderOverviewCards()}
      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Conversion Funnel */}
        {renderConversionFunnel()}

        {/* Device Segments */}
        {renderDeviceSegments()}
      </div>
      {/* Performance Correlation */}
      {renderPerformanceCorrelation()}
      {/* Real-time Activity */}
      <div className="bg-white rounded-lg p-6 border border-gray-200">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Real-time Activity</h3>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-gray-600">
              {uxMetrics?.realTimeActivity?.currentUsers} users online
            </span>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {uxMetrics?.realTimeActivity?.topPages?.map((page) => (
            <div key={page?.page} className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-900">{page?.page}</span>
                <span className="text-sm text-gray-600">{page?.users} users</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default UserExperienceMonitor;