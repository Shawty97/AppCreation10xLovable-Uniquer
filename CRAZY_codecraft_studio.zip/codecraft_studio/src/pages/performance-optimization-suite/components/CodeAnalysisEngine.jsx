import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Code, AlertTriangle, CheckCircle, TrendingUp, Bug, Zap, Package, RefreshCw, ArrowRight, FileText, Activity } from 'lucide-react';
import Icon from '../../../components/AppIcon';


const CodeAnalysisEngine = () => {
  const [analysisResults, setAnalysisResults] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedFilter, setSelectedFilter] = useState('all');

  useEffect(() => {
    performCodeAnalysis();
  }, []);

  const performCodeAnalysis = async () => {
    try {
      // Simulate code analysis
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setAnalysisResults({
        overview: {
          totalFiles: 247,
          linesOfCode: 18429,
          issues: 23,
          duplicateCode: 8.2,
          testCoverage: 85.7,
          maintainabilityIndex: 74
        },
        issues: [
          {
            id: 1,
            type: 'performance',
            severity: 'high',
            title: 'Large bundle size in components/Dashboard.jsx',
            description: 'Component imports entire lodash library instead of specific functions',
            file: 'src/components/Dashboard.jsx',
            line: 12,
            impact: 'Increases bundle size by 67KB',
            fix: 'Import specific lodash functions instead of entire library'
          },
          {
            id: 2,
            type: 'performance',
            severity: 'medium',
            title: 'Unused CSS rules detected',
            description: '156 CSS rules are not being used in the application',
            file: 'src/styles/globals.css',
            line: null,
            impact: 'Adds 12KB to stylesheet',
            fix: 'Remove unused CSS rules or implement CSS purging'
          },
          {
            id: 3,
            type: 'optimization',
            severity: 'medium',
            title: 'Missing React.memo for heavy component',
            description: 'DataTable component re-renders on every parent update',
            file: 'src/components/DataTable.jsx',
            line: 45,
            impact: 'Unnecessary re-renders affecting performance',
            fix: 'Wrap component with React.memo and optimize props'
          },
          {
            id: 4,
            type: 'dependency',
            severity: 'low',
            title: 'Outdated dependency versions',
            description: '5 dependencies have security updates available',
            file: 'package.json',
            line: null,
            impact: 'Potential security vulnerabilities',
            fix: 'Update dependencies to latest secure versions'
          }
        ],
        dependencies: {
          total: 89,
          outdated: 5,
          vulnerable: 2,
          unused: 3,
          heavy: [
            { name: 'lodash', size: '67.3KB', usage: '12%' },
            { name: 'moment', size: '45.2KB', usage: '8%' },
            { name: '@babel/polyfill', size: '89.1KB', usage: '5%' }
          ]
        },
        optimizations: [
          {
            id: 1,
            category: 'Bundle Splitting',
            title: 'Implement route-based code splitting',
            impact: 'Reduce initial bundle size by 40%',
            effort: 'Medium',
            automated: true
          },
          {
            id: 2,
            category: 'Tree Shaking',
            title: 'Enable tree shaking for unused exports',
            impact: 'Reduce bundle size by 15%',
            effort: 'Low',
            automated: true
          },
          {
            id: 3,
            category: 'Image Optimization',
            title: 'Convert images to WebP format',
            impact: 'Reduce image sizes by 35%',
            effort: 'Low',
            automated: false
          }
        ]
      });
      
      setLoading(false);
    } catch (error) {
      console.error('Error performing code analysis:', error);
      setLoading(false);
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-blue-600 bg-blue-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'performance': return Zap;
      case 'optimization': return TrendingUp;
      case 'dependency': return Package;
      default: return Bug;
    }
  };

  const filteredIssues = analysisResults?.issues?.filter(issue => 
    selectedFilter === 'all' || issue?.type === selectedFilter
  ) || [];

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg p-6 border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-100 rounded-lg">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-2xl font-bold text-blue-600">
              {analysisResults?.overview?.totalFiles}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900">Total Files</h3>
          <p className="text-sm text-gray-600">{analysisResults?.overview?.linesOfCode?.toLocaleString()} lines of code</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-lg p-6 border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-yellow-100 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-yellow-600" />
            </div>
            <span className="text-2xl font-bold text-yellow-600">
              {analysisResults?.overview?.issues}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900">Issues Found</h3>
          <p className="text-sm text-gray-600">Performance and optimization opportunities</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-lg p-6 border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-green-100 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-2xl font-bold text-green-600">
              {analysisResults?.overview?.maintainabilityIndex}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900">Maintainability</h3>
          <p className="text-sm text-gray-600">Code quality index score</p>
        </motion.div>
      </div>

      {/* Quick Stats */}
      <div className="bg-white rounded-lg p-6 border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Code Quality Metrics</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-600">Test Coverage</span>
              <span className="text-sm font-medium">{analysisResults?.overview?.testCoverage}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-green-600 h-2 rounded-full"
                style={{ width: `${analysisResults?.overview?.testCoverage}%` }}
              />
            </div>
          </div>
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-600">Duplicate Code</span>
              <span className="text-sm font-medium">{analysisResults?.overview?.duplicateCode}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-yellow-600 h-2 rounded-full"
                style={{ width: `${analysisResults?.overview?.duplicateCode}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderIssuesTab = () => (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <select
            value={selectedFilter}
            onChange={(e) => setSelectedFilter(e?.target?.value)}
            className="rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Issues</option>
            <option value="performance">Performance</option>
            <option value="optimization">Optimization</option>
            <option value="dependency">Dependencies</option>
          </select>
        </div>
        <button className="flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
          <RefreshCw className="w-4 h-4" />
          <span>Re-analyze</span>
        </button>
      </div>

      {/* Issues List */}
      <div className="space-y-4">
        {filteredIssues?.map((issue) => {
          const TypeIcon = getTypeIcon(issue?.type);
          
          return (
            <motion.div
              key={issue?.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-lg p-6 border border-gray-200 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className="p-2 bg-gray-100 rounded-lg">
                    <TypeIcon className="w-5 h-5 text-gray-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h4 className="font-semibold text-gray-900">{issue?.title}</h4>
                      <span className={`px-2 py-1 text-xs rounded-full ${getSeverityColor(issue?.severity)}`}>
                        {issue?.severity}
                      </span>
                    </div>
                    <p className="text-gray-600 mb-3">{issue?.description}</p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span>{issue?.file}</span>
                      {issue?.line && <span>Line {issue?.line}</span>}
                    </div>
                    <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                      <p className="text-sm text-blue-800">
                        <strong>Impact:</strong> {issue?.impact}
                      </p>
                      <p className="text-sm text-blue-800 mt-1">
                        <strong>Fix:</strong> {issue?.fix}
                      </p>
                    </div>
                  </div>
                </div>
                <button className="p-2 text-gray-400 hover:text-gray-600">
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );

  const renderOptimizationsTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6">
        {analysisResults?.optimizations?.map((optimization) => (
          <motion.div
            key={optimization?.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg p-6 border border-gray-200"
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="font-semibold text-gray-900">{optimization?.title}</h4>
                <p className="text-sm text-gray-600">{optimization?.category}</p>
              </div>
              <div className="flex items-center space-x-3">
                {optimization?.automated && (
                  <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full">
                    Auto-fix Available
                  </span>
                )}
                <span className={`px-2 py-1 text-xs rounded-full ${
                  optimization?.effort === 'Low' ? 'bg-green-100 text-green-700' :
                  optimization?.effort === 'Medium'? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'
                }`}>
                  {optimization?.effort} Effort
                </span>
              </div>
            </div>
            
            <p className="text-gray-600 mb-4">{optimization?.impact}</p>
            
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Estimated performance improvement
              </div>
              <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
                {optimization?.automated ? 'Apply Fix' : 'View Details'}
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mb-4"></div>
        <h3 className="text-lg font-medium text-gray-900">Analyzing Code...</h3>
        <p className="text-gray-600 mt-1">Scanning for performance bottlenecks and optimization opportunities</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Code Analysis Engine</h2>
        <p className="text-gray-600 mt-1">Automated performance analysis and optimization recommendations</p>
      </div>
      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {[
            { key: 'overview', label: 'Overview', icon: Activity },
            { key: 'issues', label: 'Issues', icon: AlertTriangle },
            { key: 'optimizations', label: 'Optimizations', icon: TrendingUp }
          ]?.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === key
                  ? 'border-indigo-500 text-indigo-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{label}</span>
            </button>
          ))}
        </nav>
      </div>
      {/* Tab Content */}
      <div>
        {activeTab === 'overview' && renderOverviewTab()}
        {activeTab === 'issues' && renderIssuesTab()}
        {activeTab === 'optimizations' && renderOptimizationsTab()}
      </div>
    </div>
  );
};

export default CodeAnalysisEngine;