import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Package, TrendingDown, Scissors, Zap, Download, FileText, Image, Code, Layers, PieChart, BarChart3, CheckCircle, AlertCircle, Clock, HardDrive } from 'lucide-react';
import { supabase } from '../../../lib/supabase';
import Icon from '../../../components/AppIcon';


const BundleOptimizer = ({ performanceData }) => {
  const [bundleAnalysis, setBundleAnalysis] = useState(null);
  const [optimizationProgress, setOptimizationProgress] = useState({});
  const [loading, setLoading] = useState(true);
  const [activeView, setActiveView] = useState('overview');

  useEffect(() => {
    loadBundleAnalysis();
  }, []);

  const loadBundleAnalysis = async () => {
    try {
      // Get bundle size data from Supabase deployment_metrics
      const { data, error } = await supabase
        ?.from('deployment_metrics')
        ?.select('bundle_size_mb, metrics_data')
        ?.order('measured_at', { ascending: false })
        ?.limit(5);

      if (!error && data?.length > 0) {
        const latest = data?.[0];
        const bundleSizeMB = latest?.bundle_size_mb || 245.6;
        
        setBundleAnalysis({
          totalSize: bundleSizeMB * 1024, // Convert to KB
          breakdown: {
            javascript: (bundleSizeMB * 1024 * 0.65), // 65% JS
            css: (bundleSizeMB * 1024 * 0.20), // 20% CSS
            images: (bundleSizeMB * 1024 * 0.15), // 15% Images
            fonts: (bundleSizeMB * 1024 * 0.05), // 5% Fonts
            other: (bundleSizeMB * 1024 * 0.05) // 5% Other
          },
          chunks: [
            { name: 'main.js', size: bundleSizeMB * 1024 * 0.35, type: 'javascript', optimizable: true },
            { name: 'vendor.js', size: bundleSizeMB * 1024 * 0.25, type: 'javascript', optimizable: true },
            { name: 'components.js', size: bundleSizeMB * 1024 * 0.15, type: 'javascript', optimizable: false },
            { name: 'styles.css', size: bundleSizeMB * 1024 * 0.20, type: 'css', optimizable: true },
            { name: 'assets', size: bundleSizeMB * 1024 * 0.05, type: 'other', optimizable: false }
          ]
        });
      } else {
        // Fallback to demo data
        setBundleAnalysis({
          totalSize: performanceData?.bundleSize?.total || 245.6,
          breakdown: {
            javascript: performanceData?.bundleSize?.javascript || 156.2,
            css: performanceData?.bundleSize?.css || 45.8,
            images: performanceData?.bundleSize?.images || 43.6,
            fonts: 12.4,
            other: 8.2
          },
          chunks: [
            { name: 'main.js', size: 85.3, type: 'javascript', optimizable: true },
            { name: 'vendor.js', size: 70.9, type: 'javascript', optimizable: true },
            { name: 'components.js', size: 34.2, type: 'javascript', optimizable: false },
            { name: 'styles.css', size: 45.8, type: 'css', optimizable: true },
            { name: 'assets', size: 9.4, type: 'other', optimizable: false }
          ]
        });
      }

      setOptimizationProgress({
        'tree-shaking': { status: 'available', savings: 23.4 },
        'code-splitting': { status: 'in-progress', savings: 45.2 },
        'compression': { status: 'completed', savings: 12.1 },
        'minification': { status: 'completed', savings: 18.7 }
      });

      setLoading(false);
    } catch (error) {
      console.error('Error loading bundle analysis:', error);
      setLoading(false);
    }
  };

  const optimizationTechniques = [
    {
      id: 'tree-shaking',
      title: 'Tree Shaking',
      description: 'Remove unused code from bundles',
      icon: Scissors,
      impact: 'High',
      effort: 'Low',
      savings: '23.4 KB',
      automated: true,
      enabled: true
    },
    {
      id: 'code-splitting',
      title: 'Code Splitting',
      description: 'Split code into smaller chunks loaded on demand',
      icon: Layers,
      impact: 'High',
      effort: 'Medium',
      savings: '45.2 KB',
      automated: true,
      enabled: false
    },
    {
      id: 'compression',
      title: 'Gzip Compression',
      description: 'Compress assets for faster transfer',
      icon: Download,
      impact: 'Medium',
      effort: 'Low',
      savings: '12.1 KB',
      automated: true,
      enabled: true
    },
    {
      id: 'minification',
      title: 'Minification',
      description: 'Remove whitespace and comments',
      icon: Code,
      impact: 'Medium',
      effort: 'Low',
      savings: '18.7 KB',
      automated: true,
      enabled: true
    },
    {
      id: 'image-optimization',
      title: 'Image Optimization',
      description: 'Convert to WebP and optimize sizes',
      icon: Image,
      impact: 'High',
      effort: 'Medium',
      savings: '67.3 KB',
      automated: false,
      enabled: false
    }
  ];

  const getFileTypeColor = (type) => {
    switch (type) {
      case 'javascript': return 'bg-yellow-500';
      case 'css': return 'bg-blue-500';
      case 'images': return 'bg-green-500';
      case 'fonts': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const getFileTypeIcon = (type) => {
    switch (type) {
      case 'javascript': return Code;
      case 'css': return FileText;
      case 'images': return Image;
      default: return Package;
    }
  };

  const handleOptimizationToggle = async (techniqueId, enabled) => {
    setOptimizationProgress(prev => ({
      ...prev,
      [techniqueId]: {
        ...prev?.[techniqueId],
        status: enabled ? 'in-progress' : 'available'
      }
    }));

    // Simulate optimization process
    setTimeout(() => {
      setOptimizationProgress(prev => ({
        ...prev,
        [techniqueId]: {
          ...prev?.[techniqueId],
          status: enabled ? 'completed' : 'available'
        }
      }));
    }, 2000);
  };

  const renderOverviewView = () => (
    <div className="space-y-6">
      {/* Bundle Size Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg p-6 border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-purple-100 rounded-lg">
              <HardDrive className="w-6 h-6 text-purple-600" />
            </div>
            <span className="text-2xl font-bold text-purple-600">
              {bundleAnalysis?.totalSize?.toFixed(1)}KB
            </span>
          </div>
          <h3 className="font-semibold text-gray-900">Total Bundle Size</h3>
          <p className="text-sm text-gray-600">Current application size</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-lg p-6 border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-green-100 rounded-lg">
              <TrendingDown className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-2xl font-bold text-green-600">127.8KB</span>
          </div>
          <h3 className="font-semibold text-gray-900">Potential Savings</h3>
          <p className="text-sm text-gray-600">With all optimizations</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-lg p-6 border border-gray-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-100 rounded-lg">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-2xl font-bold text-blue-600">2.3s</span>
          </div>
          <h3 className="font-semibold text-gray-900">Load Time Impact</h3>
          <p className="text-sm text-gray-600">Estimated improvement</p>
        </motion.div>
      </div>

      {/* Bundle Breakdown */}
      <div className="bg-white rounded-lg p-6 border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Bundle Breakdown</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Pie Chart Representation */}
          <div className="space-y-4">
            {bundleAnalysis?.breakdown && Object.entries(bundleAnalysis?.breakdown)?.map(([type, size]) => {
              const percentage = ((size / bundleAnalysis?.totalSize) * 100)?.toFixed(1);
              const Icon = getFileTypeIcon(type);
              
              return (
                <div key={type} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-4 h-4 rounded ${getFileTypeColor(type)}`} />
                    <div className="flex items-center space-x-2">
                      <Icon className="w-4 h-4 text-gray-600" />
                      <span className="font-medium text-gray-900 capitalize">{type}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-gray-900">{size?.toFixed(1)}KB</div>
                    <div className="text-sm text-gray-600">{percentage}%</div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Progress Bars */}
          <div className="space-y-4">
            {bundleAnalysis?.breakdown && Object.entries(bundleAnalysis?.breakdown)?.map(([type, size]) => {
              const percentage = (size / bundleAnalysis?.totalSize) * 100;
              
              return (
                <div key={type}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600 capitalize">{type}</span>
                    <span className="text-gray-900">{percentage?.toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full ${getFileTypeColor(type)}`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );

  const renderOptimizationsView = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6">
        {optimizationTechniques?.map((technique) => {
          const Icon = technique?.icon;
          const progress = optimizationProgress?.[technique?.id];
          
          return (
            <motion.div
              key={technique?.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-lg p-6 border border-gray-200"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-indigo-100 rounded-lg">
                    <Icon className="w-6 h-6 text-indigo-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">{technique?.title}</h4>
                    <p className="text-sm text-gray-600">{technique?.description}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    technique?.impact === 'High' ? 'bg-red-100 text-red-700' :
                    technique?.impact === 'Medium'? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'
                  }`}>
                    {technique?.impact} Impact
                  </span>
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    technique?.effort === 'Low' ? 'bg-green-100 text-green-700' :
                    technique?.effort === 'Medium'? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'
                  }`}>
                    {technique?.effort} Effort
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="text-sm text-gray-600">
                    Potential savings: <span className="font-semibold text-green-600">{technique?.savings}</span>
                  </div>
                  {progress?.status && (
                    <div className="flex items-center space-x-1">
                      {progress?.status === 'completed' && <CheckCircle className="w-4 h-4 text-green-600" />}
                      {progress?.status === 'in-progress' && <div className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />}
                      {progress?.status === 'available' && <AlertCircle className="w-4 h-4 text-yellow-600" />}
                      <span className="text-sm text-gray-600 capitalize">{progress?.status?.replace('-', ' ')}</span>
                    </div>
                  )}
                </div>
                
                <div className="flex items-center space-x-2">
                  {technique?.automated && (
                    <span className="px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded-full">
                      Auto-fix
                    </span>
                  )}
                  <button
                    onClick={() => handleOptimizationToggle(technique?.id, !technique?.enabled)}
                    disabled={progress?.status === 'in-progress'}
                    className={`px-4 py-2 rounded-lg text-sm font-medium ${
                      technique?.enabled || progress?.status === 'completed'
                        ? 'bg-green-600 text-white hover:bg-green-700' :'bg-indigo-600 text-white hover:bg-indigo-700'
                    } disabled:opacity-50 disabled:cursor-not-allowed`}
                  >
                    {progress?.status === 'in-progress' ? 'Optimizing...' :
                     progress?.status === 'completed'? 'Optimized' : technique?.enabled ?'Enabled' : 'Enable'}
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );

  const renderChunksView = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Bundle Chunks</h3>
          <p className="text-sm text-gray-600">Individual file analysis and optimization opportunities</p>
        </div>
        <div className="divide-y divide-gray-200">
          {bundleAnalysis?.chunks?.map((chunk, index) => {
            const Icon = getFileTypeIcon(chunk?.type);
            
            return (
              <motion.div
                key={chunk?.name}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="px-6 py-4 hover:bg-gray-50"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="p-2 bg-gray-100 rounded-lg">
                      <Icon className="w-5 h-5 text-gray-600" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">{chunk?.name}</h4>
                      <p className="text-sm text-gray-600 capitalize">{chunk?.type} file</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-6">
                    <div className="text-right">
                      <div className="font-semibold text-gray-900">{chunk?.size?.toFixed(1)}KB</div>
                      <div className="text-sm text-gray-600">
                        {((chunk?.size / bundleAnalysis?.totalSize) * 100)?.toFixed(1)}% of total
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {chunk?.optimizable ? (
                        <span className="px-2 py-1 text-xs bg-yellow-100 text-yellow-700 rounded-full">
                          Optimizable
                        </span>
                      ) : (
                        <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full">
                          Optimized
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mb-4"></div>
        <h3 className="text-lg font-medium text-gray-900">Analyzing Bundle...</h3>
        <p className="text-gray-600 mt-1">Evaluating optimization opportunities</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Bundle Optimizer</h2>
        <p className="text-gray-600 mt-1">Asset compression, code splitting, and performance optimization tools</p>
      </div>
      {/* View Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {[
            { key: 'overview', label: 'Overview', icon: PieChart },
            { key: 'optimizations', label: 'Optimizations', icon: Zap },
            { key: 'chunks', label: 'File Analysis', icon: BarChart3 }
          ]?.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setActiveView(key)}
              className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm ${
                activeView === key
                  ? 'border-indigo-500 text-indigo-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{label}</span>
            </button>
          ))}
        </nav>
      </div>
      {/* Content */}
      <div>
        {activeView === 'overview' && renderOverviewView()}
        {activeView === 'optimizations' && renderOptimizationsView()}
        {activeView === 'chunks' && renderChunksView()}
      </div>
    </div>
  );
};

export default BundleOptimizer;