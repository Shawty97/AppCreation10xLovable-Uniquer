import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Select from '../../components/ui/Select';


import BuildQueue from './components/BuildQueue';
import PipelineVisualization from './components/PipelineVisualization';
import BuildConfiguration from './components/BuildConfiguration';
import LogViewer from './components/LogViewer';
import TestingPanel from './components/TestingPanel';
import OptimizationSettings from './components/OptimizationSettings';
import RollbackManager from './components/RollbackManager';

const BuildPipeline = () => {
  const navigate = useNavigate();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [activePanel, setActivePanel] = useState('dashboard');
  const [buildStatus, setBuildStatus] = useState('idle');
  const [buildLogs, setBuildLogs] = useState([]);
  const [buildQueue, setBuildQueue] = useState([]);
  const [pipelineStages, setPipelineStages] = useState([]);

  // Mock project data
  const mockProjects = [
    {
      id: 1,
      name: "E-commerce Dashboard",
      type: "React Web App",
      framework: "React",
      buildTime: "2m 34s",
      status: "building",
      lastBuild: new Date(Date.now() - 300000),
      buildNumber: "#1247",
      branch: "main",
      commit: "a7b3c45"
    },
    {
      id: 2,
      name: "Task Management App",
      type: "Progressive Web App", 
      framework: "Vue.js",
      buildTime: "1m 56s",
      status: "success",
      lastBuild: new Date(Date.now() - 1800000),
      buildNumber: "#1246",
      branch: "develop",
      commit: "x9e2f12"
    },
    {
      id: 3,
      name: "Restaurant Website",
      type: "Static Site",
      framework: "Next.js",
      buildTime: "45s",
      status: "failed",
      lastBuild: new Date(Date.now() - 3600000),
      buildNumber: "#1245",
      branch: "feature/menu-update",
      commit: "m3k7p89"
    }
  ];

  const [projects, setProjects] = useState(mockProjects);

  // Mock build queue data
  const mockBuildQueue = [
    {
      id: 1,
      projectName: "E-commerce Dashboard",
      status: "building",
      progress: 65,
      stage: "Testing",
      estimatedTime: "1m 25s",
      startTime: new Date(Date.now() - 180000),
      queuePosition: 0
    },
    {
      id: 2,
      projectName: "Portfolio Site",
      status: "queued",
      progress: 0,
      stage: "Waiting",
      estimatedTime: "2m 10s",
      startTime: null,
      queuePosition: 1
    },
    {
      id: 3,
      projectName: "Blog Platform",
      status: "queued", 
      progress: 0,
      stage: "Waiting",
      estimatedTime: "3m 45s",
      startTime: null,
      queuePosition: 2
    }
  ];

  // Mock pipeline stages
  const mockPipelineStages = [
    {
      id: 1,
      name: "Code Checkout",
      status: "completed",
      duration: "12s",
      icon: "GitBranch"
    },
    {
      id: 2,
      name: "Install Dependencies",
      status: "completed",
      duration: "45s", 
      icon: "Package"
    },
    {
      id: 3,
      name: "Build Application",
      status: "running",
      duration: "1m 23s",
      progress: 65,
      icon: "Hammer"
    },
    {
      id: 4,
      name: "Run Tests",
      status: "pending",
      duration: "",
      icon: "TestTube"
    },
    {
      id: 5,
      name: "Security Scan",
      status: "pending", 
      duration: "",
      icon: "Shield"
    },
    {
      id: 6,
      name: "Optimize Assets",
      status: "pending",
      duration: "",
      icon: "Zap"
    },
    {
      id: 7,
      name: "Deploy",
      status: "pending",
      duration: "",
      icon: "Rocket"
    }
  ];

  const navigationPanels = [
    { id: 'dashboard', label: 'Dashboard', icon: 'LayoutDashboard' },
    { id: 'queue', label: 'Build Queue', icon: 'Clock' },
    { id: 'pipeline', label: 'Pipeline View', icon: 'Workflow' },
    { id: 'configuration', label: 'Configuration', icon: 'Settings' },
    { id: 'logs', label: 'Build Logs', icon: 'FileText' },
    { id: 'testing', label: 'Testing', icon: 'TestTube' },
    { id: 'optimization', label: 'Optimization', icon: 'Zap' },
    { id: 'rollback', label: 'Rollback', icon: 'RotateCcw' }
  ];

  useEffect(() => {
    if (projects?.length > 0 && !selectedProject) {
      setSelectedProject(projects?.[0]);
    }
    setBuildQueue(mockBuildQueue);
    setPipelineStages(mockPipelineStages);
  }, [projects]);

  // Simulate real-time build updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Update build progress and logs
      setBuildQueue(prev => prev?.map(build => {
        if (build?.status === 'building') {
          const newProgress = Math.min(build?.progress + Math.random() * 5, 100);
          return { ...build, progress: newProgress };
        }
        return build;
      }));

      // Add random log entries
      const logMessages = [
        'Installing dependencies...',
        'Compiling source code...',
        'Running unit tests...',
        'Building production bundle...',
        'Optimizing images...',
        'Minifying JavaScript...',
        'Generating source maps...',
        'Running security checks...'
      ];

      if (Math.random() > 0.7) {
        setBuildLogs(prev => [...prev, {
          id: Date.now(),
          message: logMessages?.[Math.floor(Math.random() * logMessages?.length)],
          timestamp: new Date(),
          level: Math.random() > 0.8 ? 'warning' : 'info'
        }]);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const handleStartBuild = async (projectId) => {
    setBuildStatus('building');
    setBuildLogs(prev => [...prev, {
      id: Date.now(),
      message: `Starting build for ${selectedProject?.name}...`,
      timestamp: new Date(),
      level: 'info'
    }]);

    // Simulate build process
    const stages = ['checkout', 'install', 'build', 'test', 'deploy'];
    for (const stage of stages) {
      await new Promise(resolve => setTimeout(resolve, 2000));
      setBuildLogs(prev => [...prev, {
        id: Date.now(),
        message: `Completed ${stage} stage`,
        timestamp: new Date(),
        level: 'success'
      }]);
    }

    setBuildStatus('success');
  };

  const handleCancelBuild = (buildId) => {
    setBuildQueue(prev => prev?.filter(build => build?.id !== buildId));
    setBuildLogs(prev => [...prev, {
      id: Date.now(),
      message: `Build #${buildId} cancelled by user`,
      timestamp: new Date(),
      level: 'warning'
    }]);
  };

  const renderPanelContent = () => {
    switch (activePanel) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            {/* Build Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-card border border-border rounded-lg p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Active Builds</p>
                    <p className="text-2xl font-bold text-foreground">
                      {buildQueue?.filter(b => b?.status === 'building')?.length}
                    </p>
                  </div>
                  <Icon name="Activity" size={24} className="text-primary" />
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  +2 from yesterday
                </p>
              </div>

              <div className="bg-card border border-border rounded-lg p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Queue Length</p>
                    <p className="text-2xl font-bold text-foreground">
                      {buildQueue?.filter(b => b?.status === 'queued')?.length}
                    </p>
                  </div>
                  <Icon name="Clock" size={24} className="text-warning" />
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Average wait: 5m
                </p>
              </div>

              <div className="bg-card border border-border rounded-lg p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Success Rate</p>
                    <p className="text-2xl font-bold text-success">94%</p>
                  </div>
                  <Icon name="CheckCircle" size={24} className="text-success" />
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Last 100 builds
                </p>
              </div>

              <div className="bg-card border border-border rounded-lg p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg Build Time</p>
                    <p className="text-2xl font-bold text-foreground">2m 18s</p>
                  </div>
                  <Icon name="Timer" size={24} className="text-info" />
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  -23s improvement
                </p>
              </div>
            </div>

            {/* Recent Builds */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-card border border-border rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-foreground">Recent Builds</h3>
                  <Button variant="outline" size="sm" onClick={() => setActivePanel('queue')}>
                    View All
                  </Button>
                </div>
                <div className="space-y-3">
                  {projects?.slice(0, 3)?.map((project) => (
                    <div key={project?.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${
                          project?.status === 'success' ? 'bg-success' :
                          project?.status === 'building' ? 'bg-warning animate-pulse' :
                          project?.status === 'failed' ? 'bg-destructive' : 'bg-muted-foreground'
                        }`} />
                        <div>
                          <h4 className="font-medium text-foreground">{project?.name}</h4>
                          <p className="text-sm text-muted-foreground">{project?.buildNumber} • {project?.branch}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-foreground">{project?.buildTime}</p>
                        <p className="text-xs text-muted-foreground">{project?.lastBuild?.toLocaleTimeString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-card border border-border rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-foreground">Resource Usage</h3>
                  <Icon name="BarChart3" size={16} className="text-muted-foreground" />
                </div>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-foreground">CPU Usage</span>
                      <span className="text-sm text-muted-foreground">68%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full" style={{ width: '68%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-foreground">Memory</span>
                      <span className="text-sm text-muted-foreground">84%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-warning h-2 rounded-full" style={{ width: '84%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-foreground">Storage</span>
                      <span className="text-sm text-muted-foreground">52%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-success h-2 rounded-full" style={{ width: '52%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'queue':
        return <BuildQueue builds={buildQueue} onCancel={handleCancelBuild} onRetry={handleStartBuild} />;
        
      case 'pipeline':
        return <PipelineVisualization stages={pipelineStages} />;
        
      case 'configuration':
        return <BuildConfiguration selectedProject={selectedProject} />;
        
      case 'logs':
        return <LogViewer logs={buildLogs} />;
        
      case 'testing':
        return <TestingPanel selectedProject={selectedProject} />;
        
      case 'optimization':
        return <OptimizationSettings selectedProject={selectedProject} />;
        
      case 'rollback':
        return <RollbackManager selectedProject={selectedProject} onRollback={handleStartBuild} />;

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar 
        isCollapsed={isSidebarCollapsed} 
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)} 
      />
      <main className={`pt-16 transition-all duration-300 ${
        isSidebarCollapsed ? 'lg:pl-16' : 'lg:pl-60'
      } pb-20 lg:pb-6`}>
        <div className="p-6 max-w-7xl mx-auto">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold text-foreground">Build Pipeline</h1>
                <p className="text-muted-foreground">
                  Comprehensive interface for managing application compilation, testing, and deployment workflows
                </p>
              </div>
              
              <div className="flex items-center space-x-3">
                <Select
                  options={projects?.map(p => ({ value: p?.id, label: p?.name }))}
                  value={selectedProject?.id}
                  onChange={(value) => setSelectedProject(projects?.find(p => p?.id === value))}
                  placeholder="Select project..."
                  className="w-64"
                />
                <Button
                  variant="outline"
                  iconName="RefreshCw"
                  iconPosition="left"
                  iconSize={16}
                  onClick={() => window.location?.reload()}
                >
                  Refresh
                </Button>
                <Button
                  variant="default"
                  iconName="Play"
                  iconPosition="left"
                  iconSize={16}
                  onClick={() => handleStartBuild(selectedProject?.id)}
                  disabled={buildStatus === 'building'}
                >
                  {buildStatus === 'building' ? 'Building...' : 'Start Build'}
                </Button>
              </div>
            </div>
          </div>

          {/* Project Status Banner */}
          {selectedProject && (
            <div className={`border rounded-lg p-4 mb-6 ${
              selectedProject?.status === 'success' ? 'bg-success/10 border-success/20' :
              selectedProject?.status === 'building' ? 'bg-warning/10 border-warning/20' :
              selectedProject?.status === 'failed'? 'bg-destructive/10 border-destructive/20' : 'bg-muted/50 border-border'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Icon 
                    name={
                      selectedProject?.status === 'success' ? 'CheckCircle' :
                      selectedProject?.status === 'building' ? 'Clock' :
                      selectedProject?.status === 'failed' ? 'XCircle' : 'Circle'
                    } 
                    size={20}
                    className={
                      selectedProject?.status === 'success' ? 'text-success' :
                      selectedProject?.status === 'building' ? 'text-warning' :
                      selectedProject?.status === 'failed' ? 'text-destructive' : 'text-muted-foreground'
                    }
                  />
                  <div>
                    <h3 className="font-semibold text-foreground">{selectedProject?.name}</h3>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                      <span>Build {selectedProject?.buildNumber}</span>
                      <span>•</span>
                      <span>{selectedProject?.branch} ({selectedProject?.commit})</span>
                      <span>•</span>
                      <span>Duration: {selectedProject?.buildTime}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {selectedProject?.status === 'building' && (
                    <Button variant="outline" size="sm" onClick={() => setBuildStatus('idle')}>
                      Cancel Build
                    </Button>
                  )}
                  <Button variant="ghost" size="sm" onClick={() => setActivePanel('logs')}>
                    View Logs
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Panels */}
          <div className="mb-6">
            <div className="border-b border-border">
              <nav className="-mb-px flex space-x-8 overflow-x-auto">
                {navigationPanels?.map((panel) => (
                  <button
                    key={panel?.id}
                    onClick={() => setActivePanel(panel?.id)}
                    className={`whitespace-nowrap flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm ${
                      activePanel === panel?.id
                        ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
                    }`}
                  >
                    <Icon name={panel?.icon} size={16} />
                    <span>{panel?.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Panel Content */}
          <div className="min-h-96">
            {renderPanelContent()}
          </div>
        </div>
      </main>
    </div>
  );
};

export default BuildPipeline;