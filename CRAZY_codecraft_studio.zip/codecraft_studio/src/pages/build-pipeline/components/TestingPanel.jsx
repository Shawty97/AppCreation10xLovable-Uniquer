import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';


const TestingPanel = ({ selectedProject }) => {
  const [activeTab, setActiveTab] = useState('unit');
  const [testResults, setTestResults] = useState({
    unit: {
      total: 127,
      passed: 125,
      failed: 2,
      duration: '45.2s',
      coverage: 94.2,
      status: 'completed'
    },
    integration: {
      total: 23,
      passed: 23,
      failed: 0,
      duration: '1m 23s',
      status: 'completed'
    },
    e2e: {
      total: 8,
      passed: 7,
      failed: 1,
      duration: '3m 12s',
      status: 'running'
    },
    performance: {
      lighthouse: 87,
      fcp: '1.2s',
      lcp: '2.1s',
      cls: 0.05,
      status: 'completed'
    },
    security: {
      vulnerabilities: 2,
      severity: 'medium',
      status: 'completed'
    }
  });

  const testTabs = [
    { id: 'unit', label: 'Unit Tests', icon: 'TestTube' },
    { id: 'integration', label: 'Integration', icon: 'Link' },
    { id: 'e2e', label: 'End-to-End', icon: 'Monitor' },
    { id: 'performance', label: 'Performance', icon: 'Zap' },
    { id: 'security', label: 'Security', icon: 'Shield' }
  ];

  const mockUnitTests = [
    {
      id: 1,
      name: 'UserAuthService.login',
      status: 'passed',
      duration: '23ms',
      suite: 'Authentication'
    },
    {
      id: 2,
      name: 'PaymentProcessor.validateCard',
      status: 'failed',
      duration: '156ms',
      suite: 'Payment',
      error: 'Expected true but received false'
    },
    {
      id: 3,
      name: 'ProductCatalog.fetchItems',
      status: 'passed',
      duration: '89ms',
      suite: 'Products'
    },
    {
      id: 4,
      name: 'CartService.addItem',
      status: 'failed',
      duration: '34ms',
      suite: 'Shopping Cart',
      error: 'Cannot read property of undefined'
    },
    {
      id: 5,
      name: 'EmailService.sendNotification',
      status: 'passed',
      duration: '245ms',
      suite: 'Notifications'
    }
  ];

  const runTests = async (testType) => {
    setTestResults(prev => ({
      ...prev,
      [testType]: {
        ...prev?.[testType],
        status: 'running'
      }
    }));

    // Simulate test run
    setTimeout(() => {
      setTestResults(prev => ({
        ...prev,
        [testType]: {
          ...prev?.[testType],
          status: 'completed'
        }
      }));
    }, 3000);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'passed':
        return 'text-success';
      case 'failed':
        return 'text-destructive';
      case 'running':
        return 'text-warning';
      case 'skipped':
        return 'text-muted-foreground';
      default:
        return 'text-foreground';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'passed':
        return 'CheckCircle';
      case 'failed':
        return 'XCircle';
      case 'running':
        return 'Clock';
      case 'skipped':
        return 'Minus';
      default:
        return 'Circle';
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'unit':
        return (
          <div className="space-y-6">
            {/* Unit Test Summary */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-success/10 border border-success/20 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-success">Passed</p>
                    <p className="text-xl font-bold text-success">{testResults?.unit?.passed}</p>
                  </div>
                  <Icon name="CheckCircle" size={20} className="text-success" />
                </div>
              </div>

              <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-destructive">Failed</p>
                    <p className="text-xl font-bold text-destructive">{testResults?.unit?.failed}</p>
                  </div>
                  <Icon name="XCircle" size={20} className="text-destructive" />
                </div>
              </div>

              <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-primary">Coverage</p>
                    <p className="text-xl font-bold text-primary">{testResults?.unit?.coverage}%</p>
                  </div>
                  <Icon name="BarChart3" size={20} className="text-primary" />
                </div>
              </div>

              <div className="bg-muted/50 border border-border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Duration</p>
                    <p className="text-xl font-bold text-foreground">{testResults?.unit?.duration}</p>
                  </div>
                  <Icon name="Timer" size={20} className="text-muted-foreground" />
                </div>
              </div>
            </div>
            {/* Test Results List */}
            <div className="bg-card border border-border rounded-lg">
              <div className="p-4 border-b border-border">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-foreground">Test Results</h4>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <Icon name="Filter" size={14} className="mr-1" />
                      Filter
                    </Button>
                    <Button 
                      variant="default" 
                      size="sm"
                      onClick={() => runTests('unit')}
                    >
                      <Icon name="Play" size={14} className="mr-1" />
                      Run Tests
                    </Button>
                  </div>
                </div>
              </div>

              <div className="divide-y divide-border">
                {mockUnitTests?.map((test) => (
                  <div key={test?.id} className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Icon 
                          name={getStatusIcon(test?.status)} 
                          size={16} 
                          className={getStatusColor(test?.status)}
                        />
                        <div>
                          <h5 className="font-medium text-foreground">{test?.name}</h5>
                          <p className="text-sm text-muted-foreground">{test?.suite}</p>
                          {test?.error && (
                            <p className="text-sm text-destructive mt-1">{test?.error}</p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-muted-foreground">{test?.duration}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'performance':
        return (
          <div className="space-y-6">
            {/* Performance Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-card border border-border rounded-lg p-6">
                <h4 className="font-medium text-foreground mb-4">Lighthouse Score</h4>
                <div className="text-center">
                  <div className="relative w-32 h-32 mx-auto mb-4">
                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="transparent"
                        className="text-muted"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="transparent"
                        strokeDasharray={`${testResults?.performance?.lighthouse * 2.827} 283`}
                        className="text-success"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-2xl font-bold text-foreground">
                        {testResults?.performance?.lighthouse}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">Overall Performance</p>
                </div>
              </div>

              <div className="bg-card border border-border rounded-lg p-6">
                <h4 className="font-medium text-foreground mb-4">Core Web Vitals</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">First Contentful Paint</span>
                    <span className="font-medium text-success">{testResults?.performance?.fcp}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Largest Contentful Paint</span>
                    <span className="font-medium text-warning">{testResults?.performance?.lcp}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Cumulative Layout Shift</span>
                    <span className="font-medium text-success">{testResults?.performance?.cls}</span>
                  </div>
                </div>
              </div>
            </div>
            {/* Performance Recommendations */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h4 className="font-medium text-foreground mb-4">Optimization Recommendations</h4>
              <div className="space-y-3">
                <div className="flex items-start space-x-3 p-3 bg-warning/10 border border-warning/20 rounded-lg">
                  <Icon name="AlertTriangle" size={16} className="text-warning mt-0.5" />
                  <div>
                    <h5 className="font-medium text-foreground">Reduce bundle size</h5>
                    <p className="text-sm text-muted-foreground">
                      Consider code splitting to improve loading performance
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3 p-3 bg-info/10 border border-info/20 rounded-lg">
                  <Icon name="Info" size={16} className="text-info mt-0.5" />
                  <div>
                    <h5 className="font-medium text-foreground">Optimize images</h5>
                    <p className="text-sm text-muted-foreground">
                      Use WebP format and lazy loading for better performance
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3 p-3 bg-success/10 border border-success/20 rounded-lg">
                  <Icon name="CheckCircle" size={16} className="text-success mt-0.5" />
                  <div>
                    <h5 className="font-medium text-foreground">Enable compression</h5>
                    <p className="text-sm text-muted-foreground">
                      Gzip compression is properly configured
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'security':
        return (
          <div className="space-y-6">
            {/* Security Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-warning/10 border border-warning/20 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-warning">Vulnerabilities</p>
                    <p className="text-xl font-bold text-warning">{testResults?.security?.vulnerabilities}</p>
                  </div>
                  <Icon name="Shield" size={20} className="text-warning" />
                </div>
              </div>

              <div className="bg-muted/50 border border-border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Severity</p>
                    <p className="text-xl font-bold text-foreground capitalize">{testResults?.security?.severity}</p>
                  </div>
                  <Icon name="AlertTriangle" size={20} className="text-muted-foreground" />
                </div>
              </div>

              <div className="bg-success/10 border border-success/20 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-success">Last Scan</p>
                    <p className="text-xl font-bold text-success">5m ago</p>
                  </div>
                  <Icon name="Clock" size={20} className="text-success" />
                </div>
              </div>
            </div>
            {/* Security Issues */}
            <div className="bg-card border border-border rounded-lg">
              <div className="p-4 border-b border-border">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-foreground">Security Issues</h4>
                  <Button 
                    variant="default" 
                    size="sm"
                    onClick={() => runTests('security')}
                  >
                    <Icon name="Shield" size={14} className="mr-1" />
                    Run Security Scan
                  </Button>
                </div>
              </div>

              <div className="divide-y divide-border">
                <div className="p-4">
                  <div className="flex items-start space-x-3">
                    <Icon name="AlertTriangle" size={16} className="text-warning mt-1" />
                    <div className="flex-1">
                      <h5 className="font-medium text-foreground">Outdated Dependencies</h5>
                      <p className="text-sm text-muted-foreground mb-2">
                        2 dependencies have known vulnerabilities
                      </p>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs bg-warning/20 text-warning px-2 py-1 rounded">MEDIUM</span>
                        <span className="text-xs text-muted-foreground">lodash@4.17.20, axios@0.21.0</span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">Fix</Button>
                  </div>
                </div>

                <div className="p-4">
                  <div className="flex items-start space-x-3">
                    <Icon name="Info" size={16} className="text-info mt-1" />
                    <div className="flex-1">
                      <h5 className="font-medium text-foreground">Missing Security Headers</h5>
                      <p className="text-sm text-muted-foreground mb-2">
                        Consider adding Content Security Policy headers
                      </p>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs bg-info/20 text-info px-2 py-1 rounded">LOW</span>
                        <span className="text-xs text-muted-foreground">CSP, HSTS headers</span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">Configure</Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center py-12">
            <Icon name="TestTube" size={48} className="text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">
              {testTabs?.find(t => t?.id === activeTab)?.label} Tests
            </h3>
            <p className="text-muted-foreground">
              Test results will appear here once configured
            </p>
            <Button 
              variant="default" 
              className="mt-4"
              onClick={() => runTests(activeTab)}
            >
              Run {testTabs?.find(t => t?.id === activeTab)?.label} Tests
            </Button>
          </div>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Testing Header */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Automated Testing</h3>
            <p className="text-sm text-muted-foreground">
              Comprehensive testing suite with performance and security analysis
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Icon name="Settings" size={14} className="mr-1" />
              Configure
            </Button>
            <Button variant="default" size="sm">
              <Icon name="Play" size={14} className="mr-1" />
              Run All Tests
            </Button>
          </div>
        </div>

        {/* Test Tabs */}
        <div className="border-b border-border">
          <nav className="-mb-px flex space-x-8 overflow-x-auto">
            {testTabs?.map((tab) => (
              <button
                key={tab?.id}
                onClick={() => setActiveTab(tab?.id)}
                className={`whitespace-nowrap flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab?.id
                    ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
                }`}
              >
                <Icon name={tab?.icon} size={14} />
                <span>{tab?.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>
      {/* Tab Content */}
      <div>
        {renderTabContent()}
      </div>
    </div>
  );
};

export default TestingPanel;