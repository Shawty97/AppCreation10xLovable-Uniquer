import React, { useState, useEffect, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const LogViewer = ({ logs }) => {
  const [filteredLogs, setFilteredLogs] = useState(logs);
  const [searchTerm, setSearchTerm] = useState('');
  const [levelFilter, setLevelFilter] = useState('all');
  const [isAutoScroll, setIsAutoScroll] = useState(true);
  const [isFollowing, setIsFollowing] = useState(true);
  const logEndRef = useRef(null);
  const logContainerRef = useRef(null);

  const logLevels = [
    { value: 'all', label: 'All Levels' },
    { value: 'info', label: 'Info' },
    { value: 'warning', label: 'Warning' },
    { value: 'error', label: 'Error' },
    { value: 'success', label: 'Success' }
  ];

  useEffect(() => {
    let filtered = logs || [];

    // Filter by search term
    if (searchTerm) {
      filtered = filtered?.filter(log =>
        log?.message?.toLowerCase()?.includes(searchTerm?.toLowerCase())
      );
    }

    // Filter by level
    if (levelFilter !== 'all') {
      filtered = filtered?.filter(log => log?.level === levelFilter);
    }

    setFilteredLogs(filtered);
  }, [logs, searchTerm, levelFilter]);

  useEffect(() => {
    if (isAutoScroll && isFollowing) {
      logEndRef?.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [filteredLogs, isAutoScroll, isFollowing]);

  const getLogLevelColor = (level) => {
    switch (level) {
      case 'error':
        return 'text-destructive';
      case 'warning':
        return 'text-warning';
      case 'success':
        return 'text-success';
      case 'info':
        return 'text-info';
      default:
        return 'text-foreground';
    }
  };

  const getLogLevelIcon = (level) => {
    switch (level) {
      case 'error':
        return 'XCircle';
      case 'warning':
        return 'AlertTriangle';
      case 'success':
        return 'CheckCircle';
      case 'info':
        return 'Info';
      default:
        return 'Circle';
    }
  };

  const handleScroll = () => {
    const container = logContainerRef?.current;
    if (container) {
      const isScrolledToBottom = 
        container?.scrollHeight - container?.scrollTop <= container?.clientHeight + 10;
      setIsFollowing(isScrolledToBottom);
    }
  };

  const clearLogs = () => {
    setFilteredLogs([]);
  };

  const downloadLogs = () => {
    const logText = filteredLogs
      ?.map(log => `[${log?.timestamp?.toISOString()}] ${log?.level?.toUpperCase()}: ${log?.message}`)
      ?.join('\n');
    
    const blob = new Blob([logText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `build-logs-${new Date()?.toISOString()?.split('T')?.[0]}.txt`;
    document.body?.appendChild(a);
    a?.click();
    document.body?.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const copyLogs = async () => {
    const logText = filteredLogs
      ?.map(log => `[${log?.timestamp?.toISOString()}] ${log?.level?.toUpperCase()}: ${log?.message}`)
      ?.join('\n');
    
    try {
      await navigator.clipboard?.writeText(logText);
      // Show success feedback
    } catch (err) {
      console.error('Failed to copy logs:', err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Log Controls */}
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div className="flex-1 lg:w-80">
              <Input
                type="text"
                placeholder="Search logs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e?.target?.value)}
                className="w-full"
              />
            </div>
            
            <Select
              options={logLevels}
              value={levelFilter}
              onChange={setLevelFilter}
              className="w-40"
            />
          </div>

          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">Auto-scroll:</span>
              <button
                onClick={() => setIsAutoScroll(!isAutoScroll)}
                className={`w-10 h-6 rounded-full border transition-colors duration-200 relative ${
                  isAutoScroll 
                    ? 'bg-primary border-primary' :'bg-muted border-border'
                }`}
              >
                <div className={`w-4 h-4 bg-white rounded-full absolute top-0.5 transition-transform duration-200 ${
                  isAutoScroll ? 'translate-x-4' : 'translate-x-0.5'
                }`} />
              </button>
            </div>

            <Button variant="outline" size="sm" onClick={clearLogs}>
              <Icon name="Trash2" size={14} className="mr-1" />
              Clear
            </Button>
            
            <Button variant="outline" size="sm" onClick={copyLogs}>
              <Icon name="Copy" size={14} className="mr-1" />
              Copy
            </Button>
            
            <Button variant="outline" size="sm" onClick={downloadLogs}>
              <Icon name="Download" size={14} className="mr-1" />
              Download
            </Button>
          </div>
        </div>

        {/* Log Stats */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
          <div className="flex items-center space-x-6 text-sm text-muted-foreground">
            <span>Total: {logs?.length || 0}</span>
            <span>Filtered: {filteredLogs?.length || 0}</span>
            <span>
              Errors: {logs?.filter(l => l?.level === 'error')?.length || 0}
            </span>
            <span>
              Warnings: {logs?.filter(l => l?.level === 'warning')?.length || 0}
            </span>
          </div>
          
          <div className="flex items-center space-x-2 text-sm">
            {isFollowing ? (
              <div className="flex items-center text-success">
                <Icon name="Eye" size={14} className="mr-1" />
                Following
              </div>
            ) : (
              <button
                onClick={() => {
                  setIsFollowing(true);
                  setIsAutoScroll(true);
                  logEndRef?.current?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="flex items-center text-primary hover:underline"
              >
                <Icon name="ArrowDown" size={14} className="mr-1" />
                Jump to bottom
              </button>
            )}
          </div>
        </div>
      </div>
      {/* Log Display */}
      <div className="bg-card border border-border rounded-lg">
        <div className="bg-muted/30 px-4 py-3 border-b border-border">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-foreground">Build Logs</h3>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Icon name="Terminal" size={14} />
              <span>Live Output</span>
              <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>

        <div 
          ref={logContainerRef}
          onScroll={handleScroll}
          className="h-96 overflow-y-auto font-mono text-sm bg-muted/10"
        >
          {filteredLogs?.length > 0 ? (
            <div className="p-4 space-y-1">
              {filteredLogs?.map((log, index) => (
                <div 
                  key={log?.id || index}
                  className={`flex items-start space-x-3 py-1 px-2 rounded hover:bg-muted/20 ${
                    log?.level === 'error' ? 'bg-destructive/5' :
                    log?.level === 'warning' ? 'bg-warning/5' :
                    log?.level === 'success' ? 'bg-success/5' : ''
                  }`}
                >
                  <span className="text-xs text-muted-foreground whitespace-nowrap mt-0.5">
                    {log?.timestamp?.toLocaleTimeString()}
                  </span>
                  
                  <Icon 
                    name={getLogLevelIcon(log?.level)} 
                    size={12} 
                    className={`mt-0.5 ${getLogLevelColor(log?.level)}`}
                  />
                  
                  <span className={`flex-1 ${getLogLevelColor(log?.level)}`}>
                    {log?.message}
                  </span>
                </div>
              ))}
              <div ref={logEndRef} />
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <div className="text-center">
                <Icon name="FileText" size={48} className="mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium">No logs to display</p>
                <p className="text-sm">Start a build to see log output here</p>
              </div>
            </div>
          )}
        </div>
      </div>
      {/* Log Analysis */}
      {filteredLogs?.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-card border border-border rounded-lg p-4">
            <h4 className="font-medium text-foreground mb-3">Performance Metrics</h4>
            <div className="space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Build Duration:</span>
                <span className="font-medium">2m 34s</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Bundle Size:</span>
                <span className="font-medium">2.4 MB</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Gzipped:</span>
                <span className="font-medium">756 KB</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Chunks:</span>
                <span className="font-medium">12</span>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-4">
            <h4 className="font-medium text-foreground mb-3">Quick Actions</h4>
            <div className="space-y-2">
              <Button variant="outline" size="sm" className="w-full justify-start">
                <Icon name="Bug" size={14} className="mr-2" />
                Report Issue
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                <Icon name="MessageSquare" size={14} className="mr-2" />
                Share Logs
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                <Icon name="BarChart3" size={14} className="mr-2" />
                View Analytics
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LogViewer;