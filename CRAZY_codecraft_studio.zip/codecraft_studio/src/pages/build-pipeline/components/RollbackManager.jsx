import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const RollbackManager = ({ selectedProject, onRollback }) => {
  const [selectedVersion, setSelectedVersion] = useState(null);
  const [compareVersions, setCompareVersions] = useState([null, null]);
  const [isRollingBack, setIsRollingBack] = useState(false);

  // Mock version history
  const versionHistory = [
    {
      id: 'v1.2.4',
      version: 'v1.2.4',
      status: 'current',
      deployedAt: new Date(Date.now() - 300000),
      commit: 'a7b3c45',
      branch: 'main',
      author: 'John Doe',
      buildTime: '2m 34s',
      size: '2.4 MB',
      performance: 87,
      tests: { passed: 125, failed: 2 },
      changes: [
        'Fixed payment processing bug',
        'Updated user dashboard UI',
        'Added performance monitoring'
      ]
    },
    {
      id: 'v1.2.3',
      version: 'v1.2.3',
      status: 'stable',
      deployedAt: new Date(Date.now() - 3600000),
      commit: 'x9e2f12',
      branch: 'main',
      author: 'Jane Smith',
      buildTime: '2m 18s',
      size: '2.3 MB',
      performance: 89,
      tests: { passed: 123, failed: 0 },
      changes: [
        'Improved loading performance',
        'Fixed responsive design issues',
        'Updated dependencies'
      ]
    },
    {
      id: 'v1.2.2',
      version: 'v1.2.2',
      status: 'stable',
      deployedAt: new Date(Date.now() - 7200000),
      commit: 'm3k7p89',
      branch: 'main',
      author: 'Mike Johnson',
      buildTime: '2m 45s',
      size: '2.2 MB',
      performance: 84,
      tests: { passed: 120, failed: 1 },
      changes: [
        'Added new product filters',
        'Fixed shopping cart sync',
        'Updated API endpoints'
      ]
    },
    {
      id: 'v1.2.1',
      version: 'v1.2.1',
      status: 'stable',
      deployedAt: new Date(Date.now() - 86400000),
      commit: 'p5q8r23',
      branch: 'main',
      author: 'Sarah Wilson',
      buildTime: '2m 12s',
      size: '2.1 MB',
      performance: 91,
      tests: { passed: 118, failed: 0 },
      changes: [
        'Security patch applied',
        'Minor UI improvements',
        'Database optimization'
      ]
    },
    {
      id: 'v1.2.0',
      version: 'v1.2.0',
      status: 'stable',
      deployedAt: new Date(Date.now() - 172800000),
      commit: 'z7x4v56',
      branch: 'main',
      author: 'David Brown',
      buildTime: '3m 01s',
      size: '2.0 MB',
      performance: 86,
      tests: { passed: 115, failed: 2 },
      changes: [
        'Major feature release',
        'New user interface',
        'Enhanced search functionality'
      ]
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'current':
        return 'bg-primary text-primary-foreground';
      case 'stable':
        return 'bg-success text-success-foreground';
      case 'failed':
        return 'bg-destructive text-destructive-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const handleRollback = async (version) => {
    setIsRollingBack(true);
    
    try {
      // Simulate rollback process
      await new Promise(resolve => setTimeout(resolve, 3000));
      onRollback?.(version?.version);
      
      // Update version statuses
      const updatedVersions = versionHistory?.map(v => ({
        ...v,
        status: v?.id === version?.id ? 'current' : v?.status === 'current' ? 'stable' : v?.status
      }));
      
      setSelectedVersion(null);
    } catch (error) {
      console.error('Rollback failed:', error);
    } finally {
      setIsRollingBack(false);
    }
  };

  const getPerformanceColor = (score) => {
    if (score >= 90) return 'text-success';
    if (score >= 70) return 'text-warning';
    return 'text-destructive';
  };

  const formatTimeAgo = (date) => {
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return `${Math.floor(diffInSeconds / 86400)}d ago`;
  };

  return (
    <div className="space-y-6">
      {/* Rollback Header */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Version Management</h3>
            <p className="text-sm text-muted-foreground">
              Manage deployments and rollback to previous stable versions when needed
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline">
              <Icon name="GitBranch" size={14} className="mr-1" />
              Compare Versions
            </Button>
            <Button variant="outline">
              <Icon name="History" size={14} className="mr-1" />
              View History
            </Button>
          </div>
        </div>

        {/* Emergency Rollback */}
        <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Icon name="AlertTriangle" size={20} className="text-destructive" />
              <div>
                <h4 className="font-medium text-foreground">Emergency Rollback</h4>
                <p className="text-sm text-muted-foreground">
                  Quickly revert to the last stable version (v1.2.3)
                </p>
              </div>
            </div>
            <Button 
              variant="destructive" 
              disabled={isRollingBack}
              onClick={() => handleRollback(versionHistory?.find(v => v?.version === 'v1.2.3'))}
            >
              {isRollingBack ? (
                <>
                  <Icon name="Loader2" size={14} className="mr-1 animate-spin" />
                  Rolling Back...
                </>
              ) : (
                <>
                  <Icon name="RotateCcw" size={14} className="mr-1" />
                  Emergency Rollback
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
      {/* Version History */}
      <div className="bg-card border border-border rounded-lg">
        <div className="p-4 border-b border-border">
          <h4 className="font-medium text-foreground">Deployment History</h4>
        </div>

        <div className="divide-y divide-border">
          {versionHistory?.map((version, index) => (
            <div 
              key={version?.id} 
              className={`p-4 ${selectedVersion?.id === version?.id ? 'bg-muted/30' : ''}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4 flex-1">
                  {/* Version Info */}
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h5 className="font-medium text-foreground">{version?.version}</h5>
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${getStatusColor(version?.status)}`}>
                        {version?.status}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {formatTimeAgo(version?.deployedAt)}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-3 text-sm text-muted-foreground">
                      <div>
                        <span className="font-medium text-foreground">Author:</span> {version?.author}
                      </div>
                      <div>
                        <span className="font-medium text-foreground">Commit:</span> {version?.commit}
                      </div>
                      <div>
                        <span className="font-medium text-foreground">Build Time:</span> {version?.buildTime}
                      </div>
                      <div>
                        <span className="font-medium text-foreground">Size:</span> {version?.size}
                      </div>
                    </div>

                    {/* Performance & Test Metrics */}
                    <div className="flex items-center space-x-4 mb-3">
                      <div className="flex items-center space-x-2">
                        <Icon name="Zap" size={14} className="text-primary" />
                        <span className={`text-sm font-medium ${getPerformanceColor(version?.performance)}`}>
                          Performance: {version?.performance}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Icon name="TestTube" size={14} className="text-success" />
                        <span className="text-sm text-success">
                          {version?.tests?.passed} passed
                        </span>
                        {version?.tests?.failed > 0 && (
                          <span className="text-sm text-destructive">
                            • {version?.tests?.failed} failed
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Changes */}
                    {selectedVersion?.id === version?.id && (
                      <div className="mt-4 p-3 bg-muted/30 rounded border">
                        <h6 className="font-medium text-foreground mb-2">Changes in this version:</h6>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          {version?.changes?.map((change, idx) => (
                            <li key={idx} className="flex items-start space-x-2">
                              <Icon name="GitCommit" size={12} className="mt-0.5 text-primary" />
                              <span>{change}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedVersion(selectedVersion?.id === version?.id ? null : version)}
                    >
                      <Icon name={selectedVersion?.id === version?.id ? "ChevronUp" : "ChevronDown"} size={14} />
                    </Button>
                    
                    {version?.status !== 'current' && (
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={isRollingBack}
                        onClick={() => handleRollback(version)}
                      >
                        <Icon name="RotateCcw" size={14} className="mr-1" />
                        Rollback
                      </Button>
                    )}

                    <Button variant="ghost" size="sm">
                      <Icon name="Download" size={14} className="mr-1" />
                      Download
                    </Button>

                    <Button variant="ghost" size="sm">
                      <Icon name="MoreHorizontal" size={14} />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Version Comparison */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h4 className="font-medium text-foreground mb-4">Version Comparison</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Compare From</label>
            <Select
              options={versionHistory?.map(v => ({ value: v?.id, label: v?.version }))}
              value={compareVersions?.[0]}
              onChange={(value) => setCompareVersions([value, compareVersions?.[1]])}
              placeholder="Select version..."
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Compare To</label>
            <Select
              options={versionHistory?.map(v => ({ value: v?.id, label: v?.version }))}
              value={compareVersions?.[1]}
              onChange={(value) => setCompareVersions([compareVersions?.[0], value])}
              placeholder="Select version..."
            />
          </div>
        </div>

        <Button 
          variant="default"
          disabled={!compareVersions?.[0] || !compareVersions?.[1]}
        >
          <Icon name="GitCompare" size={14} className="mr-1" />
          Compare Versions
        </Button>
      </div>
      {/* Rollback Guidelines */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h4 className="font-medium text-foreground mb-4">Rollback Guidelines</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h5 className="font-medium text-foreground mb-2 flex items-center">
              <Icon name="CheckCircle" size={16} className="mr-2 text-success" />
              When to Rollback
            </h5>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Critical bugs affecting user experience</li>
              <li>• Performance degradation &gt; 20%</li>
              <li>• Security vulnerabilities discovered</li>
              <li>• High error rates in production</li>
            </ul>
          </div>
          
          <div>
            <h5 className="font-medium text-foreground mb-2 flex items-center">
              <Icon name="AlertTriangle" size={16} className="mr-2 text-warning" />
              Rollback Checklist
            </h5>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Verify target version stability</li>
              <li>• Check database compatibility</li>
              <li>• Notify team members</li>
              <li>• Monitor post-rollback metrics</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RollbackManager;