import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';

const OptimizationSettings = ({ selectedProject }) => {
  const [optimizations, setOptimizations] = useState({
    codeSplitting: true,
    treeshaking: true,
    minification: true,
    compression: true,
    imageOptimization: true,
    bundleAnalysis: false,
    lazyLoading: true,
    prefetching: false,
    caching: true,
    cdnConfig: false
  });

  const [compressionSettings, setCompressionSettings] = useState({
    gzip: true,
    brotli: false,
    level: 6
  });

  const [imageSettings, setImageSettings] = useState({
    webpConversion: true,
    quality: 85,
    responsiveImages: true,
    lazyLoading: true
  });

  const [performanceMetrics, setPerformanceMetrics] = useState({
    bundleSize: '2.4 MB',
    gzippedSize: '756 KB',
    chunks: 12,
    loadTime: '1.2s',
    score: 87
  });

  const toggleOptimization = (key) => {
    setOptimizations(prev => ({
      ...prev,
      [key]: !prev?.[key]
    }));
  };

  const optimizationCategories = [
    {
      title: 'Code Optimization',
      items: [
        {
          key: 'codeSplitting',
          title: 'Code Splitting',
          description: 'Split code into smaller chunks for better loading performance',
          impact: 'High',
          savings: '~30% faster initial load'
        },
        {
          key: 'treeshaking',
          title: 'Tree Shaking',
          description: 'Remove unused code from the final bundle',
          impact: 'Medium',
          savings: '~15% smaller bundle'
        },
        {
          key: 'minification',
          title: 'Code Minification',
          description: 'Minify JavaScript and CSS files',
          impact: 'Medium',
          savings: '~25% smaller files'
        }
      ]
    },
    {
      title: 'Asset Optimization',
      items: [
        {
          key: 'imageOptimization',
          title: 'Image Optimization',
          description: 'Compress and optimize images for web delivery',
          impact: 'High',
          savings: '~40% smaller images'
        },
        {
          key: 'compression',
          title: 'Asset Compression',
          description: 'Enable Gzip/Brotli compression for all assets',
          impact: 'High',
          savings: '~60% smaller transfer'
        },
        {
          key: 'lazyLoading',
          title: 'Lazy Loading',
          description: 'Load images and components only when needed',
          impact: 'Medium',
          savings: '~20% faster initial load'
        }
      ]
    },
    {
      title: 'Performance Features',
      items: [
        {
          key: 'prefetching',
          title: 'Resource Prefetching',
          description: 'Preload critical resources for faster navigation',
          impact: 'Medium',
          savings: '~200ms faster navigation'
        },
        {
          key: 'caching',
          title: 'Browser Caching',
          description: 'Configure optimal caching headers',
          impact: 'High',
          savings: 'Instant repeat visits'
        },
        {
          key: 'cdnConfig',
          title: 'CDN Configuration',
          description: 'Distribute assets through global CDN',
          impact: 'High',
          savings: '~50% faster global delivery'
        }
      ]
    }
  ];

  const getImpactColor = (impact) => {
    switch (impact?.toLowerCase()) {
      case 'high':
        return 'text-success';
      case 'medium':
        return 'text-warning';
      case 'low':
        return 'text-muted-foreground';
      default:
        return 'text-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Performance Overview */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Build Optimization</h3>
            <p className="text-sm text-muted-foreground">
              Configure optimization settings to improve application performance and reduce bundle size
            </p>
          </div>
          <Button variant="default">
            <Icon name="Zap" size={14} className="mr-1" />
            Apply Optimizations
          </Button>
        </div>

        {/* Performance Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <div className="text-center p-4 border border-border rounded-lg">
            <p className="text-2xl font-bold text-foreground">{performanceMetrics?.bundleSize}</p>
            <p className="text-sm text-muted-foreground">Bundle Size</p>
          </div>
          <div className="text-center p-4 border border-border rounded-lg">
            <p className="text-2xl font-bold text-success">{performanceMetrics?.gzippedSize}</p>
            <p className="text-sm text-muted-foreground">Gzipped</p>
          </div>
          <div className="text-center p-4 border border-border rounded-lg">
            <p className="text-2xl font-bold text-primary">{performanceMetrics?.chunks}</p>
            <p className="text-sm text-muted-foreground">Chunks</p>
          </div>
          <div className="text-center p-4 border border-border rounded-lg">
            <p className="text-2xl font-bold text-warning">{performanceMetrics?.loadTime}</p>
            <p className="text-sm text-muted-foreground">Load Time</p>
          </div>
          <div className="text-center p-4 border border-border rounded-lg">
            <p className="text-2xl font-bold text-info">{performanceMetrics?.score}</p>
            <p className="text-sm text-muted-foreground">Performance Score</p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center space-x-3">
          <Button variant="outline" size="sm">
            <Icon name="BarChart3" size={14} className="mr-1" />
            Analyze Bundle
          </Button>
          <Button variant="outline" size="sm">
            <Icon name="Download" size={14} className="mr-1" />
            Bundle Report
          </Button>
          <Button variant="outline" size="sm">
            <Icon name="RefreshCw" size={14} className="mr-1" />
            Re-optimize
          </Button>
        </div>
      </div>
      {/* Optimization Categories */}
      {optimizationCategories?.map((category) => (
        <div key={category?.title} className="bg-card border border-border rounded-lg p-6">
          <h4 className="font-medium text-foreground mb-4">{category?.title}</h4>
          <div className="space-y-4">
            {category?.items?.map((item) => (
              <div key={item?.key} className="flex items-start space-x-4 p-4 border border-border rounded-lg">
                <div className="flex-shrink-0 pt-1">
                  <Checkbox
                    checked={optimizations?.[item?.key]}
                    onChange={() => toggleOptimization(item?.key)}
                  />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h5 className="font-medium text-foreground">{item?.title}</h5>
                    <div className="flex items-center space-x-2">
                      <span className={`text-xs font-medium ${getImpactColor(item?.impact)}`}>
                        {item?.impact} Impact
                      </span>
                      <span className="text-xs text-muted-foreground">{item?.savings}</span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">{item?.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
      {/* Advanced Settings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Compression Settings */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h4 className="font-medium text-foreground mb-4">Compression Settings</h4>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-foreground">Enable Gzip</span>
              <Checkbox
                checked={compressionSettings?.gzip}
                onChange={(checked) => setCompressionSettings(prev => ({ ...prev, gzip: checked }))}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-foreground">Enable Brotli</span>
              <Checkbox
                checked={compressionSettings?.brotli}
                onChange={(checked) => setCompressionSettings(prev => ({ ...prev, brotli: checked }))}
              />
            </div>
            
            <div>
              <label className="block text-sm text-foreground mb-2">Compression Level</label>
              <Select
                options={[
                  { value: 1, label: 'Level 1 (Fast)' },
                  { value: 6, label: 'Level 6 (Balanced)' },
                  { value: 9, label: 'Level 9 (Best)' }
                ]}
                value={compressionSettings?.level}
                onChange={(value) => setCompressionSettings(prev => ({ ...prev, level: value }))}
              />
            </div>
          </div>
        </div>

        {/* Image Optimization */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h4 className="font-medium text-foreground mb-4">Image Optimization</h4>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-foreground">WebP Conversion</span>
              <Checkbox
                checked={imageSettings?.webpConversion}
                onChange={(checked) => setImageSettings(prev => ({ ...prev, webpConversion: checked }))}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-foreground">Responsive Images</span>
              <Checkbox
                checked={imageSettings?.responsiveImages}
                onChange={(checked) => setImageSettings(prev => ({ ...prev, responsiveImages: checked }))}
              />
            </div>
            
            <div>
              <label className="block text-sm text-foreground mb-2">Image Quality</label>
              <div className="flex items-center space-x-3">
                <Input
                  type="range"
                  min="50"
                  max="100"
                  value={imageSettings?.quality}
                  onChange={(e) => setImageSettings(prev => ({ ...prev, quality: parseInt(e?.target?.value) }))}
                  className="flex-1"
                />
                <span className="text-sm font-medium text-foreground w-12">{imageSettings?.quality}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Performance Impact Analysis */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h4 className="font-medium text-foreground mb-4">Optimization Impact Analysis</h4>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-success/10 border border-success/20 rounded-lg">
            <div className="flex items-center space-x-3">
              <Icon name="TrendingUp" size={16} className="text-success" />
              <span className="text-sm text-foreground">Bundle size reduction</span>
            </div>
            <span className="font-medium text-success">-847 KB (32%)</span>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-primary/10 border border-primary/20 rounded-lg">
            <div className="flex items-center space-x-3">
              <Icon name="Zap" size={16} className="text-primary" />
              <span className="text-sm text-foreground">Load time improvement</span>
            </div>
            <span className="font-medium text-primary">-0.8s (42%)</span>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-info/10 border border-info/20 rounded-lg">
            <div className="flex items-center space-x-3">
              <Icon name="Globe" size={16} className="text-info" />
              <span className="text-sm text-foreground">Global performance score</span>
            </div>
            <span className="font-medium text-info">+18 points</span>
          </div>
        </div>

        <div className="mt-6 p-4 bg-muted/30 rounded-lg">
          <div className="flex items-start space-x-3">
            <Icon name="Lightbulb" size={16} className="text-warning mt-0.5" />
            <div>
              <h5 className="font-medium text-foreground mb-1">Optimization Recommendation</h5>
              <p className="text-sm text-muted-foreground">
                Enable code splitting and image optimization for the best performance gains. 
                These optimizations can reduce your bundle size by up to 40% and improve load times significantly.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OptimizationSettings;