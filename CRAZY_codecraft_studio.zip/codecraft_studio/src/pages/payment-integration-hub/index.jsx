import React, { useState, useEffect } from 'react';
import { StripeProvider } from '../../contexts/StripeContext';
import { useAuth } from '../../contexts/AuthContext';
import { paymentService } from '../../services/paymentService';
import PaymentMethodsPanel from './components/PaymentMethodsPanel';
import CheckoutInterface from './components/CheckoutInterface';
import TransactionHistory from './components/TransactionHistory';
import SubscriptionManager from './components/SubscriptionManager';
import PaymentAnalytics from './components/PaymentAnalytics';
import RevenueTracker from './components/RevenueTracker';
import Button from '../../components/ui/Button';

const PaymentIntegrationHub = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('checkout');
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [orders, setOrders] = useState([]);
  const [subscription, setSubscription] = useState(null);
  const [revenueStats, setRevenueStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const tabs = [
    { id: 'checkout', label: 'Checkout', icon: 'CreditCard' },
    { id: 'methods', label: 'Payment Methods', icon: 'Wallet' },
    { id: 'history', label: 'Transaction History', icon: 'Receipt' },
    { id: 'subscription', label: 'Subscriptions', icon: 'Calendar' },
    { id: 'analytics', label: 'Analytics', icon: 'BarChart3' },
    { id: 'revenue', label: 'Revenue Tracker', icon: 'TrendingUp' }
  ];

  useEffect(() => {
    if (user?.id) {
      loadPaymentData();
    }
  }, [user?.id]);

  const loadPaymentData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const [methodsData, ordersData, subscriptionData, revenueData] = await Promise.allSettled([
        paymentService?.getPaymentMethods(user?.id),
        paymentService?.getUserOrders(user?.id),
        paymentService?.getUserSubscription(user?.id),
        paymentService?.getSellerStats(user?.id)
      ]);

      if (methodsData?.status === 'fulfilled') {
        setPaymentMethods(methodsData?.value);
      }
      
      if (ordersData?.status === 'fulfilled') {
        setOrders(ordersData?.value);
      }
      
      if (subscriptionData?.status === 'fulfilled') {
        setSubscription(subscriptionData?.value);
      }
      
      if (revenueData?.status === 'fulfilled') {
        setRevenueStats(revenueData?.value);
      }
    } catch (error) {
      console.error('Error loading payment data:', error);
      setError('Failed to load payment data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentMethodUpdate = () => {
    paymentService?.getPaymentMethods(user?.id)?.then(setPaymentMethods)?.catch(console.error);
  };

  const handleOrderUpdate = () => {
    paymentService?.getUserOrders(user?.id)?.then(setOrders)?.catch(console.error);
  };

  const handleSubscriptionUpdate = () => {
    paymentService?.getUserSubscription(user?.id)?.then(setSubscription)?.catch(console.error);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center p-8 bg-white rounded-lg shadow-md">
          <div className="text-gray-400 mb-4">
            <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Authentication Required</h3>
          <p className="text-gray-600 mb-4">Please sign in to access the Payment Integration Hub</p>
          <Button variant="primary" onClick={() => window.location.href = '/authentication-portal'}>
            Sign In
          </Button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading payment data...</p>
        </div>
      </div>
    );
  }

  return (
    <StripeProvider>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="py-6">
              <h1 className="text-3xl font-bold text-gray-900">Payment Integration Hub</h1>
              <p className="mt-2 text-gray-600">
                Comprehensive Stripe payment processing for Component Marketplace transactions
              </p>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8" aria-label="Tabs">
              {tabs?.map((tab) => (
                <button
                  key={tab?.id}
                  onClick={() => setActiveTab(tab?.id)}
                  className={`
                    whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm flex items-center space-x-2
                    ${activeTab === tab?.id
                      ? 'border-blue-500 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }
                  `}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    {tab?.icon === 'CreditCard' && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />}
                    {tab?.icon === 'Wallet' && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />}
                    {tab?.icon === 'Receipt' && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />}
                    {tab?.icon === 'Calendar' && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />}
                    {tab?.icon === 'BarChart3' && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />}
                    {tab?.icon === 'TrendingUp' && <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />}
                  </svg>
                  <span>{tab?.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {activeTab === 'checkout' && (
            <CheckoutInterface 
              user={user}
              onOrderUpdate={handleOrderUpdate}
            />
          )}
          
          {activeTab === 'methods' && (
            <PaymentMethodsPanel
              user={user}
              paymentMethods={paymentMethods}
              onUpdate={handlePaymentMethodUpdate}
            />
          )}
          
          {activeTab === 'history' && (
            <TransactionHistory
              user={user}
              orders={orders}
              onRefresh={handleOrderUpdate}
            />
          )}
          
          {activeTab === 'subscription' && (
            <SubscriptionManager
              user={user}
              subscription={subscription}
              onUpdate={handleSubscriptionUpdate}
            />
          )}
          
          {activeTab === 'analytics' && (
            <PaymentAnalytics
              user={user}
              orders={orders}
              revenueStats={revenueStats}
            />
          )}
          
          {activeTab === 'revenue' && (
            <RevenueTracker
              user={user}
              revenueStats={revenueStats}
              onRefresh={() => {
                paymentService?.getSellerStats(user?.id)?.then(setRevenueStats)?.catch(console.error);
              }}
            />
          )}
        </div>
      </div>
    </StripeProvider>
  );
};

export default PaymentIntegrationHub;