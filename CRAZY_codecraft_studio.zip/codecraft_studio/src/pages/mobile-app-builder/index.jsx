import React, { useState } from 'react';
import { Smartphone, Tablet, Monitor, Settings, Play, Download, Share, Zap, Eye, BarChart3 } from 'lucide-react';
import DevicePreview from './components/DevicePreview';
import MobileComponentLibrary from './components/MobileComponentLibrary';
import PlatformConfiguration from './components/PlatformConfiguration';
import NativeFeatures from './components/NativeFeatures';
import AppStoreTools from './components/AppStoreTools';
import MobileBuildPipeline from './components/MobileBuildPipeline';

const MobileAppBuilder = () => {
  const [selectedDevice, setSelectedDevice] = useState('iphone');
  const [activeTab, setActiveTab] = useState('canvas');
  const [selectedComponent, setSelectedComponent] = useState(null);
  const [isBuilding, setIsBuilding] = useState(false);

  const devices = [
    { id: 'iphone', name: 'iPhone 15', width: '375px', height: '812px', icon: Smartphone },
    { id: 'android', name: 'Pixel 8', width: '393px', height: '851px', icon: Smartphone },
    { id: 'ipad', name: 'iPad Pro', width: '1024px', height: '1366px', icon: Tablet },
    { id: 'desktop', name: 'Desktop', width: '1920px', height: '1080px', icon: Monitor }
  ];

  const tabs = [
    { id: 'canvas', name: 'Canvas', description: 'Design your mobile app' },
    { id: 'components', name: 'Components', description: 'Mobile UI elements' },
    { id: 'native', name: 'Native Features', description: 'Device integrations' },
    { id: 'config', name: 'Platform Config', description: 'iOS/Android settings' },
    { id: 'store', name: 'App Store', description: 'Publishing tools' },
    { id: 'build', name: 'Build & Test', description: 'Compilation pipeline' }
  ];

  const quickActions = [
    { icon: Play, label: 'Preview', action: () => {} },
    { icon: Download, label: 'Export', action: () => {} },
    { icon: Share, label: 'Share', action: () => {} },
    { icon: Settings, label: 'Settings', action: () => {} }
  ];

  const handleBuild = () => {
    setIsBuilding(true);
    setTimeout(() => setIsBuilding(false), 3000);
  };

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Smartphone className="h-6 w-6 text-purple-600" />
              <h1 className="text-xl font-semibold text-gray-900">Mobile App Builder</h1>
            </div>
            <div className="h-6 w-px bg-gray-300" />
            <span className="text-sm text-gray-500">MyAwesome App v1.0</span>
          </div>
          
          <div className="flex items-center space-x-3">
            {quickActions?.map((action) => (
              <button
                key={action?.label}
                onClick={action?.action}
                className="flex items-center space-x-2 px-3 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors"
              >
                <action.icon className="h-4 w-4" />
                <span className="text-sm">{action?.label}</span>
              </button>
            ))}
            
            <button
              onClick={handleBuild}
              disabled={isBuilding}
              className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50 flex items-center space-x-2"
            >
              <Zap className="h-4 w-4" />
              <span>{isBuilding ? 'Building...' : 'Build App'}</span>
            </button>
          </div>
        </div>
      </header>
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
          {/* Tab Navigation */}
          <div className="border-b border-gray-200">
            <nav className="flex flex-wrap">
              {tabs?.map((tab) => (
                <button
                  key={tab?.id}
                  onClick={() => setActiveTab(tab?.id)}
                  className={`flex-1 min-w-0 px-3 py-3 text-xs font-medium text-center border-b-2 transition-colors ${
                    activeTab === tab?.id
                      ? 'border-purple-600 text-purple-600 bg-purple-50' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <div className="truncate">{tab?.name}</div>
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto">
            {activeTab === 'canvas' && (
              <div className="p-4">
                <h3 className="font-medium text-gray-900 mb-4">Device Preview</h3>
                <div className="space-y-2">
                  {devices?.map((device) => (
                    <button
                      key={device?.id}
                      onClick={() => setSelectedDevice(device?.id)}
                      className={`w-full flex items-center space-x-3 p-3 rounded-lg border transition-all ${
                        selectedDevice === device?.id
                          ? 'border-purple-300 bg-purple-50 shadow-sm'
                          : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      <device.icon className="h-5 w-5 text-gray-600" />
                      <div className="flex-1 text-left">
                        <div className="font-medium text-gray-900">{device?.name}</div>
                        <div className="text-sm text-gray-500">{device?.width} × {device?.height}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'components' && <MobileComponentLibrary />}
            {activeTab === 'native' && <NativeFeatures />}
            {activeTab === 'config' && <PlatformConfiguration />}
            {activeTab === 'store' && <AppStoreTools />}
            {activeTab === 'build' && <MobileBuildPipeline />}
          </div>
        </div>

        {/* Main Canvas */}
        <div className="flex-1 flex flex-col bg-gray-100">
          <div className="flex-1 flex items-center justify-center p-8">
            <DevicePreview 
              device={devices?.find(d => d?.id === selectedDevice)} 
              isBuilding={isBuilding}
            />
          </div>
        </div>

        {/* Properties Panel */}
        <div className="w-80 bg-white border-l border-gray-200">
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-medium text-gray-900">Properties</h3>
            <p className="text-sm text-gray-500 mt-1">Configure selected element</p>
          </div>
          
          <div className="p-4">
            {selectedComponent ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Component Type
                  </label>
                  <input
                    type="text"
                    value={selectedComponent?.type || ''}
                    readOnly
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Label
                  </label>
                  <input
                    type="text"
                    placeholder="Enter label"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Style
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    <option>Default</option>
                    <option>Primary</option>
                    <option>Secondary</option>
                    <option>Outline</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Size
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    <option>Small</option>
                    <option>Medium</option>
                    <option>Large</option>
                  </select>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-500 py-8">
                <Eye className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-sm">Select a component to edit its properties</p>
              </div>
            )}
          </div>
        </div>
      </div>
      {/* Status Bar */}
      <div className="bg-gray-900 text-white px-6 py-2 flex items-center justify-between text-sm">
        <div className="flex items-center space-x-4">
          <span>Device: {devices?.find(d => d?.id === selectedDevice)?.name}</span>
          <span>•</span>
          <span>Last saved: 2 minutes ago</span>
        </div>
        
        <div className="flex items-center space-x-4">
          <span>Ready</span>
          <div className="flex items-center space-x-2">
            <BarChart3 className="h-4 w-4" />
            <span>Performance: Good</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MobileAppBuilder;