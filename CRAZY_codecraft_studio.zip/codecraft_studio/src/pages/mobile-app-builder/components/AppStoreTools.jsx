import React, { useState } from 'react';
import { Apple, Smartphone, Upload, Download, Image, FileText, Star, DollarSign, Globe, Shield, CheckCircle, AlertCircle, Clock, Target, TrendingUp, Eye } from 'lucide-react';

const AppStoreTools = () => {
  const [activeStore, setActiveStore] = useState('app-store');
  const [activeTab, setActiveTab] = useState('metadata');

  const stores = [
    { id: 'app-store', name: 'App Store', icon: Apple, color: 'blue' },
    { id: 'play-store', name: 'Play Store', icon: Smartphone, color: 'green' }
  ];

  const tabs = [
    { id: 'metadata', name: 'Metadata', icon: FileText },
    { id: 'assets', name: 'Assets', icon: Image },
    { id: 'pricing', name: 'Pricing', icon: DollarSign },
    { id: 'compliance', name: 'Compliance', icon: Shield },
    { id: 'analytics', name: 'Analytics', icon: TrendingUp }
  ];

  const [appMetadata, setAppMetadata] = useState({
    name: 'MyAwesome App',
    subtitle: 'Build amazing apps visually',
    description: 'Create professional mobile applications without coding using our intuitive drag-and-drop interface.',
    keywords: 'app builder, no-code, mobile development, visual builder',
    category: 'Developer Tools',
    contentRating: '4+',
    version: '1.0.0',
    releaseNotes: 'Initial release with core app building features.'
  });

  const compliance = {
    'app-store': [
      { name: 'App Review Guidelines', status: 'compliant', description: 'Follows Apple App Store guidelines' },
      { name: 'Privacy Policy', status: 'pending', description: 'Privacy policy URL required' },
      { name: 'Terms of Service', status: 'compliant', description: 'Terms of service document ready' },
      { name: 'Age Rating', status: 'compliant', description: 'Appropriate for 4+ age rating' },
      { name: 'Data Usage', status: 'review', description: 'Data collection practices need review' }
    ],
    'play-store': [
      { name: 'Developer Policy', status: 'compliant', description: 'Meets Google Play policies' },
      { name: 'Target API Level', status: 'compliant', description: 'Targets API level 33+' },
      { name: 'App Bundle', status: 'compliant', description: 'Using Android App Bundle format' },
      { name: 'Privacy Policy', status: 'pending', description: 'Privacy policy URL required' },
      { name: 'Content Rating', status: 'compliant', description: 'ESRB rating assigned' }
    ]
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'compliant': return 'text-green-600 bg-green-100';
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'review': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'compliant': return CheckCircle;
      case 'pending': return Clock;
      case 'review': return AlertCircle;
      default: return Shield;
    }
  };

  const renderMetadataTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              App Name *
            </label>
            <input
              type="text"
              value={appMetadata?.name}
              onChange={(e) => setAppMetadata({...appMetadata, name: e?.target?.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="Enter app name"
            />
            <p className="text-xs text-gray-500 mt-1">30 characters max</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Subtitle
            </label>
            <input
              type="text"
              value={appMetadata?.subtitle}
              onChange={(e) => setAppMetadata({...appMetadata, subtitle: e?.target?.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="Brief app description"
            />
            <p className="text-xs text-gray-500 mt-1">30 characters max</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Category *
            </label>
            <select
              value={appMetadata?.category}
              onChange={(e) => setAppMetadata({...appMetadata, category: e?.target?.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              <option>Developer Tools</option>
              <option>Business</option>
              <option>Productivity</option>
              <option>Utilities</option>
              <option>Education</option>
              <option>Entertainment</option>
              <option>Social Networking</option>
              <option>Lifestyle</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Content Rating
            </label>
            <select
              value={appMetadata?.contentRating}
              onChange={(e) => setAppMetadata({...appMetadata, contentRating: e?.target?.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              <option>4+</option>
              <option>9+</option>
              <option>12+</option>
              <option>17+</option>
            </select>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description *
            </label>
            <textarea
              value={appMetadata?.description}
              onChange={(e) => setAppMetadata({...appMetadata, description: e?.target?.value})}
              rows={6}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
              placeholder="Describe your app's features and benefits"
            />
            <p className="text-xs text-gray-500 mt-1">4000 characters max</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Keywords
            </label>
            <input
              type="text"
              value={appMetadata?.keywords}
              onChange={(e) => setAppMetadata({...appMetadata, keywords: e?.target?.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="Comma-separated keywords"
            />
            <p className="text-xs text-gray-500 mt-1">100 characters max, improves discoverability</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              What's New (Release Notes)
            </label>
            <textarea
              value={appMetadata?.releaseNotes}
              onChange={(e) => setAppMetadata({...appMetadata, releaseNotes: e?.target?.value})}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
              placeholder="Describe new features and improvements"
            />
            <p className="text-xs text-gray-500 mt-1">4000 characters max</p>
          </div>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-4">
        <h3 className="font-medium text-gray-900 mb-3">Preview</h3>
        <div className="bg-white rounded-lg border border-gray-200 p-4 max-w-sm">
          <div className="flex items-start space-x-3">
            <div className="w-16 h-16 bg-purple-100 rounded-xl flex items-center justify-center">
              <Smartphone className="h-8 w-8 text-purple-600" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-gray-900 truncate">{appMetadata?.name}</h4>
              <p className="text-sm text-gray-600 truncate">{appMetadata?.subtitle}</p>
              <div className="flex items-center space-x-1 mt-1">
                {[...Array(5)]?.map((_, i) => (
                  <Star key={i} className="h-3 w-3 text-yellow-400 fill-current" />
                ))}
                <span className="text-xs text-gray-500 ml-1">4.8</span>
              </div>
            </div>
          </div>
          <p className="text-sm text-gray-600 mt-3 line-clamp-3">{appMetadata?.description}</p>
        </div>
      </div>
    </div>
  );

  const renderAssetsTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* App Icon */}
        <div>
          <h3 className="font-medium text-gray-900 mb-4">App Icon</h3>
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors cursor-pointer">
              <Image className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-sm text-gray-600">Upload App Icon</p>
              <p className="text-xs text-gray-500 mt-1">1024×1024px PNG</p>
            </div>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <h4 className="text-sm font-medium text-blue-900 mb-1">Icon Requirements</h4>
              <ul className="text-xs text-blue-700 space-y-1">
                <li>• 1024×1024 pixels minimum</li>
                <li>• PNG or JPEG format</li>
                <li>• No rounded corners or transparency</li>
                <li>• Clear and recognizable design</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Screenshots */}
        <div>
          <h3 className="font-medium text-gray-900 mb-4">Screenshots</h3>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              {[1, 2, 3, 4]?.map((i) => (
                <div key={i} className="aspect-[9/16] border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center text-gray-400 hover:border-gray-400 transition-colors cursor-pointer">
                  <div className="text-center">
                    <Image className="h-6 w-6 mx-auto mb-1" />
                    <p className="text-xs">Screenshot {i}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <h4 className="text-sm font-medium text-yellow-900 mb-1">Screenshot Tips</h4>
              <ul className="text-xs text-yellow-700 space-y-1">
                <li>• Device-specific sizes required</li>
                <li>• Minimum 3-5 screenshots</li>
                <li>• Show key app features</li>
                <li>• High quality and readable text</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Additional Assets */}
      <div>
        <h3 className="font-medium text-gray-900 mb-4">Additional Assets</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="border border-gray-200 rounded-lg p-4 text-center">
            <FileText className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            <h4 className="text-sm font-medium text-gray-900 mb-1">App Preview Video</h4>
            <p className="text-xs text-gray-500 mb-3">15-30 seconds, optional</p>
            <button className="text-sm text-purple-600 hover:text-purple-700">Upload Video</button>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-4 text-center">
            <Image className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            <h4 className="text-sm font-medium text-gray-900 mb-1">Feature Graphic</h4>
            <p className="text-xs text-gray-500 mb-3">1024×500px for Play Store</p>
            <button className="text-sm text-purple-600 hover:text-purple-700">Upload Graphic</button>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-4 text-center">
            <Globe className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            <h4 className="text-sm font-medium text-gray-900 mb-1">Promo Graphics</h4>
            <p className="text-xs text-gray-500 mb-3">Marketing materials</p>
            <button className="text-sm text-purple-600 hover:text-purple-700">Upload Assets</button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderPricingTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              App Pricing Model
            </label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
              <option>Free</option>
              <option>Paid (One-time)</option>
              <option>Freemium</option>
              <option>Subscription</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Base Price (USD)
            </label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Available Countries
            </label>
            <select multiple className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent h-32">
              <option>United States</option>
              <option>United Kingdom</option>
              <option>Canada</option>
              <option>Australia</option>
              <option>Germany</option>
              <option>France</option>
              <option>Japan</option>
              <option>All Countries</option>
            </select>
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-medium text-gray-900 mb-3">Revenue Projection</h4>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Base Price</span>
                <span className="font-medium">$0.99</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">App Store Fee (30%)</span>
                <span className="text-red-600">-$0.30</span>
              </div>
              <div className="flex justify-between text-sm pt-2 border-t border-gray-300">
                <span className="font-medium">Your Revenue per Sale</span>
                <span className="font-bold text-green-600">$0.69</span>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="text-sm font-medium text-blue-900 mb-2">Pricing Tips</h4>
            <ul className="text-xs text-blue-700 space-y-1">
              <li>• Research competitor pricing</li>
              <li>• Consider freemium model for user acquisition</li>
              <li>• A/B test different price points</li>
              <li>• Localize pricing for different markets</li>
              <li>• Factor in app store fees (30%)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );

  const renderComplianceTab = () => (
    <div className="space-y-6">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Shield className="h-5 w-5 text-blue-600 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-blue-900">App Store Compliance</h4>
            <p className="text-sm text-blue-700 mt-1">
              Ensure your app meets all requirements before submission to avoid rejections.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {compliance?.[activeStore]?.map((item, index) => {
          const StatusIcon = getStatusIcon(item?.status);
          return (
            <div key={index} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <StatusIcon className={`h-5 w-5 mt-0.5 ${
                  item?.status === 'compliant' ? 'text-green-600' : 
                  item?.status === 'pending' ? 'text-yellow-600' : 'text-red-600'
                }`} />
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className="text-sm font-medium text-gray-900">{item?.name}</h4>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${getStatusColor(item?.status)}`}>
                      {item?.status}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{item?.description}</p>
                  
                  {item?.status !== 'compliant' && (
                    <button className="text-sm text-purple-600 hover:text-purple-700 mt-2">
                      Fix Issue →
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span className="text-sm font-medium text-green-900">
              Compliance Score: 80%
            </span>
          </div>
          <button className="text-sm bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
            Generate Compliance Report
          </button>
        </div>
      </div>
    </div>
  );

  const renderAnalyticsTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border border-gray-200 rounded-lg p-6 text-center">
          <Download className="h-8 w-8 text-blue-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-gray-900">0</div>
          <div className="text-sm text-gray-600">Downloads</div>
        </div>
        
        <div className="bg-white border border-gray-200 rounded-lg p-6 text-center">
          <Star className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-gray-900">-</div>
          <div className="text-sm text-gray-600">Average Rating</div>
        </div>
        
        <div className="bg-white border border-gray-200 rounded-lg p-6 text-center">
          <DollarSign className="h-8 w-8 text-green-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-gray-900">$0</div>
          <div className="text-sm text-gray-600">Revenue</div>
        </div>
      </div>

      <div className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg p-12 text-center">
        <TrendingUp className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">Analytics Coming Soon</h3>
        <p className="text-gray-600 mb-4">
          App analytics will be available after your first submission to the app stores.
        </p>
        <button className="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 transition-colors">
          Set Up Analytics
        </button>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'metadata': return renderMetadataTab();
      case 'assets': return renderAssetsTab();
      case 'pricing': return renderPricingTab();
      case 'compliance': return renderComplianceTab();
      case 'analytics': return renderAnalyticsTab();
      default: return renderMetadataTab();
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Store Selector */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex space-x-2">
          {stores?.map((store) => (
            <button
              key={store?.id}
              onClick={() => setActiveStore(store?.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg border transition-all ${
                activeStore === store?.id
                  ? `border-${store?.color}-300 bg-${store?.color}-50 text-${store?.color}-700`
                  : 'border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50'
              }`}
            >
              <store.icon className="h-4 w-4" />
              <span className="font-medium">{store?.name}</span>
            </button>
          ))}
        </div>
      </div>
      {/* Tab Navigation */}
      <div className="border-b border-gray-200">
        <nav className="flex overflow-x-auto">
          {tabs?.map((tab) => (
            <button
              key={tab?.id}
              onClick={() => setActiveTab(tab?.id)}
              className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeTab === tab?.id
                  ? 'border-purple-600 text-purple-600 bg-purple-50' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <tab.icon className="h-4 w-4" />
              <span>{tab?.name}</span>
            </button>
          ))}
        </nav>
      </div>
      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {renderTabContent()}
      </div>
      {/* Actions */}
      <div className="border-t border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <button className="flex items-center space-x-2 text-gray-600 hover:text-gray-800">
            <Eye className="h-4 w-4" />
            <span className="text-sm">Preview Store Listing</span>
          </button>
          
          <div className="flex space-x-3">
            <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors text-sm">
              Save Draft
            </button>
            <button className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors text-sm flex items-center space-x-2">
              <Upload className="h-4 w-4" />
              <span>Submit for Review</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppStoreTools;