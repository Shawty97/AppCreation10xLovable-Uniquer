import React, { useState } from 'react';
import { Smartphone, Apple, Settings, Shield, Key, Package, Palette, Bell, Camera, MapPin, Wifi, Database, Globe, CheckCircle, AlertTriangle, Info } from 'lucide-react';

const PlatformConfiguration = () => {
  const [selectedPlatform, setSelectedPlatform] = useState('ios');
  const [activeSection, setActiveSection] = useState('general');

  const platforms = [
    { id: 'ios', name: 'iOS', icon: Apple, color: 'blue' },
    { id: 'android', name: 'Android', icon: Smartphone, color: 'green' }
  ];

  const sections = [
    { id: 'general', name: 'General', icon: Settings },
    { id: 'permissions', name: 'Permissions', icon: Shield },
    { id: 'signing', name: 'Code Signing', icon: Key },
    { id: 'build', name: 'Build Settings', icon: Package },
    { id: 'appearance', name: 'Appearance', icon: Palette }
  ];

  const iosConfig = {
    general: [
      { key: 'Bundle ID', value: 'com.yourcompany.awesomeapp', editable: true },
      { key: 'Version', value: '1.0.0', editable: true },
      { key: 'Build Number', value: '1', editable: true },
      { key: 'Minimum iOS Version', value: '15.0', editable: true },
      { key: 'Deployment Target', value: 'iPhone, iPad', editable: false }
    ],
    permissions: [
      { name: 'Camera', key: 'NSCameraUsageDescription', enabled: true, required: false },
      { name: 'Photo Library', key: 'NSPhotoLibraryUsageDescription', enabled: true, required: false },
      { name: 'Location (Always)', key: 'NSLocationAlwaysAndWhenInUseUsageDescription', enabled: false, required: false },
      { name: 'Location (In Use)', key: 'NSLocationWhenInUseUsageDescription', enabled: true, required: false },
      { name: 'Microphone', key: 'NSMicrophoneUsageDescription', enabled: false, required: false },
      { name: 'Contacts', key: 'NSContactsUsageDescription', enabled: false, required: false },
      { name: 'Push Notifications', key: 'aps-environment', enabled: true, required: false }
    ],
    signing: [
      { key: 'Team ID', value: 'ABC123DEF4', editable: true },
      { key: 'Signing Certificate', value: 'iPhone Developer', editable: false },
      { key: 'Provisioning Profile', value: 'Automatic', editable: true },
      { key: 'Code Sign Identity', value: 'iPhone Developer', editable: false }
    ]
  };

  const androidConfig = {
    general: [
      { key: 'Package Name', value: 'com.yourcompany.awesomeapp', editable: true },
      { key: 'Version Name', value: '1.0.0', editable: true },
      { key: 'Version Code', value: '1', editable: true },
      { key: 'Minimum SDK', value: '21 (Android 5.0)', editable: true },
      { key: 'Target SDK', value: '34 (Android 14)', editable: true }
    ],
    permissions: [
      { name: 'Camera', key: 'android.permission.CAMERA', enabled: true, required: false },
      { name: 'Storage', key: 'android.permission.WRITE_EXTERNAL_STORAGE', enabled: true, required: false },
      { name: 'Location (Fine)', key: 'android.permission.ACCESS_FINE_LOCATION', enabled: true, required: false },
      { name: 'Location (Coarse)', key: 'android.permission.ACCESS_COARSE_LOCATION', enabled: false, required: false },
      { name: 'Microphone', key: 'android.permission.RECORD_AUDIO', enabled: false, required: false },
      { name: 'Contacts', key: 'android.permission.READ_CONTACTS', enabled: false, required: false },
      { name: 'Internet', key: 'android.permission.INTERNET', enabled: true, required: true }
    ],
    signing: [
      { key: 'Keystore File', value: 'release.keystore', editable: true },
      { key: 'Key Alias', value: 'release', editable: true },
      { key: 'Store Password', value: '••••••••', editable: true },
      { key: 'Key Password', value: '••••••••', editable: true }
    ]
  };

  const currentConfig = selectedPlatform === 'ios' ? iosConfig : androidConfig;

  const renderGeneralSettings = () => (
    <div className="space-y-4">
      {currentConfig?.general?.map((setting) => (
        <div key={setting?.key} className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            {setting?.key}
          </label>
          <input
            type="text"
            defaultValue={setting?.value}
            disabled={!setting?.editable}
            className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent ${
              setting?.editable 
                ? 'border-gray-300 bg-white' :'border-gray-200 bg-gray-50 text-gray-500'
            }`}
          />
        </div>
      ))}
    </div>
  );

  const renderPermissions = () => (
    <div className="space-y-4">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Info className="h-5 w-5 text-blue-600 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-blue-900">Permission Guidelines</h4>
            <p className="text-sm text-blue-700 mt-1">
              Only request permissions that your app actually needs. Users can deny permissions.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {currentConfig?.permissions?.map((permission) => (
          <div key={permission?.key} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg ${
                permission?.name?.includes('Camera') ? 'bg-purple-100' :
                permission?.name?.includes('Location') ? 'bg-red-100' :
                permission?.name?.includes('Storage') || permission?.name?.includes('Photo') ? 'bg-blue-100' :
                permission?.name?.includes('Microphone') ? 'bg-green-100' :
                permission?.name?.includes('Contacts') ? 'bg-yellow-100' :
                'bg-gray-100'
              }`}>
                {permission?.name?.includes('Camera') && <Camera className="h-4 w-4 text-purple-600" />}
                {permission?.name?.includes('Location') && <MapPin className="h-4 w-4 text-red-600" />}
                {(permission?.name?.includes('Storage') || permission?.name?.includes('Photo')) && <Package className="h-4 w-4 text-blue-600" />}
                {permission?.name?.includes('Microphone') && <Wifi className="h-4 w-4 text-green-600" />}
                {permission?.name?.includes('Contacts') && <Database className="h-4 w-4 text-yellow-600" />}
                {permission?.name?.includes('Notifications') && <Bell className="h-4 w-4 text-gray-600" />}
                {permission?.name?.includes('Internet') && <Globe className="h-4 w-4 text-gray-600" />}
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-900">
                  {permission?.name}
                  {permission?.required && (
                    <span className="ml-2 text-xs text-red-600 bg-red-100 px-2 py-0.5 rounded-full">
                      Required
                    </span>
                  )}
                </h4>
                <p className="text-xs text-gray-500">{permission?.key}</p>
              </div>
            </div>
            
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                className="sr-only peer"
                defaultChecked={permission?.enabled}
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
            </label>
          </div>
        ))}
      </div>
    </div>
  );

  const renderSigningSettings = () => (
    <div className="space-y-4">
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-yellow-900">
              {selectedPlatform === 'ios' ? 'iOS Code Signing' : 'Android App Signing'}
            </h4>
            <p className="text-sm text-yellow-700 mt-1">
              {selectedPlatform === 'ios' ?'Requires Apple Developer Account and valid certificates' :'Required for publishing to Google Play Store'
              }
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {currentConfig?.signing?.map((setting) => (
          <div key={setting?.key} className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              {setting?.key}
            </label>
            <div className="relative">
              <input
                type={setting?.key?.toLowerCase()?.includes('password') ? 'password' : 'text'}
                defaultValue={setting?.value}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
              {setting?.key?.toLowerCase()?.includes('password') && (
                <Key className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderBuildSettings = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Build Configuration
          </label>
          <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
            <option>Debug</option>
            <option>Release</option>
            <option>Staging</option>
          </select>
        </div>
        
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Architecture
          </label>
          <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
            <option>Universal (arm64, armv7)</option>
            <option>arm64 only</option>
            <option>armv7 only</option>
          </select>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
          <div>
            <h4 className="text-sm font-medium text-gray-900">Enable Bitcode</h4>
            <p className="text-xs text-gray-500">App Store optimization (iOS only)</p>
          </div>
          <input
            type="checkbox"
            defaultChecked={selectedPlatform === 'ios'}
            disabled={selectedPlatform !== 'ios'}
            className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
          />
        </div>

        <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
          <div>
            <h4 className="text-sm font-medium text-gray-900">Proguard/R8 Optimization</h4>
            <p className="text-xs text-gray-500">Code shrinking and obfuscation (Android only)</p>
          </div>
          <input
            type="checkbox"
            defaultChecked={selectedPlatform === 'android'}
            disabled={selectedPlatform !== 'android'}
            className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
          />
        </div>
      </div>
    </div>
  );

  const renderAppearanceSettings = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            App Icon (1024×1024)
          </label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors cursor-pointer">
            <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-sm text-gray-600">Click to upload icon</p>
            <p className="text-xs text-gray-500 mt-1">PNG, 1024×1024px</p>
          </div>
        </div>
        
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Splash Screen
          </label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors cursor-pointer">
            <Palette className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-sm text-gray-600">Click to upload splash</p>
            <p className="text-xs text-gray-500 mt-1">PNG, various sizes</p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Status Bar Style
          </label>
          <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
            <option>Default</option>
            <option>Light Content</option>
            <option>Dark Content</option>
          </select>
        </div>

        <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
          <div>
            <h4 className="text-sm font-medium text-gray-900">Hide Status Bar</h4>
            <p className="text-xs text-gray-500">Full screen mode</p>
          </div>
          <input
            type="checkbox"
            className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
          />
        </div>

        <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
          <div>
            <h4 className="text-sm font-medium text-gray-900">Force Portrait</h4>
            <p className="text-xs text-gray-500">Lock to portrait orientation</p>
          </div>
          <input
            type="checkbox"
            defaultChecked
            className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
          />
        </div>
      </div>
    </div>
  );

  const renderSectionContent = () => {
    switch (activeSection) {
      case 'general': return renderGeneralSettings();
      case 'permissions': return renderPermissions();
      case 'signing': return renderSigningSettings();
      case 'build': return renderBuildSettings();
      case 'appearance': return renderAppearanceSettings();
      default: return renderGeneralSettings();
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Platform Selector */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex space-x-2">
          {platforms?.map((platform) => (
            <button
              key={platform?.id}
              onClick={() => setSelectedPlatform(platform?.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg border transition-all ${
                selectedPlatform === platform?.id
                  ? `border-${platform?.color}-300 bg-${platform?.color}-50 text-${platform?.color}-700`
                  : 'border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50'
              }`}
            >
              <platform.icon className="h-4 w-4" />
              <span className="font-medium">{platform?.name}</span>
            </button>
          ))}
        </div>
      </div>
      {/* Section Navigation */}
      <div className="border-b border-gray-200">
        <nav className="flex overflow-x-auto">
          {sections?.map((section) => (
            <button
              key={section?.id}
              onClick={() => setActiveSection(section?.id)}
              className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeSection === section?.id
                  ? 'border-purple-600 text-purple-600 bg-purple-50' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <section.icon className="h-4 w-4" />
              <span>{section?.name}</span>
            </button>
          ))}
        </nav>
      </div>
      {/* Section Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {renderSectionContent()}
      </div>
      {/* Save Button */}
      <div className="border-t border-gray-200 p-4">
        <button className="w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center space-x-2">
          <CheckCircle className="h-4 w-4" />
          <span>Save Configuration</span>
        </button>
      </div>
    </div>
  );
};

export default PlatformConfiguration;