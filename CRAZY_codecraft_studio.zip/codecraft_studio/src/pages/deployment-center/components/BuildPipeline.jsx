import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const BuildPipeline = ({ logs, status }) => {
  const [pipelineConfig, setPipelineConfig] = useState({
    buildCommand: 'npm run build',
    outputDirectory: 'dist',
    nodeVersion: '18.x',
    installCommand: 'npm install',
    testCommand: 'npm test',
    environmentVariables: []
  });

  const [showAdvanced, setShowAdvanced] = useState(false);
  const [activeStep, setActiveStep] = useState(0);

  const buildSteps = [
    {
      id: 'install',
      name: 'Install Dependencies',
      description: 'Installing project dependencies',
      status: status === 'building' && activeStep >= 0 ? 'running' : status === 'success' ? 'completed' : 'pending',
      duration: '1m 23s',
      command: pipelineConfig?.installCommand
    },
    {
      id: 'test',
      name: 'Run Tests',
      description: 'Running automated tests',
      status: status === 'building' && activeStep >= 1 ? 'running' : status === 'success' ? 'completed' : 'pending',
      duration: '45s',
      command: pipelineConfig?.testCommand
    },
    {
      id: 'build',
      name: 'Build Application',
      description: 'Building production bundle',
      status: status === 'building' && activeStep >= 2 ? 'running' : status === 'success' ? 'completed' : 'pending',
      duration: '2m 15s',
      command: pipelineConfig?.buildCommand
    },
    {
      id: 'optimize',
      name: 'Optimize Assets',
      description: 'Compressing and optimizing files',
      status: status === 'building' && activeStep >= 3 ? 'running' : status === 'success' ? 'completed' : 'pending',
      duration: '30s',
      command: 'Auto-optimization'
    },
    {
      id: 'deploy',
      name: 'Deploy',
      description: 'Deploying to target environment',
      status: status === 'building' && activeStep >= 4 ? 'running' : status === 'success' ? 'completed' : 'pending',
      duration: '1m 45s',
      command: 'Platform deployment'
    }
  ];

  const nodeVersions = [
    { value: '16.x', label: 'Node.js 16.x' },
    { value: '18.x', label: 'Node.js 18.x (Recommended)' },
    { value: '20.x', label: 'Node.js 20.x' }
  ];

  const packageManagers = [
    { value: 'npm', label: 'npm' },
    { value: 'yarn', label: 'Yarn' },
    { value: 'pnpm', label: 'pnpm' }
  ];

  const getStepIcon = (stepStatus) => {
    switch (stepStatus) {
      case 'completed':
        return { name: 'CheckCircle', className: 'text-success' };
      case 'running':
        return { name: 'Loader', className: 'text-primary animate-spin' };
      case 'error':
        return { name: 'XCircle', className: 'text-destructive' };
      default:
        return { name: 'Circle', className: 'text-muted-foreground' };
    }
  };

  const handleConfigChange = (field, value) => {
    setPipelineConfig(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSaveConfig = () => {
    console.log('Saving pipeline configuration:', pipelineConfig);
  };

  const handleRunPipeline = () => {
    console.log('Running build pipeline...');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Build Pipeline</h2>
          <p className="text-muted-foreground">
            Configure automated build processes and monitor deployment progress
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            iconName="Settings"
            iconPosition="left"
            iconSize={16}
            onClick={() => setShowAdvanced(!showAdvanced)}
          >
            {showAdvanced ? 'Hide Config' : 'Configure'}
          </Button>
          <Button
            variant="default"
            iconName="Play"
            iconPosition="left"
            iconSize={16}
            onClick={handleRunPipeline}
            disabled={status === 'building'}
          >
            {status === 'building' ? 'Building...' : 'Run Pipeline'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pipeline Visualization */}
        <div className="lg:col-span-2 space-y-6">
          {/* Build Steps */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-6">Pipeline Steps</h3>
            
            <div className="space-y-4">
              {buildSteps?.map((step, index) => {
                const icon = getStepIcon(step?.status);
                
                return (
                  <div key={step?.id} className="relative">
                    {/* Connector Line */}
                    {index < buildSteps?.length - 1 && (
                      <div className="absolute left-4 top-8 w-0.5 h-8 bg-border" />
                    )}
                    
                    <div className="flex items-start space-x-4">
                      <div className="flex-shrink-0">
                        <Icon name={icon?.name} size={20} className={icon?.className} />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-medium text-foreground">{step?.name}</h4>
                          {step?.status === 'completed' && (
                            <span className="text-sm text-muted-foreground">{step?.duration}</span>
                          )}
                        </div>
                        
                        <p className="text-sm text-muted-foreground mb-2">{step?.description}</p>
                        
                        <div className="bg-muted rounded px-3 py-2">
                          <code className="text-xs text-foreground">{step?.command}</code>
                        </div>
                        
                        {step?.status === 'running' && (
                          <div className="mt-2">
                            <div className="w-full bg-muted rounded-full h-1">
                              <div className="bg-primary h-1 rounded-full animate-pulse" style={{ width: '60%' }} />
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Build Configuration */}
          {showAdvanced && (
            <div className="bg-card border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-6">Build Configuration</h3>
              
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Node.js Version
                    </label>
                    <Select
                      options={nodeVersions}
                      value={pipelineConfig?.nodeVersion}
                      onChange={(value) => handleConfigChange('nodeVersion', value)}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Output Directory
                    </label>
                    <Input
                      value={pipelineConfig?.outputDirectory}
                      onChange={(e) => handleConfigChange('outputDirectory', e?.target?.value)}
                      placeholder="dist"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Install Command
                    </label>
                    <Input
                      value={pipelineConfig?.installCommand}
                      onChange={(e) => handleConfigChange('installCommand', e?.target?.value)}
                      placeholder="npm install"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Build Command
                    </label>
                    <Input
                      value={pipelineConfig?.buildCommand}
                      onChange={(e) => handleConfigChange('buildCommand', e?.target?.value)}
                      placeholder="npm run build"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Test Command
                  </label>
                  <Input
                    value={pipelineConfig?.testCommand}
                    onChange={(e) => handleConfigChange('testCommand', e?.target?.value)}
                    placeholder="npm test"
                  />
                </div>

                <div className="flex items-center justify-end pt-4 border-t border-border">
                  <Button variant="default" onClick={handleSaveConfig}>
                    Save Configuration
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Build Logs */}
        <div className="space-y-6">
          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">Build Logs</h3>
              <Button
                variant="ghost"
                size="sm"
                iconName="Download"
                iconSize={16}
                onClick={() => console.log('Download logs')}
              >
                Download
              </Button>
            </div>
            
            <div className="bg-muted rounded-lg p-4 h-64 overflow-y-auto font-mono text-sm">
              {logs?.length > 0 ? (
                <div className="space-y-1">
                  {logs?.map((log) => (
                    <div key={log?.id} className="flex items-start space-x-3">
                      <span className="text-muted-foreground text-xs w-20 flex-shrink-0">
                        {log?.timestamp?.toLocaleTimeString()}
                      </span>
                      <span className={`${
                        log?.type === 'success' ? 'text-success' :
                        log?.type === 'warning' ? 'text-warning' :
                        log?.type === 'error'? 'text-destructive' : 'text-foreground'
                      }`}>
                        {log?.message}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  <div className="text-center">
                    <Icon name="Terminal" size={32} className="mx-auto mb-2" />
                    <p>No build logs yet</p>
                    <p className="text-xs">Logs will appear here during builds</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Build Statistics */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Build Statistics</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Success Rate</span>
                <span className="text-success font-medium">94.2%</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Avg. Build Time</span>
                <span className="text-foreground font-medium">4m 23s</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Total Builds</span>
                <span className="text-foreground font-medium">127</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Failed Builds</span>
                <span className="text-destructive font-medium">8</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Bundle Size</span>
                <span className="text-foreground font-medium">2.4 MB</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Cache Hit Rate</span>
                <span className="text-primary font-medium">87%</span>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
            
            <div className="space-y-3">
              <Button variant="outline" className="w-full justify-start" iconName="RotateCcw" iconPosition="left">
                Rebuild Last Version
              </Button>
              
              <Button variant="outline" className="w-full justify-start" iconName="Trash2" iconPosition="left">
                Clear Build Cache
              </Button>
              
              <Button variant="outline" className="w-full justify-start" iconName="FileText" iconPosition="left">
                View Full Logs
              </Button>
              
              <Button variant="outline" className="w-full justify-start" iconName="AlertTriangle" iconPosition="left">
                Report Issue
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BuildPipeline;