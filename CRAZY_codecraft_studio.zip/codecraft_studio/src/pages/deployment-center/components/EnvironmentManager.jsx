import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';


const EnvironmentManager = ({ selectedProject }) => {
  const [environments, setEnvironments] = useState([
    {
      id: 'production',
      name: 'Production',
      description: 'Live environment for end users',
      url: 'https://myapp.com',
      branch: 'main',
      status: 'healthy',
      lastDeployment: new Date(Date.now() - 86400000),
      autoDeployEnabled: true,
      variables: [
        { key: 'NODE_ENV', value: 'production', encrypted: false },
        { key: 'API_URL', value: 'https://api.myapp.com', encrypted: false },
        { key: 'DATABASE_URL', value: '••••••••••••', encrypted: true }
      ]
    },
    {
      id: 'staging',
      name: 'Staging',
      description: 'Testing environment for QA and preview',
      url: 'https://staging.myapp.com',
      branch: 'develop',
      status: 'healthy',
      lastDeployment: new Date(Date.now() - 3600000),
      autoDeployEnabled: true,
      variables: [
        { key: 'NODE_ENV', value: 'staging', encrypted: false },
        { key: 'API_URL', value: 'https://staging-api.myapp.com', encrypted: false }
      ]
    },
    {
      id: 'development',
      name: 'Development',
      description: 'Development environment for testing features',
      url: 'https://dev.myapp.com',
      branch: 'feature/*',
      status: 'building',
      lastDeployment: new Date(Date.now() - 1800000),
      autoDeployEnabled: false,
      variables: [
        { key: 'NODE_ENV', value: 'development', encrypted: false }
      ]
    }
  ]);

  const [selectedEnv, setSelectedEnv] = useState(environments?.[0]);
  const [showAddVariable, setShowAddVariable] = useState(false);
  const [newVariable, setNewVariable] = useState({ key: '', value: '', encrypted: false });

  const statusColors = {
    healthy: 'text-success bg-success/10',
    building: 'text-warning bg-warning/10',
    error: 'text-destructive bg-destructive/10',
    stopped: 'text-muted-foreground bg-muted'
  };

  const handleAddVariable = () => {
    if (newVariable?.key && newVariable?.value) {
      setEnvironments(prev => prev?.map(env => 
        env?.id === selectedEnv?.id 
          ? { ...env, variables: [...env?.variables, { ...newVariable, id: Date.now() }] }
          : env
      ));
      setNewVariable({ key: '', value: '', encrypted: false });
      setShowAddVariable(false);
    }
  };

  const handleDeleteVariable = (variableKey) => {
    setEnvironments(prev => prev?.map(env => 
      env?.id === selectedEnv?.id 
        ? { ...env, variables: env?.variables?.filter(v => v?.key !== variableKey) }
        : env
    ));
  };

  const handleToggleAutoDeploy = (envId) => {
    setEnvironments(prev => prev?.map(env => 
      env?.id === envId 
        ? { ...env, autoDeployEnabled: !env?.autoDeployEnabled }
        : env
    ));
  };

  const handleCreateEnvironment = () => {
    const newEnv = {
      id: `env-${Date.now()}`,
      name: 'New Environment',
      description: 'Custom environment',
      url: '',
      branch: '',
      status: 'stopped',
      lastDeployment: null,
      autoDeployEnabled: false,
      variables: []
    };
    setEnvironments(prev => [...prev, newEnv]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Environment Management</h2>
          <p className="text-muted-foreground">
            Manage staging, production, and development configurations
          </p>
        </div>
        <Button
          variant="default"
          iconName="Plus"
          iconPosition="left"
          iconSize={16}
          onClick={handleCreateEnvironment}
        >
          Create Environment
        </Button>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Environment List */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">Environments</h3>
          {environments?.map((env) => (
            <div
              key={env?.id}
              className={`bg-card border rounded-lg p-4 cursor-pointer transition-all duration-200 hover:shadow-elevation-1 ${
                selectedEnv?.id === env?.id ? 'border-primary ring-2 ring-primary/20' : 'border-border'
              }`}
              onClick={() => setSelectedEnv(env)}
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-foreground">{env?.name}</h4>
                <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${statusColors?.[env?.status]}`}>
                  {env?.status}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mb-3">{env?.description}</p>
              
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">URL:</span>
                  <span className="text-foreground font-mono">{env?.url || 'Not configured'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Branch:</span>
                  <span className="text-foreground font-mono">{env?.branch || 'Not set'}</span>
                </div>
                {env?.lastDeployment && (
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Last Deploy:</span>
                    <span className="text-foreground">{env?.lastDeployment?.toLocaleDateString()}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                <div className="flex items-center space-x-2">
                  <Icon name={env?.autoDeployEnabled ? 'GitBranch' : 'GitBranchPlus'} size={12} />
                  <span className="text-xs text-muted-foreground">
                    Auto-deploy {env?.autoDeployEnabled ? 'enabled' : 'disabled'}
                  </span>
                </div>
                <Icon name="ChevronRight" size={16} className="text-muted-foreground" />
              </div>
            </div>
          ))}
        </div>

        {/* Environment Details */}
        <div className="lg:col-span-2 space-y-6">
          {selectedEnv && (
            <>
              {/* Basic Configuration */}
              <div className="bg-card border border-border rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-foreground">Configuration</h3>
                  <Button variant="outline" size="sm" iconName="Settings" iconSize={16}>
                    Edit
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Environment Name
                    </label>
                    <Input
                      value={selectedEnv?.name}
                      readOnly
                      className="bg-muted"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Status
                    </label>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${
                        selectedEnv?.status === 'healthy' ? 'bg-success' :
                        selectedEnv?.status === 'building' ? 'bg-warning' :
                        selectedEnv?.status === 'error'? 'bg-destructive' : 'bg-muted-foreground'
                      }`} />
                      <span className="text-sm text-foreground capitalize">{selectedEnv?.status}</span>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      URL
                    </label>
                    <Input
                      value={selectedEnv?.url}
                      readOnly
                      className="bg-muted"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Git Branch
                    </label>
                    <Input
                      value={selectedEnv?.branch}
                      readOnly
                      className="bg-muted"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
                  <div className="flex items-center space-x-3">
                    <Icon name="GitBranch" size={16} className="text-muted-foreground" />
                    <span className="text-sm text-foreground">Auto-deploy from Git</span>
                  </div>
                  <Button
                    variant={selectedEnv?.autoDeployEnabled ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleToggleAutoDeploy(selectedEnv?.id)}
                  >
                    {selectedEnv?.autoDeployEnabled ? 'Enabled' : 'Disabled'}
                  </Button>
                </div>
              </div>

              {/* Environment Variables */}
              <div className="bg-card border border-border rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-foreground">Environment Variables</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Plus"
                    iconSize={16}
                    onClick={() => setShowAddVariable(true)}
                  >
                    Add Variable
                  </Button>
                </div>

                {showAddVariable && (
                  <div className="bg-muted border border-border rounded-lg p-4 mb-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <Input
                        placeholder="Variable name"
                        value={newVariable?.key}
                        onChange={(e) => setNewVariable(prev => ({ ...prev, key: e?.target?.value }))}
                      />
                      <Input
                        placeholder="Variable value"
                        type={newVariable?.encrypted ? "password" : "text"}
                        value={newVariable?.value}
                        onChange={(e) => setNewVariable(prev => ({ ...prev, value: e?.target?.value }))}
                      />
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id="encrypted"
                          checked={newVariable?.encrypted}
                          onChange={(e) => setNewVariable(prev => ({ ...prev, encrypted: e?.target?.checked }))}
                          className="rounded border-border text-primary focus:ring-primary"
                        />
                        <label htmlFor="encrypted" className="text-sm text-foreground">Encrypted</label>
                      </div>
                    </div>
                    <div className="flex items-center justify-end space-x-2 mt-3">
                      <Button variant="ghost" size="sm" onClick={() => setShowAddVariable(false)}>
                        Cancel
                      </Button>
                      <Button variant="default" size="sm" onClick={handleAddVariable}>
                        Add Variable
                      </Button>
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  {selectedEnv?.variables?.map((variable, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div className="flex items-center space-x-4 flex-1">
                        <code className="text-sm font-mono text-foreground">{variable?.key}</code>
                        <span className="text-muted-foreground">=</span>
                        <code className="text-sm font-mono text-foreground">
                          {variable?.encrypted ? '••••••••••••' : variable?.value}
                        </code>
                        {variable?.encrypted && (
                          <Icon name="Lock" size={12} className="text-muted-foreground" />
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          iconName="Edit"
                          iconSize={12}
                          className="h-6 w-6 p-0"
                        />
                        <Button
                          variant="ghost"
                          size="sm"
                          iconName="Trash2"
                          iconSize={12}
                          className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                          onClick={() => handleDeleteVariable(variable?.key)}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                {selectedEnv?.variables?.length === 0 && (
                  <div className="text-center py-8">
                    <Icon name="Database" size={32} className="text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">No environment variables configured</p>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Button variant="default" iconName="Rocket" iconPosition="left" iconSize={16}>
                    Deploy Environment
                  </Button>
                  <Button variant="outline" iconName="RotateCcw" iconPosition="left" iconSize={16}>
                    Rollback
                  </Button>
                </div>
                <Button variant="destructive" iconName="Trash2" iconPosition="left" iconSize={16}>
                  Delete Environment
                </Button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default EnvironmentManager;