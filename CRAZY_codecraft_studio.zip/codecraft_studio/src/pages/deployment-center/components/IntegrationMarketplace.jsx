import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const IntegrationMarketplace = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [connectedIntegrations, setConnectedIntegrations] = useState(['google-analytics', 'stripe']);

  const integrations = [
    {
      id: 'google-analytics',
      name: 'Google Analytics',
      description: 'Track user behavior and website performance with detailed analytics',
      category: 'Analytics',
      icon: 'BarChart3',
      provider: 'Google',
      pricing: 'Free',
      rating: 4.8,
      installs: '2.1M+',
      features: ['Real-time tracking', 'Custom events', 'Conversion goals', 'Demographics'],
      setupTime: '5 min',
      connected: true
    },
    {
      id: 'stripe',
      name: 'Stripe Payments',
      description: 'Accept payments online with secure payment processing',
      category: 'Payment',
      icon: 'CreditCard',
      provider: 'Stripe',
      pricing: '2.9% + 30¢',
      rating: 4.9,
      installs: '1.8M+',
      features: ['Credit cards', 'Digital wallets', 'Subscriptions', 'Invoicing'],
      setupTime: '10 min',
      connected: true
    },
    {
      id: 'sendgrid',
      name: 'SendGrid Email',
      description: 'Send transactional and marketing emails at scale',
      category: 'Communication',
      icon: 'Mail',
      provider: 'Twilio',
      pricing: 'Free tier available',
      rating: 4.6,
      installs: '890K+',
      features: ['Email templates', 'A/B testing', 'Analytics', 'SMTP relay'],
      setupTime: '8 min',
      connected: false
    },
    {
      id: 'auth0',
      name: 'Auth0',
      description: 'Secure authentication and authorization platform',
      category: 'Authentication',
      icon: 'Shield',
      provider: 'Auth0',
      pricing: 'Free for 7,000 users',
      rating: 4.7,
      installs: '1.2M+',
      features: ['Social login', 'Multi-factor auth', 'SSO', 'User management'],
      setupTime: '15 min',
      connected: false
    },
    {
      id: 'intercom',
      name: 'Intercom',
      description: 'Customer messaging platform for support and engagement',
      category: 'Customer Support',
      icon: 'MessageCircle',
      provider: 'Intercom',
      pricing: 'From $39/month',
      rating: 4.5,
      installs: '560K+',
      features: ['Live chat', 'Help desk', 'Product tours', 'Chatbots'],
      setupTime: '12 min',
      connected: false
    },
    {
      id: 'supabase',
      name: 'Supabase',
      description: 'Open source Firebase alternative with PostgreSQL',
      category: 'Database',
      icon: 'Database',
      provider: 'Supabase',
      pricing: 'Free tier available',
      rating: 4.8,
      installs: '450K+',
      features: ['Real-time DB', 'Authentication', 'Storage', 'Edge functions'],
      setupTime: '20 min',
      connected: false
    },
    {
      id: 'hotjar',
      name: 'Hotjar',
      description: 'Behavior analytics and user feedback platform',
      category: 'Analytics',
      icon: 'Eye',
      provider: 'Hotjar',
      pricing: 'Free for 35 sessions/day',
      rating: 4.4,
      installs: '780K+',
      features: ['Heatmaps', 'Session recordings', 'Surveys', 'Feedback polls'],
      setupTime: '5 min',
      connected: false
    },
    {
      id: 'klaviyo',
      name: 'Klaviyo',
      description: 'Email and SMS marketing automation platform',
      category: 'Marketing',
      icon: 'Megaphone',
      provider: 'Klaviyo',
      pricing: 'Free for 250 contacts',
      rating: 4.6,
      installs: '320K+',
      features: ['Email campaigns', 'SMS marketing', 'Segmentation', 'Automation'],
      setupTime: '15 min',
      connected: false
    }
  ];

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'Analytics', label: 'Analytics' },
    { value: 'Payment', label: 'Payment' },
    { value: 'Communication', label: 'Communication' },
    { value: 'Authentication', label: 'Authentication' },
    { value: 'Customer Support', label: 'Customer Support' },
    { value: 'Database', label: 'Database' },
    { value: 'Marketing', label: 'Marketing' }
  ];

  const filteredIntegrations = integrations?.filter(integration => {
    const matchesSearch = integration?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
                         integration?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || integration?.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleConnect = (integrationId) => {
    setConnectedIntegrations(prev => [...prev, integrationId]);
    console.log(`Connecting ${integrationId}...`);
  };

  const handleDisconnect = (integrationId) => {
    setConnectedIntegrations(prev => prev?.filter(id => id !== integrationId));
    console.log(`Disconnecting ${integrationId}...`);
  };

  const handleConfigure = (integrationId) => {
    console.log(`Configuring ${integrationId}...`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Integration Marketplace</h2>
          <p className="text-muted-foreground">
            Connect popular services to enhance your application with guided setup workflows
          </p>
        </div>
        <Button
          variant="outline"
          iconName="Plus"
          iconPosition="left"
          iconSize={16}
          onClick={() => console.log('Request integration')}
        >
          Request Integration
        </Button>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <Input
            type="search"
            placeholder="Search integrations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e?.target?.value)}
            className="w-full"
          />
        </div>
        <div className="sm:w-64">
          <Select
            options={categories}
            value={selectedCategory}
            onChange={setSelectedCategory}
            placeholder="Select category..."
          />
        </div>
      </div>

      {/* Connected Integrations Summary */}
      {connectedIntegrations?.length > 0 && (
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-foreground">Connected Integrations</h3>
            <span className="text-sm text-muted-foreground">
              {connectedIntegrations?.length} connected
            </span>
          </div>
          <div className="flex flex-wrap gap-3">
            {connectedIntegrations?.map(integrationId => {
              const integration = integrations?.find(i => i?.id === integrationId);
              return integration ? (
                <div key={integrationId} className="flex items-center space-x-2 bg-muted rounded-lg px-3 py-2">
                  <Icon name={integration?.icon} size={16} className="text-primary" />
                  <span className="text-sm font-medium text-foreground">{integration?.name}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="X"
                    iconSize={12}
                    className="h-4 w-4 p-0 ml-2"
                    onClick={() => handleDisconnect(integrationId)}
                  />
                </div>
              ) : null;
            })}
          </div>
        </div>
      )}

      {/* Integrations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredIntegrations?.map((integration) => {
          const isConnected = connectedIntegrations?.includes(integration?.id);
          
          return (
            <div
              key={integration?.id}
              className={`bg-card border rounded-lg p-6 transition-all duration-200 hover:shadow-elevation-2 ${
                isConnected ? 'border-success ring-2 ring-success/20' : 'border-border'
              }`}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${
                    isConnected ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'
                  }`}>
                    <Icon name={integration?.icon} size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">{integration?.name}</h4>
                    <p className="text-sm text-muted-foreground">{integration?.provider}</p>
                  </div>
                </div>
                
                {isConnected && (
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-success/10 text-success">
                    Connected
                  </span>
                )}
              </div>

              {/* Description */}
              <p className="text-sm text-muted-foreground mb-4">
                {integration?.description}
              </p>

              {/* Features */}
              <div className="mb-4">
                <div className="flex flex-wrap gap-1">
                  {integration?.features?.slice(0, 3)?.map((feature, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-2 py-1 rounded text-xs bg-muted text-muted-foreground"
                    >
                      {feature}
                    </span>
                  ))}
                  {integration?.features?.length > 3 && (
                    <span className="inline-flex items-center px-2 py-1 rounded text-xs bg-muted text-muted-foreground">
                      +{integration?.features?.length - 3} more
                    </span>
                  )}
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 mb-4 text-xs">
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-1">
                    <Icon name="Star" size={12} className="text-warning" />
                    <span className="font-medium text-foreground">{integration?.rating}</span>
                  </div>
                  <span className="text-muted-foreground">Rating</span>
                </div>
                <div className="text-center">
                  <div className="font-medium text-foreground">{integration?.installs}</div>
                  <span className="text-muted-foreground">Installs</span>
                </div>
                <div className="text-center">
                  <div className="font-medium text-foreground">{integration?.setupTime}</div>
                  <span className="text-muted-foreground">Setup</span>
                </div>
              </div>

              {/* Pricing */}
              <div className="mb-4 p-3 bg-muted rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Pricing</span>
                  <span className="text-sm font-medium text-foreground">{integration?.pricing}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-2">
                {isConnected ? (
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      iconName="Settings"
                      iconPosition="left"
                      onClick={() => handleConfigure(integration?.id)}
                    >
                      Configure
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full text-destructive hover:text-destructive"
                      iconName="Unplug"
                      iconPosition="left"
                      onClick={() => handleDisconnect(integration?.id)}
                    >
                      Disconnect
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="default"
                    size="sm"
                    className="w-full"
                    iconName="Plus"
                    iconPosition="left"
                    onClick={() => handleConnect(integration?.id)}
                  >
                    Connect
                  </Button>
                )}
              </div>

              {/* Setup Guide Link */}
              <div className="mt-3 pt-3 border-t border-border">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full text-xs"
                  iconName="FileText"
                  iconPosition="left"
                  onClick={() => console.log(`View setup guide for ${integration?.id}`)}
                >
                  View Setup Guide
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredIntegrations?.length === 0 && (
        <div className="text-center py-12">
          <Icon name="Search" size={64} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No integrations found</h3>
          <p className="text-muted-foreground mb-6">
            Try adjusting your search or filter criteria
          </p>
          <Button
            variant="outline"
            iconName="RotateCcw"
            iconPosition="left"
            iconSize={16}
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
            }}
          >
            Clear Filters
          </Button>
        </div>
      )}
    </div>
  );
};

export default IntegrationMarketplace;