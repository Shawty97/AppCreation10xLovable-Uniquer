import React, { useState, useEffect } from 'react';
import { deploymentService } from '../../../services/deploymentService';
import Button from '../../../components/ui/Button';

import Select from '../../../components/ui/Select';
import { useAuth } from '../../../contexts/AuthContext';

const DeploymentDashboard = ({ projectId }) => {
  const { user } = useAuth();
  const [deployments, setDeployments] = useState([]);
  const [deploymentTargets, setDeploymentTargets] = useState([]);
  const [buildQueue, setBuildQueue] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTarget, setSelectedTarget] = useState('');
  const [isDeploying, setIsDeploying] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!projectId || !user) return;
    loadData();
  }, [projectId, user]);

  const loadData = async () => {
    try {
      setLoading(true);
      setError('');
      
      const [deploymentsData, targetsData, queueData] = await Promise.all([
        deploymentService?.getDeployments(projectId),
        deploymentService?.getDeploymentTargets(projectId),
        deploymentService?.getBuildQueue()
      ]);

      setDeployments(deploymentsData || []);
      setDeploymentTargets(targetsData || []);
      setBuildQueue(queueData || []);
    } catch (err) {
      setError('Failed to load deployment data: ' + err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeploy = async () => {
    if (!selectedTarget) {
      setError('Please select a deployment target');
      return;
    }

    try {
      setIsDeploying(true);
      setError('');
      
      await deploymentService?.triggerDeployment(selectedTarget, {
        branch: 'main',
        priority: 5
      });
      
      // Reload data to show new deployment
      await loadData();
    } catch (err) {
      setError('Deployment failed: ' + err?.message);
    } finally {
      setIsDeploying(false);
    }
  };

  const handleCancelDeployment = async (deploymentId) => {
    try {
      setError('');
      await deploymentService?.cancelDeployment(deploymentId);
      await loadData();
    } catch (err) {
      setError('Failed to cancel deployment: ' + err?.message);
    }
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
          <div className="h-48 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Deployment Center</h1>
          <p className="text-gray-600 mt-1">Deploy and manage your application with one click</p>
        </div>
        <div className="flex items-center space-x-3">
          <Select
            value={selectedTarget}
            onValueChange={setSelectedTarget}
            placeholder="Select deployment target"
            className="w-64"
          >
            {deploymentTargets?.map((target) => (
              <option key={target?.id} value={target?.id}>
                {deploymentService?.getProviderIcon(target?.provider)} {target?.name}
              </option>
            ))}
          </Select>
          <Button
            onClick={handleDeploy}
            disabled={!selectedTarget || isDeploying}
            className="bg-green-600 hover:bg-green-700"
          >
            {isDeploying ? 'Deploying...' : '🚀 Deploy Now'}
          </Button>
        </div>
      </div>
      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-600">{error}</p>
        </div>
      )}
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <span className="text-xl">🚀</span>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Total Deployments</p>
              <p className="text-2xl font-bold text-gray-900">{deployments?.length || 0}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <span className="text-xl">✅</span>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Successful</p>
              <p className="text-2xl font-bold text-gray-900">
                {deployments?.filter(d => d?.status === 'success')?.length || 0}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center">
            <div className="p-2 bg-yellow-100 rounded-lg">
              <span className="text-xl">⏳</span>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">In Queue</p>
              <p className="text-2xl font-bold text-gray-900">
                {buildQueue?.filter(q => q?.status === 'queued')?.length || 0}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded-lg">
              <span className="text-xl">🎯</span>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Targets</p>
              <p className="text-2xl font-bold text-gray-900">{deploymentTargets?.length || 0}</p>
            </div>
          </div>
        </div>
      </div>
      {/* Recent Deployments */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Recent Deployments</h2>
        </div>
        <div className="p-6">
          {deployments?.length === 0 ? (
            <div className="text-center py-12">
              <span className="text-6xl">🚀</span>
              <h3 className="text-lg font-medium text-gray-900 mt-4">No deployments yet</h3>
              <p className="text-gray-500 mt-2">Deploy your project to see deployment history</p>
            </div>
          ) : (
            <div className="space-y-4">
              {deployments?.map((deployment) => (
                <div key={deployment?.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${deploymentService?.getStatusColor(deployment?.status)}`}>
                      {deployment?.status}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">
                        {deployment?.target?.provider && deploymentService?.getProviderIcon(deployment?.target?.provider)} 
                        {deployment?.target?.name}
                      </p>
                      <p className="text-sm text-gray-500">
                        {deployment?.branch} • {deployment?.commit_hash?.substring(0, 7)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      {deployment?.build_duration && (
                        <p className="text-sm text-gray-900">
                          Build: {deploymentService?.formatDeploymentDuration(deployment?.build_duration)}
                        </p>
                      )}
                      <p className="text-sm text-gray-500">
                        {new Date(deployment?.created_at)?.toLocaleString()}
                      </p>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {deployment?.deployment_url && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => window.open(deployment?.deployment_url, '_blank')}
                        >
                          🔗 Visit
                        </Button>
                      )}
                      
                      {(deployment?.status === 'pending' || deployment?.status === 'building') && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleCancelDeployment(deployment?.id)}
                        >
                          ❌ Cancel
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      {/* Build Queue */}
      {buildQueue?.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Build Queue</h2>
          </div>
          <div className="p-6">
            <div className="space-y-3">
              {buildQueue?.map((item) => (
                <div key={item?.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`px-2 py-1 rounded text-xs font-medium ${deploymentService?.getStatusColor(item?.status)}`}>
                      {item?.status}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">{item?.project?.name}</p>
                      <p className="text-xs text-gray-500">Priority: {item?.priority}</p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-xs text-gray-500">
                      {new Date(item?.created_at)?.toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DeploymentDashboard;