import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const VersionControl = ({ selectedProject, onRollback }) => {
  const [selectedBranch, setSelectedBranch] = useState('main');
  const [autoDeployEnabled, setAutoDeployEnabled] = useState(true);
  const [showCommitModal, setShowCommitModal] = useState(false);

  const repositories = [
    {
      id: 'github',
      name: 'GitHub',
      connected: true,
      url: 'https://github.com/user/myapp',
      lastSync: new Date(Date.now() - 300000)
    },
    {
      id: 'gitlab',
      name: 'GitLab',
      connected: false,
      url: null,
      lastSync: null
    },
    {
      id: 'bitbucket',
      name: 'Bitbucket',
      connected: false,
      url: null,
      lastSync: null
    }
  ];

  const branches = [
    { value: 'main', label: 'main' },
    { value: 'develop', label: 'develop' },
    { value: 'staging', label: 'staging' },
    { value: 'feature/new-ui', label: 'feature/new-ui' }
  ];

  const deploymentHistory = [
    {
      id: 1,
      version: 'v2.1.4',
      commit: 'a1b2c3d',
      message: 'Add user authentication and dashboard improvements',
      author: 'John Doe',
      branch: 'main',
      deployedAt: new Date(Date.now() - 86400000),
      status: 'active',
      environment: 'production',
      buildTime: '3m 24s'
    },
    {
      id: 2,
      version: 'v2.1.3',
      commit: 'e4f5g6h',
      message: 'Fix payment processing bug and update dependencies',
      author: 'Jane Smith',
      branch: 'main',
      deployedAt: new Date(Date.now() - 172800000),
      status: 'inactive',
      environment: 'production',
      buildTime: '2m 56s'
    },
    {
      id: 3,
      version: 'v2.1.2',
      commit: 'i7j8k9l',
      message: 'Implement responsive design for mobile devices',
      author: 'Mike Johnson',
      branch: 'main',
      deployedAt: new Date(Date.now() - 259200000),
      status: 'inactive',
      environment: 'production',
      buildTime: '4m 12s'
    },
    {
      id: 4,
      version: 'v2.1.1',
      commit: 'm1n2o3p',
      message: 'Performance optimizations and code cleanup',
      author: 'Sarah Wilson',
      branch: 'main',
      deployedAt: new Date(Date.now() - 432000000),
      status: 'inactive',
      environment: 'production',
      buildTime: '3m 45s'
    }
  ];

  const environments = [
    {
      name: 'Production',
      branch: 'main',
      autoDeployEnabled: true,
      lastDeployment: deploymentHistory?.[0],
      triggerType: 'push'
    },
    {
      name: 'Staging',
      branch: 'develop',
      autoDeployEnabled: true,
      lastDeployment: null,
      triggerType: 'pull_request'
    },
    {
      name: 'Development',
      branch: 'feature/*',
      autoDeployEnabled: false,
      lastDeployment: null,
      triggerType: 'manual'
    }
  ];

  const handleConnectRepository = (repoId) => {
    console.log(`Connecting to ${repoId}...`);
  };

  const handleDisconnectRepository = (repoId) => {
    console.log(`Disconnecting from ${repoId}...`);
  };

  const handleManualDeploy = (branch) => {
    console.log(`Manually deploying from ${branch}...`);
  };

  const handleRollbackToVersion = (version) => {
    if (onRollback) {
      onRollback(version);
    }
  };

  const CommitModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-card border border-border rounded-lg p-6 w-full max-w-md">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Commit Details</h3>
          <Button
            variant="ghost"
            size="sm"
            iconName="X"
            iconSize={16}
            onClick={() => setShowCommitModal(false)}
          />
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Commit Message
            </label>
            <Input placeholder="Enter commit message..." />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Description (optional)
            </label>
            <textarea
              className="w-full px-3 py-2 border border-border rounded-md text-foreground bg-background"
              rows={3}
              placeholder="Detailed description of changes..."
            />
          </div>
        </div>
        <div className="flex items-center justify-end space-x-3 mt-6">
          <Button variant="outline" onClick={() => setShowCommitModal(false)}>
            Cancel
          </Button>
          <Button variant="default">
            Commit & Deploy
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Version Control</h2>
          <p className="text-muted-foreground">
            Manage Git integration with automatic deployments and version tracking
          </p>
        </div>
        <Button
          variant="default"
          iconName="GitCommit"
          iconPosition="left"
          iconSize={16}
          onClick={() => setShowCommitModal(true)}
        >
          Commit & Deploy
        </Button>
      </div>

      {/* Repository Connections */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Repository Connections</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {repositories?.map((repo) => (
            <div
              key={repo?.id}
              className={`border rounded-lg p-4 ${
                repo?.connected ? 'border-success bg-success/5' : 'border-border'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <Icon 
                    name={
                      repo?.id === 'github' ? 'Github' :
                      repo?.id === 'gitlab'? 'GitlabIcon' : 'BitbucketIcon'
                    } 
                    size={20} 
                    className={repo?.connected ? 'text-success' : 'text-muted-foreground'}
                  />
                  <span className="font-medium text-foreground">{repo?.name}</span>
                </div>
                <div className={`w-2 h-2 rounded-full ${
                  repo?.connected ? 'bg-success' : 'bg-muted-foreground'
                }`} />
              </div>

              {repo?.connected ? (
                <div className="space-y-2">
                  <p className="text-xs text-muted-foreground font-mono">
                    {repo?.url}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Last sync: {repo?.lastSync?.toLocaleString()}
                  </p>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      iconName="RefreshCw"
                      iconSize={12}
                      onClick={() => console.log(`Sync ${repo?.id}`)}
                    >
                      Sync
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      iconName="Unplug"
                      iconSize={12}
                      className="text-destructive hover:text-destructive"
                      onClick={() => handleDisconnectRepository(repo?.id)}
                    />
                  </div>
                </div>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => handleConnectRepository(repo?.id)}
                >
                  Connect
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Environment Configuration */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Auto-Deploy Configuration</h3>
        
        <div className="space-y-4">
          {environments?.map((env, index) => (
            <div key={index} className="flex items-center justify-between p-4 border border-border rounded-lg">
              <div className="flex items-center space-x-4">
                <div>
                  <h4 className="font-medium text-foreground">{env?.name}</h4>
                  <p className="text-sm text-muted-foreground">
                    Branch: <code className="font-mono">{env?.branch}</code>
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="text-right text-sm">
                  <p className="text-muted-foreground">Trigger: {env?.triggerType?.replace('_', ' ')}</p>
                  {env?.lastDeployment && (
                    <p className="text-foreground">
                      {env?.lastDeployment?.version} - {env?.lastDeployment?.deployedAt?.toLocaleDateString()}
                    </p>
                  )}
                </div>
                
                <div className="flex items-center space-x-2">
                  <Button
                    variant={env?.autoDeployEnabled ? "default" : "outline"}
                    size="sm"
                    onClick={() => console.log(`Toggle auto-deploy for ${env?.name}`)}
                  >
                    {env?.autoDeployEnabled ? 'Auto' : 'Manual'}
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Play"
                    iconSize={12}
                    onClick={() => handleManualDeploy(env?.branch)}
                  >
                    Deploy
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Deployment History */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground">Deployment History</h3>
          <div className="flex items-center space-x-3">
            <Select
              options={branches}
              value={selectedBranch}
              onChange={setSelectedBranch}
              className="w-40"
            />
            <Button
              variant="outline"
              iconName="Download"
              iconSize={16}
              onClick={() => console.log('Export deployment history')}
            >
              Export
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          {deploymentHistory?.map((deployment) => (
            <div
              key={deployment?.id}
              className={`border rounded-lg p-4 ${
                deployment?.status === 'active' ? 'border-success bg-success/5' : 'border-border'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className={`p-2 rounded-lg ${
                    deployment?.status === 'active' ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'
                  }`}>
                    <Icon name="GitCommit" size={16} />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h4 className="font-medium text-foreground">{deployment?.version}</h4>
                      <code className="text-sm bg-muted px-2 py-1 rounded text-foreground">
                        {deployment?.commit}
                      </code>
                      {deployment?.status === 'active' && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-success/10 text-success">
                          Current
                        </span>
                      )}
                    </div>
                    
                    <p className="text-sm text-foreground mb-2">{deployment?.message}</p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs text-muted-foreground">
                      <div>
                        <span className="block">Author</span>
                        <span className="text-foreground font-medium">{deployment?.author}</span>
                      </div>
                      <div>
                        <span className="block">Branch</span>
                        <span className="text-foreground font-medium">{deployment?.branch}</span>
                      </div>
                      <div>
                        <span className="block">Build Time</span>
                        <span className="text-foreground font-medium">{deployment?.buildTime}</span>
                      </div>
                      <div>
                        <span className="block">Deployed</span>
                        <span className="text-foreground font-medium">
                          {deployment?.deployedAt?.toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="ExternalLink"
                    iconSize={12}
                    onClick={() => console.log(`View commit ${deployment?.commit}`)}
                  />
                  
                  {deployment?.status !== 'active' && (
                    <Button
                      variant="outline"
                      size="sm"
                      iconName="RotateCcw"
                      iconSize={12}
                      onClick={() => handleRollbackToVersion(deployment?.version)}
                    >
                      Rollback
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center pt-4">
          <Button variant="outline" onClick={() => console.log('Load more deployments')}>
            Load More Deployments
          </Button>
        </div>
      </div>

      {showCommitModal && <CommitModal />}
    </div>
  );
};

export default VersionControl;