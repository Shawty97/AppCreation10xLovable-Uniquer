import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { projectService } from '../../services/projectService';
import DeploymentDashboard from './components/DeploymentDashboard';
import DeploymentTargetsManager from './components/DeploymentTargetsManager';
import PerformanceMonitor from './components/PerformanceMonitor';
import { useAuth } from '../../contexts/AuthContext';

const DeploymentCenter = () => {
  const { projectId } = useParams();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [project, setProject] = useState(null);
  const [selectedDeploymentId, setSelectedDeploymentId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (projectId && user) {
      loadProject();
    }
  }, [projectId, user]);

  const loadProject = async () => {
    try {
      setLoading(true);
      setError('');
      
      // Load project details
      const projectData = await projectService?.getProject(projectId);
      setProject(projectData);
    } catch (err) {
      setError('Failed to load project: ' + err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleTabClick = (tab) => {
    setActiveTab(tab);
    setError(''); // Clear any previous errors when switching tabs
  };

  const tabs = [
    {
      id: 'dashboard',
      name: 'Dashboard',
      icon: '📊',
      description: 'Overview and deployment history'
    },
    {
      id: 'targets',
      name: 'Targets',
      icon: '🎯',
      description: 'Manage deployment destinations'
    },
    {
      id: 'performance',
      name: 'Performance',
      icon: '⚡',
      description: 'Monitor and optimize'
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-gray-600 mt-4">Loading deployment center...</p>
        </div>
      </div>
    );
  }

  if (error && !project) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto">
          <span className="text-6xl">❌</span>
          <h2 className="text-2xl font-bold text-gray-900 mt-4">Error Loading Project</h2>
          <p className="text-gray-600 mt-2">{error}</p>
          <button
            onClick={() => window.history?.back()}
            className="mt-6 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => window.history?.back()}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg"
              >
                ← Back
              </button>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">
                  {project?.name || 'Project'} - Deployment Center
                </h1>
                <p className="text-sm text-gray-500">
                  Deploy and manage your application
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <span className="px-3 py-1 bg-green-100 text-green-800 text-sm font-medium rounded-full">
                {project?.framework || 'React'}
              </span>
              <span className="px-3 py-1 bg-blue-100 text-blue-800 text-sm font-medium rounded-full">
                {project?.status || 'Active'}
              </span>
            </div>
          </div>
        </div>
      </div>
      {/* Navigation Tabs */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {tabs?.map((tab) => (
              <button
                key={tab?.id}
                onClick={() => handleTabClick(tab?.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab?.id
                    ? 'border-blue-500 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span>{tab?.icon}</span>
                  <span>{tab?.name}</span>
                </div>
                <p className="text-xs text-gray-400 mt-1">{tab?.description}</p>
              </button>
            ))}
          </div>
        </div>
      </div>
      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Global Error Message */}
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex">
              <span className="text-red-400 text-lg">⚠️</span>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Something went wrong</h3>
                <p className="text-sm text-red-700 mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab Content */}
        {activeTab === 'dashboard' && (
          <DeploymentDashboard 
            projectId={projectId}
            onDeploymentSelect={setSelectedDeploymentId}
          />
        )}

        {activeTab === 'targets' && (
          <DeploymentTargetsManager 
            projectId={projectId}
            onTargetCreated={(target) => {
              // Optionally switch to dashboard after creating target
              // setActiveTab('dashboard');
            }}
          />
        )}

        {activeTab === 'performance' && (
          <div className="space-y-6">
            {!selectedDeploymentId && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex">
                  <span className="text-blue-400 text-lg">💡</span>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-blue-800">Select a Deployment</h3>
                    <p className="text-sm text-blue-700 mt-1">
                      Go to the Dashboard tab and click on a deployment to view its performance metrics.
                    </p>
                    <button
                      onClick={() => setActiveTab('dashboard')}
                      className="mt-2 text-sm text-blue-600 hover:text-blue-800 underline"
                    >
                      Go to Dashboard
                    </button>
                  </div>
                </div>
              </div>
            )}
            
            <PerformanceMonitor 
              deploymentId={selectedDeploymentId}
              projectId={projectId}
            />
          </div>
        )}
      </div>
      {/* Footer */}
      <div className="bg-white border-t mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-500">
              <p>🚀 Deployment Center • Built with CodeCraft Studio</p>
            </div>
            <div className="flex items-center space-x-4 text-sm text-gray-500">
              <span>📊 Real-time monitoring</span>
              <span>⚡ Instant deployments</span>
              <span>🎯 Multi-provider support</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeploymentCenter;