import React, { useEffect } from 'react';

const SQLExporter = () => {
  React.useEffect(() => {
    // eslint-disable-next-line no-console
    console.warn('Placeholder: SQLExporter is not implemented yet.');
  }, []);
  return (
    <>
  { /*SQLExporter */} 
 </>
  );
};

export default SQLExporter;
