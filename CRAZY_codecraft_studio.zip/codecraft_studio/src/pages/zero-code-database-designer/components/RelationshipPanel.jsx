import React, { useEffect } from 'react';

const RelationshipPanel = () => {
  React.useEffect(() => {
    // eslint-disable-next-line no-console
    console.warn('Placeholder: RelationshipPanel is not implemented yet.');
  }, []);
  return (
    <>
  { /*RelationshipPanel */} 
 </>
  );
};

export default RelationshipPanel;
