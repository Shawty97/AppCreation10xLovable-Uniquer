import React, { useState } from 'react';
import { ChevronDown, Plus, RefreshCw, Database, Settings } from 'lucide-react';
import databaseDesignerService from '../../../services/databaseDesignerService';

const SchemaSelector = ({ schemas, currentSchema, onSchemaChange, onRefresh }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [newSchemaData, setNewSchemaData] = useState({
    name: '',
    description: '',
    project_id: ''
  });

  const handleCreateSchema = async (e) => {
    e?.preventDefault();
    if (!newSchemaData?.name?.trim()) return;
    
    setIsLoading(true);
    try {
      const result = await databaseDesignerService?.createDatabaseSchema(newSchemaData);
      if (result?.success) {
        setNewSchemaData({ name: '', description: '', project_id: '' });
        setShowCreateForm(false);
        setIsOpen(false);
        onRefresh();
        onSchemaChange(result?.data);
      }
    } catch (error) {
      console.error('Failed to create schema:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative">
      {/* Schema selector button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
      >
        <Database className="w-4 h-4 text-gray-500" />
        <span className="text-sm font-medium text-gray-900">
          {currentSchema?.name || 'Select Schema'}
        </span>
        <ChevronDown className={`w-4 h-4 text-gray-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {/* Dropdown menu */}
      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-10" 
            onClick={() => {
              setIsOpen(false);
              setShowCreateForm(false);
            }}
          />
          <div className="absolute top-full left-0 mt-2 w-80 bg-white border border-gray-200 rounded-lg shadow-lg z-20">
            {/* Header */}
            <div className="px-4 py-3 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium text-gray-900">Database Schemas</h3>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={onRefresh}
                    className="p-1 hover:bg-gray-100 rounded text-gray-500"
                    title="Refresh"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setShowCreateForm(!showCreateForm)}
                    className="p-1 hover:bg-gray-100 rounded text-gray-500"
                    title="Create New Schema"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Create form */}
            {showCreateForm && (
              <div className="px-4 py-3 border-b border-gray-200 bg-gray-50">
                <form onSubmit={handleCreateSchema} className="space-y-3">
                  <div>
                    <input
                      type="text"
                      placeholder="Schema name"
                      value={newSchemaData?.name}
                      onChange={(e) => setNewSchemaData({...newSchemaData, name: e?.target?.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      required
                    />
                  </div>
                  <div>
                    <textarea
                      placeholder="Description (optional)"
                      value={newSchemaData?.description}
                      onChange={(e) => setNewSchemaData({...newSchemaData, description: e?.target?.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                      rows={2}
                    />
                  </div>
                  <div className="flex items-center justify-end space-x-2">
                    <button
                      type="button"
                      onClick={() => setShowCreateForm(false)}
                      className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isLoading || !newSchemaData?.name?.trim()}
                      className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isLoading ? 'Creating...' : 'Create'}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Schema list */}
            <div className="max-h-64 overflow-y-auto">
              {schemas?.length === 0 ? (
                <div className="px-4 py-6 text-center text-gray-500">
                  <Database className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm">No database schemas found</p>
                  <p className="text-xs text-gray-400 mt-1">Create your first schema to get started</p>
                </div>
              ) : (
                <div className="py-2">
                  {schemas?.map((schema) => (
                    <button
                      key={schema?.id}
                      onClick={() => {
                        onSchemaChange(schema);
                        setIsOpen(false);
                      }}
                      className={`w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors ${
                        currentSchema?.id === schema?.id ? 'bg-blue-50 border-r-2 border-blue-600' : ''
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2">
                            <Database className="w-4 h-4 text-gray-400 flex-shrink-0" />
                            <span className="font-medium text-gray-900 truncate">
                              {schema?.name}
                            </span>
                            <span className={`inline-flex px-2 py-1 text-xs rounded-full ${
                              schema?.status === 'published' ?'bg-green-100 text-green-800' 
                                : schema?.status === 'draft' ?'bg-yellow-100 text-yellow-800' :'bg-gray-100 text-gray-800'
                            }`}>
                              {schema?.status}
                            </span>
                          </div>
                          {schema?.description && (
                            <p className="text-sm text-gray-500 truncate mt-1">
                              {schema?.description}
                            </p>
                          )}
                          <div className="flex items-center mt-2 space-x-4 text-xs text-gray-400">
                            <span>v{schema?.version}</span>
                            <span>
                              Updated {new Date(schema.updated_at)?.toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        <Settings className="w-4 h-4 text-gray-400" />
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default SchemaSelector;