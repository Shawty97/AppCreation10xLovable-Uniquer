import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';

const PasswordRecovery = ({ onBack }) => {
  const [step, setStep] = useState(1); // 1: Email, 2: Verification, 3: New Password, 4: Success
  const [formData, setFormData] = useState({
    email: '',
    verificationCode: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const handleInputChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors?.[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSendResetEmail = async (e) => {
    e?.preventDefault();
    
    if (!formData?.email) {
      setErrors({ email: 'Please enter your email address' });
      return;
    }

    if (!/\S+@\S+\.\S+/?.test(formData?.email)) {
      setErrors({ email: 'Please enter a valid email address' });
      return;
    }

    setLoading(true);
    setErrors({});

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      setStep(2);
    } catch (error) {
      setErrors({ email: 'Failed to send reset email. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyCode = async (e) => {
    e?.preventDefault();
    
    if (!formData?.verificationCode || formData?.verificationCode?.length !== 6) {
      setErrors({ verificationCode: 'Please enter the 6-digit verification code' });
      return;
    }

    setLoading(true);
    setErrors({});

    try {
      // Simulate API verification
      await new Promise(resolve => setTimeout(resolve, 1500));
      setStep(3);
    } catch (error) {
      setErrors({ verificationCode: 'Invalid verification code. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e) => {
    e?.preventDefault();
    
    const newErrors = {};
    
    if (!formData?.newPassword) {
      newErrors.newPassword = 'Please enter a new password';
    } else if (formData?.newPassword?.length < 6) {
      newErrors.newPassword = 'Password must be at least 6 characters';
    }

    if (!formData?.confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your new password';
    } else if (formData?.newPassword !== formData?.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    if (Object.keys(newErrors)?.length > 0) {
      setErrors(newErrors);
      return;
    }

    setLoading(true);
    setErrors({});

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      setStep(4);
    } catch (error) {
      setErrors({ newPassword: 'Failed to reset password. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const renderProgressIndicator = () => (
    <div className="flex items-center justify-center space-x-2 mb-8">
      {[1, 2, 3]?.map((stepNumber) => (
        <React.Fragment key={stepNumber}>
          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
              step >= stepNumber
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground'
            }`}
          >
            {step > stepNumber ? (
              <Icon name="Check" size={16} />
            ) : (
              stepNumber
            )}
          </div>
          {stepNumber < 3 && (
            <div
              className={`w-8 h-0.5 transition-colors ${
                step > stepNumber ? 'bg-primary' : 'bg-border'
              }`}
            />
          )}
        </React.Fragment>
      ))}
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Header */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-2xl mb-4 shadow-elevation-2"
          >
            <Icon name="Key" size={32} className="text-primary-foreground" />
          </motion.div>
          <h1 className="text-2xl font-semibold text-foreground mb-2">
            Reset Password
          </h1>
          <p className="text-muted-foreground">
            {step === 1 && "Enter your email to receive a reset link"}
            {step === 2 && "Check your email for the verification code"}
            {step === 3 && "Create a new secure password"}
            {step === 4 && "Your password has been successfully reset"}
          </p>
        </div>

        {/* Progress Indicator */}
        {step < 4 && renderProgressIndicator()}

        {/* Reset Card */}
        <div className="bg-card rounded-2xl shadow-elevation-3 border border-border p-6">
          {step === 1 && (
            <motion.form
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              onSubmit={handleSendResetEmail}
              className="space-y-6"
            >
              <Input
                type="email"
                label="Email Address"
                placeholder="Enter your registered email"
                value={formData?.email}
                onChange={(e) => handleInputChange('email', e?.target?.value)}
                error={errors?.email}
                required
              />

              <div className="flex space-x-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onBack}
                  fullWidth
                >
                  Back to Login
                </Button>
                <Button
                  type="submit"
                  loading={loading}
                  fullWidth
                >
                  Send Reset Email
                </Button>
              </div>
            </motion.form>
          )}

          {step === 2 && (
            <motion.form
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              onSubmit={handleVerifyCode}
              className="space-y-6"
            >
              <div className="text-center mb-4">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/20 rounded-xl mb-3">
                  <Icon name="Mail" size={24} className="text-primary" />
                </div>
                <p className="text-sm text-muted-foreground">
                  We've sent a verification code to<br />
                  <strong className="text-foreground">{formData?.email}</strong>
                </p>
              </div>

              <Input
                type="text"
                label="Verification Code"
                placeholder="Enter 6-digit code"
                value={formData?.verificationCode}
                onChange={(e) => {
                  const value = e?.target?.value?.replace(/\D/g, '');
                  if (value?.length <= 6) {
                    handleInputChange('verificationCode', value);
                  }
                }}
                className="text-center text-lg tracking-widest font-mono"
                maxLength="6"
                error={errors?.verificationCode}
              />

              <div className="text-center">
                <button
                  type="button"
                  className="text-sm text-primary hover:underline focus:outline-none"
                  onClick={() => console.log('Resend code')}
                >
                  Didn't receive the code? Resend
                </button>
              </div>

              <div className="flex space-x-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep(1)}
                  fullWidth
                >
                  Back
                </Button>
                <Button
                  type="submit"
                  loading={loading}
                  disabled={formData?.verificationCode?.length !== 6}
                  fullWidth
                >
                  Verify Code
                </Button>
              </div>
            </motion.form>
          )}

          {step === 3 && (
            <motion.form
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              onSubmit={handleResetPassword}
              className="space-y-6"
            >
              <Input
                type="password"
                label="New Password"
                placeholder="Create a strong password"
                value={formData?.newPassword}
                onChange={(e) => handleInputChange('newPassword', e?.target?.value)}
                error={errors?.newPassword}
                required
              />

              <Input
                type="password"
                label="Confirm New Password"
                placeholder="Confirm your new password"
                value={formData?.confirmPassword}
                onChange={(e) => handleInputChange('confirmPassword', e?.target?.value)}
                error={errors?.confirmPassword}
                required
              />

              <div className="flex space-x-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep(2)}
                  fullWidth
                >
                  Back
                </Button>
                <Button
                  type="submit"
                  loading={loading}
                  fullWidth
                >
                  Reset Password
                </Button>
              </div>
            </motion.form>
          )}

          {step === 4 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center space-y-6"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 bg-success/20 rounded-2xl">
                <Icon name="CheckCircle" size={32} className="text-success" />
              </div>

              <div>
                <h3 className="text-lg font-medium text-foreground mb-2">
                  Password Reset Successful!
                </h3>
                <p className="text-muted-foreground">
                  Your password has been successfully reset. You can now sign in with your new password.
                </p>
              </div>

              <Button
                onClick={onBack}
                fullWidth
                size="lg"
              >
                Back to Login
              </Button>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default PasswordRecovery;