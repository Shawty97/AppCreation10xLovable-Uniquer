import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const SocialAuthButtons = ({ loading }) => {
  const socialProviders = [
    { id: 'google', name: 'Google', icon: 'Chrome', color: 'hover:bg-red-50 hover:border-red-200' },
    { id: 'github', name: 'GitHub', icon: 'Github', color: 'hover:bg-gray-50 hover:border-gray-200' },
    { id: 'microsoft', name: 'Microsoft', icon: 'Box', color: 'hover:bg-blue-50 hover:border-blue-200' }
  ];

  const handleSocialAuth = async (provider) => {
    console.log(`Authenticating with ${provider}`);
    // Implement social authentication logic
  };

  return (
    <div className="space-y-3">
      {socialProviders?.map((provider) => (
        <Button
          key={provider?.id}
          variant="outline"
          fullWidth
          size="lg"
          disabled={loading}
          onClick={() => handleSocialAuth(provider?.id)}
          className={`justify-center transition-colors ${provider?.color}`}
        >
          <Icon 
            name={provider?.icon} 
            size={20} 
            className="mr-3" 
          />
          Continue with {provider?.name}
        </Button>
      ))}
    </div>
  );
};

export default SocialAuthButtons;