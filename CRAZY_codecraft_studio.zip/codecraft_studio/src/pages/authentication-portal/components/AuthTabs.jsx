import React, { useState } from 'react';
import { useAuth } from '../../../contexts/AuthContext';


export function AuthTabs() {
  const [activeTab, setActiveTab] = useState('signin')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  
  const { signIn, signUp } = useAuth()

  const handleSignIn = async (e) => {
    e?.preventDefault()
    if (!email || !password) {
      setError('Please fill in all fields')
      return
    }

    setLoading(true)
    setError('')

    const { error } = await signIn(email, password)
    
    if (error) {
      if (error?.message?.includes('Invalid login credentials')) {
        setError('Invalid email or password. Please check your credentials.')
      } else if (error?.message?.includes('Email not confirmed')) {
        setError('Please check your email and click the confirmation link.')
      } else {
        setError(error?.message || 'Sign in failed. Please try again.')
      }
    }
    
    setLoading(false)
  }

  const handleSignUp = async (e) => {
    e?.preventDefault()
    if (!email || !password || !fullName) {
      setError('Please fill in all fields')
      return
    }

    if (password?.length < 6) {
      setError('Password must be at least 6 characters')
      return
    }

    setLoading(true)
    setError('')
    setSuccess('')

    const { error } = await signUp(email, password, { full_name: fullName })
    
    if (error) {
      if (error?.message?.includes('already registered')) {
        setError('This email is already registered. Please sign in instead.')
      } else {
        setError(error?.message || 'Sign up failed. Please try again.')
      }
    } else {
      setSuccess('Account created! Please check your email for verification.')
      setEmail('')
      setPassword('')
      setFullName('')
    }
    
    setLoading(false)
  }

  const clearMessages = () => {
    setError('')
    setSuccess('')
  }

  return (
    <div className="w-full max-w-md mx-auto">
      {/* Tab Headers */}
      <div className="flex border-b border-gray-200 mb-6">
        <button
          onClick={() => {
            setActiveTab('signin')
            clearMessages()
          }}
          className={`flex-1 py-2 px-4 text-center font-medium ${
            activeTab === 'signin' ?'border-b-2 border-blue-600 text-blue-600' :'text-gray-500 hover:text-gray-700'
          }`}
        >
          Sign In
        </button>
        <button
          onClick={() => {
            setActiveTab('signup')
            clearMessages()
          }}
          className={`flex-1 py-2 px-4 text-center font-medium ${
            activeTab === 'signup' ?'border-b-2 border-blue-600 text-blue-600' :'text-gray-500 hover:text-gray-700'
          }`}
        >
          Sign Up
        </button>
      </div>
      {/* Sign In Form */}
      {activeTab === 'signin' && (
        <form onSubmit={handleSignIn} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e?.target?.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter your email"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e?.target?.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter your password"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {loading ? 'Signing In...' : 'Sign In'}
          </button>
        </form>
      )}
      {/* Sign Up Form */}
      {activeTab === 'signup' && (
        <form onSubmit={handleSignUp} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Full Name
            </label>
            <input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e?.target?.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter your full name"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e?.target?.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter your email"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e?.target?.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Create a password"
              required
            />
            <p className="text-xs text-gray-500 mt-1">Must be at least 6 characters</p>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {loading ? 'Creating Account...' : 'Create Account'}
          </button>
        </form>
      )}
      {/* Error Message */}
      {error && (
        <div className="mt-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-md text-sm">
          {error}
          <button 
            onClick={() => setError('')}
            className="float-right text-red-500 hover:text-red-700 font-bold"
          >
            ×
          </button>
        </div>
      )}
      {/* Success Message */}
      {success && (
        <div className="mt-4 p-3 bg-green-100 border border-green-400 text-green-700 rounded-md text-sm">
          {success}
          <button 
            onClick={() => setSuccess('')}
            className="float-right text-green-500 hover:text-green-700 font-bold"
          >
            ×
          </button>
        </div>
      )}
      {/* Demo Credentials Section */}
      <div className="mt-6 p-4 bg-gray-50 rounded-md">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Demo Credentials:</h3>
        <div className="text-sm text-gray-600 space-y-1">
          <div 
            onClick={() => {
              setEmail('admin@codecraft.com')
              setPassword('password123')
              setActiveTab('signin')
            }}
            className="cursor-pointer hover:text-blue-600 transition-colors"
          >
            <strong>Admin:</strong> admin@codecraft.com / password123
          </div>
          <div 
            onClick={() => {
              setEmail('premium@codecraft.com')
              setPassword('password123')
              setActiveTab('signin')
            }}
            className="cursor-pointer hover:text-blue-600 transition-colors"
          >
            <strong>Premium:</strong> premium@codecraft.com / password123
          </div>
          <div 
            onClick={() => {
              setEmail('user@codecraft.com')
              setPassword('password123')
              setActiveTab('signin')
            }}
            className="cursor-pointer hover:text-blue-600 transition-colors"
          >
            <strong>Free User:</strong> user@codecraft.com / password123
          </div>
        </div>
        <p className="text-xs text-gray-500 mt-2">Click any credential to auto-fill the form</p>
      </div>
    </div>
  );
}