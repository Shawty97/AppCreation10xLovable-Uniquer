import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import DevicePreview from './components/DevicePreview';
import TestingToolbar from './components/TestingToolbar';
import CollaborationPanel from './components/CollaborationPanel';
import PerformanceMonitor from './components/PerformanceMonitor';
import BrowserCompatibility from './components/BrowserCompatibility';
import UserTestingPanel from './components/UserTestingPanel';
import QRCodeGenerator from './components/QRCodeGenerator';

const LivePreviewHub = () => {
  const navigate = useNavigate();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [activeDevices, setActiveDevices] = useState(['desktop', 'tablet', 'mobile']);
  const [currentUrl, setCurrentUrl] = useState('');
  const [isLiveMode, setIsLiveMode] = useState(false);
  const [activePanel, setActivePanel] = useState('preview');
  const [collaborators, setCollaborators] = useState([]);
  const [annotations, setAnnotations] = useState([]);
  const [showQRCode, setShowQRCode] = useState(false);
  const [testingSessions, setTestingSessions] = useState([]);

  // Mobile responsive state
  const [mobileView, setMobileView] = useState('preview');

  const projects = [
    {
      id: 1,
      name: "E-commerce Dashboard",
      url: "https://demo-ecommerce.example.com",
      status: "live",
      lastUpdated: new Date(Date.now() - 3600000),
      framework: "React",
      branch: "main"
    },
    {
      id: 2,
      name: "Task Management App",
      url: "https://demo-tasks.example.com",
      status: "development",
      lastUpdated: new Date(Date.now() - 7200000),
      framework: "Vue",
      branch: "feature/ui-updates"
    },
    {
      id: 3,
      name: "Portfolio Website",
      url: "https://demo-portfolio.example.com",
      status: "staging",
      lastUpdated: new Date(Date.now() - 14400000),
      framework: "Next.js",
      branch: "staging"
    }
  ];

  const deviceOptions = [
    { value: 'desktop', label: 'Desktop', icon: 'Monitor', dimensions: '1920x1080' },
    { value: 'laptop', label: 'Laptop', icon: 'Laptop', dimensions: '1366x768' },
    { value: 'tablet', label: 'Tablet', icon: 'Tablet', dimensions: '768x1024' },
    { value: 'mobile', label: 'Mobile', icon: 'Smartphone', dimensions: '375x667' },
    { value: 'mobile-lg', label: 'Mobile Large', icon: 'Smartphone', dimensions: '414x896' }
  ];

  const panelOptions = [
    { value: 'preview', label: 'Preview', icon: 'Eye' },
    { value: 'collaboration', label: 'Collaborate', icon: 'Users' },
    { value: 'performance', label: 'Performance', icon: 'Gauge' },
    { value: 'compatibility', label: 'Browsers', icon: 'Globe' },
    { value: 'testing', label: 'User Testing', icon: 'TestTube' }
  ];

  useEffect(() => {
    if (projects?.length > 0 && !selectedProject) {
      setSelectedProject(projects?.[0]);
      setCurrentUrl(projects?.[0]?.url);
    }
  }, []);

  useEffect(() => {
    // Simulate real-time updates when live mode is active
    if (isLiveMode && selectedProject) {
      const interval = setInterval(() => {
        // Simulate updates
        console.log('Syncing preview updates...');
      }, 2000);

      return () => clearInterval(interval);
    }
  }, [isLiveMode, selectedProject]);

  const handleProjectSelect = (project) => {
    setSelectedProject(project);
    setCurrentUrl(project?.url);
  };

  const handleDeviceToggle = (deviceId) => {
    setActiveDevices(prev => 
      prev?.includes(deviceId) 
        ? prev?.filter(d => d !== deviceId)
        : [...prev, deviceId]
    );
  };

  const handleUrlChange = (url) => {
    setCurrentUrl(url);
  };

  const handleAddCollaborator = (collaborator) => {
    setCollaborators(prev => [...prev, { ...collaborator, id: Date.now() }]);
  };

  const handleAddAnnotation = (annotation) => {
    setAnnotations(prev => [...prev, { ...annotation, id: Date.now(), timestamp: new Date() }]);
  };

  const handleStartTesting = (testConfig) => {
    const newSession = {
      id: Date.now(),
      name: testConfig?.name,
      url: currentUrl,
      startTime: new Date(),
      status: 'active',
      participants: []
    };
    setTestingSessions(prev => [...prev, newSession]);
  };

  const renderMobileContent = () => {
    switch (mobileView) {
      case 'preview':
        return (
          <DevicePreview
            devices={[activeDevices?.[0] || 'mobile']}
            url={currentUrl}
            isLiveMode={isLiveMode}
            annotations={annotations}
            onAddAnnotation={handleAddAnnotation}
            isMobile={true}
          />
        );
      case 'tools':
        return <TestingToolbar selectedProject={selectedProject} onStartTesting={handleStartTesting} isMobile={true} />;
      case 'collaboration':
        return (
          <CollaborationPanel
            collaborators={collaborators}
            onAddCollaborator={handleAddCollaborator}
            isMobile={true}
          />
        );
      case 'performance':
        return <PerformanceMonitor project={selectedProject} isMobile={true} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar 
        isCollapsed={isSidebarCollapsed} 
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)} 
      />
      <main className={`pt-16 transition-all duration-300 ${
        isSidebarCollapsed ? 'lg:pl-16' : 'lg:pl-60'
      } pb-20 lg:pb-6`}>
        
        {/* Mobile Header */}
        <div className="lg:hidden p-4 border-b border-border bg-card">
          <div className="flex items-center justify-between mb-3">
            <h1 className="text-xl font-bold text-foreground">Live Preview Hub</h1>
            <div className="flex items-center space-x-2">
              <Button
                variant={isLiveMode ? "default" : "outline"}
                size="sm"
                iconName="Zap"
                iconSize={14}
                onClick={() => setIsLiveMode(!isLiveMode)}
                className={isLiveMode ? 'animate-pulse' : ''}
              >
                Live
              </Button>
              <Button
                variant="outline"
                size="sm"
                iconName="QrCode"
                iconSize={14}
                onClick={() => setShowQRCode(true)}
              />
            </div>
          </div>

          <div className="flex space-x-2 mb-3">
            {[
              { key: 'preview', label: 'Preview', icon: 'Eye' },
              { key: 'tools', label: 'Tools', icon: 'Wrench' },
              { key: 'collaboration', label: 'Team', icon: 'Users' },
              { key: 'performance', label: 'Perf', icon: 'Gauge' }
            ]?.map((tab) => (
              <Button
                key={tab?.key}
                variant={mobileView === tab?.key ? "default" : "outline"}
                size="sm"
                iconName={tab?.icon}
                iconSize={14}
                onClick={() => setMobileView(tab?.key)}
                className="flex-1"
              >
                {tab?.label}
              </Button>
            ))}
          </div>

          {selectedProject && (
            <div className="text-xs text-muted-foreground">
              {selectedProject?.name} • {selectedProject?.framework}
            </div>
          )}
        </div>

        {/* Desktop Layout */}
        <div className="hidden lg:block h-[calc(100vh-4rem)]">
          <div className="flex h-full">
            {/* Left Sidebar - Projects and Controls */}
            <div className="w-80 border-r border-border bg-card flex flex-col">
              {/* Header */}
              <div className="p-6 border-b border-border">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h1 className="text-2xl font-bold text-foreground">Live Preview Hub</h1>
                    <p className="text-sm text-muted-foreground">
                      Real-time testing across devices
                    </p>
                  </div>
                  <Button
                    variant={isLiveMode ? "default" : "outline"}
                    size="sm"
                    iconName="Zap"
                    iconSize={16}
                    onClick={() => setIsLiveMode(!isLiveMode)}
                    className={isLiveMode ? 'animate-pulse' : ''}
                  >
                    {isLiveMode ? 'Live' : 'Static'}
                  </Button>
                </div>

                {/* URL Input */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Preview URL</label>
                  <Input
                    type="url"
                    placeholder="Enter URL to preview..."
                    value={currentUrl}
                    onChange={(e) => handleUrlChange(e?.target?.value)}
                    className="w-full"
                  />
                </div>
              </div>

              {/* Project Selection */}
              <div className="p-6 border-b border-border">
                <h3 className="font-medium text-foreground mb-3">Quick Select Projects</h3>
                <div className="space-y-2">
                  {projects?.map((project) => (
                    <div
                      key={project?.id}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        selectedProject?.id === project?.id
                          ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                      }`}
                      onClick={() => handleProjectSelect(project)}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium text-foreground">
                          {project?.name}
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          project?.status === 'live' ?'bg-green-100 text-green-800'
                            : project?.status === 'staging' ?'bg-yellow-100 text-yellow-800' :'bg-blue-100 text-blue-800'
                        }`}>
                          {project?.status}
                        </span>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {project?.framework} • {project?.branch}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Device Selection */}
              <div className="p-6 border-b border-border">
                <h3 className="font-medium text-foreground mb-3">Active Devices</h3>
                <div className="grid grid-cols-1 gap-2">
                  {deviceOptions?.map((device) => (
                    <div
                      key={device?.value}
                      className={`flex items-center justify-between p-2 rounded border cursor-pointer transition-all ${
                        activeDevices?.includes(device?.value)
                          ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                      }`}
                      onClick={() => handleDeviceToggle(device?.value)}
                    >
                      <div className="flex items-center space-x-2">
                        <Icon name={device?.icon} size={16} className="text-foreground" />
                        <span className="text-sm text-foreground">{device?.label}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {device?.dimensions}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Actions */}
              <div className="p-6">
                <h3 className="font-medium text-foreground mb-3">Quick Actions</h3>
                <div className="space-y-2">
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="QrCode"
                    iconPosition="left"
                    iconSize={14}
                    onClick={() => setShowQRCode(true)}
                    className="w-full justify-start"
                  >
                    Generate QR Code
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Share"
                    iconPosition="left"
                    iconSize={14}
                    className="w-full justify-start"
                  >
                    Share Preview Link
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Camera"
                    iconPosition="left"
                    iconSize={14}
                    className="w-full justify-start"
                  >
                    Take Screenshots
                  </Button>
                </div>
              </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 flex">
              {/* Preview Area */}
              <div className="flex-1 bg-muted">
                <div className="p-4 border-b border-border bg-card">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        {activeDevices?.map((deviceId) => {
                          const device = deviceOptions?.find(d => d?.value === deviceId);
                          return device ? (
                            <div key={deviceId} className="flex items-center space-x-1">
                              <Icon name={device?.icon} size={16} className="text-primary" />
                              <span className="text-sm text-foreground">{device?.label}</span>
                            </div>
                          ) : null;
                        })}
                      </div>
                      {isLiveMode && (
                        <div className="flex items-center space-x-1 text-green-600">
                          <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse"></div>
                          <span className="text-xs">Live Updates</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {panelOptions?.map((panel) => (
                        <Button
                          key={panel?.value}
                          variant={activePanel === panel?.value ? "default" : "ghost"}
                          size="sm"
                          iconName={panel?.icon}
                          iconSize={16}
                          onClick={() => setActivePanel(panel?.value)}
                          className="h-8"
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div className="h-[calc(100%-60px)] overflow-auto p-4">
                  {activePanel === 'preview' && (
                    <DevicePreview
                      devices={activeDevices}
                      url={currentUrl}
                      isLiveMode={isLiveMode}
                      annotations={annotations}
                      onAddAnnotation={handleAddAnnotation}
                    />
                  )}
                  {activePanel === 'collaboration' && (
                    <CollaborationPanel
                      collaborators={collaborators}
                      onAddCollaborator={handleAddCollaborator}
                    />
                  )}
                  {activePanel === 'performance' && (
                    <PerformanceMonitor project={selectedProject} />
                  )}
                  {activePanel === 'compatibility' && (
                    <BrowserCompatibility url={currentUrl} />
                  )}
                  {activePanel === 'testing' && (
                    <UserTestingPanel
                      sessions={testingSessions}
                      onStartTesting={handleStartTesting}
                    />
                  )}
                </div>
              </div>

              {/* Right Panel - Tools */}
              <div className="w-80 border-l border-border bg-card">
                <TestingToolbar 
                  selectedProject={selectedProject}
                  onStartTesting={handleStartTesting}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Layout */}
        <div className="lg:hidden h-[calc(100vh-8rem)]">
          {renderMobileContent()}
        </div>
      </main>
      {/* QR Code Modal */}
      {showQRCode && (
        <QRCodeGenerator
          url={currentUrl}
          projectName={selectedProject?.name}
          onClose={() => setShowQRCode(false)}
        />
      )}
    </div>
  );
};

export default LivePreviewHub;