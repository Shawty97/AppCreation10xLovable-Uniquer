import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PerformanceMonitor = ({ project, isMobile }) => {
  const [performanceData, setPerformanceData] = useState({
    loadTime: 2.3,
    firstContentfulPaint: 1.2,
    largestContentfulPaint: 2.8,
    timeToInteractive: 3.1,
    cumulativeLayoutShift: 0.05,
    memoryUsage: 15.2,
    networkRequests: 12,
    bundleSize: 245.6
  });

  const [isMonitoring, setIsMonitoring] = useState(false);
  const [optimizationSuggestions] = useState([
    {
      id: 1,
      type: 'critical',
      title: 'Optimize Images',
      description: 'Large images are slowing down page load. Consider using WebP format and proper sizing.',
      impact: 'High',
      estimatedSaving: '1.2s'
    },
    {
      id: 2,
      type: 'warning',
      title: 'Reduce JavaScript Bundle',
      description: 'Bundle size is larger than recommended. Consider code splitting and tree shaking.',
      impact: 'Medium',
      estimatedSaving: '0.8s'
    },
    {
      id: 3,
      type: 'info',
      title: 'Enable Compression',
      description: 'Gzip compression is not enabled. This can reduce transfer sizes significantly.',
      impact: 'Medium',
      estimatedSaving: '0.5s'
    },
    {
      id: 4,
      type: 'info',
      title: 'Use CDN',
      description: 'Static assets are not served from CDN. Consider using a CDN for better performance.',
      impact: 'Low',
      estimatedSaving: '0.3s'
    }
  ]);

  useEffect(() => {
    if (isMonitoring) {
      const interval = setInterval(() => {
        setPerformanceData(prev => ({
          ...prev,
          loadTime: prev?.loadTime + (Math.random() - 0.5) * 0.2,
          memoryUsage: prev?.memoryUsage + (Math.random() - 0.5) * 2,
          networkRequests: prev?.networkRequests + Math.floor(Math.random() * 3)
        }));
      }, 2000);

      return () => clearInterval(interval);
    }
  }, [isMonitoring]);

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600 bg-green-50 border-green-200';
    if (score >= 70) return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    return 'text-red-600 bg-red-50 border-red-200';
  };

  const getSuggestionColor = (type) => {
    switch (type) {
      case 'critical':
        return 'border-l-red-500 bg-red-50';
      case 'warning':
        return 'border-l-yellow-500 bg-yellow-50';
      default:
        return 'border-l-blue-500 bg-blue-50';
    }
  };

  const calculateScore = (metric, value) => {
    const thresholds = {
      loadTime: { good: 2, poor: 4 },
      firstContentfulPaint: { good: 1.8, poor: 3 },
      largestContentfulPaint: { good: 2.5, poor: 4 },
      timeToInteractive: { good: 3.8, poor: 7 },
      cumulativeLayoutShift: { good: 0.1, poor: 0.25 },
    };

    const threshold = thresholds?.[metric];
    if (!threshold) return 85;

    if (value <= threshold?.good) return 95;
    if (value >= threshold?.poor) return 40;
    
    return Math.round(95 - ((value - threshold?.good) / (threshold?.poor - threshold?.good)) * 55);
  };

  if (isMobile) {
    return (
      <div className="h-full p-4 bg-card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">Performance</h2>
          <Button
            variant={isMonitoring ? "default" : "outline"}
            size="sm"
            iconName={isMonitoring ? "Square" : "Play"}
            iconSize={14}
            onClick={() => setIsMonitoring(!isMonitoring)}
          >
            {isMonitoring ? 'Stop' : 'Monitor'}
          </Button>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-secondary rounded-lg p-3 text-center">
              <div className="text-lg font-semibold text-foreground">
                {performanceData?.loadTime?.toFixed(1)}s
              </div>
              <div className="text-xs text-muted-foreground">Load Time</div>
            </div>
            <div className="bg-secondary rounded-lg p-3 text-center">
              <div className="text-lg font-semibold text-foreground">
                {performanceData?.memoryUsage?.toFixed(1)} MB
              </div>
              <div className="text-xs text-muted-foreground">Memory</div>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="font-medium text-foreground">Top Issues</h3>
            {optimizationSuggestions?.slice(0, 2)?.map((suggestion) => (
              <div key={suggestion?.id} className={`p-3 rounded border-l-4 ${getSuggestionColor(suggestion?.type)}`}>
                <div className="font-medium text-sm text-foreground">{suggestion?.title}</div>
                <div className="text-xs text-muted-foreground">Save {suggestion?.estimatedSaving}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg shadow-sm border border-border h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-xl font-semibold text-foreground">Performance Monitor</h2>
          <Button
            variant={isMonitoring ? "default" : "outline"}
            iconName={isMonitoring ? "Square" : "Play"}
            iconPosition="left"
            iconSize={16}
            onClick={() => setIsMonitoring(!isMonitoring)}
          >
            {isMonitoring ? 'Stop Monitoring' : 'Start Monitoring'}
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">
          Real-time performance metrics and optimization suggestions
        </p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Core Web Vitals */}
        <div>
          <h3 className="font-medium text-foreground mb-4">Core Web Vitals</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="bg-secondary rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Largest Contentful Paint</span>
                <div className={`px-2 py-1 rounded text-xs border ${getScoreColor(calculateScore('largestContentfulPaint', performanceData?.largestContentfulPaint))}`}>
                  {calculateScore('largestContentfulPaint', performanceData?.largestContentfulPaint)}
                </div>
              </div>
              <div className="text-2xl font-bold text-foreground mb-1">
                {performanceData?.largestContentfulPaint?.toFixed(1)}s
              </div>
              <div className="text-xs text-muted-foreground">
                Time until the largest content is visible
              </div>
            </div>

            <div className="bg-secondary rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">First Contentful Paint</span>
                <div className={`px-2 py-1 rounded text-xs border ${getScoreColor(calculateScore('firstContentfulPaint', performanceData?.firstContentfulPaint))}`}>
                  {calculateScore('firstContentfulPaint', performanceData?.firstContentfulPaint)}
                </div>
              </div>
              <div className="text-2xl font-bold text-foreground mb-1">
                {performanceData?.firstContentfulPaint?.toFixed(1)}s
              </div>
              <div className="text-xs text-muted-foreground">
                Time until first content appears
              </div>
            </div>

            <div className="bg-secondary rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Cumulative Layout Shift</span>
                <div className={`px-2 py-1 rounded text-xs border ${getScoreColor(calculateScore('cumulativeLayoutShift', performanceData?.cumulativeLayoutShift))}`}>
                  {calculateScore('cumulativeLayoutShift', performanceData?.cumulativeLayoutShift)}
                </div>
              </div>
              <div className="text-2xl font-bold text-foreground mb-1">
                {performanceData?.cumulativeLayoutShift?.toFixed(3)}
              </div>
              <div className="text-xs text-muted-foreground">
                Visual stability measurement
              </div>
            </div>
          </div>
        </div>

        {/* Additional Metrics */}
        <div>
          <h3 className="font-medium text-foreground mb-4">Additional Metrics</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-secondary rounded-lg">
              <Icon name="Clock" size={20} className="text-primary mx-auto mb-2" />
              <div className="text-lg font-semibold text-foreground">
                {performanceData?.loadTime?.toFixed(1)}s
              </div>
              <div className="text-xs text-muted-foreground">Total Load Time</div>
            </div>

            <div className="text-center p-4 bg-secondary rounded-lg">
              <Icon name="Cpu" size={20} className="text-primary mx-auto mb-2" />
              <div className="text-lg font-semibold text-foreground">
                {performanceData?.memoryUsage?.toFixed(1)} MB
              </div>
              <div className="text-xs text-muted-foreground">Memory Usage</div>
            </div>

            <div className="text-center p-4 bg-secondary rounded-lg">
              <Icon name="Network" size={20} className="text-primary mx-auto mb-2" />
              <div className="text-lg font-semibold text-foreground">
                {performanceData?.networkRequests}
              </div>
              <div className="text-xs text-muted-foreground">Network Requests</div>
            </div>

            <div className="text-center p-4 bg-secondary rounded-lg">
              <Icon name="Package" size={20} className="text-primary mx-auto mb-2" />
              <div className="text-lg font-semibold text-foreground">
                {performanceData?.bundleSize?.toFixed(1)} KB
              </div>
              <div className="text-xs text-muted-foreground">Bundle Size</div>
            </div>
          </div>
        </div>

        {/* Optimization Suggestions */}
        <div>
          <h3 className="font-medium text-foreground mb-4">Optimization Suggestions</h3>
          <div className="space-y-3">
            {optimizationSuggestions?.map((suggestion) => (
              <div key={suggestion?.id} className={`p-4 rounded-lg border-l-4 ${getSuggestionColor(suggestion?.type)}`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={suggestion?.type === 'critical' ? 'AlertCircle' : suggestion?.type === 'warning' ? 'AlertTriangle' : 'Info'} 
                      size={16} 
                      className={suggestion?.type === 'critical' ? 'text-red-600' : suggestion?.type === 'warning' ? 'text-yellow-600' : 'text-blue-600'}
                    />
                    <span className="font-medium text-foreground">{suggestion?.title}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-medium text-foreground">
                      Save {suggestion?.estimatedSaving}
                    </span>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      suggestion?.impact === 'High' ?'bg-red-100 text-red-800'
                        : suggestion?.impact === 'Medium' ?'bg-yellow-100 text-yellow-800' :'bg-blue-100 text-blue-800'
                    }`}>
                      {suggestion?.impact}
                    </span>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-3">
                  {suggestion?.description}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  iconName="ArrowRight"
                  iconPosition="right"
                  iconSize={14}
                >
                  Learn How to Fix
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Performance History */}
        <div>
          <h3 className="font-medium text-foreground mb-4">Performance Trend</h3>
          <div className="bg-secondary rounded-lg p-4 text-center">
            <Icon name="TrendingUp" size={32} className="text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              Performance chart will appear here when monitoring is active
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceMonitor;