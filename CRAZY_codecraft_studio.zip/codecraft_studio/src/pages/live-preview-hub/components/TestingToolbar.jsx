import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const TestingToolbar = ({ selectedProject, onStartTesting, isMobile }) => {
  const [testingMode, setTestingMode] = useState('manual');
  const [selectedTool, setSelectedTool] = useState('inspector');

  const testingModes = [
    { value: 'manual', label: 'Manual Testing', icon: 'Hand' },
    { value: 'automated', label: 'Automated Tests', icon: 'Bot' },
    { value: 'user', label: 'User Testing', icon: 'Users' }
  ];

  const testingTools = [
    { value: 'inspector', label: 'Element Inspector', icon: 'Search' },
    { value: 'responsive', label: 'Responsive Tester', icon: 'Smartphone' },
    { value: 'performance', label: 'Performance Audit', icon: 'Gauge' },
    { value: 'accessibility', label: 'Accessibility Check', icon: 'Eye' },
    { value: 'seo', label: 'SEO Analyzer', icon: 'TrendingUp' }
  ];

  const quickTests = [
    {
      id: 'responsive',
      name: 'Responsive Design',
      description: 'Test layout across different screen sizes',
      icon: 'Smartphone',
      estimatedTime: '2 min'
    },
    {
      id: 'performance',
      name: 'Performance Audit',
      description: 'Analyze loading times and optimization',
      icon: 'Zap',
      estimatedTime: '30 sec'
    },
    {
      id: 'accessibility',
      name: 'Accessibility Scan',
      description: 'Check for WCAG compliance issues',
      icon: 'Shield',
      estimatedTime: '1 min'
    },
    {
      id: 'forms',
      name: 'Form Validation',
      description: 'Test form inputs and validations',
      icon: 'FileText',
      estimatedTime: '3 min'
    },
    {
      id: 'navigation',
      name: 'Navigation Flow',
      description: 'Verify all links and navigation paths',
      icon: 'Navigation',
      estimatedTime: '5 min'
    },
    {
      id: 'cross-browser',
      name: 'Cross-Browser',
      description: 'Test compatibility across browsers',
      icon: 'Globe',
      estimatedTime: '10 min'
    }
  ];

  const handleStartQuickTest = (test) => {
    onStartTesting?.({
      name: test?.name,
      type: test?.id,
      mode: 'automated',
      estimatedTime: test?.estimatedTime
    });
  };

  if (isMobile) {
    return (
      <div className="h-full p-4 bg-card">
        <h2 className="text-lg font-semibold text-foreground mb-4">Testing Tools</h2>
        
        <div className="space-y-4">
          <Select
            options={testingModes}
            value={testingMode}
            onChange={setTestingMode}
            placeholder="Select testing mode..."
          />

          <div className="grid grid-cols-1 gap-2">
            {quickTests?.slice(0, 3)?.map((test) => (
              <Button
                key={test?.id}
                variant="outline"
                iconName={test?.icon}
                iconPosition="left"
                iconSize={16}
                onClick={() => handleStartQuickTest(test)}
                className="w-full justify-start"
              >
                <div className="text-left">
                  <div className="font-medium">{test?.name}</div>
                  <div className="text-xs text-muted-foreground">{test?.estimatedTime}</div>
                </div>
              </Button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <h2 className="text-lg font-semibold text-foreground mb-2">Testing Tools</h2>
        <p className="text-sm text-muted-foreground">
          Interactive tools for comprehensive application testing
        </p>
      </div>

      {/* Testing Mode Selection */}
      <div className="p-6 border-b border-border">
        <h3 className="font-medium text-foreground mb-3">Testing Mode</h3>
        <div className="grid grid-cols-1 gap-2">
          {testingModes?.map((mode) => (
            <Button
              key={mode?.value}
              variant={testingMode === mode?.value ? "default" : "outline"}
              iconName={mode?.icon}
              iconPosition="left"
              iconSize={16}
              onClick={() => setTestingMode(mode?.value)}
              className="w-full justify-start"
            >
              {mode?.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Quick Tests */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        <div>
          <h3 className="font-medium text-foreground mb-3">Quick Tests</h3>
          <div className="space-y-3">
            {quickTests?.map((test) => (
              <div
                key={test?.id}
                className="p-4 border border-border rounded-lg hover:border-primary/50 transition-colors cursor-pointer group"
                onClick={() => handleStartQuickTest(test)}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={test?.icon} 
                      size={16} 
                      className="text-primary group-hover:text-primary/80" 
                    />
                    <span className="font-medium text-foreground group-hover:text-primary">
                      {test?.name}
                    </span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {test?.estimatedTime}
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-3">
                  {test?.description}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  iconName="Play"
                  iconPosition="left"
                  iconSize={14}
                  className="w-full group-hover:bg-primary group-hover:text-primary-foreground"
                >
                  Run Test
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Advanced Tools */}
        <div>
          <h3 className="font-medium text-foreground mb-3">Advanced Tools</h3>
          <div className="space-y-2">
            {testingTools?.map((tool) => (
              <Button
                key={tool?.value}
                variant={selectedTool === tool?.value ? "default" : "outline"}
                iconName={tool?.icon}
                iconPosition="left"
                iconSize={16}
                onClick={() => setSelectedTool(tool?.value)}
                className="w-full justify-start"
              >
                {tool?.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Custom Test Configuration */}
        <div className="bg-muted rounded-lg p-4">
          <h4 className="font-medium text-foreground mb-3">Custom Test</h4>
          <div className="space-y-3">
            <Input
              placeholder="Test name..."
              className="w-full"
            />
            <textarea
              placeholder="Test description or steps..."
              className="w-full px-3 py-2 bg-background border border-border rounded-md resize-none text-sm"
              rows={3}
            />
            <Button
              variant="default"
              iconName="Plus"
              iconPosition="left"
              iconSize={14}
              className="w-full"
            >
              Create Test
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestingToolbar;