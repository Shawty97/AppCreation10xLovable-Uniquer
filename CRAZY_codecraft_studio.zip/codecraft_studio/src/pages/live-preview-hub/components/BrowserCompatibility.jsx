import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const BrowserCompatibility = ({ url }) => {
  const [isRunningTest, setIsRunningTest] = useState(false);
  const [selectedBrowser, setSelectedBrowser] = useState('chrome');

  const browsers = [
    { id: 'chrome', name: 'Google Chrome', icon: 'Chrome', version: '118.0', score: 98, status: 'excellent' },
    { id: 'firefox', name: 'Mozilla Firefox', icon: 'Firefox', version: '119.0', score: 96, status: 'excellent' },
    { id: 'safari', name: 'Safari', icon: 'Globe', version: '17.0', score: 94, status: 'good' },
    { id: 'edge', name: 'Microsoft Edge', icon: 'Edge', version: '118.0', score: 97, status: 'excellent' },
    { id: 'opera', name: 'Opera', icon: 'Music', version: '104.0', score: 95, status: 'good' }
  ];

  const compatibilityIssues = [
    {
      id: 1,
      browser: 'safari',
      severity: 'medium',
      feature: 'CSS Grid Auto-fit',
      description: 'Safari 16.0 and earlier may not fully support grid auto-fit functionality',
      workaround: 'Use explicit grid definitions or add webkit prefixes',
      affectedElements: ['product-grid', 'image-gallery']
    },
    {
      id: 2,
      browser: 'firefox',
      severity: 'low',
      feature: 'Scroll Behavior Smooth',
      description: 'Smooth scrolling animation may not work as expected',
      workaround: 'Implement JavaScript-based smooth scrolling fallback',
      affectedElements: ['navigation-links']
    },
    {
      id: 3,
      browser: 'edge',
      severity: 'low',
      feature: 'Container Queries',
      description: 'Container queries not supported in older Edge versions',
      workaround: 'Use media queries as fallback',
      affectedElements: ['responsive-cards']
    }
  ];

  const handleRunTest = async () => {
    setIsRunningTest(true);
    
    // Simulate browser testing
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setIsRunningTest(false);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'excellent':
        return 'text-green-600 bg-green-50 border-green-200';
      case 'good':
        return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'warning':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'poor':
        return 'text-red-600 bg-red-50 border-red-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high':
        return 'text-red-600 bg-red-50 border-red-200';
      case 'medium':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low':
        return 'text-blue-600 bg-blue-50 border-blue-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="bg-card rounded-lg shadow-sm border border-border h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-xl font-semibold text-foreground">Browser Compatibility</h2>
          <Button
            variant="default"
            iconName={isRunningTest ? "Loader2" : "Play"}
            iconPosition="left"
            iconSize={16}
            onClick={handleRunTest}
            disabled={isRunningTest}
            className={isRunningTest ? 'animate-spin' : ''}
          >
            {isRunningTest ? 'Running Test...' : 'Run Compatibility Test'}
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">
          Test your application across different browsers and identify compatibility issues
        </p>
      </div>
      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Browser Overview */}
        <div>
          <h3 className="font-medium text-foreground mb-4">Browser Support Overview</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {browsers?.map((browser) => (
              <div
                key={browser?.id}
                className={`p-4 border rounded-lg cursor-pointer transition-all ${
                  selectedBrowser === browser?.id
                    ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                }`}
                onClick={() => setSelectedBrowser(browser?.id)}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <Icon name={browser?.icon} size={20} className="text-foreground" />
                    <span className="font-medium text-foreground">{browser?.name}</span>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs border font-medium ${getStatusColor(browser?.status)}`}>
                    {browser?.score}%
                  </div>
                </div>
                
                <div className="text-sm text-muted-foreground mb-2">
                  Version {browser?.version}
                </div>
                
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all ${
                      browser?.score >= 95 ? 'bg-green-500' : browser?.score >= 90 ? 'bg-blue-500' : 'bg-yellow-500'
                    }`}
                    style={{ width: `${browser?.score}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Compatibility Issues */}
        <div>
          <h3 className="font-medium text-foreground mb-4">Compatibility Issues</h3>
          {compatibilityIssues?.length > 0 ? (
            <div className="space-y-4">
              {compatibilityIssues?.map((issue) => {
                const browser = browsers?.find(b => b?.id === issue?.browser);
                return (
                  <div key={issue?.id} className="border border-border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <Icon name={browser?.icon} size={16} className="text-foreground" />
                        <span className="font-medium text-foreground">{browser?.name}</span>
                        <div className={`px-2 py-1 rounded text-xs border font-medium ${getSeverityColor(issue?.severity)}`}>
                          {issue?.severity}
                        </div>
                      </div>
                    </div>

                    <div className="mb-3">
                      <h4 className="font-medium text-foreground mb-1">{issue?.feature}</h4>
                      <p className="text-sm text-muted-foreground">{issue?.description}</p>
                    </div>

                    <div className="mb-3">
                      <h5 className="text-sm font-medium text-foreground mb-1">Recommended Workaround:</h5>
                      <p className="text-sm text-muted-foreground">{issue?.workaround}</p>
                    </div>

                    <div className="mb-3">
                      <h5 className="text-sm font-medium text-foreground mb-2">Affected Elements:</h5>
                      <div className="flex flex-wrap gap-1">
                        {issue?.affectedElements?.map((element, index) => (
                          <span
                            key={index}
                            className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded"
                          >
                            .{element}
                          </span>
                        ))}
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      iconName="ArrowRight"
                      iconPosition="right"
                      iconSize={14}
                    >
                      View Solution
                    </Button>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8">
              <Icon name="CheckCircle" size={48} className="text-green-500 mx-auto mb-3" />
              <h4 className="text-lg font-medium text-foreground mb-2">
                No Compatibility Issues Found
              </h4>
              <p className="text-muted-foreground">
                Your application works great across all tested browsers!
              </p>
            </div>
          )}
        </div>

        {/* Browser Screenshots */}
        <div>
          <h3 className="font-medium text-foreground mb-4">Browser Screenshots</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {browsers?.slice(0, 4)?.map((browser) => (
              <div key={browser?.id} className="border border-border rounded-lg overflow-hidden">
                <div className="p-3 bg-muted border-b border-border">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Icon name={browser?.icon} size={16} className="text-foreground" />
                      <span className="text-sm font-medium text-foreground">
                        {browser?.name}
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      iconName="Download"
                      iconSize={14}
                      className="h-6 w-6"
                    />
                  </div>
                </div>
                
                <div className="aspect-video bg-gray-100 flex items-center justify-center">
                  <div className="text-center">
                    <Icon name="Camera" size={32} className="text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">Screenshot Preview</p>
                    <p className="text-xs text-gray-500">{browser?.name}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Feature Support Matrix */}
        <div>
          <h3 className="font-medium text-foreground mb-4">Feature Support Matrix</h3>
          <div className="overflow-x-auto">
            <table className="w-full border border-border rounded-lg">
              <thead>
                <tr className="bg-muted">
                  <th className="text-left p-3 font-medium text-foreground border-b border-border">
                    Feature
                  </th>
                  {browsers?.slice(0, 4)?.map((browser) => (
                    <th key={browser?.id} className="text-center p-3 font-medium text-foreground border-b border-border">
                      <div className="flex flex-col items-center">
                        <Icon name={browser?.icon} size={16} className="mb-1" />
                        <span className="text-xs">{browser?.name?.split(' ')?.[0]}</span>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[
                  { feature: 'CSS Grid', support: [true, true, true, true] },
                  { feature: 'Flexbox', support: [true, true, true, true] },
                  { feature: 'CSS Variables', support: [true, true, true, true] },
                  { feature: 'Container Queries', support: [true, true, false, true] },
                  { feature: 'Scroll Behavior', support: [true, false, true, true] }
                ]?.map((row, index) => (
                  <tr key={index}>
                    <td className="p-3 font-medium text-foreground border-b border-border">
                      {row?.feature}
                    </td>
                    {row?.support?.map((supported, browserIndex) => (
                      <td key={browserIndex} className="text-center p-3 border-b border-border">
                        <Icon
                          name={supported ? "CheckCircle" : "XCircle"}
                          size={16}
                          className={supported ? "text-green-500" : "text-red-500"}
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BrowserCompatibility;