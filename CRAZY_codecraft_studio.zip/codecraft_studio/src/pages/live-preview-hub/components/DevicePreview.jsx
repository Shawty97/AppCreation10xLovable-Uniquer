import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const DevicePreview = ({ devices, url, isLiveMode, annotations, onAddAnnotation, isMobile }) => {
  const [selectedDevice, setSelectedDevice] = useState(devices?.[0] || 'desktop');
  const [isAddingAnnotation, setIsAddingAnnotation] = useState(false);
  const [showAnnotations, setShowAnnotations] = useState(true);
  const previewRef = useRef(null);

  const deviceConfigs = {
    desktop: { width: '100%', height: '100%', frame: false, label: 'Desktop (1920x1080)' },
    laptop: { width: '1366px', height: '768px', frame: false, label: 'Laptop (1366x768)' },
    tablet: { width: '768px', height: '1024px', frame: true, label: 'Tablet (768x1024)' },
    mobile: { width: '375px', height: '667px', frame: true, label: 'iPhone SE (375x667)' },
    'mobile-lg': { width: '414px', height: '896px', frame: true, label: 'iPhone 11 (414x896)' }
  };

  const getDeviceFrame = (deviceId) => {
    const config = deviceConfigs?.[deviceId];
    if (!config?.frame) return '';
    
    return `
      border-[8px] border-gray-800 rounded-[20px] shadow-2xl
      ${deviceId?.includes('mobile') ? 'bg-gray-800' : 'bg-gray-700'}
    `;
  };

  const handleAnnotationClick = (e) => {
    if (!isAddingAnnotation) return;
    
    const rect = e?.currentTarget?.getBoundingClientRect();
    const x = ((e?.clientX - rect?.left) / rect?.width) * 100;
    const y = ((e?.clientY - rect?.top) / rect?.height) * 100;

    const annotation = {
      x: Math.round(x),
      y: Math.round(y),
      device: selectedDevice,
      text: prompt('Enter annotation text:') || 'New annotation',
      author: 'You'
    };

    if (annotation?.text) {
      onAddAnnotation?.(annotation);
    }
    
    setIsAddingAnnotation(false);
  };

  const filteredAnnotations = annotations?.filter(a => a?.device === selectedDevice) || [];

  if (isMobile) {
    return (
      <div className="h-full flex flex-col">
        {/* Mobile Controls */}
        <div className="p-4 border-b border-border bg-card">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Icon name="Smartphone" size={16} className="text-primary" />
              <span className="text-sm font-medium text-foreground">
                {deviceConfigs?.[selectedDevice]?.label}
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <Button
                variant={showAnnotations ? "default" : "outline"}
                size="sm"
                iconName="MessageSquare"
                iconSize={14}
                onClick={() => setShowAnnotations(!showAnnotations)}
              />
              <Button
                variant={isAddingAnnotation ? "default" : "outline"}
                size="sm"
                iconName="Plus"
                iconSize={14}
                onClick={() => setIsAddingAnnotation(!isAddingAnnotation)}
              />
            </div>
          </div>
        </div>
        {/* Mobile Preview */}
        <div className="flex-1 bg-gray-100 flex items-center justify-center p-4">
          <div 
            className={`relative ${getDeviceFrame(selectedDevice)} overflow-hidden`}
            style={{ 
              width: '100%',
              maxWidth: deviceConfigs?.[selectedDevice]?.width,
              aspectRatio: selectedDevice === 'tablet' ? '3/4' : '9/16'
            }}
            onClick={handleAnnotationClick}
          >
            <iframe
              src={url || 'about:blank'}
              className="w-full h-full border-0"
              title="Mobile Preview"
              sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
            />

            {/* Annotations */}
            {showAnnotations && filteredAnnotations?.map((annotation) => (
              <div
                key={annotation?.id}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 z-10"
                style={{
                  left: `${annotation?.x}%`,
                  top: `${annotation?.y}%`
                }}
              >
                <div className="bg-red-500 w-3 h-3 rounded-full border-2 border-white shadow-lg cursor-pointer group relative">
                  <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-black text-white text-xs p-2 rounded whitespace-nowrap z-20">
                    {annotation?.text}
                    <div className="text-xs opacity-75">by {annotation?.author}</div>
                  </div>
                </div>
              </div>
            ))}

            {/* Loading Overlay */}
            {!url && (
              <div className="absolute inset-0 bg-gray-50 flex items-center justify-center">
                <div className="text-center">
                  <Icon name="Globe" size={32} className="text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Enter URL to preview</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Desktop Controls */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            {devices?.map((deviceId) => {
              const config = deviceConfigs?.[deviceId];
              return (
                <Button
                  key={deviceId}
                  variant={selectedDevice === deviceId ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedDevice(deviceId)}
                  className="text-xs"
                >
                  {config?.label?.split(' ')?.[0]}
                </Button>
              );
            })}
          </div>
          {isLiveMode && (
            <div className="flex items-center space-x-1 text-green-600">
              <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse"></div>
              <span className="text-xs">Syncing</span>
            </div>
          )}
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant={showAnnotations ? "default" : "outline"}
            size="sm"
            iconName="MessageSquare"
            iconPosition="left"
            iconSize={14}
            onClick={() => setShowAnnotations(!showAnnotations)}
          >
            Annotations ({filteredAnnotations?.length})
          </Button>
          <Button
            variant={isAddingAnnotation ? "default" : "outline"}
            size="sm"
            iconName="Plus"
            iconPosition="left"
            iconSize={14}
            onClick={() => setIsAddingAnnotation(!isAddingAnnotation)}
          >
            Add Note
          </Button>
        </div>
      </div>
      {/* Desktop Preview Grid */}
      <div className="flex-1 overflow-auto">
        {devices?.length === 1 ? (
          /* Single Device View */
          (<div className="h-full flex items-center justify-center bg-gray-50 p-4">
            <div 
              className={`relative ${getDeviceFrame(selectedDevice)} overflow-hidden`}
              style={{
                width: deviceConfigs?.[selectedDevice]?.width,
                height: deviceConfigs?.[selectedDevice]?.height,
                maxWidth: '100%',
                maxHeight: '100%'
              }}
              onClick={handleAnnotationClick}
            >
              <iframe
                src={url || 'about:blank'}
                className="w-full h-full border-0"
                title={`Preview - ${deviceConfigs?.[selectedDevice]?.label}`}
                sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
              />

              {/* Annotations */}
              {showAnnotations && filteredAnnotations?.map((annotation) => (
                <div
                  key={annotation?.id}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 z-10"
                  style={{
                    left: `${annotation?.x}%`,
                    top: `${annotation?.y}%`
                  }}
                >
                  <div className="bg-red-500 w-4 h-4 rounded-full border-2 border-white shadow-lg cursor-pointer group relative">
                    <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-black text-white text-xs p-2 rounded whitespace-nowrap z-20 min-w-max">
                      {annotation?.text}
                      <div className="text-xs opacity-75">by {annotation?.author}</div>
                    </div>
                  </div>
                </div>
              ))}

              {/* Loading State */}
              {!url && (
                <div className="absolute inset-0 bg-gray-50 flex items-center justify-center">
                  <div className="text-center">
                    <Icon name="Globe" size={48} className="text-gray-400 mx-auto mb-3" />
                    <p className="text-gray-600 mb-2">Enter URL to preview</p>
                    <p className="text-sm text-gray-500">
                      {deviceConfigs?.[selectedDevice]?.label}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>)
        ) : (
          /* Multi-Device Grid View */
          (<div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 p-4">
            {devices?.map((deviceId) => {
              const config = deviceConfigs?.[deviceId];
              const deviceAnnotations = annotations?.filter(a => a?.device === deviceId) || [];
              
              return (
                <div key={deviceId} className="bg-white rounded-lg shadow-sm border border-border overflow-hidden">
                  <div className="p-3 border-b border-border bg-muted">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Icon 
                          name={deviceId?.includes('mobile') ? 'Smartphone' : deviceId === 'tablet' ? 'Tablet' : 'Monitor'} 
                          size={16} 
                          className="text-foreground" 
                        />
                        <span className="text-sm font-medium text-foreground">
                          {config?.label}
                        </span>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {deviceAnnotations?.length} notes
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-gray-50 flex items-center justify-center" style={{ minHeight: '300px' }}>
                    <div 
                      className={`relative ${getDeviceFrame(deviceId)} overflow-hidden`}
                      style={{
                        width: deviceId?.includes('mobile') ? '150px' : deviceId === 'tablet' ? '200px' : '300px',
                        aspectRatio: deviceId === 'tablet' ? '3/4' : deviceId?.includes('mobile') ? '9/16' : '16/9'
                      }}
                      onClick={handleAnnotationClick}
                    >
                      <iframe
                        src={url || 'about:blank'}
                        className="w-full h-full border-0 scale-50 origin-top-left"
                        style={{ 
                          width: '200%', 
                          height: '200%',
                          transform: 'scale(0.5)',
                          transformOrigin: '0 0'
                        }}
                        title={`Preview - ${config?.label}`}
                        sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
                      />

                      {/* Device Annotations */}
                      {showAnnotations && deviceAnnotations?.map((annotation) => (
                        <div
                          key={annotation?.id}
                          className="absolute transform -translate-x-1/2 -translate-y-1/2 z-10"
                          style={{
                            left: `${annotation?.x * 0.5}%`,
                            top: `${annotation?.y * 0.5}%`
                          }}
                        >
                          <div className="bg-red-500 w-2 h-2 rounded-full border border-white shadow-md"></div>
                        </div>
                      ))}

                      {!url && (
                        <div className="absolute inset-0 bg-gray-100 flex items-center justify-center">
                          <Icon name="Globe" size={24} className="text-gray-400" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>)
        )}
      </div>
      {/* Instructions */}
      {isAddingAnnotation && (
        <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center space-x-2">
            <Icon name="Info" size={16} className="text-blue-600" />
            <span className="text-sm text-blue-800">
              Click anywhere on the preview to add an annotation
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default DevicePreview;