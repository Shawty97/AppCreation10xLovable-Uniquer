import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QRCodeGenerator = ({ url, projectName, onClose }) => {
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (url) {
      // Generate QR code URL using a QR code API service
      const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(url)}`;
      setQrCodeUrl(qrApiUrl);
    }
  }, [url]);

  const handleCopyUrl = () => {
    navigator?.clipboard?.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadQR = () => {
    const link = document.createElement('a');
    link.href = qrCodeUrl;
    link.download = `${projectName || 'preview'}-qr-code.png`;
    link?.click();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-border rounded-lg shadow-elevation-2 w-full max-w-md">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-foreground">QR Code</h2>
              <p className="text-sm text-muted-foreground">
                Scan to open on mobile device
              </p>
            </div>
            <Button
              variant="ghost"
              iconName="X"
              iconSize={20}
              onClick={onClose}
              className="h-10 w-10"
            />
          </div>
        </div>

        {/* Content */}
        <div className="p-6 text-center">
          {/* QR Code */}
          <div className="mb-6 flex justify-center">
            <div className="bg-white p-4 rounded-lg border-2 border-dashed border-border">
              {qrCodeUrl ? (
                <img
                  src={qrCodeUrl}
                  alt="QR Code"
                  className="w-48 h-48 object-contain"
                />
              ) : (
                <div className="w-48 h-48 bg-muted rounded flex items-center justify-center">
                  <Icon name="Loader2" size={32} className="text-muted-foreground animate-spin" />
                </div>
              )}
            </div>
          </div>

          {/* Project Info */}
          {projectName && (
            <div className="mb-4">
              <h3 className="font-medium text-foreground">{projectName}</h3>
              <p className="text-sm text-muted-foreground break-all">{url}</p>
            </div>
          )}

          {/* Instructions */}
          <div className="mb-6 p-4 bg-muted rounded-lg">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <Icon name="Smartphone" size={20} className="text-primary" />
              <span className="font-medium text-foreground">How to use:</span>
            </div>
            <ol className="text-sm text-muted-foreground space-y-1">
              <li>1. Open camera app on your mobile device</li>
              <li>2. Point camera at QR code</li>
              <li>3. Tap the notification to open the preview</li>
            </ol>
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <Button
              variant="default"
              iconName="Download"
              iconPosition="left"
              iconSize={16}
              onClick={handleDownloadQR}
              className="w-full"
              disabled={!qrCodeUrl}
            >
              Download QR Code
            </Button>
            
            <Button
              variant="outline"
              iconName={copied ? "Check" : "Copy"}
              iconPosition="left"
              iconSize={16}
              onClick={handleCopyUrl}
              className="w-full"
            >
              {copied ? 'Copied!' : 'Copy URL'}
            </Button>
          </div>

          {/* Additional Info */}
          <div className="mt-6 pt-4 border-t border-border">
            <p className="text-xs text-muted-foreground">
              QR code will automatically update when the preview URL changes
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QRCodeGenerator;