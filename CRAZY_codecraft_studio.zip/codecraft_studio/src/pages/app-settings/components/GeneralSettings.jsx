import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const GeneralSettings = () => {
  const [appData, setAppData] = useState({
    name: "E-Commerce Dashboard",
    description: "A comprehensive dashboard for managing online store operations, inventory, and customer analytics.",
    favicon: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=64&h=64&fit=crop&crop=center",
    category: "business",
    version: "1.2.3",
    status: "published"
  });

  const [seoData, setSeoData] = useState({
    title: "E-Commerce Dashboard - Manage Your Store",
    metaDescription: "Powerful e-commerce management dashboard with real-time analytics, inventory tracking, and customer insights.",
    keywords: "ecommerce, dashboard, analytics, inventory, management",
    ogImage: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&h=630&fit=crop&crop=center"
  });

  const [brandingData, setBrandingData] = useState({
    primaryColor: "#2563EB",
    secondaryColor: "#64748B",
    logoUrl: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=200&h=80&fit=crop&crop=center",
    fontFamily: "Inter"
  });

  const categoryOptions = [
    { value: 'business', label: 'Business & Finance' },
    { value: 'ecommerce', label: 'E-Commerce' },
    { value: 'education', label: 'Education' },
    { value: 'healthcare', label: 'Healthcare' },
    { value: 'portfolio', label: 'Portfolio' },
    { value: 'blog', label: 'Blog & Content' },
    { value: 'nonprofit', label: 'Non-Profit' },
    { value: 'other', label: 'Other' }
  ];

  const statusOptions = [
    { value: 'draft', label: 'Draft' },
    { value: 'published', label: 'Published' },
    { value: 'maintenance', label: 'Maintenance Mode' },
    { value: 'archived', label: 'Archived' }
  ];

  const fontOptions = [
    { value: 'Inter', label: 'Inter' },
    { value: 'Roboto', label: 'Roboto' },
    { value: 'Open Sans', label: 'Open Sans' },
    { value: 'Lato', label: 'Lato' },
    { value: 'Montserrat', label: 'Montserrat' }
  ];

  const handleAppDataChange = (field, value) => {
    setAppData(prev => ({ ...prev, [field]: value }));
  };

  const handleSeoDataChange = (field, value) => {
    setSeoData(prev => ({ ...prev, [field]: value }));
  };

  const handleBrandingDataChange = (field, value) => {
    setBrandingData(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveSettings = () => {
    console.log('Saving general settings:', { appData, seoData, brandingData });
  };

  return (
    <div className="space-y-8">
      {/* App Information Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Icon name="Info" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">App Information</h3>
            <p className="text-sm text-muted-foreground">Basic details about your application</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <Input
              label="App Name"
              type="text"
              placeholder="Enter app name"
              value={appData?.name}
              onChange={(e) => handleAppDataChange('name', e?.target?.value)}
              required
            />

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Description</label>
              <textarea
                className="w-full px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none"
                rows={4}
                placeholder="Describe your application..."
                value={appData?.description}
                onChange={(e) => handleAppDataChange('description', e?.target?.value)}
              />
            </div>

            <Select
              label="Category"
              options={categoryOptions}
              value={appData?.category}
              onChange={(value) => handleAppDataChange('category', value)}
            />

            <Select
              label="Status"
              options={statusOptions}
              value={appData?.status}
              onChange={(value) => handleAppDataChange('status', value)}
            />
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Favicon</label>
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 border border-border rounded-lg overflow-hidden bg-muted flex items-center justify-center">
                  <Image
                    src={appData?.favicon}
                    alt="App favicon"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <Input
                    type="url"
                    placeholder="https://example.com/favicon.ico"
                    value={appData?.favicon}
                    onChange={(e) => handleAppDataChange('favicon', e?.target?.value)}
                  />
                  <p className="text-xs text-muted-foreground mt-1">Recommended: 64x64px ICO or PNG</p>
                </div>
              </div>
            </div>

            <Input
              label="Version"
              type="text"
              placeholder="1.0.0"
              value={appData?.version}
              onChange={(e) => handleAppDataChange('version', e?.target?.value)}
              description="Semantic versioning (major.minor.patch)"
            />

            <div className="bg-muted rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="Calendar" size={16} color="var(--color-muted-foreground)" />
                <span className="text-sm font-medium text-foreground">Last Updated</span>
              </div>
              <p className="text-sm text-muted-foreground">October 1, 2025 at 2:09 PM</p>
            </div>
          </div>
        </div>
      </div>
      {/* SEO Settings Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-success rounded-lg flex items-center justify-center">
            <Icon name="Search" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">SEO Configuration</h3>
            <p className="text-sm text-muted-foreground">Optimize your app for search engines</p>
          </div>
        </div>

        <div className="space-y-4">
          <Input
            label="Page Title"
            type="text"
            placeholder="Enter SEO title"
            value={seoData?.title}
            onChange={(e) => handleSeoDataChange('title', e?.target?.value)}
            description="Recommended: 50-60 characters"
          />

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Meta Description</label>
            <textarea
              className="w-full px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none"
              rows={3}
              placeholder="Brief description for search results..."
              value={seoData?.metaDescription}
              onChange={(e) => handleSeoDataChange('metaDescription', e?.target?.value)}
            />
            <p className="text-xs text-muted-foreground mt-1">Recommended: 150-160 characters</p>
          </div>

          <Input
            label="Keywords"
            type="text"
            placeholder="keyword1, keyword2, keyword3"
            value={seoData?.keywords}
            onChange={(e) => handleSeoDataChange('keywords', e?.target?.value)}
            description="Comma-separated list of relevant keywords"
          />

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Open Graph Image</label>
            <div className="flex items-center space-x-4">
              <div className="w-24 h-12 border border-border rounded-lg overflow-hidden bg-muted flex items-center justify-center">
                <Image
                  src={seoData?.ogImage}
                  alt="Open Graph preview"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1">
                <Input
                  type="url"
                  placeholder="https://example.com/og-image.jpg"
                  value={seoData?.ogImage}
                  onChange={(e) => handleSeoDataChange('ogImage', e?.target?.value)}
                />
                <p className="text-xs text-muted-foreground mt-1">Recommended: 1200x630px</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Branding Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
            <Icon name="Palette" size={20} color="white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Branding & Theme</h3>
            <p className="text-sm text-muted-foreground">Customize your app's visual identity</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Logo</label>
              <div className="flex items-center space-x-4">
                <div className="w-20 h-12 border border-border rounded-lg overflow-hidden bg-muted flex items-center justify-center">
                  <Image
                    src={brandingData?.logoUrl}
                    alt="App logo"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="flex-1">
                  <Input
                    type="url"
                    placeholder="https://example.com/logo.png"
                    value={brandingData?.logoUrl}
                    onChange={(e) => handleBrandingDataChange('logoUrl', e?.target?.value)}
                  />
                  <p className="text-xs text-muted-foreground mt-1">Recommended: PNG with transparent background</p>
                </div>
              </div>
            </div>

            <Select
              label="Font Family"
              options={fontOptions}
              value={brandingData?.fontFamily}
              onChange={(value) => handleBrandingDataChange('fontFamily', value)}
            />
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Primary Color</label>
              <div className="flex items-center space-x-3">
                <div
                  className="w-12 h-10 rounded-md border border-border cursor-pointer"
                  style={{ backgroundColor: brandingData?.primaryColor }}
                />
                <Input
                  type="text"
                  placeholder="#2563EB"
                  value={brandingData?.primaryColor}
                  onChange={(e) => handleBrandingDataChange('primaryColor', e?.target?.value)}
                  className="flex-1"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Secondary Color</label>
              <div className="flex items-center space-x-3">
                <div
                  className="w-12 h-10 rounded-md border border-border cursor-pointer"
                  style={{ backgroundColor: brandingData?.secondaryColor }}
                />
                <Input
                  type="text"
                  placeholder="#64748B"
                  value={brandingData?.secondaryColor}
                  onChange={(e) => handleBrandingDataChange('secondaryColor', e?.target?.value)}
                  className="flex-1"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Live Preview */}
        <div className="mt-6 p-4 bg-muted rounded-lg">
          <h4 className="text-sm font-medium text-foreground mb-3">Live Preview</h4>
          <div className="bg-card border border-border rounded-lg p-4" style={{ fontFamily: brandingData?.fontFamily }}>
            <div className="flex items-center space-x-3 mb-3">
              <Image
                src={brandingData?.logoUrl}
                alt="Preview logo"
                className="w-8 h-6 object-contain"
              />
              <h5 className="font-semibold" style={{ color: brandingData?.primaryColor }}>
                {appData?.name}
              </h5>
            </div>
            <p className="text-sm" style={{ color: brandingData?.secondaryColor }}>
              {appData?.description}
            </p>
            <Button
              variant="default"
              className="mt-3"
              style={{ backgroundColor: brandingData?.primaryColor }}
            >
              Sample Button
            </Button>
          </div>
        </div>
      </div>
      {/* Save Actions */}
      <div className="flex items-center justify-between pt-6 border-t border-border">
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <Icon name="Clock" size={16} />
          <span>Auto-saved 2 minutes ago</span>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline">
            Reset to Default
          </Button>
          <Button
            variant="default"
            onClick={handleSaveSettings}
            iconName="Save"
            iconPosition="left"
          >
            Save Changes
          </Button>
        </div>
      </div>
    </div>
  );
};

export default GeneralSettings;